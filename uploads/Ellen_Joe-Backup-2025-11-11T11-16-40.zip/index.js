import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion
} from '@whiskeysockets/baileys';

import qr from 'qrcode-terminal';
import pino from 'pino';
import path from 'path';
import fs from 'fs/promises';
import * as fsSync from 'fs'; // <-- Tambahkan impor fs sinkron
import { fileURLToPath } from 'url';

// Menyiapkan __dirname untuk konteks ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Import Config dan Handler Lokal
import log from './lib/logger.js';
import cfg from './config/config.json' assert { type: 'json' };
let Msg = await import('./handlers/messageHandler.js'); // Menggunakan dynamic import untuk memungkinkan reload

const sessionFolder = path.join(__dirname, 'session');
const dbPath = path.join(__dirname, 'database/users.json');

// Pastikan file users.json ada dan tidak kosong saat startup
async function checkDatabase() {
  try {
    await fs.access(dbPath);
    const fileContent = (await fs.readFile(dbPath, 'utf8')).trim();
    if (fileContent.length === 0) {
      await fs.writeFile(dbPath, JSON.stringify({}));
    }
  } catch (error) {
    if (error.code === 'ENOENT') {
      await fs.writeFile(dbPath, JSON.stringify({}));
    } else {
      throw error;
    }
  }
}

let isReady = false;

async function Start() {
  await checkDatabase();

  try {
    await fs.access(sessionFolder);
  } catch (error) {
    if (error.code === 'ENOENT') {
      await fs.mkdir(sessionFolder, { recursive: true });
    }
  }
  
  const { state, saveCreds } = await useMultiFileAuthState(sessionFolder);
  const { version, isLatest } = await fetchLatestBaileysVersion();

  log.info(`Baileys v${version.join('.')}, latest: ${isLatest}`);

  const sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: true,
    syncFullHistory: false,
    patch: ['status']
  });

  sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr: code }) => {
    if (code) {
      log.info('🔐 Scan QR berikut untuk login WhatsApp:');
      qr.generate(code, { small: true });
    }

    if (connection === 'open') {
      isReady = true;
      log.ok('✅ Bot WhatsApp aktif dan online!');

      const ownerJid = cfg.owner + '@s.whatsapp.net';
      try {
        await sock.sendMessage(ownerJid, {
          text: '✅ Bot berhasil online dan koneksi tersambung!'
        });
        log.ok('📩 Notifikasi online berhasil dikirim ke owner.');
      } catch (err) {
        log.err('❌ Gagal kirim notifikasi owner: ' + err.message);
      }
    }

    if (connection === 'close') {
      isReady = false;
      const reason = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.message || 'Unknown';
      log.warn(`❌ Koneksi tertutup. Alasan: ${reason}`);
      if (reason !== DisconnectReason.loggedOut) {
        log.info('🔁 Mencoba sambung ulang...');
        Start();
      } else {
        log.err('🚪 Logged out. Hapus folder session dan scan ulang.');
      }
    }
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('messages.upsert', async ({ messages }) => {
    if (!isReady || !messages || !messages[0]?.message) return;

    try {
      // Panggil fungsi default dari modul yang diimpor
      await Msg.default(sock, messages[0]);
    } catch (err) {
      log.err(`❌ Plugin error: ${err.message}`);
      if (cfg.owner) {
        const sender = messages[0].key.participant || messages[0].key.remoteJid;
        sock.sendMessage(cfg.owner + '@s.whatsapp.net', {
          text: `❌ Plugin Error:\nNomor: ${sender}\nPesan: ${(messages[0].message?.conversation || messages[0].message?.extendedTextMessage?.text || '-').slice(0, 100)}\nError: ${err.stack || err.message}`
        });
      }
    }
  });

  // ✅ Plugin reload otomatis (Perbaikan menggunakan fsSync)
  fsSync.watch(path.join(__dirname, 'plugins'), (evt, filename) => {
    if (filename && filename.endsWith('.js')) {
      log.info(`[PLUGIN] Perubahan terdeteksi: ${filename}`);
      try {
        const timestamp = Date.now();
        // Menggunakan path relatif
        import(`./handlers/messageHandler.js?v=${timestamp}`).then(reloadedMsg => {
            Msg = reloadedMsg;
            log.ok('[PLUGIN] Handler plugin dimuat ulang ✅');
        }).catch(e => {
            log.err('[PLUGIN] Gagal reload dynamic import:', e.message);
        });

      } catch (e) {
        log.err('[PLUGIN] Gagal reload:', e.message);
      }
    }
  });

  process.on('unhandledRejection', e => log.err('UNHANDLED: ' + e));
  process.on('uncaughtException', e => log.err('UNCAUGHT: ' + e));
}

Start();
