import axios from 'axios';
import { URL } from 'url';

// Endpoint API yang digunakan
const THREADS_API = 'https://api.ryzumi.vip/api/downloader/threads';

/**
 * Mengambil data postingan Threads dan mengembalikan respons media URLs.
 * @param {string} url URL Threads.
 * @returns {Promise<object>} Objek berisi array image_urls dan video_urls.
 */
async function threadDownloader(url) {
  const apiUrl = `${THREADS_API}?url=${encodeURIComponent(url)}`;

  const response = await axios.get(apiUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
  });
  
  const data = response.data;

  // Cek jika API mengembalikan respons error atau tidak ada media
  if (!data || (data.image_urls?.length === 0 && data.video_urls?.length === 0)) {
    throw new Error("Gagal mengambil data dari Threads. Pastikan URL valid dan postingan memiliki media.");
  }
  
  return data;
}


/**
 * Handler utama untuk Threads Downloader, mengirim media langsung ke chat.
 */
const handler = async ({ sock, msg, from, command, args }) => {
    
    const text = args.join(' ').trim();
    
    // --- Validasi Input ---

    if (!text) {
        return sock.sendMessage(from, { text: `Masukkan link Threads!\n\nContoh:\n*.${command} https://www.threads.net/@user/post/XXX*` }, { quoted: msg });
    }

    if (!text.includes('threads.net') && !text.includes('threads.com')) {
        return sock.sendMessage(from, { text: '❌ URL tidak valid atau bukan link Threads.' }, { quoted: msg });
    }

    try {
        await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

        const data = await threadDownloader(text);
        const mediaUrls = [...data.image_urls, ...data.video_urls];
        
        if (mediaUrls.length === 0) {
            await sock.sendMessage(from, { text: "Tidak ada media yang dapat diunduh dari postingan ini." }, { quoted: msg });
            return await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
        }
            
        // --- Loop dan Kirim Media ---

        for (let url of mediaUrls) {
            // Gunakan URL class untuk parsing yang lebih andal
            const mediaUrl = new URL(url);
            const pathName = mediaUrl.pathname;
            
            // Cek apakah ekstensi adalah video (.mp4, dll.)
            const isVideo = pathName.endsWith('.mp4') || pathName.includes('video');

            // Kirim media
            if (isVideo) {
                await sock.sendMessage(from, { 
                    video: { url: url },
                    caption: 'Video Threads'
                }, { quoted: msg });
            } else {
                await sock.sendMessage(from, { 
                    image: { url: url },
                    caption: 'Gambar Threads'
                }, { quoted: msg });
            }
        }
        
        // Reaksi '✅' sebagai indikator sukses
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (e) {
        console.error('[THREADS DL ERROR]', e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        await sock.sendMessage(from, { text: `❌ Gagal memproses Threads: ${e.message}` }, { quoted: msg });
    }
};

export default {
    command: ["threads", "thrd", "th"],
    description: 'Download media (gambar/video) dari postingan Threads.',
    // PERBAIKAN UTAMA: Menggunakan huruf kecil 'downloader'
    category: 'downloader', 
    handler,
};