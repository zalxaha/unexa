import fs from 'fs/promises';
import path from 'path';
import axios from 'axios';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import cfg from '../config/config.json' assert { type: 'json' };

function formatUptime(seconds) {
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    
    const parts = [];
    if (d > 0) parts.push(`${d} hari`);
    if (h > 0) parts.push(`${h} jam`);
    if (m > 0) parts.push(`${m} menit`);
    if (s > 0 || parts.length === 0) parts.push(`${s} detik`);
    
    return parts.join(', ');
}

const userDataFile = path.join(__dirname, '../data/userData.json');
let userData = {};

async function loadUserData() {
  try {
    await fs.access(userDataFile);
    const content = await fs.readFile(userDataFile, 'utf8');
    userData = JSON.parse(content);
  } catch (e) {
    if (e.code === 'ENOENT') {
      await fs.mkdir(path.dirname(userDataFile), { recursive: true });
      await fs.writeFile(userDataFile, JSON.stringify({}, null, 2), 'utf8');
      userData = {};
    } else if (e instanceof SyntaxError) {
      console.warn(`[WARN] userData.json korup, diinisialisasi ulang: ${e.message}`);
      userData = {};
    } else {
      console.error(`[ERROR] Gagal memuat userData: ${e.message}`);
    }
  }
}

await loadUserData();

async function saveUserData() {
    await fs.writeFile(userDataFile, JSON.stringify(userData, null, 2), 'utf8');
}


export default {
  command: ['menu', 'help'],
  description: 'Menampilkan daftar command',
  category: 'info',
  handler: async ({ sock, msg, args, from, pushName }) => {
    
    // --- TAMBAH REAKSI WAKTU (⏳) UNTUK TANDA MERESPON ---
    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    // Tentukan apakah menu lengkap (.menu all) harus ditampilkan
    const showAllCommands = args[0]?.toLowerCase() === 'all'; 

    const pluginDir = path.join(__dirname);
    const files = (await fs.readdir(pluginDir)).filter(f => f.endsWith('.js') && f !== 'menu.js');
    const commands = [];

    for (const file of files) {
      try {
        const absolutePath = path.join(pluginDir, file);
        const modulePath = new URL(`file://${absolutePath}`).href;
        
        const plModule = await import(modulePath);
        const pl = plModule.default; 
        
        const allCmds = Array.isArray(pl.command) ? pl.command : [pl.command];
        
        // --- LOGIKA FILTER UTAMA VS LENGKAP ---
        const cmdsToList = showAllCommands ? allCmds : [allCmds[0]]; // Ambil semua atau hanya command pertama
        
        for (const cmd of cmdsToList) {
            if (!cmd) continue; // Pastikan command tidak null/undefined
            
            commands.push({
                command: cmd, 
                category: pl.category || 'Umum' 
            });
        }
        // --- AKHIR LOGIKA FILTER ---
        
      } catch (e) {
         console.error(`Gagal memuat plugin ${file}: ${e.message}`);
      }
    }

    userData[from] = { lastSeen: new Date().toISOString() };
    await saveUserData();

    const ownerId = `${cfg.owner}@s.whatsapp.net`;
    
    const uptimeSeconds = process.uptime();
    const uptimeFormatted = formatUptime(uptimeSeconds);
    
    let teks = `*${cfg.botName}*\n\n`;
    teks += `Creator: @${cfg.owner}\n`;
    teks += `Powered by: ${cfg.menuLink}\n`;
    teks += `Runtime: *${uptimeFormatted}*\n`; 
    teks += `Fitur: *${commands.length}*\n`;
    teks += `Prefix: *${cfg.prefix}*\n\n`;

    teks += `Halo *${pushName}*, berikut daftar command:\n\n`;

    const grouped = {};
    const commandSet = new Set(); // Set untuk menghindari duplikat (misalnya jika dua plugin punya command yang sama)
    
    for (const cmd of commands) {
      
      // Mengelompokkan Kategori: Paksa lowercase untuk pengelompokan yang seragam
      const categoryRaw = (cmd.category || 'Umum').toLowerCase(); 
      // Format display kategori: Huruf kapital di awal (Owner, Downloader, Fun)
      const categoryDisplay = categoryRaw.charAt(0).toUpperCase() + categoryRaw.slice(1);
      
      if (!grouped[categoryRaw]) grouped[categoryRaw] = [];

      const mainCommand = cmd.command; 
      
      let formattedCommand = null;
      
      if (typeof mainCommand === 'string') {
          if (mainCommand && mainCommand.length > 0) {
              formattedCommand = `• ${cfg.prefix}${mainCommand}`;
          }
      } else if (mainCommand instanceof RegExp) {
          const regexStr = mainCommand.toString();
          if (regexStr === '/^(vera|bot)$/i') {
            formattedCommand = '• vera | bot';
          }
      }
      
      if (formattedCommand && !commandSet.has(formattedCommand)) {
          // Simpan command ke dalam grup yang seragam
          grouped[categoryRaw].push({
              commandText: formattedCommand, 
              categoryDisplay: categoryDisplay
          });
          commandSet.add(formattedCommand);
      }
    }
    
    // Menampilkan Output
    for (const [categoryRaw, list] of Object.entries(grouped)) {
        // Ambil nama kategori display yang sudah diformat
        const categoryDisplay = list.length > 0 ? list[0].categoryDisplay : categoryRaw.charAt(0).toUpperCase() + categoryRaw.slice(1);
        
        teks += `📁 *${categoryDisplay}*\n`;
        teks += list.map(item => item.commandText).join('\n') + '\n\n';
    }

    // Tambahkan catatan jika ini adalah menu ringkas
    if (!showAllCommands) {
        teks += `*Note*: Gunakan *.menu all* untuk melihat semua command dan alias.`;
    }

    let thumb;
    try {
      const res = await axios.get(cfg.menuThumbnail, { responseType: 'arraybuffer' });
      thumb = Buffer.from(res.data, 'binary');
    } catch {}
    
    // --- TAMBAH REAKSI CENTANG (✅) UNTUK TANDA SELESAI ---
    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    await sock.sendMessage(from, {
      text: teks,
      mentions: [ownerId],
      contextInfo: {
        mentionedJid: [ownerId],
        externalAdReply: {
          title: '📜 MENU BOT',
          body: cfg.botName,
          mediaType: 1,
          thumbnail: thumb,
          renderLargerThumbnail: true,
          sourceUrl: cfg.menuLink
        }
      }
    }, { quoted: msg });
  }
};