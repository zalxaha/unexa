import fs from 'fs/promises'; 
import fsSync from 'fs'; 
import path from 'path';
import Crypto from 'crypto';
import { tmpdir } from 'os';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { uploadCatbox } from '../lib/uploader.js'; 
import { fileURLToPath } from 'url';
import { generateCertificate } from '../lib/sertifikat.js'; 


// --- [ SETUP PATH & DATABASE ] ---

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const userDataFile = path.join(__dirname, '../data/userData.json');
let userData = {}; 

async function loadUserData() {
  try {
    const content = await fs.readFile(userDataFile, 'utf8');
    userData = JSON.parse(content);
  } catch (e) {
    if (e.code === 'ENOENT') {
        await fs.mkdir(path.dirname(userDataFile), { recursive: true });
        await fs.writeFile(userDataFile, JSON.stringify({}, null, 2), 'utf8');
    }
    userData = {};
  }
}

async function saveUserData() {
    await fs.writeFile(userDataFile, JSON.stringify(userData, null, 2), 'utf8');
}

try {
    await loadUserData(); 
} catch (e) {
    console.error("[WAIFU] Gagal memuat database saat startup:", e);
}


// --- [ KONSTANTA WAKTU COOLDOWN ] ---
const COOLDOWN_LIGHT = 1 * 3600000; // 1 jam
const COOLDOWN_NAUGHTY = 1 * 3600000; // 1 jam
const COOLDOWN_HEAVY = 3 * 3600000; // 3 jam
const COOLDOWN_NEGLECT = 24 * 3600000; // 24 jam 


// --- [ HELPER FUNCTIONS ] ---

function generateFileName(ext = '') {
  return path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}${ext}`);
}

async function downloadMedia(mediaInfo, mimeType) {
    const mediaTypeForDownload = mimeType.includes('image') ? 'image' : 'document';
    let fileExt = '.jpg';

    const filePath = generateFileName(fileExt);
    const stream = await downloadContentFromMessage(mediaInfo, mediaTypeForDownload);
    const chunks = [];
    for await (const chunk of stream) {
        chunks.push(chunk);
    }
    const mediaBuffer = Buffer.concat(chunks);
    await fs.writeFile(filePath, mediaBuffer);
    return filePath;
}

function formatRemainingTime(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    
    let parts = [];
    if (hours > 0) parts.push(`${hours} jam`);
    if (minutes > 0) parts.push(`${minutes} menit`);
    if (seconds > 0 && parts.length < 2) parts.push(`${seconds} detik`);
    
    return parts.length > 0 ? parts.join(' ') : 'sebentar';
}

// --- [ UTILITY WAIFU ] ---

function getWaifuData(userId) {
    if (!userData[userId] || !userData[userId].waifus) {
        return [];
    }
    return userData[userId].waifus; 
}

function getTargetWaifu(userId, args) {
    const waifus = getWaifuData(userId);
    if (waifus.length === 0) return null;

    const targetArg = args[0]?.trim();
    
    const targetNumber = parseInt(targetArg);
    if (!isNaN(targetNumber) && targetNumber >= 1 && targetNumber <= waifus.length) {
        const index = targetNumber - 1; 
        return { wife: waifus[index], wifeIndex: index };
    }

    const nameArgs = isNaN(targetNumber) ? args : args.slice(1);
    const targetName = nameArgs.join(' ').trim().toLowerCase();
    
    if (targetName) {
        const index = waifus.findIndex(w => w.name.toLowerCase().includes(targetName));
        if (index !== -1) {
            return { wife: waifus[index], wifeIndex: index };
        }
    }
    
    return { wife: waifus[0], wifeIndex: 0 };
}

async function checkAndDecreaseAffection(userId) {
    const waifus = userData[userId]?.waifus;
    if (!waifus || waifus.length === 0) return false;

    let changed = false;
    const now = Date.now();

    for (const wife of waifus) {
        const lastInteraction = Math.max(
            wife.lastKiss || 0,
            wife.lastHug || 0,
            wife.lastPatpat || 0,
            wife.lastHeavyInteraction || 0
        );

        if (lastInteraction && (now - lastInteraction) > COOLDOWN_NEGLECT) {
            const oldAffection = wife.affection;
            wife.affection = Math.max(0, wife.affection - 5); 
            
            if (oldAffection !== wife.affection) {
                console.log(`[WAIFU NEGLECT] ${wife.name} (${userId}) affection berkurang dari ${oldAffection} menjadi ${wife.affection}`);
                changed = true;
            }
        }
    }

    if (changed) {
        await saveUserData();
    }
    return changed;
}


// --- [ FUNGSI KHUSUS SERTIFIKAT (Dipanggil saat marry) ] ---

async function generateAndStoreCertificate(sock, remoteJid, msg, newWaifu, pushName, user) {
    let tempImagePath = '';
    
    try {
        const husbandName = pushName; 
        const wifeName = newWaifu.name;
        const marriageDate = newWaifu.dateMarried;
        
        // 1. Panggil fungsi generateCertificate dari file terpisah
        tempImagePath = await generateCertificate(husbandName, wifeName, marriageDate);
        
        // 2. Upload ke Catbox
        const certificateUrl = await uploadCatbox(tempImagePath);

        // 3. Simpan URL di DB 
        newWaifu.marriageCertificateUrl = certificateUrl;
        
        await sock.sendMessage(remoteJid, { 
            image: { url: certificateUrl },
            caption: `📜 Sertifikat Pernikahan untuk *${wifeName}* berhasil dibuat dan disimpan!`,
            mentions: [user] 
        }, { quoted: msg });

    } catch (error) {
        console.error('[CERTIFICATE GENERATION ERROR]', error);
        await sock.sendMessage(remoteJid, { text: `⚠️ Gagal otomatis membuat Sertifikat Pernikahan untuk ${newWaifu.name}. Detail Error: ${error.message}` }, { quoted: msg });
    } finally {
        if (tempImagePath && fsSync.existsSync(tempImagePath)) {
            await fs.unlink(tempImagePath).catch(() => {});
        }
    }
}


// --- [ HANDLER UTAMA ] ---

const handler = async ({ sock, msg, from, args, command, pushName, sender }) => {
    
    try {
        await loadUserData(); 

        const user = sender;
        const remoteJid = from; 

        const mainCommand = command?.toLowerCase(); 
        const subCommand = args[0]?.toLowerCase(); 

        // --- INISIALISASI DATA PENGGUNA ---
        if (!userData[user]) {
            userData[user] = {}; 
        }
        if (!userData[user].waifus) {
            userData[user].waifus = []; 
        }
        if (!userData[user].children) {
            userData[user].children = []; 
        }
        
        await checkAndDecreaseAffection(user);
        
        const waifus = getWaifuData(user);

        // ======================================================
        // Logika Interaksi Ringan: Kiss, Hug, Patpat
        // ======================================================
        const lightInteractionCommands = ['kiss', 'hug', 'patpat'];
        if (lightInteractionCommands.includes(mainCommand) || (mainCommand === 'waifu' && lightInteractionCommands.includes(subCommand))) {
            
            const action = (mainCommand !== 'waifu') ? mainCommand : subCommand;
            const targetArgs = (mainCommand !== 'waifu') ? args : args.slice(1);
            const target = getTargetWaifu(user, targetArgs);

            if (!target) {
                return sock.sendMessage(remoteJid, { text: `Anda belum memiliki waifu! Silahkan menikah dulu.` }, { quoted: msg });
            }
            const { wife, wifeIndex } = target; 
            
            const cooldownTime = COOLDOWN_LIGHT; 
            let lastInteractKey;

            if (action === 'kiss') {
                lastInteractKey = 'lastKiss';
            } else if (action === 'hug') {
                lastInteractKey = 'lastHug';
            } else if (action === 'patpat') {
                lastInteractKey = 'lastPatpat';
            }
            
            const lastInteractTime = wife[lastInteractKey] || 0;
            const affectionGain = 5;

            if (Date.now() - lastInteractTime < cooldownTime) {
                const remaining = (lastInteractTime + cooldownTime) - Date.now();
                return sock.sendMessage(remoteJid, { text: `*${wife.name}* (${wife.affection}/100) masih beristirahat. Anda harus menunggu ${formatRemainingTime(remaining)} lagi untuk interaksi ringan (${action}).` }, { quoted: msg });
            }

            if (wife.isPregnant) {
                 return sock.sendMessage(remoteJid, { text: `*${wife.name}* sedang hamil. Interaksi ringan boleh, tapi jangan terlalu sering!` }, { quoted: msg });
            }
            
            let reactionText;
            let reactionEmoji;
            let affectionChange = affectionGain;

            if (action === 'kiss') {
                reactionEmoji = '😘';
                if (wife.affection < 40) reactionText = `*${wife.name}*: "Ew, apa-apaan itu! Jangan mendadak cium aku, ${pushName}!"`;
                else if (wife.affection < 70) reactionText = `*${wife.name}*: "Ah... terima kasih, Suami. *chuu*."`;
                else reactionText = `*${wife.name}*: "Aku juga mencintaimu! Aku tak akan pernah bosan dicium olehmu. ❤️"`;
            } else if (action === 'hug') {
                 reactionEmoji = '🤗';
                if (wife.affection < 40) reactionText = `*${wife.name}*: "Lepaskan aku! Aku butuh ruang!"`;
                else if (wife.affection < 70) reactionText = `*${wife.name}*: "Pelukan yang hangat... ini cukup membuatku tenang."`;
                else reactionText = `*${wife.name}*: "Aku suka saat kau memelukku seperti ini, Suami. Jangan lepaskan aku."`;
            } else if (action === 'patpat') { 
                 reactionEmoji = '😊';
                if (wife.affection < 40) reactionText = `*${wife.name}*: "Tanganku kotor! Jangan sentuh kepalaku, ${pushName}. (menampar tangan Anda pelan)"`;
                else if (wife.affection < 70) reactionText = `*${wife.name}*: "Pat pat? Hehe, sudah kuduga kau menyayangiku, Suami."`;
                else reactionText = `*${wife.name}*: "Ah, itu membuatku ngantuk. Lebih lembut lagi, Suamiku. 😴"`;
            }
            
            wife.affection = Math.min(100, wife.affection + affectionChange);
            wife[lastInteractKey] = Date.now(); 
            
            userData[user].waifus[wifeIndex] = wife;
            await saveUserData();


            await sock.sendMessage(remoteJid, { react: { text: reactionEmoji, key: msg.key } });
            await sock.sendMessage(remoteJid, { 
                image: { url: wife.url }, 
                caption: `${reactionText}\n\n*Kasih Sayang bertambah +${affectionChange}!* (Saat ini: ${wife.affection}/100)`,
                mentions: [user]
            }, { quoted: msg });
            return;
        }

        // ======================================================
        // Logika Istri Nakal
        // ======================================================
        if (mainCommand === 'istrinakal' || (mainCommand === 'waifu' && subCommand === 'istrinakal')) {
            
             const targetArgs = (mainCommand !== 'waifu') ? args : args.slice(1);
            const target = getTargetWaifu(user, targetArgs);

            if (!target) {
                return sock.sendMessage(remoteJid, { text: `Anda belum memiliki waifu! Silahkan menikah dulu.` }, { quoted: msg });
            }
            const { wife, wifeIndex } = target; 
            
            const cooldownTime = COOLDOWN_NAUGHTY; 
            const lastInteractTime = wife.lastNaughtyInteraction || 0; 
            const affectionGain = 3; 

            if (Date.now() - lastInteractTime < cooldownTime) {
                const remaining = (lastInteractTime + cooldownTime) - Date.now();
                return sock.sendMessage(remoteJid, { text: `*${wife.name}* sedang fokus dengan kegiatannya. Anda harus menunggu ${formatRemainingTime(remaining)} lagi untuk mengganggunya. 🤭` }, { quoted: msg });
            }

            if (wife.isPregnant) {
                 return sock.sendMessage(remoteJid, { text: `*${wife.name}* sedang hamil. Jangan nakal-nakal dulu, kasihan si jabang bayi! 😉` }, { quoted: msg });
            }
            
            const successChance = 0.05 + (wife.affection / 100) * 0.75; 
            const roll = Math.random();
            let resultText;

            wife.lastNaughtyInteraction = Date.now(); 
            wife.affection = Math.min(100, wife.affection + affectionGain);
            
            if (roll < successChance) {
                wife.lastHeavyInteraction = 0; 
                
                resultText = `*${wife.name}*: "Ehehe, *nggak sabar ya* @${user.split('@')[0]}? Aku juga! Malam ini, kita lanjut lagi ya!"\n\n` +
                             `🎉 *Cooldown Senggama di-reset!* Gunakan *.waifu senggama ${wife.name}* sekarang. Kasih Sayang +${affectionGain}.`;
                await sock.sendMessage(remoteJid, { react: { text: '😏', key: msg.key } });
            } else {
                resultText = `*${wife.name}*: "Hmm, nanti malam saja ya, Suami. Aku masih sedikit lelah, lagipula... kau belum cukup nakal hari ini. 😜"\n\n` +
                             `❌ Cooldown Senggama *tetap*. Kasih Sayang +${affectionGain}.`;
                await sock.sendMessage(remoteJid, { react: { text: '🙁', key: msg.key } });
            }
            
            userData[user].waifus[wifeIndex] = wife;
            await saveUserData();

            await sock.sendMessage(remoteJid, { 
                image: { url: wife.url }, 
                caption: resultText,
                mentions: [user]
            }, { quoted: msg });
            return;
        }

        // ===================================
        // 1. COMMAND: MENIKAH / TAMBAH ISTRI
        // ===================================

        if (mainCommand === 'marry' || subCommand === 'marry') { 
            
            const nameArgs = (mainCommand === 'marry') ? args : args.slice(1);
            const newWaifuName = nameArgs.join(' ').trim();
            
            const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
            const quoted = contextInfo?.quotedMessage;
            const mediaMessage = quoted || msg.message;
            
            const mimeType = Object.keys(mediaMessage || {}).find(k => k.endsWith('Message')) || '';

            if (!mimeType.includes('image')) {
                return sock.sendMessage(remoteJid, { text: `❌ Untuk menikah, kirim atau reply dengan *gambar* calon waifu Anda, disertai nama.\nContoh: *.marry Asuna Yuuki*` }, { quoted: msg });
            }

            if (!newWaifuName || newWaifuName.toLowerCase() === 'marry') {
                return sock.sendMessage(remoteJid, { text: `❌ Berikan nama untuk waifu Anda.\nContoh: *.marry Asuna Yuuki*` }, { quoted: msg });
            }
            
            if (waifus.length >= 1) {
                const firstWife = waifus[0];
                if (firstWife.affection < 70) { 
                    return sock.sendMessage(remoteJid, { 
                        text: `💔 *${firstWife.name}* (Istri Pertama) tampak cemburu. Anda harus meningkatkan kasih sayangnya di atas 70 (Saat ini: ${firstWife.affection}) sebelum bisa menikah lagi.` 
                    }, { quoted: msg });
                }
                await sock.sendMessage(remoteJid, { text: `💍 Istri pertama (*${firstWife.name}*) setuju! Memproses pernikahan kedua...` }, { quoted: msg });
            }
            
            await sock.sendMessage(remoteJid, { react: { text: '⏳', key: msg.key } });

            let mediaPath = '';
            let waifuUrl = '';
            let newWaifu = {};

            try {
                mediaPath = await downloadMedia(mediaMessage[mimeType], mimeType);
                waifuUrl = await uploadCatbox(mediaPath);

                newWaifu = {
                    id: Crypto.randomBytes(4).toString('hex'),
                    name: newWaifuName,
                    url: waifuUrl,
                    dateMarried: new Date().toISOString().split('T')[0],
                    affection: 50, 
                    status: 'Married',
                    childrenCount: 0,
                    lastKiss: 0, 
                    lastHug: 0,
                    lastPatpat: 0,
                    lastNaughtyInteraction: 0,
                    lastHeavyInteraction: 0, 
                    isPregnant: false,  
                    dueDate: null,
                    marriageCertificateUrl: null // Akan diisi oleh fungsi generate
                };

                userData[user].waifus.push(newWaifu);
                
                const role = waifus.length === 0 ? 'Istri Pertama' : 'Istri Berikutnya';
                
                const caption = `🎉 Selamat, @${user.split('@')[0]}! Anda berhasil menikahi *${newWaifuName}*.\n\n` +
                                `Status: ${role}\n` +
                                `Kasih Sayang Awal: ${newWaifu.affection}\n` +
                                `Sekarang Anda memiliki ${userData[user].waifus.length} Waifu.\n\n` +
                                `*Membuat Sertifikat Pernikahan Otomatis...* 📜`;

                await sock.sendMessage(remoteJid, { 
                    image: { url: waifuUrl }, 
                    caption: caption,
                    mentions: [user] 
                }, { quoted: msg });
                
                // --- LANGSUNG GENERATE SERTIFIKAT ---
                // Simpan data di DB sebelum generate untuk memastikan wifeIndex benar
                await saveUserData(); 
                // Karena kita menggunakan newWaifu dari array, kita harus ambil lagi indexnya
                const currentWifeIndex = userData[user].waifus.length - 1;
                await generateAndStoreCertificate(sock, remoteJid, msg, userData[user].waifus[currentWifeIndex], pushName, user);
                // -------------------------------------
                
                // Save sudah dilakukan di dalam generateAndStoreCertificate, tapi panggil lagi untuk jaga-jaga
                await saveUserData(); 
                await sock.sendMessage(remoteJid, { react: { text: '✅', key: msg.key } });

            } catch (e) {
                console.error('[MARRY INTERNAL ERROR]', e);
                await sock.sendMessage(remoteJid, { react: { text: '❌', key: msg.key } });
                sock.sendMessage(remoteJid, { text: `❌ Gagal memproses pernikahan: ${e.message}` }, { quoted: msg });
            } finally {
                if (mediaPath && fsSync.existsSync(mediaPath)) {
                    await fs.unlink(mediaPath).catch(() => {});
                }
            }
            return;
        }
        
        // ===================================
        // 3. COMMAND: SENGGAMA (Interaksi Berat) 
        // ===================================
        
        if (mainCommand === 'senggama' || subCommand === 'senggama') {
            
            const targetArgs = (mainCommand !== 'waifu') ? args : args.slice(1);
            const target = getTargetWaifu(user, targetArgs);

            if (!target) {
                return sock.sendMessage(remoteJid, { text: `Anda harus menikah dulu! Gunakan *.senggama [Nomor/Nama]*` }, { quoted: msg });
            }
            const { wife, wifeIndex } = target; 
            
            const cooldownTime = COOLDOWN_HEAVY; 
            const lastHeavyInteract = wife.lastHeavyInteraction || 0;
            const affectionGain = 10;

            if (Date.now() - lastHeavyInteract < cooldownTime) {
                const remaining = (lastHeavyInteract + cooldownTime) - Date.now();
                return sock.sendMessage(remoteJid, { text: `*${wife.name}* (${wife.affection}/100) masih kelelahan. Anda harus menunggu ${formatRemainingTime(remaining)} lagi.` }, { quoted: msg });
            }

            if (wife.isPregnant) {
                return sock.sendMessage(remoteJid, { text: `*${wife.name}* sedang hamil. Anda tidak bisa berinteraksi dengannya saat ini.` }, { quoted: msg });
            }
            
            let responses = [
                `*${wife.name}*: "Ahh... enak banget, @${user.split('@')[0]}!"`,
                `*${wife.name}*: "Terima kasih atas malam yang indah ini, Suamiku. 💖"`,
                `*${wife.name}*: "Aku tidak akan pernah melupakan malam ini. *ngos-ngosan*"`,
                `*${wife.name}*: "Kau luar biasa, @${user.split('@')[0]}. Aku mencintaimu."`
            ];
            
            const randomResponse = responses[Math.floor(Math.random() * responses.length)];
            
            wife.lastHeavyInteraction = Date.now(); 
            wife.affection = Math.min(100, wife.affection + affectionGain);
            
            await sock.sendMessage(remoteJid, { react: { text: '💦', key: msg.key } });

            let resultText = `${randomResponse}\n\n*Kasih Sayang bertambah +${affectionGain}.* (Saat ini: ${wife.affection}/100)`;

            let roll = Math.random();
            if (wife.affection > 60 && roll < 0.30) {
                wife.isPregnant = true;
                wife.dueDate = Date.now() + (3 * 3600000); 
                resultText += `\n\n*Eits!* Ada kejutan! Sepertinya *${wife.name}* sekarang hamil! Perkiraan melahirkan dalam 3 jam. 🤰`;
            } else {
                resultText += `\n\nNamun sepertinya belum ada tanda-tanda kehamilan. Coba lagi nanti!`;
            }
            
            userData[user].waifus[wifeIndex] = wife;
            await saveUserData();
            
            return sock.sendMessage(remoteJid, { 
                text: resultText,
                mentions: [user] 
            }, { quoted: msg });
        }


        // ===================================
        // 4. COMMAND: MELAHIRKAN
        // ===================================

        if (mainCommand === 'birth' || subCommand === 'birth') {
            
            const targetArgs = (mainCommand !== 'waifu') ? args : args.slice(1);
            const target = getTargetWaifu(user, targetArgs);

            if (!target) {
                return sock.sendMessage(remoteJid, { text: `Anda belum menikah.` }, { quoted: msg });
            }
            const { wife, wifeIndex } = target;

            if (!wife.isPregnant) {
                return sock.sendMessage(remoteJid, { text: `*${wife.name}* tidak sedang hamil.` }, { quoted: msg });
            }

            if (Date.now() < wife.dueDate) {
                const remaining = wife.dueDate - Date.now();
                return sock.sendMessage(remoteJid, { text: `Belum waktunya melahirkan. Tunggu ${formatRemainingTime(remaining)} lagi.` }, { quoted: msg });
            }

            const childName = `Anak ${pushName} ke-${userData[user].children.length + 1}`;
            const isMale = Math.random() > 0.5;
            
            const newChild = {
                name: childName,
                gender: isMale ? 'Laki-laki' : 'Perempuan',
                age: 0,
                mother: wife.name,
                birthDate: new Date().toISOString().split('T')[0]
            };

            userData[user].children.push(newChild);
            wife.childrenCount++;
            wife.isPregnant = false;
            wife.dueDate = null;
            
            wife.lastHeavyInteraction = Date.now(); 
            
            userData[user].waifus[wifeIndex] = wife;
            await saveUserData();

            await sock.sendMessage(remoteJid, { react: { text: '👶', key: msg.key } });
            return sock.sendMessage(remoteJid, {
                text: `🎉 *SELAMAT*! *${wife.name}* telah melahirkan ${isMale ? 'seorang putra' : 'seorang putri'} bernama *${childName}*!`
            }, { quoted: msg });
        }


        // ===================================
        // 5. COMMAND: STATUS
        // ===================================
        
        if (mainCommand === 'waifustatus' || subCommand === 'status') {
            const totalChildren = userData[user]?.children?.length || 0;
            
            let statusText = `*WAIFU SIMULATOR STATUS*\n\n`;
            statusText += `Suami: @${user.split('@')[0]}\n`;
            statusText += `Total Waifu: ${waifus.length}\n`;
            statusText += `Total Anak: ${totalChildren}\n\n`;
            
            let firstWaifuImage = null;

            waifus.forEach((w, index) => {
                if (index === 0) firstWaifuImage = w.url;
                
                statusText += `💍 *Istri ke-${index + 1}: ${w.name}*\n`;
                statusText += `   - Kasih Sayang: ${w.affection} / 100\n`;
                statusText += `   - Anak Bersama: ${w.childrenCount}\n`;
                
                if (w.isPregnant) {
                    if (Date.now() > w.dueDate) {
                        statusText += `   - Kehamilan: *Siap Melahirkan!* (Gunakan *.waifu birth ${index + 1}*)\n`;
                    } else {
                        const remaining = w.dueDate - Date.now();
                        statusText += `   - Kehamilan: Hamil (Melahirkan dalam ${formatRemainingTime(remaining)})\n`;
                    }
                } else {
                    statusText += `   - Kehamilan: Tidak Hamil\n`;
                }
                
                if (w.marriageCertificateUrl) {
                     statusText += `   - Sertifikat: ✅ Tersimpan (Cek *.marriageid show ${index + 1}*)\n`;
                } else {
                    statusText += `   - Sertifikat: ❌ Belum dibuat (Akan dibuat saat menikah)\n`;
                }
                
                const lastInteraction = Math.max(
                    w.lastKiss || 0,
                    w.lastHug || 0,
                    w.lastPatpat || 0,
                    w.lastHeavyInteraction || 0,
                    w.lastNaughtyInteraction || 0
                );
                
                if (lastInteraction && (Date.now() - lastInteraction) > COOLDOWN_NEGLECT && w.affection > 5) {
                     statusText += `   ⚠️: Lupa interaksi! Kasih sayang bisa berkurang.\n`;
                }

                statusText += `--------------------------\n`;
            });
            
            if (waifus.length === 0) {
                statusText += `Anda belum menikah. Gunakan *.marry [Nama]* untuk memulai!`;
            }

            if (firstWaifuImage) {
                 await sock.sendMessage(remoteJid, { 
                    image: { url: firstWaifuImage }, 
                    caption: statusText,
                    mentions: [user] 
                }, { quoted: msg });
            } else {
                await sock.sendMessage(remoteJid, { 
                    text: statusText, 
                    mentions: [user] 
                }, { quoted: msg });
            }
            return;
        }

        // ===================================
        // 6. DEFAULT HELP MESSAGE (.waifu)
        // ===================================
        
        if (mainCommand === 'waifu' && !subCommand) {
            let help = `*WAIFU SIMULATOR COMMANDS*\n\n`;
            help += `Gunakan perintah ini untuk berinteraksi dengan waifu Anda.\n\n`;
            help += `*NOTE*: Untuk memilih waifu, gunakan *Nomor Urut (1, 2, dst.)* atau *Nama* di belakang perintah. (Contoh: *.kiss 2* atau *.senggama Asuna*)\n\n`;
            
            help += `*I. Interaksi Ringan (CD 1 Jam, +5 Affection per aksi)*:\n`;
            help += `*.waifu kiss [No/Nama]* : Memberi ciuman.\n`;
            help += `*.waifu hug [No/Nama]* : Memberi pelukan.\n`;
            help += `*.waifu patpat [No/Nama]* : Mengelus kepala/pundak.\n`;
            help += `*.istrinakal [No/Nama]* : Colek manja (CD 1 Jam). Ada peluang me-reset CD senggama.\n\n`;
            
            help += `*II. Interaksi Berat:*\n`;
            help += `*.waifu senggama [No/Nama]*: Mencoba hamil (CD 3 Jam, +10 Affection).\n`;
            help += `*.waifu birth [No/Nama]*: Melahirkan anak (jika sudah waktunya).\n\n`;

            help += `*III. Lain-lain:*\n`;
            help += `*.marry [Nama]*: Menikahi waifu baru (Reply gambar) & *Sertifikat Langsung Dibuat*.\n`;
            help += `*.marriageid [subcommand]*: Kelola Kartu ID Pernikahan (Gunakan *.marriageid* untuk bantuan).\n`;
            help += `*.waifu status*: Cek status keluarga dan gambar waifu utama.\n`;
            
            await sock.sendMessage(remoteJid, { text: help }, { quoted: msg });
            return;
        }

    } catch (e) {
        console.error('[WAIFU HANDLER ERROR]', e);
        await sock.sendMessage(from, { 
            text: `❌ Terjadi error internal pada plugin Waifu.\n\n${e.message}` 
        }, { quoted: msg });
    }
};

export default {
    command: ['waifu', 'marry', 'kiss', 'hug', 'patpat', 'senggama', 'birth', 'waifustatus', 'istrinakal'],
    description: 'Game simulasi menikahi waifu, punya anak, dan poligami.',
    category: 'fun',
    handler,
};
