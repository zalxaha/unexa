import axios from 'axios';
import { tmpdir } from 'os'; 
import fs from 'fs'; 
import path from 'path';

const API_URL = 'https://api.siputzx.my.id/api/d/igdl';

const instaTiktokDownloader = async (inputUrl) => {
  const apiUrl = `${API_URL}?url=${encodeURIComponent(inputUrl)}`;

  try {
    const res = await axios.get(apiUrl);
    const { status, data } = res.data;

    if (status !== true || !data || data.length === 0) {
      throw new Error(`Gagal mengambil data dari API. Status: ${status}`);
    }

    const links = data.map(item => item.url).filter(url => url);

    if (links.length === 0) {
      throw new Error('Tautan media tidak ditemukan di hasil API.');
    }

    return links;

  } catch (e) {
    const errorMessage = e.response?.data?.message || e.message || e;
    throw new Error(`Gagal mengambil media: ${errorMessage}`);
  }
};

const handler = async ({ sock, msg, args, from }) => { 
  const sender = msg.key.participant || msg.key.remoteJid;
  const url = args[0];
  
  const senderNumber = sender.split('@')[0];

  if (!url || !url.includes('instagram.com')) {
    return sock.sendMessage(from, {
      text: '📌 Masukkan URL Instagram!\nContoh: *.ig https://www.instagram.com/reel/...*'
    }, { quoted: msg });
  }
  
  await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

  try {
    const mediaUrls = await instaTiktokDownloader(url);

    if (!mediaUrls || mediaUrls.length === 0) {
      throw new Error('Media tidak ditemukan atau link rusak.');
    }

    for (let i = 0; i < mediaUrls.length; i++) {
      const fileUrl = mediaUrls[i];
      const isVideo = fileUrl.includes('.mp4');

      const tempPath = path.join(tmpdir(), `igdl-${Date.now()}-${i}.${isVideo ? 'mp4' : 'jpg'}`);
      const writer = fs.createWriteStream(tempPath);

      const response = await axios({
        method: 'GET',
        url: fileUrl,
        responseType: 'stream'
      });

      response.data.pipe(writer);

      await new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
      });
      
      const captionText = i === 0 ? `Ini kak media ke-${i+1} @${senderNumber}` : `Media ke-${i+1}`;

      await sock.sendMessage(from, {
        [isVideo ? 'video' : 'image']: { url: tempPath },
        caption: captionText,
        mentions: i === 0 ? [sender] : undefined 
      }, { quoted: msg });

      fs.unlinkSync(tempPath);
    }

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
  } catch (e) {
    console.error('[IG DL ERROR]', e);
    return sock.sendMessage(from, {
      text: `❌ Gagal mengambil media.\n${e.message}`
    }, { quoted: msg });
  }
};

export default {
  command: ['ig', 'instagram', 'igdl'],
  description: 'Download media dari Instagram menggunakan API.',
  category: 'Downloader',
  handler,
};
