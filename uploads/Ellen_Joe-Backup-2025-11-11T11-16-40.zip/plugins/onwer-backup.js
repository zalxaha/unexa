import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import os from 'os';
import archiver from 'archiver';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import cfg from '../config/config.json' assert { type: 'json' };

const PROJECT_ROOT = path.join(__dirname, '..');

const handler = async ({ sock, msg, args, from }) => {
    const sender = msg.key.participant || msg.key.remoteJid;
    
    const authorizedJids = [
        `${cfg.owner}@s.whatsapp.net`,
        ...(cfg.ownerAltJids || [])
    ];
    
    if (!authorizedJids.includes(sender)) {
        return sock.sendMessage(from, { text: "Akses ditolak. Perintah ini hanya untuk Owner." }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '📦', key: msg.key } });

    const date = new Date().toISOString().replace(/:/g, '-').replace(/\..+/, '');
    const zipName = `${cfg.botName.replace(/\s/g, '_')}-Backup-${date}.zip`;
    const outputPath = path.join(os.tmpdir(), zipName);
    const output = fs.createWriteStream(outputPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    let success = false;
    let fileCreated = false;

    const archivePromise = new Promise((resolve, reject) => {
        output.on('close', resolve);
        archive.on('error', reject);
    });

    try {
        archive.pipe(output);
        fileCreated = true;

        archive.glob('**/*', {
            cwd: PROJECT_ROOT,
            ignore: [
                '**/node_modules/**',
                '**/.npm/**',
                '**/.git/**',
                '**/sessions/**',
                zipName,
                '*.zip',
                '*.log',
            ],
            dot: true
        });

        const credsPath = path.join(PROJECT_ROOT, 'sessions/creds.json');
        try {
            await fsp.access(credsPath);
            archive.file(credsPath, { name: 'sessions/creds.json' });
        } catch (e) {
            console.warn("creds.json tidak ditemukan, melanjutkan tanpa file ini.");
        }

        await archive.finalize();
        await archivePromise;
        success = true;

        await sock.sendMessage(from, { react: { text: '💾', key: msg.key } });

        await sock.sendMessage(from, {
            document: { url: outputPath },
            fileName: zipName,
            mimetype: 'application/zip',
            caption: `✅ Backup bot *${cfg.botName}* berhasil dibuat.`,
        }, { quoted: msg });

    } catch (e) {
        console.error('[ARCHIVER ERROR]', e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        return sock.sendMessage(from, {
            text: `❌ Gagal membuat arsip backup.\nDetail: ${e.message}`
        }, { quoted: msg });
    } finally {
        if (fileCreated) {
            try {
                // Hapus file ZIP dari direktori sementara setelah dikirim/gagal
                await fsp.unlink(outputPath);
                console.log(`[CLEANUP] File ${zipName} dihapus dari direktori sementara.`);
            } catch (e) {
                console.error(`Gagal menghapus file sementara ${outputPath}:`, e);
            }
        }
    }
};

export default {
    command: ['backup', 'arsip'],
    description: 'Membuat backup seluruh proyek bot (Owner Only)',
    category: 'owner',
    handler,
};