import axios from 'axios';
import { tmpdir } from 'os'; 
import fs from 'fs'; 
import path from 'path';

// --- API Baru ---
const API_URL = 'https://api.siputzx.my.id/api/d/twitter';

/**
 * Mengunduh media dari X (Twitter) menggunakan API siputzx.
 * @param {string} inputUrl - URL media X/Twitter.
 * @returns {Promise<{videoTitle: string, videoDescription: string, downloadLink: string}>} Data media.
 */
const xDownloader = async (inputUrl) => {
  const apiUrl = `${API_URL}?url=${encodeURIComponent(inputUrl)}`;

  try {
    const res = await axios.get(apiUrl);
    const { status, data } = res.data;

    if (status !== true || !data || !data.downloadLink) {
      const errorMessage = res.data?.message || `Status: ${status}. Gagal mengambil link unduhan.`;
      throw new Error(errorMessage);
    }

    return data;

  } catch (e) {
    const errorMessage = e.response?.data?.message || e.message || e;
    throw new Error(`Gagal mengambil media: ${errorMessage}`);
  }
};

const handler = async ({ sock, msg, args, from }) => { 
  const sender = msg.key.participant || msg.key.remoteJid;
  const url = args[0];
  const senderNumber = sender.split('@')[0];

  if (!url || !url.includes('x.com') && !url.includes('twitter.com')) {
    return sock.sendMessage(from, {
      text: '📌 Masukkan URL X (Twitter) yang valid!\nContoh: *.x https://x.com/user/status/1234567890*'
    }, { quoted: msg });
  }
  
  await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

  try {
    const result = await xDownloader(url);
    const { downloadLink, videoTitle, videoDescription } = result;
    
    // Asumsi: API ini hanya mengembalikan video, jadi ekstensi adalah mp4
    const isVideo = true; 
    const fileExtension = 'mp4';

    const tempPath = path.join(tmpdir(), `x-dl-${Date.now()}.${fileExtension}`);
    const writer = fs.createWriteStream(tempPath);

    const response = await axios({
      method: 'GET',
      url: downloadLink,
      responseType: 'stream'
    });

    response.data.pipe(writer);

    await new Promise((resolve, reject) => {
      writer.on('finish', resolve);
      writer.on('error', reject);
    });
    
    let captionText = `Ini kak videonya untuk @${senderNumber}\n\n`;
    captionText += `*Judul:* ${videoTitle || 'N/A'}\n`;
    if (videoDescription) {
        captionText += `*Deskripsi:*\n${videoDescription}`;
    }

    await sock.sendMessage(from, {
      [isVideo ? 'video' : 'image']: { url: tempPath },
      caption: captionText,
      mentions: [sender]
    }, { quoted: msg });

    fs.unlinkSync(tempPath);

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
  } catch (e) {
    console.error('[X DL ERROR]', e);
    return sock.sendMessage(from, {
      text: `❌ Gagal mengunduh media dari X (Twitter).\nDetail: ${e.message}`
    }, { quoted: msg });
  }
};

export default {
  command: ['x', 'twitter', 'xdl'],
  description: 'Download media dari X/Twitter menggunakan API.',
  category: 'Downloader',
  handler,
};
