import fs from 'fs';
import path from 'path';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { writeExifImg, writeExifVid } from '../lib/exif.js';

import cfg from '../config/config.json' assert { type: 'json' }; 

const handler = async ({ sock, msg, from, pushName }) => {
    
    const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
    const quoted = contextInfo?.quotedMessage;
    
    const mediaMessage = quoted || msg.message;
    
    const mimeType = Object.keys(mediaMessage || {}).find(k => k.endsWith('Message')) || '';

    if (!mimeType.includes('image') && !mimeType.includes('video')) {
      return sock.sendMessage(from, {
        text: '❌ Kirim atau reply gambar/video (maks 5 detik) dengan perintah *.stiker*'
      }, { quoted: msg })
    }

    const mediaInfo = mediaMessage[mimeType];
    
    const type = mimeType.includes('image') ? 'image' : 'video';

    const stickerMetadata = {
        pack: cfg.botName || 'Vera Quin Bot', 
        author: 'https://zalxzhu.my.id', 
    }

    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } })

    let mediaBuffer;
    let resultPath = '';

    try {
      const stream = await downloadContentFromMessage(mediaInfo, type);
      
      const chunks = [];
      for await (const chunk of stream) {
          chunks.push(chunk);
      }
      mediaBuffer = Buffer.concat(chunks);

    } catch (e) {
      console.error('[STICKER DL ERROR]', e)
      await sock.sendMessage(from, { react: { text: '❌', key: msg.key } })
      return sock.sendMessage(from, {
        text: `❌ Gagal mengunduh media. Coba lagi dengan media yang baru saja dikirim.`
      }, { quoted: msg })
    }

    try {
      resultPath = type === 'image'
        ? await writeExifImg(mediaBuffer, stickerMetadata)
        : await writeExifVid(mediaBuffer, stickerMetadata)

      const finalBuffer = fs.readFileSync(resultPath)

      await sock.sendMessage(from, {
        sticker: finalBuffer
      }, { quoted: msg })

      await sock.sendMessage(from, { react: { text: '✅', key: msg.key } })

    } catch (e) {
      console.error('[STICKER CONV ERROR]', e)
      await sock.sendMessage(from, { react: { text: '❌', key: msg.key } })
      sock.sendMessage(from, {
        text: '❌ Gagal membuat stiker. Pastikan *FFmpeg* terinstal dan PATH-nya sudah benar di \'lib/exif.js\'.'
      }, { quoted: msg })
    } finally {
        if (resultPath && fs.existsSync(resultPath)) {
            fs.unlinkSync(resultPath);
        }
    }
}

export default {
    command: ['stiker', 'sticker', 's'],
    description: 'Buat stiker dari gambar atau video (maks 5 detik)',
    category: 'Media',
    handler,
};