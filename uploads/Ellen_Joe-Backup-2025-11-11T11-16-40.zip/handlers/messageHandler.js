import fs from 'fs/promises'; 
import path from 'path';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { fileURLToPath } from 'url';
import { createRequire } from 'module'; 

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url);

import log from '../lib/logger.js';
import cfg from '../config/config.json' assert { type: 'json' };

const dbPath = path.join(__dirname, '../database/users.json');
let sockGlobal = null;

async function readDatabase() {
  let db = {};
  try {
    const fileContent = await fs.readFile(dbPath, 'utf8');
    const trimmedContent = fileContent.trim();
    if (trimmedContent.length > 0) {
      db = JSON.parse(trimmedContent);
    } else {
      log.warn('⚠️ [DB] users.json kosong, diinisialisasi sebagai objek kosong.');
    }
  } catch (error) {
    if (error.code === 'ENOENT') {
      await fs.writeFile(dbPath, JSON.stringify({}));
    } else {
      log.err(`❌ [DB] Gagal membaca/mengurai database: ${error.message}. Menggunakan objek kosong.`);
    }
    db = {};
  }
  return db;
}

const parseQuoted = (m, sock) => {
  const q = m.message?.extendedTextMessage?.contextInfo;
  if (!q?.quotedMessage) return;
  const quoted = q.quotedMessage;
  const mtype = Object.keys(quoted)[0];
  const msg = quoted[mtype];
  m.quoted = {
    type: mtype,
    mtype,
    id: q.stanzaId,
    sender: q.participant,
    fromMe: q.participant === sock.user.id,
    isBaileys: !!q.isForwarded,
    text: msg?.text || msg?.caption || '',
    message: quoted,
    download: async () => {
      const stream = await downloadContentFromMessage(quoted[mtype], mtype.replace('Message', ''));
      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }
      return buffer;
    }
  };
};

function mapJid(incomingJid, db, ownerJid, ownerAltJids) {
  if (incomingJid === ownerJid || (ownerAltJids && ownerAltJids.includes(incomingJid))) {
    return ownerJid;
  }
  
  for (const realJid in db) {
    if (db[realJid].altJids && db[realJid].altJids.includes(incomingJid)) {
      log.info(`✅ Mapped JID ${incomingJid} to actual JID ${realJid}`);
      return realJid;
    }
  }

  return incomingJid;
}

async function Msg(sock, m) {
  try {
    sockGlobal = sock;
    if (!m || !m.message) return;

    const now = Date.now();
    const { key, message, pushName } = m;
    const remoteJid = key.remoteJid;
    
    const isGroup = remoteJid.endsWith('@g.us');
    let incomingJid = isGroup ? key.participant : remoteJid;
    m.isGroup = isGroup;

    // JID yang awalnya digunakan (sebelum di-mapping)
    const originalIncomingJid = incomingJid;

    // ==========================================================
    // --- PERBAIKAN LOGIKA: Mapping LID ke PN untuk Group Chat ---
    // Jika dari grup DAN JID aslinya LID, gunakan participantPn.
    // ==========================================================
    if (isGroup && key.participantPn && /@lid$/.test(key.participant)) {
        // incomingJid akan menjadi JID nomor telepon (@s.whatsapp.net)
        incomingJid = key.participantPn; 
        log.info(`🔧 JID Group di-mapping dari LID ${key.participant} ke PN ${incomingJid}`);
    }
    // ==========================================================

    const msgTypes = {
      conversation: () => message.conversation,
      imageMessage: () => message.imageMessage.caption || '',
      videoMessage: () => message.videoMessage.caption || '',
      extendedTextMessage: () => message.extendedTextMessage.text,
      buttonsResponseMessage: () => message.buttonsResponseMessage.selectedButtonId,
      listResponseMessage: () => message.listResponseMessage.singleSelectReply.selectedRowId,
      templateButtonReplyMessage: () => message.templateButtonReplyMessage.selectedId
    };
    const msgType = Object.keys(message || {})[0];
    const body = (msgTypes[msgType] ? msgTypes[msgType]() : '') || '';

    if (!body.startsWith(cfg.prefix)) return;
    const args = body.slice(cfg.prefix.length).trim().split(/ +/);
    if (!args[0]) return;
    const cmd = args.shift().toLowerCase();

    let db = await readDatabase();

    const ownerConfigJid = cfg.owner + '@s.whatsapp.net';
    
    // Gunakan mapJid untuk mencari JID utama (senderJid)
    const senderJid = mapJid(incomingJid, db, ownerConfigJid, cfg.ownerAltJids);
    m.sender = senderJid;

    // 1. Cek apakah JID (yang sudah dimapping ke PN jika dari grup) perlu dibuat entri baru
    const existingJidKey = Object.keys(db).find(key => key === incomingJid || (db[key].altJids && db[key].altJids.includes(incomingJid)));
    
    // JID yang kita gunakan sebagai kunci database utama (PN atau LID jika chat pribadi)
    const primaryJidToUse = (senderJid !== incomingJid && senderJid) ? senderJid : incomingJid;


    if (!existingJidKey) {
        // Buat entri baru jika JID yang dimapping (PN atau LID baru) belum ada di DB
        db[primaryJidToUse] = {
            nama: null,
            registered: false,
            lastReset: now,
            status: 'guest',
            altJids: []
        };
        m.sender = primaryJidToUse;
        log.info(`➕ JID baru dibuat: ${primaryJidToUse}`);
    } 

    // 2. Logika untuk menyimpan JID lama/alternatif ke altJids JID utama
    const finalSenderJid = m.sender || primaryJidToUse;
    
    // Kasus 1: incomingJid adalah JID alt (misal, LID lama)
    if (incomingJid !== finalSenderJid) {
        if (!db[finalSenderJid].altJids.includes(incomingJid)) {
            db[finalSenderJid].altJids.push(incomingJid);
            log.info(`🔗 JID alt ${incomingJid} ditambahkan ke ${finalSenderJid}`);
        }
    }
    
    // Kasus 2: originalIncomingJid (JID grup LID) perlu disimpan jika berbeda dari incomingJid (PN)
    if (originalIncomingJid !== incomingJid && /@lid$/.test(originalIncomingJid)) {
        if (!db[finalSenderJid].altJids.includes(originalIncomingJid)) {
             db[finalSenderJid].altJids.push(originalIncomingJid);
             log.info(`🔗 JID alt LID ${originalIncomingJid} ditambahkan ke ${finalSenderJid}`);
        }
    }
    
    // Tulis ke file hanya jika ada perubahan yang dibuat di atas
    await fs.writeFile(dbPath, JSON.stringify(db, null, 2));

    const userDbEntry = db[finalSenderJid];
    m.sender = finalSenderJid;

    // Cek status premium
    if (userDbEntry?.premiumUntil && now > userDbEntry.premiumUntil) {
      userDbEntry.premiumUntil = 0;
      userDbEntry.status = userDbEntry.registered ? 'user' : 'guest';
      await fs.writeFile(dbPath, JSON.stringify(db, null, 2));
    }

    const isOwner = m.sender === ownerConfigJid;
    const isUserRegistered = !!userDbEntry?.registered;
    const isPremium = userDbEntry?.premiumUntil && now < userDbEntry.premiumUntil;
    
    parseQuoted(m, sock);

    m.reply = async (text, opt = {}) => {
      return sock.sendMessage(remoteJid, { text, ...opt }, { quoted: m });
    };

    const pluginDir = path.join(__dirname, '../plugins');
    const pluginFiles = (await fs.readdir(pluginDir)).filter(f => f.endsWith('.js')); 

    let found = false;
    for (const file of pluginFiles) {
      try {
        const timestamp = Date.now();
        const plugin = await import(`../plugins/${file}?v=${timestamp}`);
        
        const commands = Array.isArray(plugin.default.command) ? plugin.default.command : [plugin.default.command];
        
        if (commands.includes(cmd)) {
          found = true;
          log.evt(`Cmd '${cmd}' dari ${m.sender} (${isOwner ? 'owner' : isPremium ? 'premium' : isUserRegistered ? 'user' : 'guest'})`);
          
          return await plugin.default.handler({ 
            sock,
            msg: m,
            args,
            command: cmd,
            from: remoteJid,
            pushName,
            isOwner,
            isPremium,
            isUserRegistered,
            db,
            sender: m.sender
          });
        }
        
      } catch (e) {
        log.err(`❌ Plugin '${file}' error: ${e.message}`);
        await sock.sendMessage(cfg.owner + '@s.whatsapp.net', {
          text: `🚨 Plugin '${file}' error:\n${e.stack || e.message}`
        });
      }
    }

    if (!found) {
      log.warn(`⚠️ Command '${cmd}' tidak ditemukan.`);
    }

  } catch (e) {
    log.err(`❌ Msg() fatal error: ${e.stack || e.message}`);
  }
}

export default Msg;