/** !! THIS CODE GENERATE BY ALLY !! **/

/** !! THIS CODE GENERATE BY ALLY !! **/

const fs = require("fs");
const path = require("path");
const { fromBuffer } = require("file-type");
const uploader = require("../lib/uploader");

const MAX_SIZE = 200 * 1024 * 1024; // 200MB
const EXT_MAP = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/gif": "gif",
  "image/webp": "webp",
  "video/mp4": "mp4",
  "video/webm": "webm",
};

let handler = async (m, { usedPrefix, command, conn }) => {
  let q = m.quoted ? m.quoted : m;
  if (!q) throw `Kirim atau reply media (foto/video) dengan perintah *${usedPrefix + command}*`;

  let mime = (q.msg || q).mimetype || "";
  if (!/image|video|webp/.test(mime)) {
    return m.reply("Media tidak didukung. Hanya gambar atau video yang bisa diupload ke Catbox.");
  }

  try {
    // Reaksi jam saat mulai proses
    if (m.react) await m.react("⏳");

    let media = await q.download();
    if (!media) throw new Error("Gagal mengunduh media.");

    if (media.length > MAX_SIZE) {
      throw new Error("Ukuran file melebihi 200MB, tidak bisa diupload ke Catbox.");
    }

    let { ext } = (await fromBuffer(media)) || {};
    if (!ext) ext = EXT_MAP[mime]; // fallback ke mimetype map

    if (!ext) {
      throw new Error("Tidak bisa menentukan format file.");
    }

    const filePath = path.join(__dirname, "../tmp", `${Date.now()}.${ext}`);
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(filePath, media);

    const url = await uploader.uploadCatbox(filePath);
    fs.unlinkSync(filePath);

    // Reaksi centang selesai
    if (m.react) await m.react("✅");

    return m.reply(`*乂 U P L O A D  -  C A T B O X*\n◦ Type : ${mime}\n◦ Ext : .${ext}\n◦ Url : ${url}`);
  } catch (err) {
    console.error("Catbox upload error:", err);
    
    // Reaksi silang jika gagal
    if (m.react) await m.react("❌");

    return m.reply("Gagal upload ke Catbox: " + err.message);
  }
};

handler.help = ["tourl", "upload"].map(v => v + " *[reply/send foto/video]*");
handler.tags = ["tools"];
handler.command = ["tourl", "upload"];

module.exports = handler;