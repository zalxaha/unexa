/** !! THIS CODE GENERATE BY ALLY !! **/

const axios = require("axios");

let zhu = async (m, { conn, text }) => {
  try {
    if (!text) return m.reply("Masukkan URL tweet!\nContoh: .sstweet https://twitter.com/user/status/1234567890");

    const imgbuff = await SsPost(text);
    await conn.sendFile(m.chat, imgbuff, "sstweet.png", "✅ Done", m);
  } catch (err) {
    m.reply(`❌ ${err.message || err}`);
  }
};

zhu.help = ["sstweet <url>"];
zhu.tags = ["tools"];
zhu.command = ["sstweet"];

module.exports = zhu;

async function SsPost(tweetUrl) {
  try {
    const match = tweetUrl.match(/status\/(\d+)/);
    if (!match) throw new Error("Masukkan link tweet yang benar!");

    const tweetId = match[1];
    const payload = {
      templateSlug: "tweet-image",
      modifications: { tweetUrl, tweetId },
      renderType: "images",
      responseFormat: "png",
      responseType: "base64",
      userAPIKey: false
    };

    const { data } = await axios.post(
      "https://orshot.com/api/templates/make-playground-request",
      JSON.stringify(payload),
      {
        headers: {
          "Content-Type": "text/plain; charset=UTF-8",
          "Origin": "https://orshot.com",
          "Referer": "https://orshot.com/templates/tweet-image/generate",
          "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) Chrome/107.0.0.0 Safari/537.36",
          "Accept": "*/*"
        }
      }
    );

    if (!data?.data?.content) throw new Error("Gagal mendapatkan gambar dari tweet!");

    const base64Data = data.data.content.replace(/^data:image\/png;base64,/, "");
    return Buffer.from(base64Data, "base64");
  } catch (err) {
    throw new Error(err.message);
  }
}