/** !! THIS CODE GENERATE BY ALLY !! **/

/** !! THIS CODE GENERATE BY ALLY – QUEUE UPLOAD VERSION !! **/

const { fromBuffer } = require("file-type");
const { Octokit } = require("@octokit/rest");
const sanitize = require("sanitize-filename");

const MAX_SIZE = 75 * 1024 * 1024; // 75MB
const EXT_MAP = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/gif": "gif",
  "image/webp": "webp",
  "video/mp4": "mp4",
  "video/webm": "webm",
};

// GitHub config
const GH_TOKEN = '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';
const GH_OWNER = 'zalxaha';
const GH_REPO = 'my-photo-drive';
const BRANCH = 'main';
const octokit = new Octokit({ auth: GH_TOKEN });

const GALLERY_URL = 'https://gng-gangsal-galeries.vercel.app/';
const ALLOWED_GROUP_ID = "120363288705815761@g.us";

// ==================== ✅ UPLOAD QUEUE ====================
const uploadQueue = [];
let uploading = false;

async function processQueue() {
  if (uploading || uploadQueue.length === 0) return;
  uploading = true;

  const task = uploadQueue.shift();
  try {
    await task(); // jalankan upload
  } catch (e) {
    console.error("[UPLOAD QUEUE ERROR]", e);
  }

  uploading = false;
  // lanjutkan proses berikutnya
  setTimeout(processQueue, 500);
}

// ==================== ✅ MAIN HANDLER ====================
let handler = async (m, { conn, usedPrefix, command }) => {
  if (!m.isGroup) throw "Perintah ini hanya bisa digunakan di grup.";
  if (m.chat !== ALLOWED_GROUP_ID) throw "Grup ini tidak diizinkan mengakses perintah upload.";

  const q = m.quoted || m;
  const mime = (q.msg || q).mimetype || "";
  if (!/image|video/.test(mime)) {
    return m.reply("Hanya gambar atau video yang bisa diupload.");
  }

  if (m.react) await m.react("⏳");

  const media = await q.download();
  if (!media) return m.reply("Gagal mengunduh media.");

  if (media.length > MAX_SIZE) {
    return m.reply("❌ Ukuran file melebihi batas 75MB.");
  }

  const { ext } = (await fromBuffer(media)) || {};
  const finalExt = ext || EXT_MAP[mime];
  if (!finalExt) return m.reply("Tidak bisa menentukan format file.");

  const fileName = `${Date.now()}-${sanitize(`media.${finalExt}`)}`;
  const base64 = Buffer.from(media).toString("base64");

  await m.reply(`📥 File diterima. Sedang masuk antrean upload...`);
  if (m.react) await m.react("📤");

  // push ke antrean
  uploadQueue.push(async () => {
    const start = Date.now();

    console.log(`[QUEUE] Mulai upload: ${fileName}`);

    await octokit.repos.createOrUpdateFileContents({
      owner: GH_OWNER,
      repo: GH_REPO,
      path: `uploads/${fileName}`,
      message: `upload ${fileName}`,
      content: base64,
      branch: BRANCH,
      committer: { name: 'Upload Bot', email: 'bot@example.com' }
    });

    const fileUrl = `https://raw.githubusercontent.com/${GH_OWNER}/${GH_REPO}/${BRANCH}/uploads/${fileName}`;
    const elapsed = (Date.now() - start) / 1000;

    await conn.sendMessage(m.chat, {
      document: Buffer.from(base64, "base64"),
      fileName,
      mimetype: mime,
      caption: `*乂 U P L O A D  -  G A L E R I*\n◦ Type : ${mime}\n◦ Ext : .${finalExt}\n◦ Url : ${fileUrl}\n\n🌐 *GALERI:* ${GALLERY_URL}`
    }, { quoted: m });

    console.log(`[QUEUE] Selesai upload ${fileName} (${elapsed}s)`);
  });

  processQueue(); // jalankan antrean
};

handler.help = ["togaleri", "upload", "up", "gangsal"].map(v => v + " *[reply/send foto/video]*");
handler.tags = ["tools"];
handler.command = ["togaleri", "upload", "up", "gangsal"];
handler.group = true;

module.exports = handler;