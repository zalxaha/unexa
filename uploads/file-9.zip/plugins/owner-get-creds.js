/** !! THIS CODE GENERATE BY ALLY !! **/

const fs = require('fs');
const path = require('path');

let rodotz = async (m, { conn, text, usedPrefix, command }) => {
  // Path ke file creds.json
  const credsFilePath = path.join(__dirname, '..', 'Ally-Sessions', 'creds.json');
  const fileName = 'creds.json';

  try {
    // Memeriksa apakah file ada
    if (!fs.existsSync(credsFilePath)) {
      return conn.sendMessage(m.chat, { text: `File **${fileName}** tidak ditemukan di direktori **Ally-Sessions**.` }, { quoted: m });
    }

    // Mengirim file creds.json
    await conn.sendMessage(m.chat, {
      document: fs.readFileSync(credsFilePath),
      mimetype: 'application/json',
      fileName: fileName,
    }, { quoted: m });

  } catch (error) {
    console.error("Gagal mengirim file creds.json:", error);
    await conn.sendMessage(m.chat, { text: `Gagal mengirim file **${fileName}**. Error: ${error.message}` }, { quoted: m });
  }
}

rodotz.help = ["ambilcredsfile"]
rodotz.tags = ["owner"]
rodotz.command = ["getcreds"]
rodotz.rowner = true;
module.exports = rodotz;