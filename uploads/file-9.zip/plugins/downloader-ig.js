/** !! THIS CODE GENERATE BY ALLY !! **/

const axios = require('axios');
const cheerio = require('cheerio');
const fetch = require('node-fetch');
const { tmpdir } = require("os");
const { join } = require("path");
const { writeFileSync } = require("fs");

const SITE_URL = 'https://instatiktok.com/';

async function instaTiktokDownloader(platform, inputUrl) {
  if (!inputUrl) throw 'masukin link yg bener!';
  if (!['instagram', 'tiktok', 'facebook'].includes(platform)) throw 'platform ga didukung.';

  const form = new URLSearchParams();
  form.append('url', inputUrl);
  form.append('platform', platform);
  form.append('siteurl', SITE_URL);

  try {
    const res = await axios.post(`${SITE_URL}api`, form.toString(), {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Origin': SITE_URL,
        'Referer': SITE_URL,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        'X-Requested-With': 'XMLHttpRequest'
      }
    });

    const html = res?.data?.html;
    if (!html || res?.data?.status !== 'success') throw 'Gagal ambil data';

    const $ = cheerio.load(html);
    const links = [];

    $('a.btn[href^="http"]').each((_, el) => {
      const link = $(el).attr('href');
      if (link && !links.includes(link)) links.push(link);
    });

    if (links.length === 0) throw 'Link tidak ditemukan';

    let download;
    if (platform === 'instagram') {
      download = links;
    } else if (platform === 'tiktok') {
      download = links.find(link => /hdplay/.test(link)) || links[0];
    } else if (platform === 'facebook') {
      download = links.at(-1);
    }

    return {
      status: true,
      platform,
      download
    };

  } catch (e) {
    throw `Gagal ambil data: ${e.message || e}`;
  }
}

let handler = async (m, { conn, usedPrefix, command, text }) => {
  if (!text) return m.reply(`• *Contoh:* ${usedPrefix + command} https://www.instagram.com/reel/...`);

  const isIG = /instagram\.com/.test(text);
  const isTT = /tiktok\.com/.test(text);
  const isFB = /facebook\.com|fb\.watch/.test(text);
  const platform = isIG ? 'instagram' : isTT ? 'tiktok' : isFB ? 'facebook' : null;

  if (!platform) return m.reply(`• *URL tidak valid.* Harus dari Instagram, TikTok, atau Facebook yaa~`);

  m.reply('⏳ Tunggu ya sayang, aku lagi ambil media buat kamu...');

  try {
    const result = await instaTiktokDownloader(platform, text);

    if (!result?.download) return m.reply("*Gagal ambil media, coba lagi nanti yaa.*");

    const urls = Array.isArray(result.download) ? result.download : [result.download];

    for (let i = 0; i < urls.length; i++) {
      const mediaUrl = urls[i];
      const mediaRes = await fetch(mediaUrl);
      const buffer = await mediaRes.buffer();
      const ext = mediaUrl.includes(".mp4") ? ".mp4" : ".jpg";
      const filename = join(tmpdir(), `${platform}_${Date.now()}_${i}${ext}`);

      writeFileSync(filename, buffer);
      await conn.sendFile(m.chat, filename, `download${ext}`, i === 0 ? `*乂 ${platform.toUpperCase()} DOWNLOADER*\n\n📎 URL: ${text}` : "", m);
    }

  } catch (err) {
    console.error(err);
    return m.reply("*Ups, terjadi kesalahan saat ambil media. Link-nya mungkin invalid atau server-nya lagi error 💔*");
  }
};

handler.help = ["ig", "tiktok", "fb", "instagram", "facebook", "igdl", "ttdl"].map(v => v + " *<url>*");
handler.tags = ["downloader"];
handler.command = ["ig", "tiktok", "fb", "instagram", "facebook", "igdl", "ttdl"];
module.exports = handler;