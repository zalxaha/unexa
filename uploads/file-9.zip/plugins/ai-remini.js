/** !! THIS CODE GENERATE BY ALLY !! **/

/** !! THIS CODE FIXED BY ALLY !! **/

const fs = require("fs");
const path = require("path");
const { fromBuffer } = require("file-type");
const uploader = require("../lib/uploader");

const MAX_SIZE = 200 * 1024 * 1024;

let handler = async (m, { conn, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime) throw `Balas gambar dengan perintah *${usedPrefix + command}*`;
  if (!/image\/(jpe?g|png)/.test(mime)) throw `_*Jenis file ${mime} tidak didukung!*_`;

  try {
    if (m.react) await m.react("⏳");

    let media = await q.download();
    if (!media) throw new Error("Gagal mengunduh gambar.");

    if (media.length > MAX_SIZE) throw new Error("Ukuran gambar terlalu besar.");

    // Deteksi ekstensi
    let { ext } = (await fromBuffer(media)) || {};
    ext = ext || "jpg";
    const filePath = path.join(__dirname, "../tmp", `${Date.now()}.${ext}`);
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(filePath, media);

    // Upload ke Catbox
    const url = await uploader.uploadCatbox(filePath);
    fs.unlinkSync(filePath);

    // Proses Remini API
    const response = await fetch("https://api.ryzumi.vip/api/ai/remini?url=" + url);
    if (!response.ok) throw new Error("Gagal dari API Remini.");

    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    await conn.sendFile(m.chat, buffer, "remini.jpg", "", m);
    if (m.react) await m.react("✅");

  } catch (e) {
    if (m.react) await m.react("❌");
    console.error(e);
    m.reply("Gagal proses gambar: " + e.message);
  }
};

handler.help = ["remini", "hd", "hdr"].map(cmd => `${cmd} *[balas gambar]*`);
handler.tags = ["tools", "ai"];
handler.command = /^(remini|hd|hdr)$/i;
handler.limit = true;

module.exports = handler;