/** !! THIS CODE GENERATE BY ALLY !! **/

/** !! THIS CODE GENERATE BY ALLY !! **/

const yts = require("yt-search");
const axios = require("axios");

const handler = async (m, {
    conn,
    command,
    text,
    usedPrefix
}) => {
    if (!text) throw `*• Example :* ${usedPrefix + command} *[query/url]*`;

    let txt = Func.isUrl(text) ? text : (await yts(text)).videos[0].url;

    await conn.sendMessage(m.chat, {
        react: {
            text: '⏳',
            key: m.key
        }
    });

    try {
        let api = await axios.get(`https://api.vreden.my.id/api/ytmp3?url=${txt}`);
        let result = api.data.result.metadata;

        let teks = `🎵 *${result.title}*\n\n⏱️ *Durasi:* ${result.timestamp}\n👀 *Views:* ${result.views}\n📅 *Upload:* ${result.ago}\n🔗 *Link:* ${result.url}`;

        // Kirim caption info biasa tanpa externalAdReply
        await conn.sendMessage(m.chat, { text: teks }, { quoted: m });

        // Kirim audio biasa tanpa iklan
        await conn.sendMessage(m.chat, {
            audio: { url: api.data.result.download.url },
            mimetype: "audio/mpeg",
            fileName: result.title + ".mp3"
        }, { quoted: m });

    } catch (e) {
        m.reply(`Gagal mengambil audio.\n\n${e}`);
    }
};

handler.help = ["ytaudio", "ytmp3", "yta"].map(a => a + ` *[query/url]*`);
handler.tags = ["downloader"];
handler.command = ["ytaudio", "ytmp3", "yta"];

handler.exp = 0;
handler.register = false;
handler.limit = true;

module.exports = handler;