/** !! THIS CODE GENERATE BY ALLY !! **/

const axios = require('axios');

async function threadDownloader(urls) {
  function getThreadIdFromUrl(url) {
    const match = url.match(/\/post\/([a-zA-Z0-9]+)/);
    return match ? match[1] : null;
  }

  const threadId = getThreadIdFromUrl(urls);

  if (!threadId) {
    throw new Error("Thread ID tidak ditemukan dalam URL.");
  }

  const response = await axios.get(
    `https://www.dolphinradar.com/api/threads/post_detail/${threadId}`,
    {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',
        'Accept': 'application/json'
      }
    }
  );
  
  const data = response.data?.data;

  if (!data || !data.post_detail || !data.user) {
    throw new Error("Kasian, data tidak ditemukan 😆");
  }

  const post = data.post_detail;
  const user = data.user;

  const mediaUrls = Array.isArray(post.media_list)
    ? post.media_list.map(media => media.url)
    : [];

  return {
    username: user.username,
    full_name: user.full_name,
    verified: user.verified || user.is_verified,
    profile: user.profile,
    follower: user.follower_count,
    caption: post.caption_text,
    like: post.like_count,
    media_urls: mediaUrls
  };
}

let zhu = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(`Masukkan link Threads!\n\nContoh:\n${usedPrefix + command} https://www.threads.net/@infipop.id/post/DMk2wrVzIoP`);
  }

  try {
    await m.react('⏳'); // kasih reaksi jam

    const data = await threadDownloader(text);

    let info = `👤 *${data.full_name}* (@${data.username})${data.verified ? ' ✅' : ''}\n`;
    info += `👥 Followers: ${data.follower}\n`;
    info += `❤️ Likes: ${data.like}\n\n`;
    info += `📜 Caption:\n${data.caption || '-'}\n`;

    if (data.media_urls.length > 0) {
      let first = true;
      for (let url of data.media_urls) {
        await conn.sendFile(m.chat, url, '', first ? info : '', m);
        first = false;
      }
    } else {
      m.reply("Tidak ada media di postingan ini.");
    }

    await m.react('✅'); // kasih reaksi sukses

  } catch (e) {
    console.error(e);
    await m.react('❌'); // kasih reaksi gagal
    m.reply(`Error: ${e.message}`);
  }
};

zhu.help = ["threads <url>"];
zhu.tags = ["downloader"];
zhu.command = ["threads", "thrd", "th"];

module.exports = zhu;