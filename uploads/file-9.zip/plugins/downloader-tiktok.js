/** !! THIS CODE GENERATE BY ALLY !! **/

/** !! THIS CODE GENERATE BY ALLY !! **/

/** !! THIS CODE GENERATE BY ALLY !! **/

/** !! THIS CODE GENERATE BY ALLY !! **/

let skr = require("chikaa-js")

let fetch = require('node-fetch')

let handler = async (m, { conn, args, text, command, usedPrefix, isCreator, isPrems }) => {
  let url = text || (m.quoted && m.quoted.text)
  if (!url) return m.reply(`*Masukkan Link!*\n\nExample: ${usedPrefix + command} <Tiktok URL>`);
  
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });

  try {

   let cls = new skr()
   let coli = new cls.Scraper()
   let data = await coli.Tiktok.download(text)

        if (data.images !== null) {
            let no = 1;
            for (let i of data.images) {
                await conn.sendMessage(
                    m.chat, {
                        image: {
                            url: i,
                        },
                        caption: data.title,
                        fileName: 'imeg.jpg',
                    }, {
                        quoted: m
                    }
                );
                await Func.delay(1300);
            };
        } else {
            await conn.sendMessage(
                m.chat, {
                    video: {
                        url: data.video,
                    },
                    caption: data.title,
                }, {
                    quoted: m
                },
            );
        };
  } catch (e) {
    console.log(e);
    return m.reply('[ ! ] Maaf terjadi kesalahan');
  }
}

handler.command = handler.help = ['tiktok', 'tt', 'ttnowm', 'ttslide', 'ttphoto', 'tiktokphoto', 'tiktokslide', 'tiktoknowm'];
handler.tags = ['downloader'];
handler.register = false;
handler.limit = true;

module.exports = handler;