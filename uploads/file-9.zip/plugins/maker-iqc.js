/** !! THIS CODE GENERATE BY ALLY !! **/

const fetch = require('node-fetch');

let zhu = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`Example:\n${usedPrefix + command} Biji ayam`);

  const time = new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Jakarta',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  }).format(new Date());

  const url = `https://brat.siputzx.my.id/iphone-quoted?` +
    `time=${encodeURIComponent(time)}` +
    `&batteryPercentage=${Math.floor(Math.random() * 100) + 1}` +
    `&carrierName=INDOSAT` +
    `&messageText=${encodeURIComponent(text)}` +
    `&emojiStyle=apple`;

  await conn.sendMessage(m.chat, {
    image: { url },
    caption: text
  }, { quoted: m });
};

zhu.help = ['iqc <teks>'];
zhu.tags = ['maker'];
zhu.command = ['iqc'];

module.exports = zhu;