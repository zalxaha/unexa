/** !! THIS CODE GENERATE BY ALLY !! **/

let fetch = require('node-fetch')

let handler = async (m, { conn }) => {
  try {
    // Daftar URL dari catbox
    let backgrounds = [
      'https://files.catbox.moe/lzvn7f.jpg',
      'https://files.catbox.moe/jbz6vq.jpg',
      'https://files.catbox.moe/zecxow.jpg',
      'https://files.catbox.moe/hy8vit.jpg',
      'https://files.catbox.moe/ueu4cf.jpg',
      'https://files.catbox.moe/wjzdss.jpg',
      'https://files.catbox.moe/euv9q7.jpg',
      'https://files.catbox.moe/1zewvx.jpg',
      'https://files.catbox.moe/mosf0e.jpg',
      'https://files.catbox.moe/yqrqx4.jpg',
      'https://files.catbox.moe/xfs58i.jpg',
      'https://files.catbox.moe/gzcczm.jpg',
      'https://files.catbox.moe/bp8gnu.jpg',
      'https://files.catbox.moe/o7htw6.jpg',
      'https://files.catbox.moe/f2xyih.jpg',
      'https://files.catbox.moe/e4cz1v.jpg'
    ]

    // Pilih acak
    let bg = backgrounds[Math.floor(Math.random() * backgrounds.length)]

    // Fetch gambar
    let res = await fetch(bg)
    if (!res.ok) throw new Error('Gagal mengunduh gambar.')
    let buffer = await res.buffer()

    // Kirim sebagai stiker
    await conn.sendSticker(m.chat, buffer, m, {
      packname: global.set.packname,
      author: global.set.author
    })

  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal mengirim stiker.')
  }
}

handler.customPrefix = /my (istri|waifu|wife|kisah)|bukankah ini my( waifu| wife| istri| kisah)?|itu (istri|waifu|bini|kisah) (gw|gue)|waifu (gw|gue)|punya(gue|ku|gw)|punyaku|jangan klaim|bukan waifu (lu|lo)|istri ane|bini ane|my girl|my bae|my baby|my love|kisah (gw|gue|ku|ane)|kisah (cinta|asmara) (gw|gue)|eh itu (punya|istri|waifu|kisah) (gw|gue)|punya saya\/i/i
handler.command = new RegExp

module.exports = handler