/** !! THIS CODE GENERATE BY ALLY !! **/

/** !! THIS CODE GENERATE BY ALLY !! **/

/** !! THIS CODE GENERATE BY ALLY !! **/

/** !! THIS CODE GENERATE BY ALLY !! **/

let rodotz = async (m, { conn, text, usedPrefix, command }) => {
if (!text) throw "Halo kak, silahkan mau bertanya apa?"
try {
let res = await fetchJson("https://api.siputzx.my.id/api/ai/meta-llama-33-70B-instruct-turbo?content=" + text)
let { key } = await m.reply(status.wait);
await conn.sendMessage(m.chat, {
      text: res.data,
      edit: key,
    });
} catch(e) {
m.reply("Error")
}
}
rodotz.help = ["llama", "ai"]
rodotz.tags = ["ai"]
rodotz.command = ["llama", "ai"]
module.exports = rodotz