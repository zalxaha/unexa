/** !! THIS CODE GENERATE BY ALLY !! **/

/** !! THIS CODE FIX MULTI-MEDIA FROM IG API !! **/

const axios = require("axios");
const { tmpdir } = require("os");
const { join } = require("path");
const { writeFileSync } = require("fs");
const fetch = require("node-fetch");

let handler = async (m, { conn, usedPrefix, command, text }) => {
  if (!text) return m.reply(`• *Example* : ${usedPrefix + command} *[instagram url]*`);
  if (!text.includes('instagram.com')) return m.reply(`• *Example* : ${usedPrefix + command} *[instagram url]*`);

  m.reply('⏳ Sedang memproses, mohon tunggu...');
  try {
    const apiUrl = `https://api.siputzx.my.id/api/d/igdl?url=${encodeURIComponent(text)}`;
    const res = await axios.get(apiUrl);
    const json = res.data;

    if (!json.status || !Array.isArray(json.data) || json.data.length === 0) {
      return m.reply("*Gagal mengambil media dari Instagram. Coba lagi nanti.*");
    }

    const mediaList = json.data;

    for (let i = 0; i < mediaList.length; i++) {
      const media = mediaList[i];
      const mediaUrl = media.url;
      const ext = mediaUrl.includes(".mp4") ? ".mp4" : ".jpg";
      const fileName = join(tmpdir(), `igdl_${Date.now()}_${i}${ext}`);

      const resMedia = await fetch(mediaUrl);
      const buffer = await resMedia.buffer();
      writeFileSync(fileName, buffer);

      await conn.sendFile(
        m.chat,
        fileName,
        `instagram${ext}`,
        i === 0 ? `*乂 INSTAGRAM DOWNLOADER*\n\n*URL:* ${text}` : "",
        m
      );
    }

  } catch (err) {
    console.error(err);
    return m.reply("*Terjadi kesalahan saat mengunduh. Pastikan URL valid atau coba beberapa saat lagi.*");
  }
};

handler.help = ["ig", "instagram", "igdl"].map(a => a + " *instagram url*");
handler.tags = ["downloader"];
handler.command = ["ig", "instagram", "igdl"];
module.exports = handler;