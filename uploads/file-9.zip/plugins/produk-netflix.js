/** !! THIS CODE GENERATE BY ALLY !! **/

let handler = async (m, { conn }) => {
    conn.sendFile(m.chat, './media/produk-netflix.jpg', '', `murah sih ini mah`, m);
}
handler.help = ['netflix']
handler.tags = ['produk']
handler.command = ['netflix']
module.exports = handler