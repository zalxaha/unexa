/** !! THIS CODE GENERATE BY ALLY !! **/

const axios = require("axios");
const uploadFile = require("../lib/uploadFile.js");
const { Sticker } = require("wa-sticker-formatter");

const cooldown = new Map();

const Amelia = async (m, { conn, text, usedPrefix }) => {
    const user = m.sender;
    const cooldownTime = 30000; // 30 detik
    const maxAttempts = 3;

    const quo = m.quoted ? m.quoted : m;
    const mime = (quo.msg || quo).mimetype || "";

    if (cooldown.has(user)) {
        const lastTime = cooldown.get(user);
        const elapsed = (Date.now() - lastTime) / 1000;

        if (elapsed < cooldownTime / 1000) {
            const attempts = global.db.data.users[user]?.attempts || 0;
            global.db.data.users[user] = {
                ...(global.db.data.users[user] || {}),
                attempts: attempts + 1
            };

            if (global.db.data.users[user].attempts >= maxAttempts) {
                global.db.data.users[user].banned = true;
                return m.reply("[❗] Anda telah dibanned karena spam!");
            }

            return m.reply(`[❗] Tunggu ${Math.ceil(cooldownTime / 1000 - elapsed)} detik sebelum menggunakan perintah ini lagi.\n\n[ note ]\nJika Anda spam fitur ini 3x dalam masa cooldown, maka Anda akan dibanned dari bot!`);
        }
    }

    cooldown.set(user, Date.now());
    if (global.db.data.users[user]?.attempts) global.db.data.users[user].attempts = 0;

    let reply;
    if (text && m.quoted) {
        if (m.quoted.sender) {
            reply = {
                name: await conn.getName(m.quoted.sender),
                text: m.quoted.text || "",
                chatId: m.chat.split("@")[0],
            };
        }
    } else if (text && !m.quoted) {
        reply = {};
    } else if (!text && m.quoted) {
        if (m.quoted.text) text = m.quoted.text || "";
        reply = {};
    } else {
        throw `*• Example:* ${usedPrefix}qc *[text atau reply pesan]*`;
    }

    const img = await quo.download?.();
    const pp = await conn.profilePictureUrl(m.sender, "image").catch(() => "https://telegra.ph/file/320b066dc81928b782c7b.png");

    const obj = {
        type: "quote",
        format: "png",
        backgroundColor: "#fff",
        width: 512,
        height: 768,
        scale: 2,
        messages: [{
            entities: [],
            avatar: true,
            from: {
                id: 1,
                name: await conn.getName(m.sender),
                photo: {
                    url: pp,
                },
            },
            text: text || "",
            replyMessage: reply,
            ...(mime && img ? {
                media: {
                    url: await uploadFile(img),
                },
            } : {}),
        }],
    };

    try {
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        const response = await axios.post('https://btzqc.betabotz.eu.org/generate', obj, {
            headers: { 'Content-Type': 'application/json' }
        });

        const buffer = Buffer.from(response.data.result.image, 'base64');
        const sticker = new Sticker(buffer, {
            pack: global.packname,
            author: global.author,
            type: 'image/png',
        });

        const stikerBuffer = await sticker.toBuffer();
        await conn.sendMessage(m.chat, { sticker: stikerBuffer }, { quoted: m });
    } catch (error) {
        console.error("Error:", error);
        m.reply("Maaf, terjadi kesalahan saat membuat sticker. Coba lagi nanti.");
    }
};

Amelia.help = ["qc *[text or reply message]*"];
Amelia.tags = ["sticker"];
Amelia.command = ["qc"];
Amelia.limit = 5;

module.exports = Amelia;