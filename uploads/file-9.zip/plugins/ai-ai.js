/** !! THIS CODE GENERATE BY ALLY !! **/

/** !! THIS CODE GENERATE BY ALLY !! **/

const axios = require('axios');

const listmodel = [
  'gpt-4.1-nano',
  'gpt-4.1-mini',
  'gpt-4.1',
  'o4-mini',
  'deepseek-r1',
  'deepseek-v3',
  'claude-3.7',
  'gemini-2.0',
  'grok-3-mini',
  'qwen-qwq-32b',
  'gpt-4o',
  'o3',
  'gpt-4o-mini',
  'llama-3.3'
];

async function chatai(q, model, system_prompt) {
  if (!listmodel.includes(model)) {
    return {
      error: `gada model, pakai model ini: ${listmodel.join(', ')}`,
      models: listmodel
    };
  }

  const h = {
    'Content-Type': 'application/json',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',
    'Referer': 'https://ai-interface.anisaofc.my.id/'
  };

  const data = {
    question: q,
    model: model,
    system_prompt: system_prompt
  };

  try {
    const res = await axios.post(
      'https://ai-interface.anisaofc.my.id/api/chat', data, {
        headers: h,
        timeout: 10000
      });
    return res.data;
  } catch (e) {
    throw new Error(e.response?.data?.message || e.message || 'Req ai gagal');
  }
}

let rodotz = async (m, { text }) => {
  if (!text) throw "Halo kak, silahkan mau bertanya apa?";
  try {
    const systemPrompt = "Nama saya Zhu, asisten virtual bot yang siap membantu Anda dengan berbagai pertanyaan dan kebutuhan Anda.";
    const res = await chatai(text, 'gpt-4o', systemPrompt);

    console.log('[ZHU RESPONSE]', res);

    const replyText = res.response || res.answer || res.data || "Maaf, tidak ada jawaban dari AI.";
    await m.reply(replyText);
  } catch (e) {
    await m.reply("Error: " + e.message);
  }
};

rodotz.help = ["ai"];
rodotz.tags = ["ai"];
rodotz.command = ["ai"];
module.exports = rodotz;