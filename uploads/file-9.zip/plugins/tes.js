/** !! THIS CODE GENERATE BY ALLY !! **/

/** !! THIS CODE GENERATE BY RODOTZ X ZHUBOT !! **/
/** !! THIS CODE GENERATE BY ALLY !! **/

const fs = require('fs');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Berikan Pesan yang lebih Spesifik!\n\nExample:\n${usedPrefix + command} netflix|ini caption nya`;

    try {
        let [cmd, cap] = text.split("|");
        cmd = cmd.trim().toLowerCase();
        cap = cap ? cap.trim() : '';

        let quoted = m.quoted ? m.quoted : m;
        let mime = (quoted.mimetype || '');

        if (!mime && !quoted.text) {
            return m.reply(`Kamu harus mereply atau mengirim media (image/video/teks)!`);
        }

        let ext = '';
        let data = '';

        if (/image/.test(mime)) {
            ext = '.jpg';
            data = await quoted.download();
        } else if (/video/.test(mime)) {
            ext = '.mp4';
            data = await quoted.download();
        } else if (quoted.text) {
            ext = '.txt';
            data = quoted.text;
        } else {
            return m.reply(`Media yang didukung hanya *gambar*, *video*, atau *teks*!`);
        }

        let path = `plugins/produk-${cmd}.js`;

        let isMedia = ext !== '.txt';
        let isi = '';

        if (isMedia) {
            let filename = `media/produk-${cmd}${ext}`;
            if (!fs.existsSync('./media')) fs.mkdirSync('./media');
            fs.writeFileSync(filename, data);

            isi = `
let handler = async (m, { conn }) => {
    conn.sendFile(m.chat, './${filename}', '', \`${cap || cmd.toUpperCase()}\`, m);
}
handler.help = ['${cmd}']
handler.tags = ['produk']
handler.command = ['${cmd}']
module.exports = handler
            `.trim();
        } else {
            isi = `
let handler = async (m, { conn }) => {
    m.reply("*${cmd.toUpperCase()}*\\n\\n" + \`${cap || data}\`);
}
handler.help = ['${cmd}']
handler.tags = ['produk']
handler.command = ['${cmd}']
module.exports = handler
            `.trim();
        }

        fs.writeFileSync(path, `/** !! THIS CODE GENERATE BY ALLY !! **/\n\n${isi}`);

        var name = m.sender;
        var fkonn = {
            key: {
                fromMe: false,
                participant: `0@s.whatsapp.net`,
                ...(m.chat ? { remoteJid: '0@s.whatsapp.net' } : {})
            },
            message: {
                contactMessage: {
                    displayName: (await conn.getName(m.sender)) || "Bot",
                    vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;${name};;;\nFN:${name}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
                }
            }
        };

        await conn.reply(m.chat, `✅ Berhasil menyimpan file:\n*${path}*`, fkonn);

    } catch (error) {
        console.log(error);
        m.reply("🐱 Terjadi Error:\n" + error);
    }
};

handler.help = ['addproduk <nama>|<caption>']
handler.tags = ['owner']
handler.command = ['ad', 'addproduk']
handler.owner = true

module.exports = handler;