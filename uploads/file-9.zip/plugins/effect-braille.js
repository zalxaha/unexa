/** !! THIS CODE GENERATE BY ALLY !! **/

let { promises: fs } = require('fs');
let { join } = require('path');
const tmp = join(__dirname, '../tmp');

async function handler(m) {
    let { braillefy } = require('img2braille');
    let q = m.quoted ? m.quoted : m;
    
    if (!/image/.test(q.mimetype) && (!m.message.imageMessage || !/^image/.test(m.message.imageMessage.mimetype))) {
        return m.reply("Please reply/send an image with the command");
    }
     
    let { key } = await m.reply(status.wait);
    
    let media = q.download ? await q.download() : await m.message.imageMessage.download();
    let filename = join(tmp, + new Date + '.png');
    
    await fs.writeFile(filename, media);
    let brailleText = await braillefy(filename, 30, {
        invert: false,
        dither: true
    });
    m.reply(brailleText);
    await fs.unlink(filename);
    
    await conn.sendMessage(m.chat, {
      text: "Done.",
      edit: key,
    });
}

handler.help = handler.command = ['braille'];
handler.tags = ['effect'];
handler.limit = 5;
handler.register = true;

module.exports = handler;