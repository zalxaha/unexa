/** !! THIS CODE GENERATE BY ALLY !! **/

const Jimp = require("jimp");

let zhu = async (m, { conn }) => {
  try {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";
    if (!/image/.test(mime)) return m.reply("Kirim atau reply gambar dengan perintah *burik*");

    let imgBuffer = await q.download();
    let image = await Jimp.read(imgBuffer);

    // Ambil ukuran asli
    let originalWidth = image.bitmap.width;
    let originalHeight = image.bitmap.height;

    // Burik tapi tetap terbaca
    let burikWidth = Math.max(80, Math.floor(originalWidth / 5)); // cukup kecil untuk pecah
    let burikHeight = Math.max(80, Math.floor(originalHeight / 5));

    image
      .resize(burikWidth, burikHeight) // perkecil
      .resize(originalWidth, originalHeight, Jimp.RESIZE_NEAREST_NEIGHBOR) // perbesar lagi dengan kotak-kotak
      .blur(2) // blur tipis biar kayak burik jadul
      .quality(40); // turunin kualitas sedikit

    let burikBuffer = await image.getBufferAsync(Jimp.MIME_JPEG);

    await conn.sendFile(m.chat, burikBuffer, "burik.jpg", "Ini gambar buriknya tuan", m);
  } catch (e) {
    console.error(e);
    m.reply("Gagal membuat gambar burik!");
  }
};

zhu.help = ["burik"];
zhu.tags = ["tools"];
zhu.command = ["burik"];

module.exports = zhu;