/** !! THIS CODE GENERATE BY ALLY !! **/

let handler = async (m, { conn, text }) => {
    let who
    let raw = text.replace(/[^0-9]/g, '') // Ambil hanya angka dari seluruh teks

    // Deteksi & ubah 08xxx → 628xxx
    if (raw.startsWith('08')) raw = '62' + raw.slice(1)

    // Validasi & buat JID
    if (raw.length >= 9) {
        who = raw + '@s.whatsapp.net'
    } else {
        // fallback: jika tidak ada nomor valid, pakai pengirim/mention
        who = m.isGroup
            ? m.mentionedJid && m.mentionedJid[0]
                ? m.mentionedJid[0]
                : m.sender
            : m.sender
    }

    try {
        let url = await conn.profilePictureUrl(who, 'image')
        await conn.sendFile(m.chat, url, 'pp.jpg', `@${who.split('@')[0]}`, m, null, {
            mentions: [who]
        })
    } catch (e) {
        m.reply('❌ Gagal mengambil foto profil. Mungkin nomor tidak punya PP atau tidak terdaftar di WhatsApp.')
    }
}

handler.command = /^(get(pp|profile))$/i
handler.help = ['getpp <@user|nomor>']
handler.tags = ['fun']
handler.limit = true

module.exports = handler