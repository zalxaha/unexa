/** !! THIS CODE GENERATE BY ALLY !! **/

const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { fromBuffer } = require('file-type');

var handler = async (m, { conn, text, command, usedPrefix }) => {
  if (!text) return m.reply(`Masukkan judul lagu.\nContoh: ${usedPrefix + command} faded`);

  await conn.sendMessage(m.chat, { react: { text: '🎧', key: m.key } });

  // Step 1: Pencarian dengan API siputzx
  let result;
  try {
    const res = await axios.get(`https://api.siputzx.my.id/api/s/soundcloud?query=${encodeURIComponent(text)}`);
    result = res.data?.data?.find(x => x.permalink_url?.includes('soundcloud.com') && x.duration);
  } catch (e) {
    console.error(e);
    return m.reply('❌ Gagal mencari lagu.');
  }

  if (!result) return m.reply('❌ Lagu tidak ditemukan.');

  const trackUrl = result.permalink_url;

  // Step 2: Scrape download dari downloadsound.cloud
  let dl;
  try {
    const response = await axios.post(
      'https://api.downloadsound.cloud/track',
      { url: trackUrl },
      {
        headers: {
          'User-Agent': 'Mozilla/5.0',
          'Accept': 'application/json, text/plain, */*',
          'Referer': 'https://downloadsound.cloud/',
          'Origin': 'https://downloadsound.cloud/',
          'Content-Type': 'application/json',
        }
      }
    );

    const data = response.data;
    dl = {
      url: data?.url || null,
      title: data?.title || result.permalink,
      author: data?.author?.username || 'SoundCloud',
      thumbnail: data?.imageURL || result.artwork_url || null
    };
  } catch (error) {
    console.error('❌ SoundCloud Download Error:', error?.response?.status, error?.response?.data || error.message);
    return m.reply('❌ Gagal mengunduh audio.');
  }

  if (!dl || !dl.url) return m.reply('❌ Gagal mendapatkan link audio.');

  const caption = `*S O U N D C L O U D*\n\n🎵 ${dl.title}\n👤 ${dl.author}\n🔗 ${trackUrl}`;

  // Step 3: Kirim thumbnail + caption
  const imgMsg = dl.thumbnail
    ? await conn.sendMessage(m.chat, { image: { url: dl.thumbnail }, caption }, { quoted: m })
    : await conn.sendMessage(m.chat, { text: caption }, { quoted: m });

  // Step 4: Download audio dan kirim sebagai audio + dokumen
  try {
    const audioBuffer = (await axios.get(dl.url, { responseType: 'arraybuffer' })).data;
    const fileType = await fromBuffer(audioBuffer);
    const ext = fileType?.ext || 'mp3';
    const fileName = `${dl.title}.${ext}`;
    const filePath = path.join(__dirname, '../tmp', fileName);

    fs.writeFileSync(filePath, audioBuffer);

    const thumbBuffer = dl.thumbnail ? (await axios.get(dl.thumbnail, { responseType: 'arraybuffer' })).data : null;

    // 🔊 Kirim sebagai audio biasa
    await conn.sendMessage(m.chat, {
      audio: fs.readFileSync(filePath),
      mimetype: 'audio/mpeg',
      ptt: false, // true jika ingin kirim sebagai voice note
      fileName: dl.title
    }, { quoted: imgMsg });

    // 📎 Kirim sebagai dokumen audio
    await conn.sendMessage(m.chat, {
      document: fs.readFileSync(filePath),
      mimetype: 'audio/mpeg',
      fileName,
      jpegThumbnail: thumbBuffer ? Buffer.from(thumbBuffer) : null,
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true
      }
    }, { quoted: imgMsg });

    fs.unlinkSync(filePath); // Hapus file sementara
  } catch (e) {
    console.error(e);
    m.reply('❌ Gagal mengirim audio.');
  }

  await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
};

handler.help = ['splay'].map(v => v + ' <judul>');
handler.tags = ['downloader'];
handler.command = /^splay$/i;
handler.limit = true;
handler.register = true;

module.exports = handler;