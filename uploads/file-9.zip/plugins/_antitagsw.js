/** !! THIS CODE GENERATE BY ALLY !! **/

/*
By Putramodz/Mputz
Don't Delete This Wm:)
My Group: https://chat.whatsapp.com/Gl5ALz9UkSOFHzJFRqdgd2
*/

let Amelia = m => m;

// Menyimpan status fitur Anti Tag Status per grup
global.db = global.db || { data: { chats: {} } };
let warningCount = {}; // Menyimpan jumlah peringatan per pengguna

Amelia.before = async function(m, { isAdmin, isBotAdmin, conn }) {
    if (!m.isGroup) return true;

    global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {};
    let chat = global.db.data.chats[m.chat];

    // Jika fitur tidak aktif, abaikan
    if (!chat.antitagsw) return true;

    // Jika pesan adalah Tag Status
    if (m.mtype === "groupStatusMentionMessage") {
        if (isAdmin) {
            await m.reply('*[ System Detected ]*\n\n> Anda admin grup ini, bebas menggunakan Tag Status.');
            return true;
        }

        let user = m.sender;
        warningCount[user] = (warningCount[user] || 0) + 1;

        if (warningCount[user] >= 3) {
            if (isBotAdmin) {
                await conn.sendMessage(m.chat, { delete: m.key });
                await m.reply(`*[ System Detected ]*\n\n> *@${user.split("@")[0]}* telah mengirim *Tag Status* sebanyak 3 kali!\n\n🚨 *AUTOMATIS DIKELUARKAN DARI GRUP!*`, null, { mentions: [user] });
                await conn.groupParticipantsUpdate(m.chat, [user], "remove");
            } else {
                await m.reply(`*[ System Detected ]*\n\n> *@${user.split("@")[0]}* sudah mencapai batas maksimal pelanggaran (3x), tetapi bot bukan admin, jadi tidak bisa mengeluarkan pengguna.`, null, { mentions: [user] });
            }
            delete warningCount[user]; // Reset hitungan setelah di-kick
        } else {
            if (isBotAdmin) {
                await conn.sendMessage(m.chat, { delete: m.key });
            }
            await m.reply(`*[ System Detected ]*\n\n> *@${user.split("@")[0]}*, dilarang mengirim *Tag Status*!\n🚨 Peringatan ke-${warningCount[user]}/3.\n\n🔴 Jika mencapai 3 kali, Anda akan dikeluarkan dari grup!`, null, { mentions: [user] });
        }
    }
    return true;
};

module.exports = Amelia;