/** !! THIS CODE GENERATE BY ALLY !! **/

/** !! THIS CODE MODIFIED BY CHATGPT !! **/

const yts = require('yt-search');
const axios = require('axios');

var handler = async (m, {
    conn,
    command,
    text,
    usedPrefix
}) => {
    if (!text) return m.reply('Masukkan query seperti\n.play dj kane');

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } }); // ⏳ reaksi jam

    let search = await yts(text);
    let vid = search.videos[0];
    if (!vid) throw 'Video tidak ditemukan, coba judul lain.';
    
    let { title, thumbnail, timestamp, views, ago, url } = vid;
    const { downloadUrl: res } = await ddownr.download(url, 'mp3');
    if (!res) throw 'Gagal mengunduh audio.';

    let captvid = `*Y O U T U B E*\n\n🎵 Judul: ${title}\n⏱️ Durasi: ${timestamp}\n👁️ Views: ${views}\n📅 Upload: ${ago}\n🔗 Link: ${url}`;

    const img = await conn.sendMessage(m.chat, {
        image: { url: thumbnail },
        caption: captvid
    }, { quoted: m });

    // Versi iklan
    await conn.sendMessage(m.chat, {
        audio: { url: res },
        mimetype: 'audio/mpeg',
        fileName: `${title}.mp3`,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                mediaType: 2,
                mediaUrl: url,
                title: title,
                body: '',
                sourceUrl: url,
                thumbnail: await (await conn.getFile(thumbnail)).data
            }
        }
    }, { quoted: img });

    // Versi biasa
    await conn.sendMessage(m.chat, {
        audio: { url: res },
        mimetype: 'audio/mp4', // Versi biasa (non-iklan)
        fileName: `${title}.mp3`
    }, { quoted: img });

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } }); // ✅ reaksi centang
};

handler.help = ['play'].map(v => v + ' <query>');
handler.tags = ['downloader'];
handler.command = /^((yt)?play)$/i;
handler.limit = true;
handler.register = true;

module.exports = handler;

const formatAudio = ['mp3', 'm4a', 'webm', 'acc', 'flac', 'opus', 'ogg', 'wav', '4k'];
const formatVideo = ['360', '480', '720', '1080', '1440'];

const ddownr = {
    download: async (url, format) => {
        try {
            const response = await axios.get(`https://p.oceansaver.in/ajax/download.php?copyright=0&format=${format}&url=${url}`, {
                headers: {
                    'User-Agent': 'MyApp/1.0',
                    'Referer': 'https://ddownr.com/enW7/youtube-video-downloader'
                }
            });

            const data = response.data;
            const media = await ddownr.cekProgress(data.id);
            return {
                success: true,
                format: format,
                title: data.title,
                thumbnail: data.info.image,
                downloadUrl: media
            };
        } catch (error) {
            console.error("Error:", error.response ? error.response.data : error.message);
            return { success: false, message: error.message };
        }
    },
    cekProgress: async (id) => {
        try {
            const progressResponse = await axios.get(`https://p.oceansaver.in/ajax/progress.php?id=${id}`, {
                headers: {
                    'User-Agent': 'MyApp/1.0',
                    'Referer': 'https://ddownr.com/enW7/youtube-video-downloader'
                }
            });

            const data = progressResponse.data;

            if (data.progress === 1000) {
                return data.download_url;
            } else {
                console.log('⏳ Tunggu sebentar, sedang proses...');
                await new Promise(resolve => setTimeout(resolve, 1000));
                return ddownr.cekProgress(id);
            }
        } catch (error) {
            console.error("Error:", error.response ? error.response.data : error.message);
            return { success: false, message: error.message };
        }
    }
};