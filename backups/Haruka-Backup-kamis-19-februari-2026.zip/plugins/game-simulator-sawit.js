export default {
    command: ['sawit', 'sawitsimulator'],
    category: 'Game',
    description: 'Simulasi Juragan Sawit dengan sistem Mitra, Mandiri, dan Leveling XP',

    handler: async ({ sock, msg, args, db, sender, saveDatabase, reply, pushName }) => {
        const user = db[sender];
        
        const COOLDOWN_CMD = 10000; 

        if (user.lastSawitCmd && (Date.now() - user.lastSawitCmd) < COOLDOWN_CMD) {
            const sisaWaktu = Math.ceil((user.lastSawitCmd + COOLDOWN_CMD - Date.now()) / 1000);
            // Hapus return reply(...) jika ingin bot diam saja saat di-spam (silent mode)
            return reply(`⏳ Tunggu ${sisaWaktu} detik sebelum menggunakan perintah ini lagi.`);
        }
        
        // Update waktu terakhir penggunaan command
        user.lastSawitCmd = Date.now();
        // ==========================================


        const subCmd = args[0]?.toLowerCase();
        const arg2 = args[1]?.toLowerCase();
        const arg3 = parseInt(args[2]);

        // ==========================================
        // --- AUTO-FIX DATABASE (ANTI ERROR NaN) ---
        // ==========================================
        if (isNaN(user.sawit_lahan)) user.sawit_lahan = 0;
        if (isNaN(user.sawit_bibit)) user.sawit_bibit = 0;
        if (isNaN(user.sawit_pohon)) user.sawit_pohon = 0;
        if (isNaN(user.sawit_pekerja)) user.sawit_pekerja = 0;
        if (isNaN(user.sawit_truk)) user.sawit_truk = 0;
        if (isNaN(user.sawit_drainase)) user.sawit_drainase = 0;
        if (isNaN(user.xp)) user.xp = 0;
        if (isNaN(user.money)) user.money = 0;
        
        // Pastikan variabel tracking modal ada
        if (typeof user.sawit_has_claimed_loan === 'undefined') user.sawit_has_claimed_loan = false;

        // ==========================================
        // --- KONFIGURASI GAMBAR (ASSETS) ---
        // ==========================================
        const baseUrl = "https://cdn.jsdelivr.net/gh/rhamt24/zalxzhu.github.io/images/";
        const img = {
            default: baseUrl + "sawit.png",
            modal: baseUrl + "sawit-beri-uang.png",     
            nomodal: baseUrl + "sawit-gaboleh.png",     
            beli: baseUrl + "sawit-beli-bibit.png",     
            pajak: baseUrl + "sawit-setor-pajak.png",   
            mandiri: baseUrl + "sawit-mandiri.png"      
        };

        const sendSawitCard = async (text, headerTitle, imageUrl) => {
            await sock.sendMessage(msg.key.remoteJid, {
                text: text,
                contextInfo: {
                    externalAdReply: {
                        title: headerTitle || "SAWIT SIMULATOR",
                        body: "Juragan Sawit Mobile - RPG Tycoon",
                        thumbnailUrl: imageUrl || img.default,
                        sourceUrl: 'https://whatsapp.com/channel/0029VaoNbbHAInPfk5U20C12',
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: msg });
        };

        // ==========================================
        // --- KONFIGURASI GAME ---
        // ==========================================
        const COOLDOWN_PANEN = 20 * 60 * 1000; 
        const MAX_POHON_PER_HA = 256;          
        const PAJAK_MITRA = 0.40;              
        const BIAYA_LUNAS = 250000000;         
        const MAX_PEKERJA = 100;

        const GAJI_PER_PEKERJA = 50000;        
        const KAPASITAS_TRUK = 256;            
        const BIAYA_ANGKUT_EXTRA = 2000;       

        const HARGA_LAHAN = 50000000;
        const HARGA_BIBIT = 30000; 
        const HARGA_PEKERJA = 2000000; 
        const HARGA_TRUK = 150000000;
        const HARGA_DRAINASE = 10000000;       

        const formatMoney = (angka) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(angka);

        // --- DATABASE INIT ---
        if (typeof user.sawit_lahan === 'undefined') user.sawit_lahan = 0;
        if (typeof user.sawit_bibit === 'undefined') user.sawit_bibit = 0;
        if (typeof user.sawit_pohon === 'undefined') user.sawit_pohon = 0;
        if (typeof user.sawit_pekerja === 'undefined') user.sawit_pekerja = 0;
        if (typeof user.sawit_truk === 'undefined') user.sawit_truk = 0;
        if (typeof user.sawit_drainase === 'undefined') user.sawit_drainase = 0;
        if (typeof user.sawit_last_panen === 'undefined') user.sawit_last_panen = 0;
        if (typeof user.sawit_is_loan === 'undefined') user.sawit_is_loan = false;
        if (typeof user.sawit_panen_count === 'undefined') user.sawit_panen_count = 0;
        if (typeof user.xp === 'undefined') user.xp = 0;

        const isRaining = Math.random() < 0.3; 
        
        // --- DIALOG SYSTEM ---
        const quotesWowok = {
            profit: ["Bisnis lancar, dompet mekar.", "Kerja bagus nak!", "Jangan lupa sisihkan buat modal bibit lagi."],
            potongan: ["Setoran aman. Makasih ya!", "Kerja yang rajin biar utangmu lunas.", "Potongan 40% buat administrasi ya!"],
            rugi: ["Boncos? Atur lagi strategi pekerjamu!", "Harga bibit lagi naik, harus makin efisien!"],
            banjir: ["Waduh! Kebunmu jadi kolam! Makanya bikin parit!", "Warga demo nih gara-gara banjir!"],
            lunas: ["Hebat kamu! Sekarang sudah jadi bos besar. Saya pamit dulu ya, sukses terus!", "Resmi mandiri! Jangan sombong kalau sudah kaya nanti."],
            nyindir: [
                "Cie, mentang-mentang mandiri sekarang panennya gak bagi-bagi ya? Sombong!",
                "Gimana bos? Lancar bener tuh kebun, inget dulu modalnya dari siapa ya!",
                "Wah, makin kaya aja nih. Gak mau mampir ke kantor saya lagi?",
                "Pasti pusing ya ngurus pajak sendiri? Enakan jaman mitra kan sebenernya?",
                "Lancar jaya nih? Awas kena hama, jangan lupa sedekah ke mantan mitra!",
                "Ciee yang udah lepas dari saya, gaya bener jalannya sekarang!",
                "Gimana sawit lu? Masih lancar kan tanpa bimbingan saya yang jenius ini?"
            ]
        };

        const quotesMandiri = [
            "Full senyum! Capek kerja tapi duitnya masuk kantong sendiri semua.",
            "Gak ada lagi potongan 40%, hidup terasa lebih ringan!",
            "Semua hasil keringat buruh masuk ke rekening saya. Mantap!",
            "Ternyata begini rasanya jadi Juragan Mandiri. Gurih!",
            "Mending capek ngitung duit daripada capek dipotong mitra."
        ];

        const getRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];
        const addXp = (amount) => { user.xp += amount; return amount; };

        // ==========================================
        // --- LOGIKA UTAMA ---
        // ==========================================

        // 1. MENU UTAMA
        if (!subCmd) {
            const statusUsaha = user.sawit_is_loan ? "🤝 Mitra (Potongan 40%)" : "👑 Juragan Mandiri";
            const menuText = `
🌴 *SAWIT SIMULATOR RPG* 🌴
_CEO Sawit Corp: Pak Wowok_

👤 Owner: ${pushName}
🏷️ Status: *${user.sawit_lahan > 0 ? statusUsaha : "Belum Main"}*
⭐ Total XP: ${user.xp}

🎮 *PANDUAN PEMULA:*

1️⃣ *MULAI BISNIS*
👉 \`.sawit daftar\`
_Ambil pinjaman modal._ 
*Note:* Uang Tunai 10jt hanya untuk pemain baru. Pemain reset hanya dapat Lahan & Bibit.

2️⃣ *MANAJEMEN KEBUN*
👉 \`.sawit status\`
_Cek kondisi kebun & sisa waktu panen._
👉 \`.sawit cekpekerja\`
_Analisis efisiensi buruh._

3️⃣ *OPERASIONAL*
👉 \`.sawit beli [item] [jumlah]\`
_Belanja aset. Contoh: .sawit beli bibit 100_
👉 \`.sawit tanam [jumlah]\`
_Tanam bibit. Contoh: .sawit tanam 50_
👉 \`.sawit panen\`
_Ambil untung setiap 20 menit._

4️⃣ *KEUANGAN & ADMIN*
👉 \`.sawit lunasi\` (Bebas Pajak)
👉 \`.sawit pecat [jumlah]\` (Kurangi Buruh)
👉 \`.sawit reset\` (Ulang dari nol)

💡 *TIPS:* Beli Drainase biar gak kena banjir!
`.trim();
            return sendSawitCard(menuText, "MANUAL BOOK JURAGAN", img.default);
        }

        // 2. DAFTAR (LOGIKA ANTI ABUSE)
        if (subCmd === 'daftar') {
            if (user.sawit_lahan > 0) return reply('❌ Kebun kamu sudah jalan.');
            
            let message = "";
            let header = "";
            let currentImage = img.default;
            let xpGain = 0;

            // [LOGIKA PENTING] 
            // Cek apakah user sudah pernah klaim loan sebelumnya?
            if (!user.sawit_has_claimed_loan) {
                // --- PEMAIN BARU (FIRST TIME) ---
                const modalUang = 10000000;
                user.money += modalUang;
                
                // Set Aset Awal
                user.sawit_lahan = 1;       
                user.sawit_bibit = 200;     
                user.sawit_pekerja = 2; 
                user.sawit_truk = 1; 
                
                user.sawit_has_claimed_loan = true; // Tandai sudah pernah ambil
                currentImage = img.modal;
                xpGain = addXp(1000); 

                header = "KONTRAK MITRA BARU";
                message = `🤝 *SELAMAT DATANG JURAGAN BARU!*\n\n💰 Modal Tunai: ${formatMoney(modalUang)}\n📦 Aset: 1 Ha, 200 Bibit, 2 Buruh, 1 Truk.\n⭐ XP Didapat: +${xpGain}\n\n_Gunakan uangnya bijak ya!_`;

            } else {
                // --- PEMAIN LAMA (RESET/BANGKRUT) ---
                // TIDAK DAPAT UANG 10JT (Supaya tidak di-abuse/transfer)
                // HANYA DAPAT ASET (Lahan & Bibit) untuk modal bangkit
                
                const bantuanOperasional = 500000; // Cuma dikasih 500rb buat gaji buruh awal
                user.money += bantuanOperasional;

                user.sawit_lahan = 1;       
                user.sawit_bibit = 100; // Bibit lebih sedikit     
                user.sawit_pekerja = 1; // Pekerja cuma 1
                user.sawit_truk = 0;    // Ga dapet truk
                
                currentImage = img.nomodal;
                xpGain = addXp(100); 

                header = "KONTRAK PEMULIHAN";
                message = `📉 *PAKET BANGKIT DARI KEBANGKRUTAN*\n\nKarena kamu pemain lama yang reset/bangkrut, Pak Wowok tidak memberi uang tunai 10jt lagi (Takut dikorupsi).\n\n📦 *Bantuan Aset:* 1 Ha Lahan, 100 Bibit, 1 Buruh.\n💰 *Uang Saku:* ${formatMoney(bantuanOperasional)}\n\n_Semangat mulai dari nol lagi ya!_`;
            }

            user.sawit_is_loan = true;
            user.sawit_panen_count = 0;
            user.sawit_drainase = 0;
            await saveDatabase();
            
            return sendSawitCard(message, header, currentImage);
        }

        if (user.sawit_lahan === 0 && subCmd !== 'reset') return reply('❌ Ketik *.sawit daftar* untuk mulai.');

        // 3. CEK PEKERJA
        if (subCmd === 'cekpekerja') {
            const maxPohonLahan = user.sawit_lahan * MAX_POHON_PER_HA;
            const idealPekerja = Math.ceil(maxPohonLahan / 100);
            const gaji = user.sawit_pekerja * GAJI_PER_PEKERJA;

            const textCek = `
👷 *KANTOR MANAJEMEN SDM*
- Total Pekerja: ${user.sawit_pekerja} Orang
- Beban Gaji: ${formatMoney(gaji)} / Panen

📊 *ANALISIS LAHAN:*
- Kapasitas Lahan: ${maxPohonLahan} Pohon
- Pekerja Ideal: ${idealPekerja} Orang
- Status: ${user.sawit_pekerja < idealPekerja ? "⚠️ Kurang Orang" : "✅ Buruh Cukup"}
`.trim();
            return sendSawitCard(textCek, "ANALISIS SDM", img.default);
        }

        // 4. PECAT
        if (subCmd === 'pecat') {
            const jml = parseInt(arg2);
            if (isNaN(jml) || jml < 1) return reply('❌ Masukkan jumlah buruh yang dipecat.');
            if (user.sawit_pekerja < jml) return reply('❌ Buruh tidak sebanyak itu!');
            
            user.sawit_pekerja -= jml;
            await saveDatabase();
            return reply(`✅ PHK Berhasil. Beban gaji berkurang ${formatMoney(jml * GAJI_PER_PEKERJA)}.`);
        }

        // 5. STATUS
        if (subCmd === 'status') {
            const now = Date.now();
            const timeLeft = COOLDOWN_PANEN - (now - user.sawit_last_panen);
            const risk = Math.max(5, Math.min(95, (5 + (user.sawit_lahan * 2) + (isRaining ? 25 : 0)) - (user.sawit_drainase * 5)));

            const statusText = `
📊 *LAPORAN HARIAN*
🌦️ Cuaca: ${isRaining ? "🌧️ Hujan" : "☀️ Cerah"}

🌳 Pohon: ${user.sawit_pohon} / ${user.sawit_lahan * MAX_POHON_PER_HA}
👷 Buruh: ${user.sawit_pekerja} Orang
🌊 Risiko Banjir: ${risk}%

🕒 Status Panen: ${timeLeft > 0 ? Math.ceil(timeLeft/60000) + " Menit" : "✅ SIAP!"}
💰 Saldo: ${formatMoney(user.money)}
⭐ XP: ${user.xp}
`.trim();
            return sendSawitCard(statusText, "STATUS KEBUN", img.default);
        }

        // 6. BELI
        if (subCmd === 'beli') {
            if (!arg2) {
                const catalog = `🛒 *TOKO PERALATAN*
1. *bibit*: ${formatMoney(HARGA_BIBIT)} (+5 XP/pcs)
2. *pekerja*: ${formatMoney(HARGA_PEKERJA)} (+50 XP/org)
3. *lahan*: ${formatMoney(HARGA_LAHAN)} / Ha (+500 XP/ha)
4. *truk*: ${formatMoney(HARGA_TRUK)} (+1000 XP/unit)
5. *drainase*: ${formatMoney(HARGA_DRAINASE)} (+150 XP/unit)`;
                return sendSawitCard(catalog, "TOKO JURAGAN", img.beli);
            }

            let jumlah = arg3 || 1;
            let harga = 0; let item = '';
            let xpReward = 0; 

            switch (arg2) {
                case 'lahan': harga = HARGA_LAHAN; item = 'sawit_lahan'; xpReward = 500; break;
                case 'bibit': harga = HARGA_BIBIT; item = 'sawit_bibit'; xpReward = 5; break;
                case 'pekerja': 
                    if (user.sawit_pekerja + jumlah > MAX_PEKERJA) return reply('❌ Mess buruh penuh!');
                    harga = HARGA_PEKERJA; item = 'sawit_pekerja'; xpReward = 50; break;
                case 'truk': harga = HARGA_TRUK; item = 'sawit_truk'; xpReward = 1000; break;
                case 'drainase': harga = HARGA_DRAINASE; item = 'sawit_drainase'; xpReward = 150; break;
                default: return reply('❌ Item tidak valid.');
            }

            if (user.money < (harga * jumlah)) return reply('❌ Saldo kurang!');
            
            const totalXp = xpReward * jumlah;
            user.money -= (harga * jumlah);
            user[item] += jumlah;
            addXp(totalXp); 
            
            await saveDatabase();
            return sendSawitCard(`🛒 *STRUK PEMBELIAN*\nItem: ${arg2}\nJumlah: ${jumlah}\n⭐ XP Didapat: +${totalXp}\nSisa Uang: ${formatMoney(user.money)}`, "TRANSAKSI BERHASIL", img.beli);
        }

        // 7. TANAM
        if (subCmd === 'tanam') {
            let jumlah = 0;
            if (arg2 && !isNaN(parseInt(arg2))) {
                jumlah = parseInt(arg2); 
            } else {
                jumlah = user.sawit_bibit; 
            }

            if (jumlah < 1) return reply(`❌ Kamu tidak punya bibit. Beli dulu di .sawit beli bibit`);
            if (user.sawit_bibit < jumlah) return reply(`❌ Stok bibit kurang. Punya kamu: ${user.sawit_bibit}`);
            
            if ((user.sawit_pohon + jumlah) > (user.sawit_lahan * MAX_POHON_PER_HA)) {
                const sisa = (user.sawit_lahan * MAX_POHON_PER_HA) - user.sawit_pohon;
                return reply(`❌ Lahan penuh! Kamu cuma bisa tanam ${sisa} pohon lagi. Beli lahan dulu.`);
            }
            
            const butuhPekerja = Math.ceil((user.sawit_pohon + jumlah) / 100);
            if (user.sawit_pekerja < butuhPekerja) return reply(`❌ Kurang orang! Kamu butuh minimal ${butuhPekerja} buruh.`);

            const totalXp = jumlah * 1; 

            user.sawit_bibit -= jumlah;
            user.sawit_pohon += jumlah;
            addXp(totalXp);
            
            await saveDatabase();
            return reply(`🌱 Menanam ${jumlah} pohon berhasil.\nTotal pohon: ${user.sawit_pohon}\n⭐ XP Didapat: +${totalXp}`);
        }

        // 8. PANEN
        if (subCmd === 'panen') {
            if (user.sawit_pohon === 0) return reply('❌ Belum ada pohon.');
            const now = Date.now();
            if (now - user.sawit_last_panen < COOLDOWN_PANEN) return reply('⏳ Belum matang.');

            const risk = Math.max(5, Math.min(95, (5 + (user.sawit_lahan * 2) + (isRaining ? 25 : 0)) - (user.sawit_drainase * 5)));
            if (Math.floor(Math.random() * 100) < risk) {
                const rugi = (user.sawit_pohon * 5000);
                user.money = Math.max(0, user.money - rugi);
                user.sawit_last_panen = now;
                await saveDatabase();
                return sendSawitCard(`🌊 *BANJIR!*\n"${getRandom(quotesWowok.banjir)}"\n💸 Rugi: -${formatMoney(rugi)}`, "BENCANA ALAM", img.nomodal);
            }

            const gross = user.sawit_pohon * (Math.floor(Math.random() * (22000 - 12000 + 1)) + 12000);
            const gaji = user.sawit_pekerja * GAJI_PER_PEKERJA;
            const transport = Math.max(0, (user.sawit_pohon - (user.sawit_truk * KAPASITAS_TRUK)) * BIAYA_ANGKUT_EXTRA);
            const pajak = user.sawit_is_loan ? Math.floor(gross * PAJAK_MITRA) : 0;
            const net = gross - (gaji + transport + pajak);
            
            const baseXpPanen = 200;
            const bonusXp = Math.floor(net / 1000000); 
            const totalXp = baseXpPanen + bonusXp;

            user.money += net;
            user.sawit_last_panen = now;
            user.sawit_panen_count += 1;
            addXp(totalXp);
            await saveDatabase();

            let dialogue = "";
            if (user.sawit_is_loan) {
                dialogue = `💬 *Pak Wowok:* "${getRandom(net > 0 ? quotesWowok.potongan : quotesWowok.rugi)}"`;
            } else {
                const randomChance = Math.random();
                if (randomChance > 0.5) {
                    dialogue = `💭 *Inner Thoughts:* "${getRandom(quotesMandiri)}"`;
                } else {
                    dialogue = `💬 *Pak Wowok (Lewat):* "${getRandom(quotesWowok.nyindir)}"`;
                }
            }

            const panenText = `
🚛 *HASIL PANEN #${user.sawit_panen_count}*
🌳 Pohon: ${user.sawit_pohon} | 👷 Buruh: ${user.sawit_pekerja}

💰 Omzet: ${formatMoney(gross)}
🛑 Gaji: -${formatMoney(gaji)}
🛑 Ongkos: -${formatMoney(transport)}
📉 Pajak Mitra: -${formatMoney(pajak)}
-------------------------------
💰 *NET PROFIT: ${formatMoney(net)}*
⭐ *XP EARNED: +${totalXp}*

${dialogue}
`.trim();
            return sendSawitCard(panenText, "PANEN RAYA", user.sawit_is_loan ? img.pajak : img.mandiri);
        }

        // 9. LUNASI
        if (subCmd === 'lunasi') {
            if (!user.sawit_is_loan) return reply('✅ Sudah mandiri.');
            if (user.money < BIAYA_LUNAS) return reply(`❌ Kurang ${formatMoney(BIAYA_LUNAS - user.money)}.`);
            
            const xpLunas = 5000; 
            
            user.money -= BIAYA_LUNAS;
            user.sawit_is_loan = false;
            addXp(xpLunas);
            await saveDatabase();
            
            const lunasText = `
🎉 *KEBEBASAN FINANSIAL!*
Status Mitra dicabut.

💬 *Pak Wowok:* "${getRandom(quotesWowok.lunas)}"

*System:* - Potongan 40% dihapus selamanya!
- ⭐ XP Bonus: +${xpLunas}
`.trim();
            
            return sendSawitCard(lunasText, "PELUNASAN SUKSES", img.mandiri);
        }

        // 10. RESET (SAFE RESET)
        if (subCmd === 'reset') {
            if (arg2 !== 'confirm') {
                return reply(`⚠️ *PERINGATAN KERAS!*
Reset akan menghapus SEMUA aset sawit (Lahan, Pohon, Pekerja, dll).
Karena kamu sudah pernah main, kamu *TIDAK AKAN MENDAPAT 10JT LAGI* saat daftar ulang.
Kamu hanya akan dapat Paket Aset Pemulihan (Lahan+Bibit).

Ketik: *.sawit reset confirm* jika yakin.`);
            }

            // Hapus data aset
            user.sawit_lahan = 0;
            user.sawit_bibit = 0;
            user.sawit_pohon = 0;
            user.sawit_pekerja = 0;
            user.sawit_truk = 0;
            user.sawit_drainase = 0;
            user.sawit_is_loan = false;
            user.sawit_panen_count = 0;
            user.sawit_last_panen = 0;
            
            // PENTING: Jangan ubah sawit_has_claimed_loan jadi false!
            // Biarkan user.sawit_has_claimed_loan tetap TRUE (atau value sebelumnya)
            // agar saat .sawit daftar, dia masuk ke kondisi "Pemain Lama".

            await saveDatabase();
            return reply('✅ Game Sawit di-reset! Ketik *.sawit daftar* untuk mulai kembali (Paket Pemulihan).');
        }
    }
};