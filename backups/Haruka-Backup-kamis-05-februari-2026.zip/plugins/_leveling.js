export default {
    command: ['profile', 'ceklevel', 'level', 'me', 'myprofile', 'dompet', 'saldo', 'balance'],
    category: 'User',
    description: 'Cek profil, level, status premium, dan saldo uang',
    isOwner: false,
    isAdmin: false,
    isBotAdmin: false,
    isPremium: false,

    handler: async ({ sock, msg, sender, db, reply, sendImage, pushName, isOwner }) => {
        const user = db[sender];
        if (!user) return reply('❌ Data user tidak ditemukan. Silakan ketik pesan apapun ke bot terlebih dahulu.');

        // 1. Identitas User
        const displayName = user.nama || pushName || 'User';
        const userRole = user.role || 'Warga Baru';

        // 2. Cek Status Premium & Limit
        let premiumStatus;
        if (isOwner) {
            premiumStatus = '👑 PERMANEN (Owner)';
        } else if (user.premiumUntil > Date.now()) {
            const dateStr = new Date(user.premiumUntil).toLocaleDateString('id-ID', {
                year: 'numeric', month: 'short', day: 'numeric'
            });
            premiumStatus = `✅ Aktif (s/d ${dateStr})`;
        } else {
            premiumStatus = '❌ Tidak Aktif (Free)';
        }

        const limitStatus = (isOwner || user.premiumUntil > Date.now()) 
            ? '♾️ Unlimited' 
            : `${user.limit} / ${db.globalSettings?.privateLimit || 20}`;

        // 3. Kalkulasi Level & XP (Rumus: Level = 0.1 * sqrt(XP))
        const currentLvl = user.level || 0;
        const currentXP = user.xp || 0;
        const nextLvl = currentLvl + 1;
        
        // XP yang dibutuhkan untuk level selanjutnya: (NextLevel / 0.1)^2
        const xpTarget = Math.pow(nextLvl * 10, 2); 
        const xpNeeded = Math.max(0, xpTarget - currentXP);
        
        // Persentase Progress
        let percent = 0;
        if (xpTarget > 0) percent = Math.floor((currentXP / xpTarget) * 100);
        if (percent > 100) percent = 100;

        // Visualisasi Progress Bar (10 blok)
        const filled = Math.floor(percent / 10);
        const progressBar = '█'.repeat(filled) + '░'.repeat(10 - filled);

        // 4. Formatting Uang
        const formatRp = (val) => new Intl.NumberFormat('id-ID', {
            style: 'currency', currency: 'IDR', minimumFractionDigits: 0
        }).format(val || 0);

        const textProfile = `
👤 *USER PROFILE*

🔖 *Nama:* ${displayName}
🏷️ *Title:* ${userRole}
🆙 *Level:* ${currentLvl}
✨ *XP:* ${currentXP} (${percent}%)
📉 *Progress:* [${progressBar}] 
_Kurang ${xpNeeded} XP ke Level ${nextLvl}_

---------------------------

💰 *Dompet:* ${formatRp(user.money)}
🏦 *Bank:* ${formatRp(user.bank)}
💳 *Limit:* ${limitStatus}
💎 *Premium:* ${premiumStatus}

_Ketik .setname <nama> untuk ubah nama profil._
`.trim();

        try {
            // Coba ambil foto profil (HD jika memungkinkan, fallback ke reguler)
            const ppUrl = await sock.profilePictureUrl(sender, 'image').catch(() => null);
            
            if (ppUrl) {
                await sendImage(ppUrl, textProfile);
            } else {
                await reply(textProfile);
            }
        } catch (e) {
            await reply(textProfile);
        }
    }
};
