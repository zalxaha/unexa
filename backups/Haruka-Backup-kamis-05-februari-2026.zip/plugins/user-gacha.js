import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Path ke DB Log Gacha (Hanya untuk mencatat cooldown)
const gachaDbPath = path.join(__dirname, '../database/gacha_log.json');

const MS_IN_DAY = 24 * 60 * 60 * 1000;
// Offset WIB (UTC+7) dalam milidetik
const WIB_OFFSET_MS = 7 * 60 * 60 * 1000; 

// --- Helper: Timestamp Tengah Malam WIB ---
function getWibMidnight(now) {
    const wibTime = now + WIB_OFFSET_MS;
    const date = new Date(wibTime);
    date.setUTCHours(0, 0, 0, 0); 
    return date.getTime() - WIB_OFFSET_MS;
}

// --- Helper: Baca/Tulis Log Gacha (Database Lokal Plugin) ---
async function getGachaLog() {
    try {
        const data = await fs.readFile(gachaDbPath, 'utf8');
        return JSON.parse(data);
    } catch (e) {
        return { userLog: {} }; // Return default jika file belum ada
    }
}

async function saveGachaLog(data) {
    // Pastikan folder database ada
    const dbDir = path.dirname(gachaDbPath);
    try { await fs.access(dbDir); } catch { await fs.mkdir(dbDir, { recursive: true }); }
    await fs.writeFile(gachaDbPath, JSON.stringify(data, null, 2));
}

// --- KONFIGURASI PROBABILITAS (Bisa diedit disini) ---
const GACHA_ITEMS = [
    { id: "RARE", days: 7, probability: 0.01, message: "🎉 *JACKPOT!* Anda memenangkan Premium 7 Hari!" }, // 1%
    { id: "UNCOMMON", days: 3, probability: 0.05, message: "✨ *LUCKY!* Anda mendapatkan Premium 3 Hari!" }, // 5%
    { id: "COMMON", days: 1, probability: 0.15, message: "🌟 *HORE!* Anda mendapatkan Premium 1 Hari!" }, // 15%
    { id: "ZONK", days: 0, probability: 0.79, message: "😔 *ZONK!* Kurang beruntung. Coba lagi besok!" } // 79%
];

// --- Logic Spin ---
function spinGacha() {
    const rand = Math.random(); 
    let cumulative = 0;
    for (const item of GACHA_ITEMS) {
        cumulative += item.probability;
        if (rand < cumulative) return item;
    }
    return GACHA_ITEMS[GACHA_ITEMS.length - 1]; // Fallback ke item terakhir (Zonk)
}

// --- HANDLER UTAMA ---
const handler = async ({ sock, msg, sender, db, saveDatabase }) => {
    const now = Date.now();
    
    // 1. Ambil Data User dari Memory Handler (SINKRON)
    // Di handler.js kamu passing: db: db.usersDb
    // Jadi 'db' disini adalah objek usersDb langsung.
    const user = db[sender];

    if (!user) {
        return msg.reply("❌ Error: Data user tidak ditemukan. Ketik pesan apapun dulu untuk register.");
    }

    // 2. Cek Cooldown dari File Log Gacha
    let gachaDb = await getGachaLog();
    if (!gachaDb.userLog) gachaDb.userLog = {};

    const lastClaim = gachaDb.userLog[sender] ? gachaDb.userLog[sender].lastClaim : 0;
    const midnightWIB = getWibMidnight(now);

    // Jika sudah klaim hari ini (setelah jam 00:00 WIB)
    if (lastClaim >= midnightWIB) {
        const nextReset = midnightWIB + MS_IN_DAY;
        const timeLeft = nextReset - now;
        const hours = Math.floor(timeLeft / 3600000);
        const minutes = Math.floor((timeLeft % 3600000) / 60000);
        
        return msg.reply(`⏳ *Limit Harian Habis*\n\nKamu sudah Gacha hari ini.\nReset pada jam 00:00 WIB.\n\nTunggu: *${hours} Jam ${minutes} Menit* lagi.`);
    }

    // 3. Spin Gacha
    const result = spinGacha();

    // 4. Simpan Log Waktu Klaim (Agar tidak bisa spam)
    gachaDb.userLog[sender] = { lastClaim: now };
    await saveGachaLog(gachaDb);

    // 5. Proses Hadiah
    if (result.days > 0) {
        // --- LOGIKA UPDATE PREMIUM (SINKRON DB) ---
        
        // Cek apakah user sudah premium sebelumnya
        const currentExp = user.premiumUntil || 0;
        const startTime = currentExp > now ? currentExp : now; // Kalau masih aktif, tambah durasinya. Kalau mati, mulai dari sekarang.
        
        // Update User Object di Memory
        user.premiumUntil = startTime + (result.days * MS_IN_DAY);
        user.status = 'premium'; // Ubah status jadi premium
        
        // Simpan Perubahan ke Database Utama
        saveDatabase(); 

        const expiryDate = new Date(user.premiumUntil).toLocaleDateString('id-ID', {
            day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit'
        });

        const replyText = `
🎰 *GACHA PREMIUM RESULT* 🎰

${result.message}

🎁 *Hadiah:* +${result.days} Hari
🏷️ *Status:* Premium User
🗓️ *Expired:* ${expiryDate}

_Status Premium telah otomatis diperbarui._
`.trim();

        await msg.reply(replyText);
        
    } else {
        // Jika Zonk
        msg.reply(`
🎰 *GACHA PREMIUM RESULT* 🎰

${result.message}

_Jangan menyerah! Kesempatan reset nanti malam._
`.trim());
    }
};

export default {
    command: ['gacha', 'claimpremium'],
    category: 'user',
    description: 'Gacha keberuntungan untuk dapat akun Premium gratis (1x Sehari).',
    handler: handler
};
