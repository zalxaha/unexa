import { downloadMediaMessage } from '@whiskeysockets/baileys';

export default {
    command: ['getmedia', 'dec'],
    category: 'Tools',
    description: 'Mendownload & Decrypt media dari pesan yang di-reply',

    handler: async ({ sock, msg, reply }) => {
        // 1. Cek apakah ada reply
        if (!msg.quoted) return reply('❌ Reply pesan media (Sticker/Image/Video) dulu!');

        try {
            await sock.sendMessage(msg.key.remoteJid, { react: { text: '⬇️', key: msg.key } });

            // --- PERBAIKAN UTAMA DI SINI ---
            // Kita harus membuat objek "Palsu" yang strukturnya 100% mirip pesan asli Baileys.
            // msg.quoted di handler kamu mungkin sudah dimodifikasi, jadi kita ambil raw message-nya.
            
            const fakeMessage = {
                key: {
                    remoteJid: msg.key.remoteJid,
                    id: msg.quoted.id,
                    participant: msg.quoted.sender
                },
                message: msg.quoted.message // Pastikan mengambil raw message dari sini
            };

            // 2. Download Media
            const buffer = await downloadMediaMessage(
                fakeMessage, 
                'buffer', 
                {}, 
                { 
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage 
                }
            );

            // 3. Deteksi Tipe Media untuk kirim balik
            // Kita cek isi message untuk tahu ini gambar, video, atau stiker
            const messageType = Object.keys(fakeMessage.message)[0]; // misal: imageMessage, stickerMessage

            if (messageType === 'stickerMessage') {
                await sock.sendMessage(msg.key.remoteJid, { sticker: buffer }, { quoted: msg });
            } else if (messageType === 'imageMessage') {
                await sock.sendMessage(msg.key.remoteJid, { image: buffer, caption: '✅ Sukses Decrypt Gambar' }, { quoted: msg });
            } else if (messageType === 'videoMessage') {
                await sock.sendMessage(msg.key.remoteJid, { video: buffer, caption: '✅ Sukses Decrypt Video' }, { quoted: msg });
            } else if (messageType === 'audioMessage') {
                await sock.sendMessage(msg.key.remoteJid, { audio: buffer, mimetype: 'audio/mp4' }, { quoted: msg });
            } else if (messageType === 'documentMessage') {
                // Ambil nama file asli jika ada
                const fileName = fakeMessage.message.documentMessage.fileName || 'result.bin';
                const mimetype = fakeMessage.message.documentMessage.mimetype || 'application/octet-stream';
                await sock.sendMessage(msg.key.remoteJid, { document: buffer, mimetype, fileName }, { quoted: msg });
            } else {
                // Fallback untuk tipe lain (ViewOnce, dll)
                await sock.sendMessage(msg.key.remoteJid, { document: buffer, mimetype: 'application/octet-stream', fileName: 'media-decrypted.bin', caption: `Type: ${messageType}` }, { quoted: msg });
            }

        } catch (e) {
            console.error(e);
            reply(`❌ Gagal Download.\nPastikan yang kamu reply adalah Gambar/Video/Stiker.\n\nError: ${e.message}`);
        }
    }
};