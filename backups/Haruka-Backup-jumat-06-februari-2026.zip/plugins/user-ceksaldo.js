export default {
    command: ['saldo', 'money', 'balance', 'dompet', 'uang', 'cekduit'],
    category: 'User',
    description: 'Cek sisa uang/saldo wallet dengan tampilan Bank Haruka',

    handler: async ({ sock, msg, db, sender, pushName }) => {
        // ==========================================
        // --- KONFIGURASI TAMPILAN ---
        // ==========================================
        const bankName = "HARUKA E-WALLET"; 
        // Pastikan gambar ini size-nya ringan (kurang dari 100KB lebih aman agar cepat muncul)
        const bankImage = "https://files.catbox.moe/xbasea.jpg"; 
        // ==========================================

        const user = db[sender];

        // 1. Validasi User (Cek apakah user ada di database)
        if (!user) {
            return sock.sendMessage(msg.key.remoteJid, { text: '❌ Data tidak ditemukan. Silakan ketik pesan apapun ke bot untuk register otomatis.' }, { quoted: msg });
        }

        // 2. Format Uang (Rupiah)
        const currentMoney = user.money || 0;
        const formattedMoney = new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
        }).format(currentMoney);

        // 3. Status Ekonomi (Gimmick / Lucu-lucuan)
        let statusKekayaan = 'Warga Sipil';
        if (currentMoney < 5000) statusKekayaan = 'Kaum Mendang-Mending 😭';
        else if (currentMoney < 100000) statusKekayaan = 'Pejuang Receh 🪙';
        else if (currentMoney < 1000000) statusKekayaan = 'Warga Menengah 🏠';
        else if (currentMoney > 10000000000) statusKekayaan = 'THE REAL SULTAN 👑';
        else if (currentMoney > 1000000000) statusKekayaan = 'Crazy Rich 💸';
        else if (currentMoney > 100000000) statusKekayaan = 'Juragan Besar 💼';
        else if (currentMoney > 10000000) statusKekayaan = 'Orang Kaya Baru 📈';

        // 4. Susun Pesan (Updated: Saldo Wallet)
        const infoText = `
👤 *USER:* ${pushName}
🆔 *ID:* ${sender.split('@')[0]}

👛 *SALDO WALLET:*
*${formattedMoney}*

📊 *STATUS EKONOMI:*
_${statusKekayaan}_
`.trim();

        // 5. Kirim dengan Gaya ExternalAdReply
        await sock.sendMessage(msg.key.remoteJid, {
            text: infoText,
            contextInfo: {
                externalAdReply: {
                    title: bankName,
                    body: "Layanan Cek Dompet Digital",
                    thumbnailUrl: bankImage, 
                    sourceUrl: 'https://whatsapp.com/channel/0029VaoNbbHAInPfk5U20C12', // Link Channel (Bisa diganti/dihapus)
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: msg });
    }
};