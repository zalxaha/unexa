import { jidNormalizedUser } from '@whiskeysockets/baileys';

// Helper: Mencari Akun Utama agar transfer tidak salah sasaran (Fix Saldo Hilang)
function mapTargetJid(incomingJid, db) {
    const cleanJid = jidNormalizedUser(incomingJid);
    for (const realJid in db) {
        const user = db[realJid];
        if (user.altJids && Array.isArray(user.altJids) && user.altJids.includes(cleanJid)) {
            return realJid; 
        }
    }
    return db[cleanJid] ? cleanJid : cleanJid;
}

export default {
    command: [
        'bank', 'cekuang', 'statusuang',
        'nabung', 'deposit', 'depo',
        'tarik', 'withdraw', 'wd',
        'transfer', 'tf', 'pay',
        'pinjam', 'loan', 'ngutang',
        'lunasi', 'bayarutang',
        'invest', 'investasi'
    ],
    category: 'Economy',
    description: 'Sistem Bank Haruka (AdReply UI)',

    handler: async ({ sock, msg, args, db, sender, pushName, command, saveDatabase }) => {
        const user = db[sender];
        const S_WHATSAPP_NET = '@s.whatsapp.net';
        
        // --- KONFIGURASI TAMPILAN & BANK ---
        const bankName = "BANK HARUKA CORP";
        const bankImage = "https://files.catbox.moe/xbasea.jpg"; // Gambar Bank
        
        const bungaInvestasi = 0.02; // SEKARANG 2%
        const durasiInvestasi = 1 * 60 * 60 * 1000; 
        const batasPinjaman = 50000000; 
        
        const formatRp = (angka) => new Intl.NumberFormat('id-ID', {
            style: 'currency', currency: 'IDR', minimumFractionDigits: 0
        }).format(angka);

        // --- HELPER KIRIM KARTU (AD REPLY) ---
        const sendCard = async (text, title = bankName) => {
            return await sock.sendMessage(msg.key.remoteJid, {
                text: text,
                contextInfo: {
                    externalAdReply: {
                        title: title,
                        body: "Layanan Perbankan Terpercaya",
                        thumbnailUrl: bankImage,
                        sourceUrl: "https://whatsapp.com/channel/0029VaoNbbHAInPfk5U20C12",
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: msg });
        };

        // --- 1. DASHBOARD / CEK STATUS ---
        if (['bank', 'cekuang', 'statusuang'].includes(command)) {
            const totalAset = user.money + user.bank + user.invest;
            const kekayaanBersih = totalAset - user.loan; 

            let status = 'Warga Sipil';
            if (kekayaanBersih < 5000) status = 'Kaum Mendang-Mending 😭';
            else if (kekayaanBersih < 100000) status = 'Pejuang Receh 🪙';
            else if (kekayaanBersih < 1000000) status = 'Warga Menengah 🏠';
            else if (kekayaanBersih > 1000000000) status = 'Crazy Rich 💸';
            else if (kekayaanBersih > 100000000) status = 'Juragan Besar 💼';
            else if (kekayaanBersih > 10000000) status = 'Orang Kaya Baru 📈';

            return sendCard(`
👤 *NASABAH:* ${pushName}
🆔 *ID:* ${sender.split('@')[0]}

╭─── 📊 *PORTOFOLIO* ───
│ 👛 *Dompet:* ${formatRp(user.money)}
│ 🏦 *Tabungan:* ${formatRp(user.bank)}
│ 📈 *Investasi:* ${formatRp(user.invest)}
│ ⚠️ *Utang:* -${formatRp(user.loan)}
╰───────────────────
💰 *KEKAYAAN BERSIH:* ${formatRp(kekayaanBersih)}

🏷️ *Status:* _${status}_`.trim(), "DASHBOARD KEUANGAN");
        }

        // --- 2. NABUNG ---
        if (['nabung', 'deposit', 'depo'].includes(command)) {
            let count = args[0] === 'all' ? user.money : parseInt(args[0]);
            if (!count || isNaN(count)) return msg.reply(`❌ Masukkan jumlah (angka/all).`);
            if (user.money < count) return msg.reply(`❌ Uang dompet kurang.`);
            if (count < 100) return msg.reply('❌ Minimal Rp 100.');

            user.money -= count;
            user.bank += count;
            await saveDatabase();
            return sendCard(`✅ *SETOR TUNAI BERHASIL*\n\n💸 Nominal: ${formatRp(count)}\n🏦 Saldo Bank: ${formatRp(user.bank)}`, "BUKTI SETORAN");
        }

        // --- 3. TARIK TUNAI ---
        if (['tarik', 'withdraw', 'wd'].includes(command)) {
            let count = args[0] === 'all' ? user.bank : parseInt(args[0]);
            if (!count || isNaN(count)) return msg.reply(`❌ Masukkan jumlah (angka/all).`);
            if (user.bank < count) return msg.reply(`❌ Saldo bank kurang.`);
            if (count < 100) return msg.reply('❌ Minimal Rp 100.');

            user.bank -= count;
            user.money += count;
            await saveDatabase();
            return sendCard(`✅ *TARIK TUNAI BERHASIL*\n\n💸 Nominal: ${formatRp(count)}\n👛 Isi Dompet: ${formatRp(user.money)}`, "BUKTI PENARIKAN");
        }

        // --- 4. TRANSFER (FIXED LOGIC) ---
        if (['transfer', 'tf', 'pay'].includes(command)) {
            let rawTarget = null, amount = 0;

            if (msg.quoted) {
                rawTarget = msg.quoted.sender;
                amount = parseInt(args[0]);
            } else if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                rawTarget = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
                const amtArgs = args.find(a => !a.includes('@') && !isNaN(parseInt(a)));
                if (amtArgs) amount = parseInt(amtArgs);
            } else if (args[0]) {
                const num = args[0].replace(/[^0-9]/g, '');
                if (num.length > 5) rawTarget = num + S_WHATSAPP_NET;
                amount = parseInt(args[1]);
            }

            if (!rawTarget || !amount || isNaN(amount)) return msg.reply(`❌ Format: .tf @tag 10000`);

            let cleanJid = jidNormalizedUser(rawTarget.split(':')[0]);
            const finalTarget = mapTargetJid(cleanJid, db);

            if (finalTarget === sender) return msg.reply('❌ Tidak bisa transfer ke diri sendiri.');
            if (user.money < amount) return msg.reply(`❌ Uang dompet kurang.`);
            if (amount < 1000) return msg.reply('❌ Minimal Rp 1.000');
            if (!db[finalTarget]) return msg.reply(`❌ User belum terdaftar di bot.`);

            const targetUser = db[finalTarget]; 
            user.money -= amount;
            targetUser.money = (parseInt(targetUser.money) || 0) + amount;
            
            await saveDatabase();
            return sock.sendMessage(msg.key.remoteJid, {
                text: `✅ *TRANSFER BERHASIL*\n\n📤 Dari: @${sender.split('@')[0]}\n📥 Ke: @${finalTarget.split('@')[0]}\n💸 Nominal: ${formatRp(amount)}\n\n_Sisa Saldo: ${formatRp(user.money)}_`,
                mentions: [sender, finalTarget],
                contextInfo: {
                    externalAdReply: {
                        title: "BUKTI TRANSFER DANA",
                        body: "Transaksi Aman & Terpercaya",
                        thumbnailUrl: bankImage,
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: msg });
        }

        // --- 5. PINJAM ---
        if (['pinjam', 'loan', 'ngutang'].includes(command)) {
            const amount = parseInt(args[0]);
            if (!amount) return msg.reply(`❌ Masukkan nominal.`);
            if (user.loan > 0) return msg.reply(`❌ Lunasi dulu utang lama.`);
            if (amount > batasPinjaman) return msg.reply(`❌ Maks: ${formatRp(batasPinjaman)}`);
            if (amount < 10000) return msg.reply(`❌ Min: Rp 10.000`);

            const admin = Math.floor(amount * 0.1);
            user.loan += amount;
            user.money += (amount - admin);
            await saveDatabase();
            return sendCard(`🤝 *PINJAMAN DISETUJUI*\n\n💸 Pinjaman: ${formatRp(amount)}\n📉 Admin 10%: ${formatRp(admin)}\n💵 Terima Bersih: ${formatRp(amount - admin)}`, "KREDIT CAIR");
        }

        // --- 6. LUNASI ---
        if (['lunasi', 'bayarutang'].includes(command)) {
            if (user.loan <= 0) return msg.reply('✅ Tidak ada utang.');
            
            let bayar = args[0] === 'all' ? user.loan : parseInt(args[0]);
            if (!bayar || isNaN(bayar)) return msg.reply(`❌ Masukkan jumlah.`);
            if (user.money < bayar) return msg.reply(`❌ Uang kurang.`);

            if (bayar >= user.loan) {
                user.money -= user.loan;
                user.loan = 0;
                await saveDatabase();
                return sendCard(`🎉 *LUNAS! BEBAS UTANG*\n\nSelamat, beban hidupmu berkurang satu.`, "PELUNASAN SUKSES");
            } else {
                user.money -= bayar;
                user.loan -= bayar;
                await saveDatabase();
                return sendCard(`✅ *CICILAN DITERIMA*\n\n💸 Dibayar: ${formatRp(bayar)}\n⚠️ Sisa Utang: ${formatRp(user.loan)}`, "BUKTI CICILAN");
            }
        }

        // --- 7. INVESTASI ---
        if (['invest', 'investasi'].includes(command)) {
            const now = Date.now();
            const sub = args[0];

            if (user.invest > 0 && (now - user.lastInvest) >= durasiInvestasi) {
                const hours = Math.floor((now - user.lastInvest) / durasiInvestasi);
                const profit = Math.floor(user.invest * bungaInvestasi * hours);
                if (profit > 0) {
                    user.invest += profit;
                    user.lastInvest = now;
                    await saveDatabase();
                    await sendCard(`📈 *PROFIT MASUK*\n\n+${formatRp(profit)} (${hours} Jam)`, "LAPORAN INVESTASI");
                }
            }

            if (!sub) {
                return sendCard(`
📈 *INVESTASI HARUKA*
Bunga: ${(bungaInvestasi * 100)}% per Jam

💰 *Saldo Invest:* ${formatRp(user.invest)}

🔹 *.invest tambah [jumlah]*
🔹 *.invest tarik [jumlah]*`, "MENU INVESTASI");
            }

            if (sub === 'tambah') {
                const amount = parseInt(args[1]);
                if (!amount || user.money < amount) return msg.reply('❌ Uang kurang/salah input.');
                user.money -= amount;
                user.invest += amount;
                user.lastInvest = now;
                await saveDatabase();
                return sendCard(`✅ *INVESTASI BERHASIL*\n\n💸 Masuk: ${formatRp(amount)}\n📈 Total Aset: ${formatRp(user.invest)}`, "PORTOFOLIO UPDATE");
            }

            if (sub === 'tarik') {
                const amount = args[1] === 'all' ? user.invest : parseInt(args[1]);
                if (!amount || amount > user.invest) return msg.reply('❌ Saldo invest kurang.');
                user.invest -= amount;
                user.money += amount;
                await saveDatabase();
                return sendCard(`✅ *PENCAIRAN INVESTASI*\n\n💸 Cair: ${formatRp(amount)}\n📈 Sisa Aset: ${formatRp(user.invest)}`, "WITHDRAWAL SUCCESS");
            }
        }
    }
};