import axios from 'axios';
import FormData from 'form-data';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { Buffer } from 'buffer';
import fs from 'fs';
import path from 'path';
import { tmpdir } from 'os';
import Crypto from 'crypto';

// --- HELPER FUNCTIONS ---
function generateFileName(ext = '.png') {
  return path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}${ext}`);
}

// --- IMGUPSCALER API FUNCTIONS ---
const availableScaleRatio = [2, 4];

const imgupscale = {
  req: async (imagePath, scaleRatio) => {
    try {
      const data = new FormData();
      // Tambahkan opsi filename dan content-type secara manual di form-data
      data.append('myfile', fs.createReadStream(imagePath), {
        filename: path.basename(imagePath),
        contentType: 'image/png',
      });
      data.append('scaleRadio', scaleRatio.toString());

      const config = {
        method: 'POST',
        url: 'https://get1.imglarger.com/api/UpscalerNew/UploadNew',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Origin': 'https://imgupscaler.com',
          'Referer': 'https://imgupscaler.com/',
          ...data.getHeaders()
        },
        data: data,
        maxContentLength: Infinity,
        maxBodyLength: Infinity
      };

      const response = await axios.request(config);
      return response.data;
    } catch (error) {
      // Menangkap error detail dari axios
      const msg = error.response ? JSON.stringify(error.response.data) : error.message;
      throw new Error(`Upload failed: ${msg}`);
    }
  },
  
  cek: async (code, scaleRatio) => {
    try {
      const data = {
        "code": code,
        "scaleRadio": parseInt(scaleRatio)
      };

      const config = {
        method: 'POST',
        url: 'https://get1.imglarger.com/api/UpscalerNew/CheckStatusNew',
        headers: {
          'Content-Type': 'application/json',
          'Origin': 'https://imgupscaler.com',
          'Referer': 'https://imgupscaler.com/',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        },
        data: data
      };

      const response = await axios.request(config);
      return response.data;
    } catch (error) {
      throw new Error(`Status check failed: ${error.message}`);
    }
  },
  
  upscale: async (imagePath, scaleRatio, maxRetries = 30, retryDelay = 3000) => {
    try {
      const uploadResult = await imgupscale.req(imagePath, scaleRatio);
      
      // Pastikan struktur response benar
      if (uploadResult.code !== 200 || !uploadResult.data) {
        throw new Error(uploadResult.msg || "Server rejected the file.");
      }

      const code = uploadResult.data.code;
      
      for (let i = 0; i < maxRetries; i++) {
        await new Promise(resolve => setTimeout(resolve, retryDelay));
        const statusResult = await imgupscale.cek(code, scaleRatio);
        
        if (statusResult.code === 200 && statusResult.data.status === 'success') {
          return {
            status: true,
            imageUrl: statusResult.data.downloadUrls[0],
            filesize: statusResult.data.filesize,
          };
        }
        
        if (statusResult.data && statusResult.data.status === 'error') {
          throw new Error('Server processing error');
        }
      }

      throw new Error('Processing timeout');
    } catch (error) {
      throw new Error(error.message);
    }
  }
};

// --- HANDLER UTAMA ---
export default {
  command: ['hdr', 'hd', 'remini', 'upscale'],
  description: 'Meningkatkan kualitas foto',
  category: 'tools',
  
  handler: async ({ sock, msg, args, from }) => {
    const scale = availableScaleRatio.includes(parseInt(args[0])) ? parseInt(args[0]) : 2;

    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage || msg.message;
    const mimeType = Object.keys(quoted || {}).find(k => k.endsWith('Message')) || '';

    if (!mimeType.includes('image')) return msg.reply('❌ Balas/kirim gambar dengan caption *.hd*');

    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    let filePath = generateFileName('.png');
    
    try {
        const media = quoted[mimeType];
        const stream = await downloadContentFromMessage(media, 'image');
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }

        fs.writeFileSync(filePath, buffer);

        const result = await imgupscale.upscale(filePath, scale);

        const resultResponse = await axios.get(result.imageUrl, { responseType: 'arraybuffer' });
        const resultBuffer = Buffer.from(resultResponse.data);
        
        await sock.sendMessage(from, { 
            image: resultBuffer, 
            caption: `✨ *HD SUCCESS* (${scale}x)\nSize: ${(resultBuffer.length / 1024).toFixed(2)} KB` 
        }, { quoted: msg });

        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (error) {
        console.error(error);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        msg.reply(`❌ *Error:* ${error.message}`);
    } finally {
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }
  }
};
