import axios from "axios";
import crypto from "crypto";
import * as fsp from 'fs/promises';
import fs from 'fs';
import * as path from 'path';
import NodeID3 from 'node-id3';
import yts from 'yt-search';
import fetch from 'node-fetch';

/**
 * Scraper Savetube Class
 */
class Savetube {
  constructor() {
    this.ky = 'C5D58EF67A7584E4A29F6C35BBC4EB12';
    this.fmt = ['144', '240', '360', '480', '720', '1080', 'mp3'];
    this.m = /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(?:embed\/)?(?:v\/)?(?:shorts\/)?([a-zA-Z0-9_-]{11})/;
    this.is = axios.create({
      headers: {
        'content-type': 'application/json',
        'origin': 'https://yt.savetube.me',
        'user-agent': 'Mozilla/5.0 (Android 15; Mobile; SM-F958; rv:130.0) Gecko/130.0 Firefox/130.0'
      }
    })
  }
  
  async decrypt(enc) {
    try {
      const sr = Buffer.from(enc, 'base64');
      const ky = Buffer.from(this.ky, 'hex');
      const iv = sr.slice(0, 16);
      const dt = sr.slice(16);
      const dc = crypto.createDecipheriv('aes-128-cbc', ky, iv);
      return JSON.parse(Buffer.concat([dc.update(dt), dc.final()]).toString());
    } catch (e) {
      throw new Error(`Error while decrypting data: ${e.message}`);
    }
  }
  
  async getCdn() {
    try {
        const response = await this.is.get("https://media.savetube.vip/api/random-cdn");
        return {
          status: true,
          data: response.data.cdn
        };
    } catch (e) {
        return { status: false, msg: e.message };
    }
  }
  
  async download(url, format = 'mp3') {
    const id = url.match(this.m)?.[3];
    if (!id) throw new Error("ID video tidak ditemukan dari URL");
    
    try {
      const u = await this.getCdn();
      if (!u.status) throw new Error("Gagal mendapatkan server CDN");
      
      const res = await this.is.post(`https://${u.data}/v2/info`, {
        url: `https://www.youtube.com/watch?v=${id}`
      });
      
      const dec = await this.decrypt(res.data.data);
      
      const dl = await this.is.post(`https://${u.data}/download`, {
        id: id,
        downloadType: format === 'mp3' ? 'audio' : 'video',
        quality: format === 'mp3' ? '128' : format,
        key: dec.key
      });

      return {
        status: true,
        title: dec.title,
        format: format,
        thumb: dec.thumbnail || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
        duration: dec.durationLabel,
        dl: dl.data.data.downloadUrl,
        channel: dec.channelName
      };
    } catch (error) {
      throw error;
    }
  }
}

/**
 * Utility Functions
 */
async function downloadAndSave(url, filePath) {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Gagal mengunduh file: ${response.statusText}`);
    const buffer = await response.buffer();
    await fsp.writeFile(filePath, buffer); 
}

async function embedMetadata(audioPath, imagePath, tags) {
    const imageBuffer = await fsp.readFile(imagePath);
    const defaultTags = {
        title: tags.title,
        artist: tags.artist || 'YouTube Downloader',
        image: {
            mime: 'image/jpeg',
            type: { id: 3, name: 'front cover' },
            description: 'Cover Art',
            imageBuffer: imageBuffer
        }
    };
    return NodeID3.write(defaultTags, audioPath);
}

/**
 * Main Handler
 */
const handler = async ({ sock, msg, args, from, command }) => {
  const text = args.join(' ');
  
  const tempId = Date.now();
  const audioTempPath = path.join('/tmp', `${tempId}-audio.mp3`); 
  const imageTempPath = path.join('/tmp', `${tempId}-thumb.jpg`);

  if (!text) {
    return sock.sendMessage(from, {
      text: 'Masukkan teks pencarian atau link YouTube.\nContoh: .play mockingbird'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🔎', key: msg.key } });

  let url;
  const isURL = text.trim().match(/youtube\.com|youtu\.be/);
  
  try {
    const st = new Savetube();
    
    // 1. Pencarian jika input bukan URL
    if (!isURL) {
      const results = await yts(text);
      if (!results.videos || results.videos.length === 0) throw new Error('Video tidak ditemukan.');
      url = results.videos[0].url;
    } else {
      url = text.trim().split(' ')[0];
    }

    // 2. Ambil data & Link Download menggunakan Savetube Class baru
    const result = await st.download(url, 'mp3');

    // 3. Kirim Informasi Video
    const captionThumbnail = `*YOUTUBE PLAY - SAVETUBE*\n\n` +
                             `• *Judul:* ${result.title}\n` +
                             `• *Durasi:* ${result.duration}\n` +
                             `• *Channel:* ${result.channel || 'YouTube'}\n\n` +
                             `*Sedang mengirim audio, mohon tunggu...*`;

    await sock.sendMessage(from, {
      image: { url: result.thumb },
      caption: captionThumbnail
    }, { quoted: msg });

    // 4. Kirim Audio (M4A/MP4 agar bisa diputar langsung di WA)
    await sock.sendMessage(from, {
        audio: { url: result.dl },
        mimetype: 'audio/mp4', 
        ptt: false 
    }, { quoted: msg });
    
    // 5. Proses MP3 dengan Metadata (ID3 Tag)
    await downloadAndSave(result.dl, audioTempPath);
    await downloadAndSave(result.thumb, imageTempPath);
    
    await embedMetadata(audioTempPath, imageTempPath, {
        title: result.title,
        artist: result.channel || 'YouTube'
    });
    
    // 6. Kirim sebagai Dokumen MP3
    await sock.sendMessage(from, {
        document: { stream: fs.createReadStream(audioTempPath) }, 
        mimetype: 'audio/mpeg', 
        fileName: `${result.title}.mp3`,
        caption: `✅ *File MP3 Berhasil Diproses*`
    }, { quoted: msg });

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (err) {
    console.error(err);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    sock.sendMessage(from, {
      text: `❌ *Kesalahan:* ${err.message}`
    }, { quoted: msg });
  } finally {
    // Hapus file temporary
    try {
        if (fs.existsSync(audioTempPath)) await fsp.unlink(audioTempPath); 
        if (fs.existsSync(imageTempPath)) await fsp.unlink(imageTempPath); 
    } catch (e) {}
  }
};

export default {
  command: ['play'],
  description: 'Mencari dan mengunduh audio YouTube via Savetube',
  category: 'Downloader',
  handler,
};