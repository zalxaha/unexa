import 'dotenv/config';
import makeWASocket, {
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    getContentType,
    jidNormalizedUser
} from '@whiskeysockets/baileys';

import qr from 'qrcode-terminal';
import pino from 'pino';
import path from 'path';
import fs from 'fs/promises';
import * as fsSync from 'fs';
import { fileURLToPath } from 'url';
import { parsePhoneNumber } from 'libphonenumber-js';
import chalk from 'chalk';
import NodeCache from 'node-cache';

// Import Handler
import log from './lib/logger.js';

// --- GLOBAL VARIABLES ---
let MsgHandler;
let loadPlugins;
let loadDisabledFeatures;
let config = {};

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Cache Metadata Grup (1 Jam) & Retry
const groupMetadataCache = new NodeCache({ stdTTL: 60 * 60, checkperiod: 60 });
const msgRetryCounterCache = new NodeCache();

// --- INITIALIZATION ---
async function initHandler() {
    try {
        const configPath = path.join(__dirname, 'config/config.json');
        const configFileContent = await fs.readFile(configPath, 'utf8');
        config = JSON.parse(configFileContent);
        
        const MsgModule = await import('./handlers/messageHandler.js');
        await MsgModule.loadDisabledFeatures();
        await MsgModule.loadPlugins();

        MsgHandler = MsgModule.default;
        loadPlugins = MsgModule.loadPlugins;
        loadDisabledFeatures = MsgModule.loadDisabledFeatures;

        console.log(chalk.green('✅ Handler & Plugins loaded.'));
    } catch (e) {
        console.error(chalk.red('⚠️ Fatal Error Loading Handler:'), e);
    }
}

await initHandler();
import CallHandler from './lib/call.js';

const sessionFolder = path.join(__dirname, 'session');
const dbPath = path.join(__dirname, 'database/users.json');

// --- UTILS ---
async function validatePhoneNumber(input) {
    if (!input) return null;
    try {
        let phone = String(input).replace(/[^0-9]/g, "");
        if (!phone.startsWith('+')) phone = '+' + phone;
        const pn = parsePhoneNumber(phone);
        return pn?.isValid() ? pn.number.replace('+', '') : null;
    } catch { return null; }
}

async function checkDatabase() {
    try {
        await fs.access(dbPath);
    } catch (err) {
        if (err.code === "ENOENT") {
            await fs.mkdir(path.dirname(dbPath), { recursive: true });
            await fs.writeFile(dbPath, JSON.stringify({}));
        }
    }
}

// --- MAIN SOCKET ---
async function Start() {
    await checkDatabase();
    try { await fs.access(sessionFolder); } catch { await fs.mkdir(sessionFolder, { recursive: true }); }

    const { state, saveCreds } = await useMultiFileAuthState(sessionFolder);
    const { version } = await fetchLatestBaileysVersion();

    log.info(`Baileys v${version.join('.')}`);
    config.version = version.join('.');
    const usePairing = config.system?.pairing === true;

    const sock = makeWASocket({
        version,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" })),
        },
        logger: pino({ level: "silent" }),
        printQRInTerminal: !usePairing,
        syncFullHistory: false, 
        generateHighQualityLinkPreview: true,
        markOnlineOnConnect: true,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        connectTimeoutMs: 60000,
        retryRequestDelayMs: 2000,
        msgRetryCounterCache,
        // FIX 1: Jangan return object kosong dengan string kosong, return null/undefined agar aman
        getMessage: async (key) => { return undefined; }
    });

    // --- CUSTOM JID DECODER ---
    sock.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            const decode = jidNormalizedUser(jid);
            return decode;
        }
        return jid;
    };

    sock.decodeLid = async (lid) => {
        if (!lid) return lid;
        if (!lid.endsWith('@lid')) return sock.decodeJid(lid);
        try {
            const key = sock.signalRepository?.lidMapping; 
            if (key) {
                const mapping = await key.getPNForLID(lid);
                if (mapping) return sock.decodeJid(mapping);
            }
            return sock.decodeJid(lid);
        } catch (e) {
            return sock.decodeJid(lid);
        }
    };

    if (usePairing && !sock.authState.creds.registered) {
        setTimeout(async () => {
            const number = await validatePhoneNumber(config.system.number);
            if (!number) return log.err("Nomor pairing invalid di config.json");
            try {
                let code = await sock.requestPairingCode(number);
                code = code?.match(/.{1,4}/g)?.join('-') || code;
                console.log(chalk.bgGreen.black(`\n📞 KODE PAIRING: `) + " " + chalk.white.bold(code));
            } catch (err) { log.err("Gagal request pairing: " + err.message); }
        }, 3000);
    }

    sock.ev.on("connection.update", async ({ connection, lastDisconnect, qr: code }) => {
        if (code && !usePairing && !sock.authState.creds.registered) qr.generate(code, { small: true });
        if (connection === "open") {
            log.ok("Bot Connected & Ready!");
            try {
                const ownerJid = await sock.decodeLid(config.owner + "@s.whatsapp.net");
                await sock.sendMessage(ownerJid, { text: `✅ *Bot Online!*\nVersion: ${config.version}` });
            } catch {}
        }
        if (connection === "close") {
            const code = lastDisconnect?.error?.output?.statusCode;
            if (code === DisconnectReason.loggedOut) {
                log.err("Session Logout.");
                await fs.rm(sessionFolder, { recursive: true, force: true });
                process.exit(1);
            } else {
                log.warn("Reconnecting...");
                Start();
            }
        }
    });

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on('groups.update', async (updates) => {
        for (const update of updates) {
            if (update.subject) groupMetadataCache.set(update.id, { subject: update.subject });
        }
    });

    // --- MESSAGE HANDLER UTAMA (UPDATED FIX SPAM) ---
    sock.ev.on("messages.upsert", async ({ messages, type }) => {
        // Hanya proses notifikasi baru, abaikan append/history sync
        if (type !== 'notify') return;

        for (const msg of messages) {
            try {
                // 1. Basic Filters
                if (!msg.message) continue;
                if (msg.key.fromMe) continue;
                if (msg.key.remoteJid === "status@broadcast") continue;

                // FIX 2: Timestamp Filter (PENTING)
                // Jika pesan lebih tua dari 2 menit (misal sisa history saat baru connect), abaikan.
                // Ini mencegah bot membalas puluhan pesan sekaligus saat baru nyala.
                if (msg.messageTimestamp && (Date.now() - (msg.messageTimestamp * 1000)) > 120000) {
                    continue; 
                }
                
                // 2. Unwrapping Message Logic
                let mContent = msg.message;
                
                // Cek Ephemeral
                if (mContent.ephemeralMessage) {
                    mContent = mContent.ephemeralMessage.message;
                }
                // Cek ViewOnce (V1 & V2)
                if (mContent.viewOnceMessageV2) {
                    mContent = mContent.viewOnceMessageV2.message;
                } else if (mContent.viewOnceMessage) {
                    mContent = mContent.viewOnceMessage.message;
                }
                
                // Update msg.message dengan konten bersih
                msg.message = mContent;
                
                // 3. Get Content Type & Strict Filtering
                const msgType = getContentType(mContent);
                
                // FIX 3: Tambahkan tipe yang diabaikan untuk mencegah crash/spam kosong
                const ignoreTypes = [
                    'protocolMessage', 
                    'senderKeyDistributionMessage', 
                    'messageContextInfo', 
                    'reactionMessage', 
                    'pollUpdateMessage',
                    'keepInChatMessage' // Fitur baru WA sering bikin trigger kosong
                ];

                if (!msgType || ignoreTypes.includes(msgType)) continue;

                // 4. Decode Sender
                const from = msg.key.remoteJid;
                const isGroup = from.endsWith('@g.us');
                let senderRaw = isGroup ? (msg.key.participant || from) : from;
                const sender = await sock.decodeLid(senderRaw);
                msg.sender = sender; 

                const pushName = msg.pushName || "Unknown";
                const groupName = isGroup ? (groupMetadataCache.get(from)?.subject || from.split('@')[0]) : "";

                // 5. Extract Body (Pesan Teks)
                let body = '';
                let logType = '';

                if (msgType === 'conversation') { 
                    body = mContent.conversation; 
                    logType = '💬 Text'; 
                } else if (msgType === 'imageMessage') { 
                    body = mContent.imageMessage.caption || ''; // Jangan paksa [Image] jika caption kosong
                    logType = '🖼️ Image'; 
                } else if (msgType === 'videoMessage') { 
                    body = mContent.videoMessage.caption || ''; 
                    logType = '📹 Video'; 
                } else if (msgType === 'extendedTextMessage') { 
                    body = mContent.extendedTextMessage.text; 
                    logType = '📝 Text'; 
                } else if (msgType === 'stickerMessage') { 
                    logType = '✨ Sticker'; // Sticker tidak punya body teks
                } else { 
                    logType = `❓ ${msgType}`; 
                }

                // FIX 4: Filter terakhir yang lebih ketat
                // Pastikan body adalah string dan tidak kosong
                if (typeof body !== 'string') body = '';
                
                // Jika body kosong dan bukan sticker/media, skip.
                // Jika Anda ingin bot merespon gambar tanpa caption, sesuaikan logika ini.
                if (body.trim().length === 0 && !['stickerMessage', 'imageMessage', 'videoMessage'].includes(msgType)) {
                    continue;
                }

                // --- LOGGING ---
                const isCmd = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&./]/gi.test(body);
                const timeStr = chalk.bgBlack.white(`⏰ ${new Date().toLocaleTimeString()}`);
                const senderStr = chalk.green(pushName) + chalk.dim(` (${sender.replace('@s.whatsapp.net', '')})`);
                const ctxStr = isGroup ? chalk.magenta(`[${groupName}]`) : chalk.blue(`[Private]`);
                
                // Hanya log jika ada body atau tipe pesan jelas
                console.log(`${timeStr} ${chalk.cyan(`[${logType}]`)} ${ctxStr} ${senderStr} : ${chalk.white(body || '<Media>')}`);

                // 7. Execute Handler
                if (isCmd && MsgHandler) {
                    // console.log(chalk.yellow(`⚡ COMMAND DETECTED`)); // Opsional: Kurangi log spam
                    MsgHandler(sock, msg).catch(e => {
                        console.error(chalk.red(`❌ Plugin Error:`), e);
                    });
                }

            } catch (e) {
                console.error("Error loop upsert:", e);
            }
        }
    });

    sock.ev.on("call", async (calls) => {
        try { await CallHandler.code(sock, calls); } catch {}
    });

    fsSync.watch(path.join(__dirname, "plugins"), async (evt, filename) => {
        if (filename && filename.endsWith(".js")) {
            try {
                const ts = Date.now();
                const reload = await import(`./handlers/messageHandler.js?v=${ts}`);
                if (reload.loadDisabledFeatures) await reload.loadDisabledFeatures();
                if (reload.loadPlugins) await reload.loadPlugins();
                MsgHandler = reload.default;
                log.ok(`[RELOAD] Plugin ${filename} updated.`);
            } catch (e) {}
        }
    });
}

process.on("unhandledRejection", () => {});
process.on("uncaughtException", () => {});

Start();
