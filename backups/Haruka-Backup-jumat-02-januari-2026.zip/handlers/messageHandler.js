import { promises as fs } from 'fs'; 
import path from 'path';
import { downloadContentFromMessage, jidNormalizedUser } from '@whiskeysockets/baileys'; 
import { fileURLToPath } from 'url';
import { createRequire } from 'module'; 
import fetch from 'node-fetch';
import process from 'process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url);

import log from '../lib/logger.js';

// Load Config (Pakai require agar tidak error JSON import)
const cfg = require('../config/config.json');

// --- PATH DATABASE ---
const dbPath = path.join(__dirname, '../database/users.json');
const featuresPath = path.join(__dirname, '../database/features.json');
const groupDbPath = path.join(__dirname, '../database/groups.json'); 
const settingsPath = path.join(__dirname, '../database/settings.json'); 
const pluginDir = path.join(__dirname, '../plugins');

let sockGlobal = null;

// --- OPTIMIZED METADATA CACHE ---
const groupMetadataCache = new Map(); 
const METADATA_CACHE_TTL = 30 * 1000; 

let pluginsCache = {};
let disabledFeatures = {};
let usersDbCache = {}; 
let groupsDbCache = {};

let globalSettings = {
    publicMode: true,       
    limitMode: true,        
    privateLimit: 10,       
    groupLink: "https://chat.whatsapp.com/C6KcF2yIWk39eC6KArmWm5"
};

const altJidCache = new Map();

// --- MAP CONFESS (GLOBAL MEMORY) ---
// Ini adalah "Kotak" penyimpanan ID pesan confess
// Diexport agar bisa diisi oleh plugin menfess
const CONFESSION_MAP = new Map();

// --- DEBOUNCE SAVE ---
let saveTimeout = null;
const DEBOUNCE_MS = 2000; 

async function debouncedSaveDatabase() {
    if (saveTimeout) clearTimeout(saveTimeout);
    saveTimeout = setTimeout(async () => {
        try {
            await Promise.all([
                fs.writeFile(dbPath, JSON.stringify(usersDbCache, null, 2)),
                fs.writeFile(groupDbPath, JSON.stringify(groupsDbCache, null, 2)),
                fs.writeFile(settingsPath, JSON.stringify(globalSettings, null, 2)),
                fs.writeFile(featuresPath, JSON.stringify(disabledFeatures, null, 2)) 
            ]);
        } catch (e) {
            log.err(`Gagal menyimpan database: ${e.message}`);
        }
        saveTimeout = null;
    }, DEBOUNCE_MS);
}

// --- INIT DATABASE ---
async function initDatabase() {
    try {
        log.info('🔄 Pre-loading Database...');
        try { usersDbCache = JSON.parse(await fs.readFile(dbPath, 'utf8')); } catch { usersDbCache = {}; }
        try { groupsDbCache = JSON.parse(await fs.readFile(groupDbPath, 'utf8')); } catch { groupsDbCache = {}; }
        try { disabledFeatures = JSON.parse(await fs.readFile(featuresPath, 'utf8')); } catch { disabledFeatures = {}; }
        try { 
            const sets = JSON.parse(await fs.readFile(settingsPath, 'utf8'));
            globalSettings = { ...globalSettings, ...sets };
        } catch { }

        rebuildAltJidCache();
        log.info(`✅ Database Ready: ${Object.keys(usersDbCache).length} users loaded.`);
    } catch (error) {
        log.err('Database Init Fatal Error: ' + error.message);
        usersDbCache = usersDbCache || {};
        groupsDbCache = groupsDbCache || {};
        disabledFeatures = disabledFeatures || {};
    }
}
await initDatabase();

function rebuildAltJidCache() {
    altJidCache.clear();
    for (const mainJid in usersDbCache) {
        const user = usersDbCache[mainJid];
        if (user.altJids && Array.isArray(user.altJids)) {
            user.altJids.forEach(alt => altJidCache.set(alt, mainJid));
        }
    }
}

async function loadDisabledFeatures() {
    try {
        const data = await fs.readFile(featuresPath, 'utf8');
        disabledFeatures = JSON.parse(data);
    } catch { 
        disabledFeatures = {}; 
        await fs.writeFile(featuresPath, JSON.stringify({}, null, 2));
    }
    log.info(`✅ Disabled features reloaded.`);
}

// --- LOAD PLUGINS & AUTO REPORT ERROR ---
async function loadPlugins(sock = null) {
    log.info('🔄 Memuat plugin...');
    const newPluginsCache = {};
    let pluginFiles = [];
    const ownerJid = jidNormalizedUser(cfg.owner + '@s.whatsapp.net');

    try {
        pluginFiles = (await fs.readdir(pluginDir)).filter(f => f.endsWith('.js'));
    } catch (e) {
        log.err("Gagal membaca folder plugins");
        return;
    }

    let errorCount = 0;
    let errorReport = `⚠️ *AUTO REPORT: RELOAD PLUGIN ERROR*\n\n`;

    for (const file of pluginFiles) {
        try {
            const v = Date.now(); // Cache busting
            const pluginModule = await import(`../plugins/${file}?v=${v}`); 
            const plugin = pluginModule.default || pluginModule;
            if (!plugin?.command) continue;

            const commands = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
            const category = plugin.isOwner ? 'Owner' : plugin.category || 'Uncategorized';

            for (const cmd of commands) {
                newPluginsCache[cmd.toLowerCase()] = {
                    file,
                    handler: plugin.handler,
                    isOwner: !!plugin.isOwner,
                    isPremium: !!plugin.isPremium,
                    isAdmin: !!plugin.isAdmin,
                    isBotAdmin: !!plugin.isBotAdmin,
                    isDisabled: disabledFeatures[cmd.toLowerCase()] || false,
                    category
                };
            }
        } catch (e) {
            errorCount++;
            const errMsg = `❌ File: ${file}\n📉 Err: ${e.message}\n`;
            log.err(`Plugin Error ${file}: ${e.message}`);
            errorReport += errMsg + '\n';
        }
    }
    pluginsCache = newPluginsCache;
    log.info(`✅ ${Object.keys(pluginsCache).length} commands dimuat.`);

    if (sock && errorCount > 0) {
        try {
            await sock.sendMessage(ownerJid, { text: errorReport.trim() });
        } catch (err) { }
    }
}

// --- UTILS ---
const parseQuoted = (m, sock) => {
    const q = m.message?.extendedTextMessage?.contextInfo;
    if (!q?.quotedMessage) return;
    const mtype = Object.keys(q.quotedMessage)[0];
    const msg = q.quotedMessage[mtype];
    m.quoted = {
        type: mtype,
        id: q.stanzaId,
        sender: q.participant,
        fromMe: q.participant === sock.user.id,
        text: msg?.text || msg?.caption || '',
        message: q.quotedMessage,
        download: async () => {
            const stream = await downloadContentFromMessage(q.quotedMessage[mtype], mtype.replace('Message', ''));
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            return buffer;
        }
    };
};

function mapJid(incomingJid, ownerJid, ownerAltJids) {
    const normalized = jidNormalizedUser(incomingJid);
    const normalizedOwner = jidNormalizedUser(ownerJid);
    if (normalized === normalizedOwner || (ownerAltJids && ownerAltJids.includes(normalized))) {
        return normalizedOwner;
    }
    return altJidCache.get(normalized) || normalized;
}

// --- FITUR DONASI ---
async function sendDonationMessage(sock, jid, caption, url) {
    try {
        const imageResponse = await fetch(url);
        if (!imageResponse.ok) throw new Error(`Failed to fetch image`);
        const imageBuffer = await imageResponse.buffer();
        await sock.sendMessage(jid, { image: imageBuffer, caption: caption });
        return true;
    } catch (e) {
        log.err(`Gagal kirim gambar donasi: ${e.message}`);
        await sock.sendMessage(jid, { text: caption });
        return false;
    }
}

function clockString(ms) {
    let h = isNaN(ms) ? "--" : Math.floor(ms / 3600000);
    let m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
    let s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(":");
}

function formatSize(bytes) {
    if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(2) + " GB";
    if (bytes >= 1048576) return (bytes / 1048576).toFixed(2) + " MB";
    if (bytes >= 1024) return (bytes / 1024).toFixed(2) + " KB";
    return bytes + " bytes";
}

function timeSince(ms) {
    const days = Math.floor(ms / (24 * 60 * 60 * 1000));
    const hours = Math.floor((ms % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
    const minutes = Math.floor((ms % (60 * 60 * 1000)) / (60 * 1000));
    if (days > 0) return `${days} hari`;
    if (hours > 0) return `${hours} jam`;
    return `${minutes} menit`;
}

// --- METADATA FETCHER ---
async function getGroupMetadata(sock, chatId) {
    const now = Date.now();
    if (groupMetadataCache.has(chatId)) {
        const cached = groupMetadataCache.get(chatId);
        if (now < cached.expires) return cached.data;
    }

    try {
        const metadata = await sock.groupMetadata(chatId);
        groupMetadataCache.set(chatId, {
            data: metadata,
            expires: now + METADATA_CACHE_TTL
        });
        return metadata;
    } catch (e) {
        return null;
    }
}

// --- ERROR REPORTING ---
async function reportError(sock, err, m, commandName) {
    const ownerJid = jidNormalizedUser(cfg.owner + '@s.whatsapp.net');
    const senderNum = m.sender.split('@')[0];
    const senderName = m.pushName || "Unknown";

    const text = `⚠️ *AUTO ERROR REPORT*\n\n` +
                 `👤 *User:* ${senderName} (wa.me/${senderNum})\n` +
                 `📝 *Command:* ${cfg.prefix}${commandName}\n` +
                 `📍 *Chat:* ${m.key.remoteJid.endsWith('@g.us') ? 'Group' : 'Private'}\n` +
                 `📉 *Error Log:* ${err.message}\n` +
                 `_Bot tetap berjalan normal._`;
    try {
        await sock.sendMessage(ownerJid, { text });
    } catch {}
}

// --- RENTAL CHECKER ---
setInterval(async () => {
    if (!sockGlobal || !groupsDbCache) return;
    const now = Date.now();
    let isChanged = false;

    for (const groupId in groupsDbCache) {
        const group = groupsDbCache[groupId];
        if (!group.expired) continue; 
        const timeLeft = group.expired - now;
        
        if (timeLeft > 0 && timeLeft <= 86400000 && !group.warningSent) {
            await sockGlobal.sendMessage(groupId, { text: `⚠️ *Sewa Bot Hampir Habis*\nTersisa: ${clockString(timeLeft)}. Hubungi owner untuk perpanjangan.` }).catch(() => {});
            group.warningSent = true;
            isChanged = true;
        }
        if (now >= group.expired) {
            await sockGlobal.sendMessage(groupId, { text: `🛑 *Masa Sewa Habis*\nBot akan keluar otomatis. Terima kasih!` }).catch(() => {});
            await new Promise(r => setTimeout(r, 3000)); 
            await sockGlobal.groupLeave(groupId).catch(() => {});
            delete groupsDbCache[groupId];
            isChanged = true;
        }
    }
    if (isChanged) debouncedSaveDatabase();
}, 60000); 


// --- MAIN HANDLER (MSG) ---
async function Msg(sock, m) {
    try {
        sockGlobal = sock;
        if (!m || !m.message) return;
        if (m.key.fromMe) return; 
        
        const now = Date.now();
        const { key, message, pushName } = m;
        const remoteJid = key.remoteJid;
        const isGroup = remoteJid.endsWith('@g.us');
        
        const ownerConfigJid = jidNormalizedUser(cfg.owner + '@s.whatsapp.net'); 

        m.reply = async (text, opt = {}) => sock.sendMessage(remoteJid, { text, ...opt }, { quoted: m });

        let incomingJid = isGroup ? key.participant : remoteJid;
        if (isGroup && key.participantPn && /@lid$/.test(key.participant)) incomingJid = key.participantPn;
        
        // --- JID NORMALIZATION (FIX PENTING) ---
        // Kita normalisasi di awal agar tidak ada error ID aneh (@lid)
        const normalizedSender = jidNormalizedUser(incomingJid); 
        const finalSenderJid = mapJid(incomingJid, ownerConfigJid, cfg.ownerAltJids); 
        m.sender = finalSenderJid;

        const msgType = Object.keys(message)[0];
        let body = '';
        if (msgType === 'conversation') body = message.conversation;
        else if (msgType === 'imageMessage') body = message.imageMessage.caption;
        else if (msgType === 'videoMessage') body = message.videoMessage.caption;
        else if (msgType === 'extendedTextMessage') body = message.extendedTextMessage.text;
        else if (msgType === 'interactiveResponseMessage') {
            const interactive = message.interactiveResponseMessage;
            body = interactive.nativeFlowResponseMessage?.paramsJson 
                ? JSON.parse(interactive.nativeFlowResponseMessage.paramsJson).id 
                : (interactive.body?.text || "");
        } else if (msgType === 'templateButtonReplyMessage') body = message.templateButtonReplyMessage.selectedId;
        else if (msgType === 'buttonsResponseMessage') body = message.buttonsResponseMessage.selectedButtonId;
        else if (msgType === 'stickerMessage') body = ''; 
        
        body = body || '';
        parseQuoted(m, sock);

        // --- 1. FAST PING ---
        if (body === cfg.prefix) {
            return m.reply(`🤖 Bot *Online*!`);
        }

        const isCommand = body.startsWith(cfg.prefix);
        
        // --- 2. USER DATA INIT ---
        let user = usersDbCache[finalSenderJid];
        let isDbChanged = false;
        
        if (!user) {
            user = usersDbCache[finalSenderJid] = {
                nama: pushName || 'User',
                registered: false,
                limit: globalSettings.privateLimit,
                lastLimitReset: now,
                promoSentToday: false,
                premiumUntil: 0,
                status: 'guest',
                afk: -1,
                afkReason: "",
                lastDonationSent: 0,
                lastPremiumNotif: 0
            };
            isDbChanged = true;
        } else {
             if (user.lastPremiumNotif === undefined) { user.lastPremiumNotif = 0; }
        }

        if (normalizedSender !== finalSenderJid) {
            if (!user.altJids) user.altJids = [];
            if (!user.altJids.includes(normalizedSender)) {
                user.altJids.push(normalizedSender);
                altJidCache.set(normalizedSender, finalSenderJid);
                isDbChanged = true;
            }
        }

        // --- CHECK EXPIRED & NOTIFICATION (PREMIUM) ---
        if (user.premiumUntil > 0 && now > user.premiumUntil) {
            user.premiumUntil = 0;
            user.status = 'user';
            user.lastPremiumNotif = 0;
            await sock.sendMessage(finalSenderJid, { text: "⚠️ Masa aktif Premium Anda telah habis." });
            isDbChanged = true;
        }

        const isOwner = finalSenderJid === ownerConfigJid;
        const isPremium = isOwner || (user.premiumUntil > 0);

        const TWO_DAYS_MS = 48 * 60 * 60 * 1000;
        const ONE_DAY_MS = 24 * 60 * 60 * 1000;

        if (!isOwner && isPremium && user.premiumUntil > 0) {
            const timeRemaining = user.premiumUntil - now;
            if (timeRemaining > 0 && timeRemaining <= TWO_DAYS_MS) {
                const lastNotification = user.lastPremiumNotif || 0;
                if (now - lastNotification > ONE_DAY_MS) {
                    const pesanPremium = `
🔔 *Notifikasi Premium*
Halo Kak ${pushName || 'User'}! 👋
Status Premium Anda akan habis dalam waktu:
⏳ *${timeSince(timeRemaining)}*
`.trim();
                    try {
                        await sock.sendMessage(finalSenderJid, { text: pesanPremium });
                        user.lastPremiumNotif = now;
                        isDbChanged = true;
                    } catch (e) { log.err('Gagal kirim notif prem'); }
                }
            }
        }

        // --- 3. CONFESSION REPLY HANDLER (FIXED) ---
        // Bagian ini menggunakan logika lama TAPI ditambahkan fix untuk LID
        const quotedId = m.quoted?.id;
        if (quotedId && CONFESSION_MAP.has(quotedId)) {
            let originalSenderJid = CONFESSION_MAP.get(quotedId);
            
            // FIX: Normalisasi ID Pengirim Asli (Dari @lid ke @s.wa.net)
            originalSenderJid = jidNormalizedUser(originalSenderJid);
            
            // FIX: Normalisasi ID Penjawab (Untuk notifikasi mention)
            const replierJid = jidNormalizedUser(remoteJid);

            try {
                // Kirim notifikasi ke pengirim asli
                await sock.sendMessage(originalSenderJid, { 
                    text: `💬 *Balasan Menfess*\nDari: @${replierJid.split('@')[0]}`, 
                    mentions: [replierJid] 
                });
                
                // === LOGIKA RELAY (OLD CODE STYLE with FIX) ===
                const currentMsgType = Object.keys(m.message || {})[0];
                if (currentMsgType) {
                    const payload = {};
                    payload[currentMsgType] = m.message[currentMsgType];
                    
                    // Relay pesan ke target
                    await sock.relayMessage(originalSenderJid, payload, { 
                        messageId: m.key.id,
                        participant: { jid: originalSenderJid } 
                    });
                }
                return; // Stop flow
            } catch (e) {
                // Fallback jika relay gagal, kirim text biasa
                log.err(`Confess Fail: ${e.message}`);
                await sock.sendMessage(originalSenderJid, { text: `Pesan balasan (Text): ${body}` });
            }
        }

        // --- 4. AFK SYSTEM ---
        if (user.afk > -1) {
            m.reply(`Kamu berhenti AFK${user.afkReason ? " setelah " + user.afkReason : ""} (${clockString(now - user.afk)})`);
            user.afk = -1;
            user.afkReason = "";
            isDbChanged = true;
        }
        
        let mentions = [...new Set([...(m.message?.extendedTextMessage?.contextInfo?.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])];
        for (let jid of mentions) {
            const targetJid = mapJid(jid, ownerConfigJid, cfg.ownerAltJids);
            const targetUser = usersDbCache[targetJid];
            if (targetUser && targetUser.afk > -1) {
                await m.reply(`Jangan tag dia! Sedang AFK: ${targetUser.afkReason || "Tanpa alasan"}\nSelama: ${clockString(now - targetUser.afk)}`);
            }
        }

        // --- 5. DONASI HARIAN ---
        if (!isGroup && !isCommand && !quotedId) {
            const ONE_DAY_MS = 24 * 60 * 60 * 1000;
            const timeSinceLastDonation = now - (user.lastDonationSent || 0);

            if (timeSinceLastDonation >= ONE_DAY_MS) {
                const DONATION_URL = 'https://cdn.jsdelivr.net/gh/rhamt24/zalxzhu.github.io/images/1764680372103.png';
                const VIDEO_TUTORIAL_URL = 'https://cdn.jsdelivr.net/gh/rhamt24/zalxzhu.github.io/mp4/lv_0_20251227110720.mp4';
                
                const DONATION_CAPTION = 
                    "Halo! 😊 Terima kasih telah menggunakan bot ini.\n\n" +
                    "Untuk membantu kelangsungan biaya server, kami menerima donasi seikhlasnya.\n\n" +
                    "(Pesan ini hanya muncul sekali dalam 24 jam di chat pribadi.)";

                sendDonationMessage(sock, finalSenderJid, DONATION_CAPTION, DONATION_URL)
                    .then(async sent => {
                        if (sent) {
                            try {
                                await sock.sendMessage(finalSenderJid, { 
                                    video: { url: VIDEO_TUTORIAL_URL }, 
                                    caption: "Berikut tutorial cara donasi via scan QRIS ✅"
                                });
                            } catch (e) {
                                log.err('Gagal kirim video tutorial donasi: ' + e.message);
                            }
                            user.lastDonationSent = now;
                            debouncedSaveDatabase();
                        }
                    });
            }
        }

        // --- 6. LIMIT & PUBLIC MODE ---
        if (!isGroup) {
            const lastDate = new Date(user.lastLimitReset).getDate();
            const currDate = new Date(now).getDate();
            if (lastDate !== currDate) {
                user.limit = globalSettings.privateLimit;
                user.lastLimitReset = now;
                user.promoSentToday = false; 
                isDbChanged = true;
            }

            if (isCommand && !isPremium && !isOwner) {
                if (!globalSettings.publicMode) return; 
                
                if (globalSettings.limitMode) {
                    if (user.limit <= 0) {
                        if (!user.promoSentToday) {
                            await m.reply(`🛑 *Limit Harian Habis*\nLimit Anda: 0/${globalSettings.privateLimit}\nLimit akan direset pukul 00:00.\n\nUpgrade ke *Premium* untuk akses tanpa batas!`);
                            user.promoSentToday = true;
                            debouncedSaveDatabase();
                        }
                        return; 
                    }
                    user.limit -= 1;
                    isDbChanged = true;
                } 
            }
        }
        
        if (isDbChanged) debouncedSaveDatabase();
        if (!isCommand) return;
        
        const rawBody = body.slice(cfg.prefix.length).trim();
        const args = rawBody.split(/ +/);
        const cmd = args.shift()?.toLowerCase();
        if (!cmd) return;

        // --- 7. SYSTEM COMMANDS ---
        if (cmd === 'status' || cmd === 'stats') {
             const uptime = process.uptime();
             const mem = process.memoryUsage().rss;
             const statusTxt = `📊 *STATUS BOT*\n\n` +
                 `🖥️ *RAM:* ${formatSize(mem)}\n` +
                 `⏳ *Uptime:* ${clockString(uptime * 1000)}\n` +
                 `👥 *Users:* ${Object.keys(usersDbCache).length}\n` +
                 `🏢 *Groups:* ${Object.keys(groupsDbCache).length}\n` +
                 `--------------------------\n` +
                 `🔓 *Mode Public:* ${globalSettings.publicMode ? '✅ ON' : '❌ OFF'}\n` +
                 `📉 *Mode Limit:* ${globalSettings.limitMode ? '✅ ON' : '❌ OFF'}\n` +
                 `🔢 *Limit User:* ${globalSettings.privateLimit} / hari`;
             return m.reply(statusTxt);
        }

        if (isOwner) {
            switch (cmd) {
                case 'join': {
                    if (!args[0] || !args[1]) return m.reply(`❌ Format: ${cfg.prefix}join <link> <hari>`);
                    const days = parseInt(args[1]);
                    if (isNaN(days)) return m.reply('❌ Hari harus angka.');
                    const codeMatch = args[0].match(/chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i);
                    const code = codeMatch ? codeMatch[1] : null;
                    if (!code) return m.reply('❌ Link grup tidak valid.');
                    try {
                        const res = await sock.groupAcceptInvite(code);
                        if (!res) throw new Error("Gagal join");
                        groupsDbCache[res] = {
                            id: res,
                            expired: now + (days * 24 * 3600 * 1000),
                            joinedAt: now,
                            warningSent: false
                        };
                        m.reply(`✅ Sukses join ke ${res}\n⏳ Mengirim salam...`);
                        await new Promise(r => setTimeout(r, 3000));
                        await sock.sendMessage(res, { text: `✅ *Bot Berhasil Join!*\nSewa aktif: ${days} Hari.` });
                        debouncedSaveDatabase();
                    } catch (e) {
                        m.reply(`❌ Gagal join: ${e.message}`);
                    }
                    return;
                }
                case 'resetalllimit': {
                    let totalUsers = 0;
                    for (const jid in usersDbCache) {
                        usersDbCache[jid].limit = globalSettings.privateLimit;
                        usersDbCache[jid].promoSentToday = false; 
                        totalUsers++;
                    }
                    debouncedSaveDatabase();
                    m.reply(`✅ Reset limit sukses untuk ${totalUsers} user.`);
                    return;
                }
                case 'public': {
                    if (!args[0]) return m.reply(`Mode: ${globalSettings.publicMode ? 'ON' : 'OFF'}\nGunakan on/off`);
                    globalSettings.publicMode = args[0].toLowerCase() === 'on';
                    m.reply(`✅ Public Mode: ${globalSettings.publicMode ? 'ON' : 'OFF'}`);
                    debouncedSaveDatabase();
                    return;
                }
                case 'limitmode': {
                    if (!args[0]) return m.reply(`Mode: ${globalSettings.limitMode ? 'ON' : 'OFF'}\nGunakan on/off`);
                    globalSettings.limitMode = args[0] === 'on';
                    m.reply(`✅ Limit Mode: *${globalSettings.limitMode ? 'ON' : 'OFF'}*`);
                    debouncedSaveDatabase();
                    return;
                }
                case 'setlimit': {
                    const num = parseInt(args[0]);
                    if (isNaN(num)) return m.reply(`❌ Masukkan angka.`);
                    globalSettings.privateLimit = num;
                    m.reply(`✅ Limit Global diubah: ${num}\n(Efektif saat reset harian/user baru)`);
                    debouncedSaveDatabase();
                    return;
                }
                case 'reload': {
                    await loadDisabledFeatures();
                    await loadPlugins(sock); 
                    m.reply('✅ Plugins & Features reloaded');
                    return;
                }
                case 'disable': {
                    if (!args[0]) return m.reply(`❌ Contoh: ${cfg.prefix}disable tiktok`);
                    const targetCmd = args[0].toLowerCase();
                    disabledFeatures[targetCmd] = true;
                    await fs.writeFile(featuresPath, JSON.stringify(disabledFeatures, null, 2));
                    if (pluginsCache[targetCmd]) pluginsCache[targetCmd].isDisabled = true;
                    m.reply(`✅ Fitur *${targetCmd}* dinonaktifkan.`);
                    return;
                }
                case 'enable': {
                    if (!args[0]) return m.reply(`❌ Contoh: ${cfg.prefix}enable tiktok`);
                    const targetCmd = args[0].toLowerCase();
                    if (disabledFeatures[targetCmd]) {
                        delete disabledFeatures[targetCmd];
                        await fs.writeFile(featuresPath, JSON.stringify(disabledFeatures, null, 2));
                        if (pluginsCache[targetCmd]) pluginsCache[targetCmd].isDisabled = false;
                        m.reply(`✅ Fitur *${targetCmd}* diaktifkan kembali.`);
                    } else {
                        m.reply(`ℹ️ Fitur ${targetCmd} tidak dalam keadaan nonaktif.`);
                    }
                    return;
                }
            }
        }

        // --- 8. PLUGIN EXECUTION ---
        const pluginEntry = pluginsCache[cmd];
        if (!pluginEntry) return;

        let isAdmin = false; 
        let groupMetadata = null;
        let participants = [];
        let botIsAdmin = false;

        if (isGroup) {
            if (pluginEntry.isAdmin || pluginEntry.isBotAdmin || pluginEntry.category === 'group') {
                groupMetadata = await getGroupMetadata(sock, remoteJid);
                if (groupMetadata) {
                    participants = groupMetadata.participants;
                    const botJid = jidNormalizedUser(sock.user.id);
                    const botP = participants.find(p => jidNormalizedUser(p.id) === botJid);
                    botIsAdmin = botP?.admin === 'admin' || botP?.admin === 'superadmin';
                    if (!isOwner) {
                        const participant = participants.find(p => jidNormalizedUser(p.id) === normalizedSender);
                        isAdmin = participant?.admin === 'admin' || participant?.admin === 'superadmin';
                    }
                }
            }
        }

        if (isOwner) isAdmin = true;

        if (pluginEntry.isDisabled) return m.reply('🚫 Fitur ini sedang dinonaktifkan oleh Owner.');
        if (pluginEntry.isOwner && !isOwner) return m.reply('🚫 Khusus Owner.');
        if (pluginEntry.isPremium && !isPremium) return m.reply('🚫 Khusus Premium.');
        
        if (pluginEntry.isAdmin && !isAdmin) return m.reply('🚫 Fitur ini Khusus Admin Grup.');
        if (pluginEntry.isBotAdmin && !botIsAdmin) return m.reply('🚫 Bot harus menjadi Admin untuk menggunakan fitur ini.');

        try {
            await pluginEntry.handler({
                sock, msg: m, args, command: cmd, from: remoteJid, pushName,
                isOwner, isPremium, db: usersDbCache, saveDatabase: debouncedSaveDatabase,
                sender: m.sender, isGroup, isAdmin, botIsAdmin, groupMetadata, participants,
                // Passing Confess Map ke plugin agar mereka sinkron
                confessMap: CONFESSION_MAP 
            });
        } catch (err) {
            m.reply(`❌ *Terjadi Kesalahan!* \nLaporan error otomatis dikirim ke Owner.`);
            await reportError(sock, err, m, cmd);
            log.err(`CMD ERROR ${cmd}: ${err.message}`);
        }

    } catch (e) {
        log.err(`Msg Fatal Error: ${e.message}`);
    }
}

// Export CONFESSION_MAP di sini sangat penting
export { loadPlugins, loadDisabledFeatures, pluginsCache, CONFESSION_MAP };
export default Msg;
