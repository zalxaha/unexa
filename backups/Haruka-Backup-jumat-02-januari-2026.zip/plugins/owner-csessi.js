import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const sessionFolder = path.join(__dirname, '../session');

const handler = async ({ sock, msg, isOwner }) => {
    
    if (!isOwner) {
        return msg.reply('🚫 *Command ini hanya untuk Owner.*');
    }

    try {
        const files = await fs.readdir(sessionFolder);
        let deletedCount = 0;
        const credsFile = 'creds.json';

        for (const file of files) {
            if (file === credsFile) {
                // Lewati creds.json
                continue;
            }

            const filePath = path.join(sessionFolder, file);
            
            // Cek status file (apakah file atau folder)
            const stat = await fs.stat(filePath);

            if (stat.isFile()) {
                await fs.unlink(filePath);
                deletedCount++;
            } else if (stat.isDirectory()) {
                // Hapus folder secara rekursif
                await fs.rm(filePath, { recursive: true, force: true });
                deletedCount++;
            }
        }

        if (deletedCount > 0) {
            msg.reply(`🗑️ *Pembersihan Sesi Berhasil!*
Menghapus ${deletedCount} file/folder dari folder \`session/\`.
File \`creds.json\` *DIJAGA* agar bot tidak logout.`);
        } else {
            msg.reply('💡 Folder \`session/\` bersih. Tidak ada file/folder lain selain \`creds.json\` yang ditemukan.');
        }

    } catch (e) {
        console.error("Error saat menjalankan csessi:", e);
        msg.reply(`❌ Gagal membersihkan folder sesi: ${e.message}`);
    }
};

export default {
    command: ['csessi', 'clearsession'],
    handler: handler,
    isOwner: true,
    isPremium: false,
    description: 'Menghapus file cache sesi (kecuali creds.json) untuk memperbaiki error sesi.'
};