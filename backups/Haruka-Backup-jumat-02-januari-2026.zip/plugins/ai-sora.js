import axios from 'axios';

const handler = async ({ sock, msg, args, command }) => {
    const text = args.join(" ");
    
    if (!text) {
        return msg.reply(`❌ Masukkan deskripsi video.\n\nContoh: *${command} a flying dragon over mountains*`);
    }

    await sock.sendMessage(msg.key.remoteJid, { react: { text: "⏳", key: msg.key } });

    try {
        // 1. Kirim Task Awal
        const { data: initialResponse } = await axios.get("https://fgsi.dpdns.org/api/ai/sora2", {
            params: {
                apikey: "fgsiapi-2b36a2b4-6d",
                prompt: text,
                ratio: "16:9",
                enhancePrompt: "true",
            }
        });

        if (!initialResponse.status || !initialResponse.data.taskId) {
            throw new Error("Gagal membuat antrean video.");
        }

        const taskId = initialResponse.data.taskId;
        const pollUrl = `http://fgsi.dpdns.org/api/process/task/${taskId}`;
        
        await msg.reply("✅ Permintaan diterima. Sedang merender video, mohon tunggu...");

        // 2. Proses Polling (Cek berkala)
        let videoUrl = null;
        let attempts = 0;
        const maxAttempts = 30; // Maksimal 30 kali cek (sekitar 2-3 menit)

        while (attempts < maxAttempts) {
            const { data: checkStatus } = await axios.get(pollUrl);
            
            // Cek jika status sudah selesai (bukan Pending lagi)
            // Asumsi: Jika sukses, link video ada di data.videoUrl atau data.url
            if (checkStatus.data && checkStatus.data.status === 'Success') {
                videoUrl = checkStatus.data.videoUrl || checkStatus.data.url;
                break;
            }

            // Jika status gagal dari server
            if (checkStatus.data && checkStatus.data.status === 'Failed') {
                throw new Error("Server gagal memproses video.");
            }

            // Tunggu 5 detik sebelum cek lagi
            await new Promise(resolve => setTimeout(resolve, 5000));
            attempts++;
        }

        if (!videoUrl) {
            throw new Error("Waktu tunggu habis atau video tidak ditemukan.");
        }

        // 3. Kirim Hasil Video
        await sock.sendMessage(msg.key.remoteJid, {
            video: { url: videoUrl },
            caption: `🎥 *Sora AI Result*\n\nPrompt: ${text}`,
        }, { quoted: msg });

        await sock.sendMessage(msg.key.remoteJid, { react: { text: "✅", key: msg.key } });

    } catch (e) {
        console.error(e);
        await msg.reply(`❌ Terjadi kesalahan: ${e.message}`);
        await sock.sendMessage(msg.key.remoteJid, { react: { text: "❌", key: msg.key } });
    }
};

export default {
    command: ['sora', 'aisora'],
    description: 'Generate video AI via FGSI',
    category: 'ai',
    handler,
};