import axios from 'axios';
import cfg from '../config/config.json' with { type: 'json' };
import log from '../lib/logger.js';

// --- CLASS ANIMAGINE XL 4.0 ---
class AnimagineAI {
    constructor() {
        this.url = 'https://asahina2k-animagine-xl-4-0.hf.space';
        this.conf = {
            ratios: {
                '1:1': '1024 x 1024',
                '9:7': '1152 x 896',
                '7:9': '896 x 1152',
                '19:13': '1216 x 832',
                '13:19': '832 x 1216',
                '7:4': '1344 x 768',
                '4:7': '768 x 1344',
                '12:5': '1536 x 640',
                '5:12': '640 x 1536',
                '16:9': '1344 x 768', // Landscape standar
                '9:16': '768 x 1344'  // Portrait HP (Wallpaper)
            },
            styles: ['(None)', 'Anim4gine', 'Painting', 'Pixel art', '1980s', '1990s', '2000s', 'Toon', 'Lineart', 'Art Nouveau', 'Western Comics', '3D', 'Realistic', 'Neonpunk']
        };
    }

    generate = async (prompt, options = {}) => {
        try {
            const {
                negative_prompt = 'lowres, bad anatomy, bad hands, text, error, missing finger, extra digits, fewer digits, cropped, worst quality, low quality, low score, bad score, average score, signature, watermark, username, blurry, nsfw',
                width = 1024,
                height = 1024,
                guidance_scale = 7,
                numInference_steps = 28,
                sampler = 'Euler a',
                aspect_ratio = '1:1',
                style_preset = '(None)',
                use_upscaler = false,
                strength = 0.55,
                upscale_by = 1.5,
                add_quality_tags = true
            } = options;

            // Validasi Input
            const finalRatio = this.conf.ratios[aspect_ratio] ? this.conf.ratios[aspect_ratio] : '1024 x 1024';
            const finalStyle = this.conf.styles.includes(style_preset) ? style_preset : '(None)';

            const session_hash = Math.random().toString(36).substring(2);

            // 1. Request Join Queue
            await axios.post(`${this.url}/queue/join?`, {
                data: [
                    prompt,
                    negative_prompt,
                    Math.floor(Math.random() * 2147483648), // Random Seed
                    width,
                    height,
                    guidance_scale,
                    numInference_steps,
                    sampler,
                    finalRatio,
                    finalStyle,
                    use_upscaler,
                    strength,
                    upscale_by,
                    add_quality_tags
                ],
                event_data: null,
                fn_index: 5,
                trigger_id: 43,
                session_hash: session_hash
            });

            // 2. Stream Status & Result
            const { data } = await axios.get(`${this.url}/queue/data?session_hash=${session_hash}`, {
                responseType: 'text' // Wajib text agar stream terbaca
            });

            // 3. Parsing Result
            let resultUrl = null;
            const lines = data.split('\n\n');
            
            for (const line of lines) {
                if (line.startsWith('data:')) {
                    try {
                        const d = JSON.parse(line.substring(6));
                        if (d.msg === 'process_completed') {
                            resultUrl = d.output.data[0][0].image.url;
                        }
                    } catch (e) {
                        // Abaikan error parsing json parsial
                    }
                }
            }

            if (!resultUrl) throw new Error('API tidak mengembalikan URL gambar. Coba lagi.');
            return resultUrl;

        } catch (error) {
            throw new Error(error.message);
        }
    }
}

const animagine = new AnimagineAI();

// --- HELPER FUNCTIONS ---

// Helper Parse Arguments (--ratio, --style)
function parseArgs(args) {
    const options = {};
    const cleanArgs = [];
    
    for (let i = 0; i < args.length; i++) {
        if (args[i].startsWith('--')) {
            const key = args[i].slice(2);
            const value = args[i + 1];
            if (value && !value.startsWith('--')) {
                options[key] = value;
                i++; 
            }
        } else {
            cleanArgs.push(args[i]);
        }
    }
    return { prompt: cleanArgs.join(' '), options };
}

// Helper Send Reaction (Aman dari error undefined JID)
async function sendReaction(sock, chatId, msgKey, text) {
    if (!chatId) return;
    try {
        await sock.sendMessage(chatId, {
            react: {
                text: text,
                key: msgKey
            }
        });
    } catch (e) {
        // Silent fail jika gagal react
    }
}

// --- EXPORT PLUGIN ---
export default {
    command: ['animagine', 'anime', 'draw'], 
    category: 'ai',
    isPremium: true, // FITUR KHUSUS PREMIUM
    
    handler: async function ({ sock, msg, args, remoteJid, isPremium }) {
        // 1. Ambil ID Chat yang valid
        const chatId = remoteJid || msg.key.remoteJid;
        if (!chatId) return;

        // 2. Parsing Prompt
        const { prompt, options } = parseArgs(args);
        const prefix = cfg.prefix || '.';

        // 3. Tampilan Help (Jika prompt kosong)
        if (!prompt) {
            return sock.sendMessage(chatId, {
                text: `🎨 *ANIMAGINE XL 4.0 (PREMIUM)* 🎨
                
Bot ini bisa menggambar karakter anime berkualitas tinggi dengan berbagai gaya.

📜 *Format Penggunaan:*
${prefix}anime <prompt deskripsi> <opsi>

⚙️ *Opsi Tambahan:*
• *--ratio* : Mengatur ukuran gambar.
  (Pilihan: 1:1, 16:9, 9:16, 3:4)
• *--style* : Mengatur gaya visual.
  (Pilihan: Anime, Realistic, 3D, Lineart, Pixel art)

📝 *Contoh Penggunaan:*

1️⃣ *Gambar Standar (Kotak)*
> ${prefix}anime Naruto makan ramen

2️⃣ *Wallpaper HP (Portrait)*
> ${prefix}anime Hatsune Miku, futuristic city, night --ratio 9:16

3️⃣ *Pemandangan Cinematic (Landscape)*
> ${prefix}anime Sunset di pantai, awan estetik --ratio 16:9 --style Realistic

4️⃣ *Gaya Sketsa (Lineart)*
> ${prefix}anime Gadis kacamata sedang membaca --style Lineart

_Note: Semakin detail bahasa Inggris pada prompt, semakin bagus hasilnya._`
            }, { quoted: msg });
        }

        // 4. Proses Generate Image
        try {
            await sendReaction(sock, chatId, msg.key, '🎨');
            
            // Mapping opsi user ke config API
            const generateOptions = {};
            if (options.ratio) generateOptions.aspect_ratio = options.ratio;
            if (options.style) generateOptions.style_preset = options.style;

            // Eksekusi API
            const imageUrl = await animagine.generate(prompt, generateOptions);

            await sendReaction(sock, chatId, msg.key, '✅');
            
            // Kirim Hasil
            await sock.sendMessage(chatId, { 
                image: { url: imageUrl }, 
                caption: `🎨 *Animagine Generated*\n\nPrompt: ${prompt}\nStyle: ${generateOptions.style_preset || 'Default'}\nRatio: ${generateOptions.aspect_ratio || '1:1'}` 
            }, { quoted: msg });

        } catch (e) {
            log.err("Animagine Error:", e.message);
            await sendReaction(sock, chatId, msg.key, '❌'); 
            
            return sock.sendMessage(chatId, { 
                text: `❌ *Gagal Membuat Gambar*\n\nPenyebab: ${e.message}\n\nCoba gunakan prompt yang lebih sederhana atau coba lagi nanti.` 
            }, { quoted: msg });
        }
    }
};