import { parsePhoneNumber } from 'libphonenumber-js';
import { jidNormalizedUser } from '@whiskeysockets/baileys'; // Tambahkan ini
import cfg from '../config/config.json' with { type: 'json' };

// HAPUS IMPORT CONFESSION_MAP DARI SINI AGAR TIDAK ERROR CIRCULAR DEPENDENCY
// import { CONFESSION_MAP } from '../handlers/messageHandler.js'; 

const cooldowns = new Map();
const COOLDOWN_SECONDS = 60; 

export default {
    command: ['confes'],
    category: 'User', 
    isOwner: false, 
    isPremium: false,
    // Tambahkan 'confessMap' di dalam kurung kurawal di bawah ini
    handler: async ({ sock, msg, args, sender, confessMap }) => {
        
        const now = Date.now();
        
        // Normalisasi Sender (PENTING AGAR TIDAK ERROR REPLY)
        // Kita pastikan yang disimpan adalah @s.whatsapp.net, bukan @lid
        const realSender = jidNormalizedUser(sender);

        if (cooldowns.has(realSender)) {
            const expirationTime = cooldowns.get(realSender) + COOLDOWN_SECONDS * 1000;
            if (now < expirationTime) {
                const timeLeft = Math.ceil((expirationTime - now) / 1000);
                return msg.reply(`🚫 Tunggu *${timeLeft} detik* sebelum mengirim konfesi lagi.`);
            }
        }

        if (args.length < 2) {
            return msg.reply(`
❌ Format salah.
*Gunakan:* ${cfg.prefix}confes [nomor target] [pesan]

Contoh: ${cfg.prefix}confes 62812345678 Aku suka kamu dari lama...
            `);
        }

        let targetNumber = args[0].replace(/[^0-9]/g, "");
        if (!targetNumber.startsWith('+')) targetNumber = '+' + targetNumber;
        
        let targetJid;
        try {
            const pn = parsePhoneNumber(targetNumber);
            if (!pn || !pn.isValid()) {
                return msg.reply("❌ Nomor target tidak valid atau tidak dikenali.");
            }
            targetJid = pn.number.replace('+', '') + '@s.whatsapp.net';
        } catch (e) {
            return msg.reply("❌ Nomor target tidak valid.");
        }
        
        // Cek ID normalisasi
        if (targetJid === realSender) {
            return msg.reply("❌ Anda tidak bisa mengirim konfesi ke diri sendiri.");
        }

        const confessionMessage = args.slice(1).join(' ').trim();
        
        if (confessionMessage.length < 15) {
            return msg.reply("❌ Pesan konfesi terlalu pendek. Minimal 15 karakter.");
        }

        const anonymousHeader = `
💌 *KONFESI ANONIM* 💌

Seseorang ingin menyampaikan ini kepada Anda:
----------------------------------------

*Pesan:*
${confessionMessage}

----------------------------------------
*Catatan:* Balas pesan ini untuk membalas konfesi secara anonim.
        `.trim();
        
        try {
            const sentMsg = await sock.sendMessage(
                targetJid,
                { text: anonymousHeader }
            );

            if (sentMsg?.key?.id) {
                // GUNAKAN confessMap DARI PARAMETER, JANGAN DARI IMPORT
                // Simpan ID Pesan -> ID Pengirim Asli (yang sudah dinormalisasi)
                confessMap.set(sentMsg.key.id, realSender);
                
                cooldowns.set(realSender, now);
                
                await msg.reply(`✅ Konfesi Anda berhasil dikirimkan kepada @${targetJid.split('@')[0]}.`);
            } else {
                throw new Error("Pesan gagal terkirim atau tidak memiliki ID.");
            }
            
        } catch (e) {
            console.error("Gagal mengirim konfesi:", e);
            await msg.reply(`❌ Gagal mengirim konfesi. Pastikan bot dan target berada di grup yang sama jika Anda mengirim dari grup, atau target telah menyimpan nomor bot. Error: ${e.message}`);
        }
    }
};