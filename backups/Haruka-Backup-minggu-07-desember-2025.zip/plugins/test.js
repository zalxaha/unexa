import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

// --- [ SETUP PATH & DATABASE ] ---

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url);

const dataDir = path.join(__dirname, '../data');
const combatDataFile = path.join(dataDir, 'combatData.json');

let userData = {};
let partiesData = {}; 

// --- [ KONSTANTA GAME ] ---

const CONFIG = {
    initialHP: 100,
    initialEnergy: 50,
    energyRecharge: 10,
    hpRecharge: 5,
    levelUpExp: 150,
    maxPartySize: 4 
};

// 1. DATA ROLE
const ROLES = {
    fighter: { name: 'Fighter', hp: 20, atk: 10, def: 5, desc: 'Petarung jarak dekat seimbang.' },
    tank: { name: 'Tank', hp: 50, atk: 2, def: 15, desc: 'Pertahanan tinggi, HP tebal.' },
    mage: { name: 'Mage', hp: 10, atk: 18, def: 2, desc: 'Magic damage tinggi, fisik lemah.' },
    archer: { name: 'Archer', hp: 15, atk: 14, def: 3, desc: 'Serangan cepat & akurat.' },
    assassin: { name: 'Assassin', hp: 5, atk: 22, def: 1, desc: 'Damage nuker sangat tinggi, tapi sangat lembek.' },
    paladin: { name: 'Paladin', hp: 40, atk: 5, def: 10, desc: 'Ksatria suci, pertahanan & healing.' }
};

// 2. DATA SKILL
const SKILL_TREE = {
    'bash': { name: 'Heavy Bash', type: 'attack', baseDmg: 20, cost: 10, unlockCost: 200, upgradeCost: 150, desc: 'Pukulan keras (Dmg +5/lvl).' },
    'fireball': { name: 'Fireball', type: 'attack', baseDmg: 35, cost: 20, unlockCost: 500, upgradeCost: 300, desc: 'Bola api besar (Dmg +10/lvl).' },
    'shadowstrike': { name: 'Shadow Strike', type: 'attack', baseDmg: 45, cost: 15, unlockCost: 700, upgradeCost: 400, desc: 'Serangan dadakan (Assassin Skill).' },
    'heal': { name: 'Holy Light', type: 'heal', baseHeal: 30, cost: 25, unlockCost: 400, upgradeCost: 200, desc: 'Memulihkan HP (Heal +10/lvl).' },
    'berserk': { name: 'Berserk Mode', type: 'buff', effect: 'atk', amount: 10, cost: 15, unlockCost: 600, upgradeCost: 400, desc: 'Buff ATK sementara (ATK +2/lvl).' }
};

// 3. DATA ITEM
const SHOP_ITEMS = {
    potions: [
        { id: 'hp_potion', name: 'HP Potion', price: 20, type: 'heal', val: 30, desc: 'Pulihkan 30 HP.' },
        { id: 'str_potion', name: 'Strength Potion', price: 50, type: 'buff', stat: 'atk', val: 15, desc: 'Tambah 15 ATK selama 1 battle.' }
    ],
    upgrades: [
        { id: 'upgrade_armor', name: 'Tempa Armor', price: 300, type: 'stat_up', stat: 'def', val: 3, desc: 'Permanen +3 DEF.' },
        { id: 'upgrade_hp', name: 'Latihan Fisik', price: 250, type: 'stat_up', stat: 'hpMax', val: 20, desc: 'Permanen +20 Max HP.' }
    ],
    artifacts: [
        { id: 'dragon_heart', name: 'Jantung Naga', price: 5000, type: 'artifact', hp: 100, atk: 20, def: 10, desc: 'Artefak Legendaris. HP+100.' },
        { id: 'demon_sword', name: 'Pedang Iblis', price: 3500, type: 'artifact', hp: 0, atk: 50, def: -5, desc: 'Kekuatan besar dengan harga pertahanan.' },
        { id: 'assassin_cloak', name: 'Jubah Bayangan', price: 4000, type: 'artifact', hp: 20, atk: 30, def: 5, desc: 'Cocok untuk Assassin.' }
    ]
};

// 4. DATA MONSTER
const MONSTERS = [
    { name: 'Slime', level: 1, hp: 40, atk: 5, def: 0, gold: 10, exp: 15 },
    { name: 'Wolf', level: 3, hp: 80, atk: 12, def: 2, gold: 25, exp: 30 },
    { name: 'Orc', level: 5, hp: 150, atk: 20, def: 5, gold: 50, exp: 60 },
    { name: 'Golem', level: 8, hp: 300, atk: 25, def: 20, gold: 100, exp: 120 },
    { name: 'Dark Knight', level: 12, hp: 500, atk: 40, def: 15, gold: 250, exp: 250 },
    { name: 'Naga Purba', level: 20, hp: 1000, atk: 70, def: 30, gold: 1000, exp: 1000, isBoss: true, drop: 'dragon_heart' }
];

// --- [ UTILITY DATABASE ] ---

async function loadUserData() {
    try {
        await fs.access(path.dirname(combatDataFile)).catch(() => fs.mkdir(path.dirname(combatDataFile), { recursive: true }));
        const content = await fs.readFile(combatDataFile, 'utf8');
        const data = content.trim() ? JSON.parse(content) : {};
        
        userData = data.users || {};
        partiesData = data.parties || {};
    } catch (e) {
        userData = {};
        partiesData = {};
        console.log("Database dibuat baru.");
    }
}

async function saveUserData() {
    const dataToSave = {
        users: userData,
        parties: partiesData
    };
    await fs.writeFile(combatDataFile, JSON.stringify(dataToSave, null, 2), 'utf8');
}

await loadUserData();

// --- [ UTILITY PLAYER ] ---

function getPlayer(userId) {
    if (!userData[userId]) {
        userData[userId] = {};
    }

    const u = userData[userId];

    // AUTO-FIX/Initial Setup
    if (!u.stats) u.stats = {
        hp: CONFIG.initialHP, hpMax: CONFIG.initialHP,
        atk: 10, def: 5, energy: CONFIG.initialEnergy,
        level: 1, exp: 0, gold: 200, role: null
    };
    
    if (!u.partyId) u.partyId = null;
    if (!Array.isArray(u.inventory)) u.inventory = [];
    if (!Array.isArray(u.artifacts)) u.artifacts = [];
    if (typeof u.skills !== 'object') u.skills = {};

    return u;
}

function calculateTotalStats(player) {
    let base = { ...player.stats };
    
    if (player.stats.role && ROLES[player.stats.role]) {
        const r = ROLES[player.stats.role];
        base.hpMax += r.hp; base.atk += r.atk; base.def += r.def;
    }
    player.artifacts.forEach(artId => {
        const art = SHOP_ITEMS.artifacts.find(a => a.id === artId);
        if (art) {
            base.hpMax += (art.hp || 0); base.atk += (art.atk || 0); base.def += (art.def || 0);
        }
    });
    
    // Check Active Battle (Solo) or Party Battle Buffs
    // Note: This needs context, simplified for now
    if (player.activeBattle && player.activeBattle.buffs) {
        base.atk += (player.activeBattle.buffs.atk || 0); base.def += (player.activeBattle.buffs.def || 0);
    }

    return base;
}



// --- [ BATTLE MODULE (UPDATED) ] ---

const BattleModule = {
    start: (userId, player) => {
        if (!player.stats.role) return `❌ Pilih Role dulu! Ketik *.role*.`;
        
        // Cek apakah player sedang battle SOLO
        if (player.activeBattle) return `⚔️ Anda sedang bertarung (Solo)! Selesaikan dulu.`;

        // --- LOGIKA PARTY START ---
        if (player.partyId) {
            const party = partiesData[player.partyId];
            if (!party) { player.partyId = null; return "❌ Party error."; }

            // Cek apakah party SUDAH battle
            if (party.activeBattle) {
                return `⚔️ Party *${party.name}* sedang bertarung melawan **${party.activeBattle.monster.name}**!\nLangsung ketik *.attack* untuk bantu temanmu!`;
            }

            // SETUP MONSTER UNTUK PARTY (Scaling stats)
            const eligibleMonsters = MONSTERS.filter(m => Math.abs(m.level - player.stats.level) < 5 || m.level <= player.stats.level);
            const rawMonster = eligibleMonsters.length > 0 
                ? eligibleMonsters[Math.floor(Math.random() * eligibleMonsters.length)]
                : MONSTERS[0];
            
            const multiplier = party.members.length; // Monster makin kuat jika party ramai
            const scaledMonster = {
                ...rawMonster,
                hpMax: rawMonster.hp * multiplier, // HP dikali jumlah member
                hpCurrent: rawMonster.hp * multiplier,
                atk: Math.floor(rawMonster.atk + (multiplier * 2)), // Sedikit buff ATK
                gold: rawMonster.gold * multiplier, // Gold dikali agar pembagian adil
                exp: rawMonster.exp * multiplier 
            };

            party.activeBattle = {
                monster: scaledMonster,
                turn: 1,
                buffs: { atk: 0, def: 0 },
                log: [],
                isParty: true
            };

            // Reset HP Player saat start
            player.stats.hp = calculateTotalStats(player).hpMax;

            return `📢 *PARTY BATTLE STARTED!*\n` +
                   `Musuh: *${scaledMonster.name}* (Titan Mode)\n` +
                   `HP: ${scaledMonster.hpCurrent} (x${multiplier} Player Scale)\n\n` +
                   `⚔️ SEMUA ANGGOTA PARTY BISA MENYERANG SEKARANG!\n` +
                   `Ketik *.attack* atau *.skill* untuk join fight!`;
        }

        // --- LOGIKA SOLO START (DEFAULT) ---
        const eligibleMonsters = MONSTERS.filter(m => Math.abs(m.level - player.stats.level) < 5 || m.level <= player.stats.level);
        const randomMonster = eligibleMonsters.length > 0 
            ? eligibleMonsters[Math.floor(Math.random() * eligibleMonsters.length)]
            : MONSTERS[0];
        
        player.activeBattle = {
            monster: { ...randomMonster, hpCurrent: randomMonster.hp, hpMax: randomMonster.hp },
            turn: 1,
            buffs: { atk: 0, def: 0 },
            log: [],
            isParty: false
        };
        player.stats.hp = calculateTotalStats(player).hpMax;

        return `⚔️ *SOLO BATTLE START!*\n\n` +
               `Musuh: *${randomMonster.name}* (Lv ${randomMonster.level})\n` +
               `HP: ${randomMonster.hp} | ATK: ${randomMonster.atk}\n\n` +
               `Giliranmu! Ketik *.attack* atau *.skill [id]*`;
    },

    attack: (userId, player, type = 'basic', skillId = null) => {
        let battle = player.activeBattle;
        let party = null;

        // 1. Cek Priority: Apakah ada Party Battle?
        if (!battle && player.partyId) {
            party = partiesData[player.partyId];
            if (party && party.activeBattle) {
                battle = party.activeBattle; // Gunakan instance battle milik Party
            }
        }

        if (!battle) return `❌ Tidak ada battle. Ketik *.start*.`;

        const totalStats = calculateTotalStats(player);
        const monster = battle.monster;
        let playerDmg = 0;
        let energyCost = 0;

        // --- PLAYER TURN ---
        if (type === 'basic') {
            playerDmg = Math.max(1, totalStats.atk - (monster.def / 2));
            playerDmg = Math.floor(playerDmg * (0.9 + Math.random() * 0.2));
        } else if (type === 'skill' && skillId) {
            const skillData = SKILL_TREE[skillId];
            const skillLvl = player.skills[skillId];

            if (!skillLvl) return `❌ Skill *${skillId}* belum dipelajari.`;
            if (player.stats.energy < skillData.cost) return `❌ Energi kurang.`;

            energyCost = skillData.cost;

            if (skillData.type === 'attack') {
                let skillPower = skillData.baseDmg + (skillLvl * 8) + (totalStats.atk * 0.6);
                playerDmg = Math.floor(skillPower);
            } else if (skillData.type === 'heal') {
                let healAmount = skillData.baseHeal + (skillLvl * 10);
                player.stats.hp = Math.min(totalStats.hpMax, player.stats.hp + healAmount);
                playerDmg = 0;
                battle.log.push(`✨ ${player.stats.role || 'Player'} memulihkan +${healAmount} HP.`);
            } else if (skillData.type === 'buff') {
                let buffAmount = skillData.amount + (skillLvl * 3);
                battle.buffs[skillData.effect] += buffAmount;
                playerDmg = 0;
                battle.log.push(`🔥 ${skillData.name}: ${skillData.effect.toUpperCase()} +${buffAmount}!`);
            }
        }

        player.stats.energy -= energyCost;
        if (playerDmg > 0) {
            monster.hpCurrent -= playerDmg;
            battle.log.push(`🗡️ @${userId.split('@')[0]} menyerang: *${playerDmg} DMG*`);
        }

        // --- WIN CONDITION (HANDLE PARTY & SOLO) ---
        if (monster.hpCurrent <= 0) {
            let winMsg = `🏆 *VICTORY!*\nMusuh ${monster.name} dikalahkan!\n\n`;

            if (battle.isParty && party) {
                // DISTRIBUSI REWARD KE SEMUA MEMBER
                const shareGold = Math.floor(monster.gold / party.members.length);
                const shareExp = Math.floor(monster.exp / party.members.length);
                
                winMsg += `🤝 *PARTY REWARDS (Dibagi Rata)*:\n`;
                
                party.members.forEach(mId => {
                    const member = userData[mId];
                    if (member) {
                        member.stats.gold += shareGold;
                        member.stats.exp += shareExp;
                        
                        // Level Up Logic Member
                        const reqExp = member.stats.level * CONFIG.levelUpExp;
                        if (member.stats.exp >= reqExp) {
                            member.stats.level++;
                            member.stats.exp -= reqExp;
                            member.stats.hpMax += 15; member.stats.atk += 3;
                        }
                    }
                });
                winMsg += `💰 +${shareGold} Gold/orang\n⭐ +${shareExp} Exp/orang`;
                
                party.activeBattle = null; // Hapus battle dari party
            } else {
                // SOLO REWARD
                player.stats.gold += monster.gold;
                player.stats.exp += monster.exp;
                
                const reqExp = player.stats.level * CONFIG.levelUpExp;
                if (player.stats.exp >= reqExp) {
                    player.stats.level++;
                    player.stats.exp -= reqExp;
                    player.stats.hpMax += 15; player.stats.atk += 3;
                    winMsg += `🎉 *LEVEL UP!* (Lv ${player.stats.level})\n`;
                }
                winMsg += `💰 +${monster.gold} G | ⭐ +${monster.exp} XP`;
                player.activeBattle = null;
            }

            return winMsg;
        }

        // --- MONSTER TURN (COUNTER ATTACK) ---
        // Monster menyerang balik orang yang baru saja memukulnya
        let monsterDmg = Math.max(1, monster.atk - totalStats.def);
        player.stats.hp -= monsterDmg;
        
        battle.log.push(`👾 ${monster.name} membalas @${userId.split('@')[0]}: *-${monsterDmg} HP*`);

        let result = `*TURN ${battle.turn}* ${battle.isParty ? '(PARTY MODE)' : ''}\n` + battle.log.join('\n') + `\n\n`;
        battle.log = []; // Clear log turn ini
        
        result += `❤️ HP Kamu: ${player.stats.hp}/${totalStats.hpMax}\n`;
        result += `🩸 BOSS: ${monster.hpCurrent}/${monster.hpMax}`;

        if (player.stats.hp <= 0) {
            player.stats.hp = 10; // Sekarat tapi tidak mati permanen
            // Jika party, player ini cuma KO, teman lain masih bisa lanjut
            if(battle.isParty) {
                 result += `\n\n💀 *KO!* Anda pingsan dan mundur dari pertarungan. Temanmu harus menyelesaikannya!`;
            } else {
                 player.activeBattle = null;
                 result += `\n\n💀 *KALAH!* Anda pingsan.`;
            }
        }

        battle.turn++;
        return result;
    }
};

// --- [ SHOP MODULE ] ---

const ShopModule = {
    buy: (userId, player, itemId) => {
        itemId = itemId.toLowerCase();
        
        let item = SHOP_ITEMS.potions.find(i => i.id === itemId);
        if (item) {
            if (player.stats.gold < item.price) return `❌ Gold kurang.`;
            player.stats.gold -= item.price;
            player.inventory.push(item);
            return `✅ Membeli 1x ${item.name}.`;
        }

        item = SHOP_ITEMS.artifacts.find(i => i.id === itemId);
        if (item) {
            if (player.artifacts.includes(itemId)) return `❌ Anda sudah punya artefak ini!`;
            if (player.stats.gold < item.price) return `❌ Gold kurang (Butuh ${item.price}).`;
            player.stats.gold -= item.price;
            player.artifacts.push(itemId);
            return `💎 ARTEFAK DIPEROLEH: ${item.name}!`;
        }

        if (SKILL_TREE[itemId]) {
            if (player.skills[itemId]) return `❌ Skill ini sudah dipelajari.`;
            const skill = SKILL_TREE[itemId];
            if (player.stats.gold < skill.unlockCost) return `❌ Gold kurang (Butuh ${skill.unlockCost}).`;
            
            player.stats.gold -= skill.unlockCost;
            player.skills[itemId] = 1; 
            return `✨ Skill Unlock: *${skill.name}*!`;
        }

        return `❌ Item/Skill tidak ditemukan di shop.`;
    },

    upgrade: (userId, player, targetId) => {
        targetId = targetId.toLowerCase();

        if (SKILL_TREE[targetId]) {
            if (!player.skills[targetId]) return `❌ Belum punya skill ini.`;
            const cost = SKILL_TREE[targetId].upgradeCost * player.skills[targetId];
            if (player.stats.gold < cost) return `❌ Gold kurang. Biaya: ${cost}G.`;
            
            player.stats.gold -= cost;
            player.skills[targetId]++;
            return `🆙 Skill *${SKILL_TREE[targetId].name}* naik ke Level ${player.skills[targetId]}!`;
        }

        const upgradeItem = SHOP_ITEMS.upgrades.find(u => u.id === targetId);
        if (upgradeItem) {
            if (player.stats.gold < upgradeItem.price) return `❌ Gold kurang.`;
            
            player.stats.gold -= upgradeItem.price;
            player.stats[upgradeItem.stat] += upgradeItem.val;
            return `🔨 Upgrade Sukses! Stat ${upgradeItem.stat.toUpperCase()} +${upgradeItem.val}.`;
        }

        return `❌ Target upgrade tidak valid.`;
    }
};

// --- [ PARTY MODULE ] ---

const PartyModule = {
    generatePartyId: (name) => {
        const cleanName = name.replace(/\s/g, '').slice(0, 5).toUpperCase();
        const rand = Math.floor(Math.random() * 900) + 100;
        return `${cleanName}${rand}`;
    },

    create: (userId, player, partyName) => {
        if (player.partyId) return `❌ Anda sudah punya Party. Keluar dulu (.leaveparty).`;
        if (!partyName) return `❌ Masukkan nama party!`;

        const partyId = PartyModule.generatePartyId(partyName);
        
        partiesData[partyId] = {
            id: partyId,
            name: partyName,
            leader: userId,
            members: [userId],
            activeBattle: null // Init battle state party
        };
        player.partyId = partyId;

        return `🎉 Party *${partyName}* dibuat! ID: **${partyId}**.\nAjak teman: *.joinparty ${partyId}*`;
    },

    join: (userId, player, partyId) => {
        if (player.partyId) return `❌ Anda sudah punya Party.`;
        if (!partyId) return `❌ Masukkan ID Party.`;

        const party = partiesData[partyId];
        if (!party) return `❌ Party ID tidak ditemukan.`;
        if (party.members.length >= CONFIG.maxPartySize) return `❌ Party penuh.`;

        party.members.push(userId);
        player.partyId = partyId;

        return `✅ Berhasil gabung Party *${party.name}*!`;
    },

    roster: (userId, player) => {
        if (!player.partyId) return `❌ Anda tidak punya party.`;
        
        const party = partiesData[player.partyId];
        if (!party) {
            player.partyId = null; 
            return `❌ Data party rusak.`;
        }

        let roster = `🛡️ *ROSTER PARTY: ${party.name}*\n\n`;
        if (party.activeBattle) roster += `🔥 *SEDANG BATTLE VS ${party.activeBattle.monster.name}*\n\n`;

        party.members.forEach((memberId, index) => {
            const member = getPlayer(memberId);
            const role = member.stats.role ? ROLES[member.stats.role].name : 'Novice';
            const isLeader = memberId === party.leader ? '👑' : '';
            const contact = memberId.split('@')[0];
            
            roster += `${index + 1}. ${contact} ${isLeader}\n`;
            roster += `   Lv ${member.stats.level} ${role} | HP: ${member.stats.hp}\n`;
        });

        return roster;
    },
    
    leave: (userId, player) => {
        if (!player.partyId) return `❌ Anda tidak dalam party.`;
        
        const party = partiesData[player.partyId];
        if (!party) {
            player.partyId = null;
            return `❌ Party tidak ditemukan.`;
        }

        party.members = party.members.filter(id => id !== userId);
        player.partyId = null;

        let msg = `👋 Anda keluar dari Party *${party.name}*.`;

        if (party.members.length === 0) {
            delete partiesData[party.id];
            msg += `\n💨 Party dibubarkan karena kosong.`;
        } else if (party.leader === userId) {
            party.leader = party.members[0];
            msg += `\n👑 Leader baru: ${party.leader.split('@')[0]}.`;
        }
        
        return msg;
    }
};

// --- [ MAIN COMMAND HANDLER ] ---

const handler = async ({ sock, msg, args, command, sender }) => {
    if (!sender) return;
    
    await loadUserData(); 
    let player = getPlayer(sender);
    let text = '';

    // Auto regen energy (Simple)
    if (!player.activeBattle) {
        player.stats.energy = Math.min(CONFIG.initialEnergy, player.stats.energy + 5);
    }

    try {
        switch (command) {
            case 'guide':
            case 'help':
            case 'menu':
                text = `📖 *MENU RPG BOT* 📖\n\n` +
                    `*⚔️ COMBAT*\n` +
                    `> .start | .attack | .skill [id] | .flee\n\n` +
                    `*👥 PARTY SYSTEM*\n` +
                    `> .createparty [nama]\n` +
                    `> .joinparty [id]\n` +
                    `> .roster (Lihat Anggota)\n` +
                    `> .leaveparty\n\n` +
                    `*Info Party:* Jika satu orang .start, teman se-party tinggal ketik .attack untuk join!\n\n` +
                    `*🏰 ETC*\n` +
                    `> .stats | .shop | .buy | .inv`;
                break;
            
            // --- PARTY COMMANDS ---
            case 'createparty': text = PartyModule.create(sender, player, args.join(' ')); break;
            case 'joinparty': text = PartyModule.join(sender, player, args[0]); break;
            case 'roster': 
            case 'party': text = PartyModule.roster(sender, player); break;
            case 'leaveparty': text = PartyModule.leave(sender, player); break;
            case 'partyid':
                text = player.partyId ? `🆔 ID: *${player.partyId}*` : `❌ Tidak ada party.`;
                break;

            // --- GAME COMMANDS ---
            case 'role':
                if (args[0] && ROLES[args[0].toLowerCase()]) {
                    if (player.stats.role) text = `❌ Role sudah dipilih.`;
                    else {
                        const r = ROLES[args[0].toLowerCase()];
                        player.stats.role = args[0].toLowerCase();
                        player.stats.hpMax += r.hp; player.stats.atk += r.atk; player.stats.def += r.def;
                        player.stats.hp = player.stats.hpMax;
                        text = `✅ Job diambil: *${r.name}*.`;
                    }
                } else {
                    text = `👤 *PILIH ROLE (.role nama)*\n` + Object.keys(ROLES).map(k => `🔸 ${k}`).join(', ');
                }
                break;
                
            case 'stats':
                const tStats = calculateTotalStats(player);
                text = `📊 *STATS* (Party: ${player.partyId || '-'}) \nLv: ${player.stats.level} | Gold: ${player.stats.gold}\nHP: ${player.stats.hp}/${tStats.hpMax} | ATK: ${tStats.atk}`;
                break;
                
            case 'start': text = BattleModule.start(sender, player); break;
            case 'attack': text = BattleModule.attack(sender, player, 'basic'); break;
            case 'skill':
                if (!args[0]) text = `Format: .skill [id]`;
                else text = BattleModule.attack(sender, player, 'skill', args[0].toLowerCase());
                break;

            case 'shop':
                text = `🛒 *SHOP*\nPotions: hp_potion, str_potion\nUpgrades: upgrade_armor, upgrade_hp\nSkills: bash, fireball, heal, berserk`;
                break;
            case 'buy': text = ShopModule.buy(sender, player, args[0]); break;
            case 'upgrade': text = ShopModule.upgrade(sender, player, args[0]); break;
            case 'inv': text = `🎒 Items: ${player.inventory.map(i=>i.name).join(', ') || 'Kosong'}`; break;
            
            case 'use':
                if (!args[0]) { text = `Contoh: .use hp_potion`; break; }
                const idx = player.inventory.findIndex(i => i.id === args[0].toLowerCase());
                if (idx === -1) { text = `❌ Item tidak ada.`; break; }
                const itm = player.inventory[idx];
                player.inventory.splice(idx, 1);
                
                // Use logic simplified (Only works in battle mostly for buffs)
                if (itm.type === 'heal') {
                    player.stats.hp = Math.min(calculateTotalStats(player).hpMax, player.stats.hp + itm.val);
                    text = `✨ HP +${itm.val}.`;
                } else if (player.activeBattle || (player.partyId && partiesData[player.partyId]?.activeBattle)) {
                     // Handle buff logic here specific to battle context
                     text = `🔥 Item dipakai (Efek aktif di battle).`; 
                } else {
                    text = `❌ Buff potion hanya bisa dipakai saat battle.`;
                    player.inventory.push(itm); // Refund
                }
                break;
        }

    } catch (e) {
        console.error(e);
        text = `❌ ERROR: ${e.message}`;
    }

    await saveUserData();
    if (text) msg.reply(text);
};

export default {
    command: ['guide', 'help', 'start', 'stats', 'role', 'shop', 'buy', 'upgrade', 'inv', 'use', 'attack', 'skill', 'createparty', 'joinparty', 'roster', 'party', 'leaveparty', 'partyid'],
    category: 'game',
    handler
};