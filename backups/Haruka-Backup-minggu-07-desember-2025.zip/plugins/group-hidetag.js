const handler = async ({ sock, msg, args, command, isGroup, isAdmin }) => {
    
    const remoteJid = msg.key.remoteJid;
    
    if (!isGroup) {
        return msg.reply('❌ Perintah *.' + command + '* hanya dapat digunakan di dalam grup.');
    }

    // Hanya cek variabel isAdmin yang sudah dihitung di handler utama (melalui Cache)
    if (!isAdmin) {
        return msg.reply('🚫 Maaf, perintah *.' + command + '* hanya dapat digunakan oleh Admin Grup.');
    }

    // Panggilan ini tetap dibutuhkan untuk mendapatkan daftar JID untuk di-tag
    try {
        const groupMetadata = await sock.groupMetadata(remoteJid); 
        const members = groupMetadata.participants;

        const memberJids = members.map(member => member.id);

        const textToTag = args.join(' ').trim() || '📢 Pesan penting dari Admin Grup.';

        await sock.sendMessage(remoteJid, { 
            text: textToTag, 
            mentions: memberJids 
        });
        
        await msg.reply('✅ Pesan hidetag berhasil dikirim ke seluruh anggota grup.');

    } catch (e) {
        console.error('[HIDETAG SEND ERROR]', e);
        msg.reply('❌ Gagal mengirim pesan hidetag. Bot mungkin bukan Admin Grup.');
    }
};

export default {
    command: ['hidetag', 'tagallhide', 'taghide', 'h'], 
    description: 'Tag seluruh anggota grup tanpa menampilkan nama, hanya Admin.',
    category: 'admin',
    handler,
};
