import axios from 'axios';
import { Buffer } from 'buffer'; 

/**
 * Mengirim request ke downr.org API dan mengembalikan array media objects.
 */
async function downr(url) {
    try {
        if (!url.includes('https://')) throw new Error('URL harus dimulai dengan "https://".');
        
        const { data } = await axios.post('https://downr.org/.netlify/functions/download', {
            url: url
        }, {
            headers: {
                'content-type': 'application/json',
                origin: 'https://downr.org',
                referer: 'https://downr.org/',
                'user-agent': 'Mozilla/5.0 (Linux; Android 15; SM-F958 Build/AP3A.240905.015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36'
            }
        });
        
        if (!data || data.error || !data.medias || data.medias.length === 0) {
             throw new Error("Media tidak ditemukan atau API gagal memproses.");
        }
        
        return data.medias;
        
    } catch (error) {
        const errorMessage = error.response?.data ? JSON.stringify(error.response.data) : error.message;
        throw new Error(`Gagal request ke Downr API: ${errorMessage}`);
    }
}


/**
 * Handler utama Threads Downloader
 */
const handler = async ({ sock, msg, from, command, args }) => {
    
    const text = args.join(' ').trim();
    
    if (!text || (!text.includes('threads.net') && !text.includes('threads.com'))) {
        return sock.sendMessage(from, { text: `❌ URL tidak valid. Masukkan link Threads!\n\nContoh:\n*.${command} https://www.threads.net/@user/post/XXX*` }, { quoted: msg });
    }

    const MAX_OUTER_RETRIES = 2; // Maksimal percobaan total (mengambil URL baru)
    let sentCount = 0;
    let finalError = null;
    
    // --- START OUTER RETRY LOOP (Untuk mendapatkan URL baru jika yang pertama gagal) ---
    for (let outerAttempt = 1; outerAttempt <= MAX_OUTER_RETRIES; outerAttempt++) {
        try {
            await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

            // 1. Dapatkan array objek media (menggunakan API call yang menghasilkan URL segar)
            const medias = await downr(text);
            
            if (medias.length === 0) {
                await sock.sendMessage(from, { text: "Tidak ada media yang ditemukan di postingan ini." }, { quoted: msg });
                sentCount = 1; // Mark as "handled"
                break; 
            }
                
            let currentSentCount = 0;
            const MAX_INNER_RETRIES = 3; // Maksimal percobaan unduh URL yang sama
            
            // 2. Loop dan Unduh (Dengan Inner Retry Loop)
            for (const media of medias) {
                const url = media.url;
                if (!url) continue; 
                
                let mediaBuffer = null;
                const isVideo = media.type === 'video' || url.endsWith('.mp4');
                let innerAttempt = 0;
                
                // Inner Retry Loop (3x)
                while (innerAttempt < MAX_INNER_RETRIES) {
                    innerAttempt++;
                    try {
                        const response = await axios.get(url, {
                            responseType: 'arraybuffer'
                        });
                        mediaBuffer = Buffer.from(response.data);
                        break; // Berhasil, keluar dari inner loop
                    } catch (bufferError) {
                        console.error(`[DOWNLOAD BUFFER ERROR] Percobaan ${innerAttempt}/${MAX_INNER_RETRIES} gagal untuk URL: ${url}.`);
                        
                        if (innerAttempt < MAX_INNER_RETRIES) {
                            await new Promise(resolve => setTimeout(resolve, 1000 * innerAttempt)); // Tunggu 1s, 2s, 3s
                        }
                    }
                }
                
                if (!mediaBuffer) continue; // Jika 3x gagal, lanjut ke media berikutnya
                
                // Pengiriman pesan
                const finalCaption = isVideo ? "Ini kak video nya" : "Ini kak gambar nya";

                if (isVideo) {
                    await sock.sendMessage(from, { video: mediaBuffer, caption: finalCaption }, { quoted: msg });
                } else {
                    await sock.sendMessage(from, { image: mediaBuffer, caption: finalCaption }, { quoted: msg });
                }
                currentSentCount++;
            }
            
            sentCount = currentSentCount;

            if (sentCount > 0) {
                // Jika berhasil mengirim minimal 1 media, anggap sukses dan hentikan outer loop
                break; 
            } else if (outerAttempt < MAX_OUTER_RETRIES) {
                 // Jika semua media gagal diunduh, simpan error dan coba lagi (API call baru di next loop)
                 finalError = new Error(`Semua media gagal diunduh pada percobaan API ke-${outerAttempt}. Mencoba mengambil URL baru...`);
                 console.error(finalError.message);
                 await new Promise(resolve => setTimeout(resolve, 2000)); // Tunggu 2 detik sebelum outer retry
            }
            
        } catch (e) {
            finalError = e;
            console.error(`[THREADS DL OUTER ERROR] Percobaan ${outerAttempt}/${MAX_OUTER_RETRIES} gagal: ${e.message}`);
            
            if (outerAttempt < MAX_OUTER_RETRIES) {
                await new Promise(resolve => setTimeout(resolve, 2000)); 
            }
        }
    }
    // --- END OUTER RETRY LOOP ---

    // Finalisasi respons setelah semua percobaan
    if (sentCount > 0) {
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
    } else {
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        const errorMessage = finalError ? finalError.message : `Tidak dapat menyelesaikan permintaan setelah ${MAX_OUTER_RETRIES} kali percobaan.`;
        await sock.sendMessage(from, { text: `❌ Gagal memproses: ${errorMessage}` }, { quoted: msg });
    }
};

export default {
    command: ["threads", "thrd", "th"],
    description: 'Download media (gambar/video) dari postingan Threads menggunakan Downr API.',
    category: 'downloader', 
    handler,
};