import axios from 'axios';
import { Buffer } from 'buffer'; // Diperlukan untuk Buffer dalam lingkungan ESM

// Menggunakan object ssweb yang Anda berikan, disesuaikan untuk ESM
const ssweb = {
    _static: Object.freeze({
        baseUrl: 'https://www.screenshotmachine.com',
        // Mengubah baseHeaders dari 'content-encoding': 'zstd' ke yang lebih umum, 
        // karena 'zstd' bisa menyebabkan masalah jika tidak didukung sempurna
        baseHeaders: { 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8' },
        maxOutputLength: 200
    }),
    
    pretyError(string) {
        if (!string) return '(empty message)';
        let message = '';
        try { message = JSON.stringify(string, null, 2); } 
        catch { message = string; }
        return message.length >= this._static.maxOutputLength ? message.substring(0, this._static.maxOutputLength) + ' [trimmed]' : message;
    },
    
    async getCookie() {
        // Menggunakan axios daripada fetch agar konsisten dan lebih mudah menangani headers
        const r = await axios.get(this._static.baseUrl, { headers: this._static.baseHeaders });
        
        const setCookieHeader = r.headers['set-cookie'] || r.headers['Set-Cookie'];
        if (!setCookieHeader) throw new Error('gagal mendapatkan kuki (Header set-cookie kosong)');

        const cookie = (Array.isArray(setCookieHeader) ? setCookieHeader.join(', ') : setCookieHeader)
                        .split(',')
                        .map(v => v.split(';')[0])
                        .join('; ');
                        
        if (!cookie) throw new Error('gagal mendapatkan kuki (hasil parsing kosong)');
        return { cookie };
    },
    
    async getBuffer(reqObj, cookie) {
        if (reqObj.status !== "success") throw new Error(`Status API tidak sukses: ${reqObj.status_text || reqObj.message || reqObj.status}`);
        
        const { link } = reqObj;
        
        const r = await axios.get(this._static.baseUrl + '/' + link, { 
            headers: { cookie },
            responseType: 'arraybuffer' // Mengunduh sebagai buffer
        });

        if (r.status !== 200) throw new Error(`${r.status} ${r.statusText} ${this.pretyError(r.data.toString())}`);
        
        return { buffer: Buffer.from(r.data) };
    },
    
    async req(url, cookie) {
        const headers = {
            cookie,
            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
            ...this._static.baseHeaders
        };
        
        const body = "url=" + encodeURIComponent(url) + "&device=desktop&cacheLimit=0";
        
        const r = await axios.post(this._static.baseUrl + '/capture.php', body, {
            headers,
        });

        if (r.status !== 200) throw new Error(`${r.status} ${r.statusText} ${this.pretyError(r.data.toString())}`);
        
        const reqObj = r.data;
        if (typeof reqObj !== 'object') {
            try {
                // Coba parsing manual jika response.data bukan objek (mungkin string JSON)
                const parsed = JSON.parse(r.data);
                return { reqObj: parsed };
            } catch {
                throw new Error("Respon API bukan JSON yang valid.");
            }
        }
        
        return { reqObj };
    },
    
    async capture(url) {
        if (!url) throw new Error('param url gak boleh kosong');
        
        const { cookie } = await this.getCookie();
        const { reqObj } = await this.req(url, cookie);
        const { buffer } = await this.getBuffer(reqObj, cookie);
        return buffer;
    }
};

// --- HANDLER BOT ---

const handler = async ({ sock, msg, args, from, command }) => {
    
    const url = args[0];
    
    try {
        if (!url) {
            return sock.sendMessage(from, { 
                text: `*Example :* .${command} https://google.com` 
            }, { quoted: msg });
        }
        
        // Tambahkan protokol jika lupa (opsional, tapi membantu)
        const fullUrl = url.startsWith('http') ? url : `http://${url}`;
        
        await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

        // Panggil fungsi capture
        let buff = await ssweb.capture(fullUrl);
        
        // Kirim hasil screenshot
        await sock.sendMessage(from, { 
            image: buff,
            caption: `📸 Screenshot dari: ${fullUrl}`
        }, { quoted: msg });
        
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
        
    } catch (e) {
        console.error('[SSWEB ERROR]', e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        await sock.sendMessage(from, { text: `❌ Gagal mengambil screenshot:\n${e.message}` }, { quoted: msg });
    }
};

export default {
    command: ['ssweb', 'ss'],
    description: 'Mengambil screenshot dari halaman web berdasarkan URL.',
    category: 'tools',
    handler,
};