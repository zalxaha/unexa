import axios from 'axios';
import crypto from 'crypto';
import * as fsp from 'fs/promises';
import fs from 'fs';
import * as path from 'path';
import NodeID3 from 'node-id3';
import yts from 'yt-search';

// ==========================================
// UTILITY FUNCTIONS
// ==========================================

// --- HELPER 1: PoW Solver ---
const solvePoW = (challenge, difficulty) => {
    let nonce = 0;
    const prefix = '0'.repeat(difficulty);
    while (true) {
        const input = challenge + nonce;
        const hash = crypto.createHash('sha256').update(input).digest('hex');
        if (hash.startsWith(prefix)) return nonce;
        nonce++;
    }
};

// --- HELPER 2: Cookie Manager ---
const updateCookies = (currentCookies, newCookies) => {
    if (!newCookies) return currentCookies;
    const parsedNew = newCookies.map(c => c.split(';')[0]);
    const merged = [...currentCookies];
    parsedNew.forEach(nc => {
        const key = nc.split('=')[0];
        const index = merged.findIndex(oc => oc.startsWith(key + '='));
        if (index > -1) merged[index] = nc;
        else merged.push(nc);
    });
    return merged;
};

// --- HELPER 3: Delay (Tidur sebentar) ---
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// --- HELPER 4: Download & Save ---
async function downloadAndSave(url, filePath) {
    const response = await axios({
        method: 'get',
        url: url,
        responseType: 'arraybuffer',
        timeout: 60000 
    });
    await fsp.writeFile(filePath, response.data); 
}

// ==========================================
// MAIN HANDLER
// ==========================================

const handler = async ({ sock, msg, args, from }) => {
    const text = args.join(' ');
    
    const tempId = Date.now();
    const audioTempPath = path.join('/tmp', `${tempId}-audio.mp3`); 
    const imageTempPath = path.join('/tmp', `${tempId}-thumb.jpg`);

    if (!text) {
        return sock.sendMessage(from, { text: '❌ Masukkan teks pencarian atau link YouTube.\nContoh: `.play mockingbird`' }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '🔎', key: msg.key } });

    try {
        let videoUrl, videoTitle, videoThumbnail, videoDuration;
        const isURL = text.trim().match(/(?:youtube\.com|youtu\.be)/);
        
        // 1. Ambil metadata video via yt-search
        if (!isURL) {
            const results = await yts(text);
            if (!results.videos || results.videos.length === 0) throw new Error('Video tidak ditemukan.');
            const video = results.videos[0];
            videoUrl = video.url;
            videoTitle = video.title;
            videoThumbnail = video.thumbnail;
            videoDuration = video.timestamp; 
        } else {
            videoUrl = text.trim().split(' ')[0];
            const videoIdMatch = videoUrl.match(/(?:v=|\/)([a-zA-Z0-9_-]{11})/);
            if (videoIdMatch && videoIdMatch[1]) {
                const videoData = await yts({ videoId: videoIdMatch[1] });
                videoTitle = videoData.title;
                videoThumbnail = videoData.thumbnail;
                videoDuration = videoData.duration.timestamp;
            } else {
                videoTitle = "YouTube Audio";
                videoThumbnail = "https://i.ytimg.com/vi/default/hqdefault.jpg";
                videoDuration = "Unknown";
            }
        }

        await sock.sendMessage(from, { react: { text: '🔄', key: msg.key } });

        // 2. Kirim Informasi Video & Thumbnail (Informasi siputzx dihapus)
        const captionThumbnail = `*YOUTUBE PLAY - HARUKA DOWNLOADER*\n\n` +
                                 `• *Judul:* ${videoTitle}\n` +
                                 `• *Durasi:* ${videoDuration}\n\n` +
                                 `*Sedang memproses audio, mohon tunggu...*`;

        await sock.sendMessage(from, {
            image: { url: videoThumbnail },
            caption: captionThumbnail
        }, { quoted: msg });

        // ==========================================
        // PROSES DOWNLOAD VIA API
        // ==========================================
        const BASE_URL = 'https://youtubedl.siputzx.my.id';
        const HEADERS = {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
            'Referer': 'https://youdl.pages.dev/',
            'Origin': 'https://youdl.pages.dev',
            'Content-Type': 'application/json'
        };

        let myCookies = [];

        // [STEP 1] Minta Challenge
        const res1 = await axios.post(`${BASE_URL}/akumaudownload`, 
            { url: videoUrl, type: 'audio' },
            { headers: HEADERS }
        );
        myCookies = updateCookies(myCookies, res1.headers['set-cookie']);

        // Jika butuh challenge
        if (res1.data.challenge) {
            const { challenge, difficulty } = res1.data;
            // [STEP 2] Solve PoW
            const nonce = solvePoW(challenge, difficulty);

            // [STEP 3] Verifikasi
            const res2 = await axios.post(`${BASE_URL}/cekpunyaku`, 
                { url: videoUrl, type: 'audio', nonce: String(nonce) },
                { headers: { ...HEADERS, 'Cookie': myCookies.join('; ') } }
            );
            myCookies = updateCookies(myCookies, res2.headers['set-cookie']);
        }

        await sock.sendMessage(from, { react: { text: '⬇️', key: msg.key } });

        // [STEP 4] POLLING (Looping sampai 'completed')
        let attempt = 0;
        let finalResult = null;

        while (attempt < 30) { // Maksimal 60 detik
            const resDownload = await axios.get(`${BASE_URL}/download`, {
                params: { url: videoUrl, type: 'audio' },
                headers: { ...HEADERS, 'Cookie': myCookies.join('; ') }
            });
            
            const data = resDownload.data;

            if (data.status === 'completed' && data.fileUrl) {
                finalResult = data;
                break;
            } else if (data.status === 'failed' || data.error) {
                throw new Error(data.error || 'Gagal memproses video di server downloader.');
            } else {
                await sleep(2000); // Tunggu 2 detik
                attempt++;
            }
        }

        if (!finalResult) throw new Error('Waktu pemrosesan habis (Timeout). Coba lagi nanti.');

        const directLink = BASE_URL + finalResult.fileUrl;

        // ==========================================
        // PROSES METADATA & KIRIM FILE
        // ==========================================
        
        // Download file audio dan thumbnail untuk diproses ID3
        await downloadAndSave(directLink, audioTempPath);
        
        let hasThumbnail = false;
        try {
            await downloadAndSave(videoThumbnail, imageTempPath);
            hasThumbnail = true;
        } catch (e) {
            console.log("Gagal mengunduh thumbnail untuk ID3 tag:", e.message);
        }
        
        // Menyisipkan Metadata (ID3 Tags - Cover Art & Title)
        const tags = {
            title: videoTitle,
            artist: 'Haruka Downloader',
        };

        if (hasThumbnail) {
            const imageBuffer = await fsp.readFile(imageTempPath);
            tags.image = {
                mime: 'image/jpeg',
                type: { id: 3, name: 'front cover' },
                description: 'Cover Art',
                imageBuffer: imageBuffer
            };
        }
        
        NodeID3.write(tags, audioTempPath);

        await sock.sendMessage(from, { react: { text: '📤', key: msg.key } });

        // Membaca file audio yang sudah disisipkan metadata
        const finalAudioBuffer = await fsp.readFile(audioTempPath);

        // Kirim Audio Langsung (Voice Note / Audio Player)
        await sock.sendMessage(from, {
            audio: finalAudioBuffer,
            mimetype: 'audio/mpeg', 
            ptt: false 
        }, { quoted: msg });
        
        // Kirim Audio sebagai Dokumen
        const safeFileName = videoTitle.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);
        await sock.sendMessage(from, {
            document: finalAudioBuffer,
            mimetype: 'audio/mpeg', 
            fileName: `${safeFileName}.mp3`,
            caption: `✅ *File Audio Berhasil Diproses*`
        }, { quoted: msg });

        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (error) {
        console.error("Handler Error:", error.message);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        await sock.sendMessage(from, { text: `❌ *Kesalahan:* ${error.message}` }, { quoted: msg });
    } finally {
        // Cleanup File Temporary
        try {
            if (fs.existsSync(audioTempPath)) await fsp.unlink(audioTempPath); 
            if (fs.existsSync(imageTempPath)) await fsp.unlink(imageTempPath); 
        } catch (e) {
            // Abaikan error saat penghapusan
        }
    }
};

export default {
    command: ['play'],
    description: 'Mencari dan mengunduh audio YouTube',
    category: 'Downloader',
    handler,
};