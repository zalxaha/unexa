import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import axios from 'axios';
import crypto from 'crypto';
import FormData from 'form-data';

// --- FUNGSI UTAMA NANO BANANA 2 (LIVE3D) ---
async function live3d(buffer, prompt) {
  const config = {
    pkey: "LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0KTUlHZk1BMEdDU3FHU0liM0RRRUJBUVVBQTRHTkFEQ0JpUUtCZ1FDd2xPK2JvQzZjd1JvM1VmWFZCYWRhWXdjWDB6S1MyZnVWTlkycVowZGd3YjFOSisvUTlGZUFvc0w0T05pb3NENzFvbjNQVllxUlVsTDUwNDVtdkgySzlpOGJBRlZNRWlwN0U2Uk1LNnRLQUFpZjd4elpyWG5QMUdaNVJpanRxZGd3aCtZbXpUbzM5Y3VCQ3NacUs5b0VvZVEzci9teUc5Uys5Y1I1aHVUdUZRSURBUUFCCi0tLS0tRU5EIFBVQkxJQyBLRVktLS0tLQ==",
    aid: "aifaceswap",
    uid: "1H5tRtzsBkqXcaJ",
    origin: "8f3f0c7387123ae0",
    theme_version: '83EmcUoQTUv50LhNx0VrdcK8rcGexcP35FcZDcpgWsAXEyO4xqL5shCY6sFIWB2Q',
    model: 'nano_banana_2',
  }
  
  let currentFp = crypto.randomBytes(16).toString('hex');
  
  const crypt = {
    aes: (data, key) => {
      const cipher = crypto.createCipheriv('aes-128-cbc', key, key);
      return Buffer.concat([cipher.update(data, 'utf8'), cipher.final()]).toString('base64')
    },
    rsa: (data) => {
      return crypto.publicEncrypt({
        key: Buffer.from(config.pkey, "base64").toString(),
        padding: crypto.constants.RSA_PKCS1_PADDING,
      }, Buffer.from(data, 'utf8')).toString('base64');
    }
  };

  const api = axios.create({
    baseURL: 'https://app-v1.live3d.io',
    headers: {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 16; NX729J) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.7499.34 Mobile Safari/537.36',
      'origin': 'https://live3d.io',
      'referer': 'https://live3d.io/',
      'theme-version': config.theme_version
    }
  });

  api.interceptors.request.use((cfg) => {
    const [i, d, n] = [
      crypto.randomBytes(8).toString('hex'),
      crypto.randomUUID(),
      Math.floor(Date.now() / 1000)
    ]
    
    const s = crypt.rsa(i);
    const signStr = cfg.url.includes('upload-img') ? `${config.aid}:${d}:${s}` : `${config.aid}:${config.uid}:${n}:${d}:${s}`;
    
    Object.assign(cfg.headers, {
      'fp': currentFp,
      'fp1': crypt.aes(`${config.aid}:${currentFp}`, i),
      'x-guide': s,
      'x-sign': crypt.aes(signStr, i),
      'x-code': Date.now().toString()
    });
    
    return cfg;
  });

  try {
    const form = new FormData();
    form.append('file', buffer, { filename: 'input.jpg', contentType: 'image/jpeg' });
    form.append('fn_name', 'demo-image-editor');
    form.append('request_from', '9');
    form.append('origin_from', config.origin);
    
    const { data: upRes } = await api.post('/aitools/upload-img', form, {
      headers: form.getHeaders()
    });
    
    const { data: job } = await api.post('/aitools/of/create', {
      fn_name: 'demo-image-editor',
      call_type: 3,
      input: {
        model: config.model,
        source_images: [upRes.data.path],
        prompt: prompt,
        aspect_radio: 'auto',
        request_from: 9
      },
      data: '',
      request_from: 9,
      origin_from: config.origin
    });
    
    const taskId = job.data?.task_id;
    if (!taskId) throw new Error("TaskId cannot be found, API limit/error.");
    
    while (true) {
      const { data: status } = await api.post('/aitools/of/check-status', {
        task_id: taskId,
        fn_name: 'demo-image-editor',
        call_type: 3,
        request_from: 9,
        origin_from: config.origin
      });
      
      if (status.data.status === 2) {
        return {
          status: 'success',
          image_url: 'https://temp.live3d.io/' + status.data.result_image
        };
      } else if (status.data.status === 3) {
        return status.data // Error dari Live3D
      }
      // Delay bawaan (polling setiap 3 detik)
      await new Promise(r => setTimeout(r, 3000));
    }
  } catch (error) {
    throw new Error(`Process failed: ${error.message}`);
  }
}
// --- AKHIR FUNGSI LIVE3D ---


const handler = async ({ sock, msg, from, args }) => {
    // PROMPT DEFAULT
    const DEFAULT_PROMPT = "turn skin tone to extreme dark charcoal black, extremely dark skin, perfectly preserve exact original facial structure, preserve original ethnicity and identity, retain original face shape, strictly do not alter facial features"; 

    const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
    const quoted = contextInfo?.quotedMessage;
    const mediaMessage = quoted || msg.message;

    const mimeType = Object.keys(mediaMessage || {}).find(k => k.endsWith('Message')) || '';
        
    if (!mimeType.includes('image')) {
        return sock.sendMessage(from, {
            text: '❌ Reply/kirim *gambar* dengan caption *.hitamkan*.'
        }, { quoted: msg })
    }

    const inputPrompt = args.join(' ').trim();
    const promptText = inputPrompt.length > 0 ? inputPrompt : DEFAULT_PROMPT;
    const mediaInfo = mediaMessage[mimeType];
    
    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } })

    try {
        // 1. UNDUH MEDIA KE DALAM BUFFER
        const stream = await downloadContentFromMessage(mediaInfo, 'image');
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        const mediaBuffer = Buffer.concat(chunks);
        
        // 2. KIRIM BUFFER LANGSUNG KE API NANO BANANA (LIVE3D)
        await sock.sendMessage(from, { react: { text: '🔄', key: msg.key } })
        
        const result = await live3d(mediaBuffer, promptText);

        if (!result || result.status !== 'success' || !result.image_url) {
            throw new Error(result?.msg || "Gagal mendapatkan hasil dari server AI.");
        }
        
        // 3. KIRIM HASIL KE WHATSAPP 
        // Menggunakan properti { url: ... } membuat Baileys men-download dan mengirim otomatis
        await sock.sendMessage(from, {
            image: { url: result.image_url },
            caption: `✅ Hasil dari penghitam kulit\n\n_Powered by Nano Banana 2_`
        }, { quoted: msg });

        await sock.sendMessage(from, { react: { text: '✨', key: msg.key } }); 

    } catch (e) {
        console.error('[NANO BANANA ERROR]', e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        sock.sendMessage(from, {
            text: `❌ Gagal memproses: ${e.message}`
        }, { quoted: msg });
    } 
}

export default {
    command: ['hitamkan', 'darkskin'], 
    description: 'Transformasi tone warna kulit menjadi sangat hitam (charcoal) tanpa mengubah struktur asli wajah.',
    category: 'tools',
    handler,
};