import axios from "axios";
import crypto from 'crypto';
import * as fsp from 'fs/promises';
import fs from 'fs';
import * as path from 'path';
import NodeID3 from 'node-id3';
import yts from 'yt-search';

// ==========================================
// UTILITY FUNCTIONS
// ==========================================

// --- HELPER 1: PoW Solver ---
const solvePoW = (challenge, difficulty) => {
    let nonce = 0;
    const prefix = '0'.repeat(difficulty);
    while (true) {
        const input = challenge + nonce;
        const hash = crypto.createHash('sha256').update(input).digest('hex');
        if (hash.startsWith(prefix)) return nonce;
        nonce++;
    }
};

// --- HELPER 2: Cookie Manager ---
const updateCookies = (currentCookies, newCookies) => {
    if (!newCookies) return currentCookies;
    const parsedNew = newCookies.map(c => c.split(';')[0]);
    const merged = [...currentCookies];
    parsedNew.forEach(nc => {
        const key = nc.split('=')[0];
        const index = merged.findIndex(oc => oc.startsWith(key + '='));
        if (index > -1) merged[index] = nc;
        else merged.push(nc);
    });
    return merged;
};

// --- HELPER 3: Delay (Tidur sebentar) ---
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// --- HELPER 4: Download & Save ---
async function downloadAndSave(url, filePath) {
    const response = await axios({
        method: 'get',
        url: url,
        responseType: 'arraybuffer',
        timeout: 60000
    });
    await fsp.writeFile(filePath, response.data); 
}

// ==========================================
// MAIN HANDLER
// ==========================================

const handler = async ({ sock, msg, args, from }) => {
  const text = args.join(' ');
  const parts = text.trim().split(' ');
  const url = parts[0];

  if (!url) {
    return sock.sendMessage(from, { 
        text: '❌ Masukkan link YouTube.\nContoh: `.yta https://youtu.be/xyz`' 
    }, { quoted: msg });
  }

  // Validasi URL YouTube
  const ytRegex = /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)/;
  if (!ytRegex.test(url)) {
    return sock.sendMessage(from, { 
        text: '❌ Link tidak valid. Pastikan menggunakan link YouTube.' 
    }, { quoted: msg });
  }
  
  const tempId = Date.now();
  const audioTempPath = path.join('/tmp', `${tempId}-audio.mp3`); 
  const imageTempPath = path.join('/tmp', `${tempId}-thumb.jpg`);

  await sock.sendMessage(from, { react: { text: '🎧', key: msg.key } });

  try {
    // 1. Ekstrak Video ID dan ambil metadata detail via yt-search
    const videoIdMatch = url.match(/(?:v=|\/)([a-zA-Z0-9_-]{11})/);
    const videoId = videoIdMatch ? videoIdMatch[1] : null;
    
    let videoTitle = "YouTube Audio";
    let videoThumbnail = "https://i.ytimg.com/vi/default/hqdefault.jpg";
    let videoDuration = "Unknown";
    let videoChannel = "Haruka Downloader";

    if (videoId) {
        const videoData = await yts({ videoId });
        if (videoData) {
            videoTitle = videoData.title;
            videoThumbnail = videoData.thumbnail;
            videoDuration = videoData.duration.timestamp;
            videoChannel = videoData.author.name;
        }
    }

    await sock.sendMessage(from, { react: { text: '🔄', key: msg.key } });

    // 2. Kirim UI Detail Info (Tanpa embel-embel sumber API)
    const caption = `*YOUTUBE AUDIO*\n\n` +
                    `• *Judul:* ${videoTitle}\n` +
                    `• *Channel:* ${videoChannel}\n` +
                    `• *Durasi:* ${videoDuration}\n\n` +
                    `_Sedang memproses audio, mohon tunggu..._`;

    await sock.sendMessage(from, { image: { url: videoThumbnail }, caption }, { quoted: msg });

    // ==========================================
    // PROSES DOWNLOAD VIA API
    // ==========================================
    const BASE_URL = 'https://youtubedl.siputzx.my.id';
    const HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        'Referer': 'https://youdl.pages.dev/',
        'Origin': 'https://youdl.pages.dev',
        'Content-Type': 'application/json'
    };

    let myCookies = [];

    // [STEP 1] Minta Challenge
    const res1 = await axios.post(`${BASE_URL}/akumaudownload`, 
        { url: url, type: 'audio' },
        { headers: HEADERS }
    );
    myCookies = updateCookies(myCookies, res1.headers['set-cookie']);

    // Jika butuh challenge
    if (res1.data.challenge) {
        const { challenge, difficulty } = res1.data;
        // [STEP 2] Solve PoW
        const nonce = solvePoW(challenge, difficulty);

        // [STEP 3] Verifikasi
        const res2 = await axios.post(`${BASE_URL}/cekpunyaku`, 
            { url: url, type: 'audio', nonce: String(nonce) },
            { headers: { ...HEADERS, 'Cookie': myCookies.join('; ') } }
        );
        myCookies = updateCookies(myCookies, res2.headers['set-cookie']);
    }

    await sock.sendMessage(from, { react: { text: '⬇️', key: msg.key } });

    // [STEP 4] POLLING (Looping sampai 'completed')
    let attempt = 0;
    let finalResult = null;

    while (attempt < 30) { // Maksimal 60 detik
        const resDownload = await axios.get(`${BASE_URL}/download`, {
            params: { url: url, type: 'audio' },
            headers: { ...HEADERS, 'Cookie': myCookies.join('; ') }
        });
        
        const data = resDownload.data;

        if (data.status === 'completed' && data.fileUrl) {
            finalResult = data;
            break;
        } else if (data.status === 'failed' || data.error) {
            throw new Error(data.error || 'Gagal memproses video di server downloader.');
        } else {
            await sleep(2000); // Tunggu 2 detik
            attempt++;
        }
    }

    if (!finalResult) throw new Error('Waktu pemrosesan habis (Timeout). Coba lagi nanti.');

    const directLink = BASE_URL + finalResult.fileUrl;

    // ==========================================
    // PROSES METADATA & KIRIM FILE
    // ==========================================

    // 4. Download file audio dan thumbnail ke temp file
    await downloadAndSave(directLink, audioTempPath);
    
    let hasThumbnail = false;
    try {
        await downloadAndSave(videoThumbnail, imageTempPath);
        hasThumbnail = true;
    } catch (e) {
        console.log("Peringatan: Gagal mengunduh thumbnail untuk ID3 tag:", e.message);
    }
    
    // 5. Inject ID3 Metadata (Cover, Judul, Artist)
    const tags = {
        title: videoTitle,
        artist: videoChannel,
    };

    if (hasThumbnail) {
        const imageBuffer = await fsp.readFile(imageTempPath);
        tags.image = {
            mime: 'image/jpeg',
            type: { id: 3, name: 'front cover' },
            description: 'Cover Art',
            imageBuffer: imageBuffer
        };
    }
    
    NodeID3.write(tags, audioTempPath);
    
    await sock.sendMessage(from, { react: { text: '📤', key: msg.key } });

    // Baca ulang file yang sudah disuntik metadata
    const finalAudioBuffer = await fsp.readFile(audioTempPath);
    const safeFileName = videoTitle.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);

    // 6. [1/2] Kirim Versi Audio Langsung (Voice Note style)
    await sock.sendMessage(from, {
        audio: finalAudioBuffer,
        mimetype: 'audio/mpeg',
        ptt: false
    }, { quoted: msg });
    
    // 7. [2/2] Kirim Versi Dokumen MP3
    await sock.sendMessage(from, {
        document: finalAudioBuffer, 
        mimetype: 'audio/mpeg', 
        fileName: `${safeFileName}.mp3`,
        caption: `✅ *File MP3 Berhasil Diproses*`
    }, { quoted: msg });

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (err) {
    console.error("Handler Error:", err);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    
    let errorMsg = err.message;
    if (err.response?.data?.message) errorMsg = err.response.data.message;
    
    await sock.sendMessage(from, { 
        text: `❌ *Error:* ${errorMsg}\n\n💡 Pastikan video publik dan bukan sesi live streaming.` 
    }, { quoted: msg });
  } finally {
    // 8. Cleanup File Temporary
    try {
      if (fs.existsSync(audioTempPath)) await fsp.unlink(audioTempPath); 
      if (fs.existsSync(imageTempPath)) await fsp.unlink(imageTempPath); 
    } catch (e) {
        // Abaikan error cleanup
    }
  }
};

export default {
  command: ['ytmp3', 'yta'],
  description: 'Download audio YouTube via Link (ID3 Metadata Terinjeksi)',
  category: 'Downloader',
  handler,
};