import fs from 'fs/promises'; 
import fsSync from 'fs'; 
import path from 'path';
import Crypto from 'crypto';
import { tmpdir } from 'os';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { fileURLToPath } from 'url';
import { createRequire } from 'module'; 

// Import modules kustom
import { uploadCatbox } from '../lib/uploader.js'; 
import { generateCertificate } from '../lib/sertifikat.js'; 

// --- [ 1. SETUP PATH & DATABASE ] ---

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url);

const userDataFile = path.join(__dirname, '../data/userData.json');
let userData = {}; 
let isSaving = false; 
const commandCooldown = new Map();

// Helper: Get Jam WIB
const getWIBHour = () => {
    const date = new Date();
    const formatter = new Intl.DateTimeFormat('en-US', {
        timeZone: 'Asia/Jakarta', hour: 'numeric', hour12: false
    });
    return parseInt(formatter.format(date));
};

// Load Database
async function loadUserData() {
  try {
    await fs.mkdir(path.dirname(userDataFile), { recursive: true });
    try { await fs.access(userDataFile); } catch {
        await fs.writeFile(userDataFile, JSON.stringify({}, null, 2), 'utf8');
        userData = {}; return;
    }
    const content = await fs.readFile(userDataFile, 'utf8');
    userData = content.trim().length > 0 ? JSON.parse(content) : {};

    // Auto-Fix Data
    Object.keys(userData).forEach(key => {
        const user = userData[key];
        if (!user.inventory) user.inventory = { bahan: 0, obat: 0, susu: 0 };
        if (user.waifus) {
            user.waifus.forEach(w => {
                if (w.hunger === undefined) w.hunger = 0;
                if (w.health === undefined) w.health = 100;
                if (w.isSick === undefined) w.isSick = false;
            });
        }
    });
    // Menghapus saveUserData() di sini untuk mencegah race condition saat bot startup
  } catch (e) {
    console.error("[WAIFU DB ERROR]", e);
    userData = {}; 
  }
}

async function saveUserData() {
    if (isSaving) return;
    isSaving = true;
    try {
        const dir = path.dirname(userDataFile);
        
        // Memastikan folder sudah ada sebelum membuat file .tmp
        if (!fsSync.existsSync(dir)) {
            await fs.mkdir(dir, { recursive: true });
        }

        const tempFile = userDataFile + '.tmp';
        await fs.writeFile(tempFile, JSON.stringify(userData, null, 2), 'utf8');
        await fs.rename(tempFile, userDataFile); 
    } catch (e) { 
        console.error("[WAIFU SAVE ERROR]", e); 
    } finally { 
        isSaving = false; 
    }
}

(async () => { try { await loadUserData(); } catch (e) {} })();


// --- [ 2. KONFIGURASI GAMEPLAY ] ---

// Cooldowns
const GLOBAL_COOLDOWN_TIME = 3000; 
const COOLDOWN_LIGHT = 30 * 60000; 
const COOLDOWN_MEDIUM = 1 * 3600000; 
const COOLDOWN_HEAVY = 3 * 3600000; 
const COOLDOWN_DATE = 4 * 3600000; 
const COOLDOWN_EXTREME = 8 * 3600000; 
const COOLDOWN_PLAY = 3600000; 

const MAX_WAIFU_GUEST = 2; 
const HAPPINESS_GAIN_CHILD = 15;

// BIAYA
const COST_GENJOT = 500000; 
const COST_BELANJA = 200000;
const COST_SEKOLAH = 50000; 

// TOKO
const SHOP_ITEMS = {
    'obat': { name: 'Obat Generik', price: 10000, type: 'health', desc: 'Sembuhkan sakit.' },
    'bahan': { name: 'Bahan Masak', price: 15000, type: 'food', desc: 'Untuk dimasak istri.' },
    'susu': { name: 'Susu Formula', price: 25000, type: 'babyfood', desc: 'Makanan anak.' },
    'bunga': { name: 'Setangkai Bunga', price: 25000, type: 'gift', affection: 5, stress: -5, desc: 'Romantis.' },
    'coklat': { name: 'Coklat Premium', price: 50000, type: 'gift', affection: 10, stress: -20, desc: 'Manis.' },
    'jamu': { name: 'Jamu Rapet Wangi', price: 35000, type: 'gift', affection: 15, stress: -30, desc: 'Bikin rapet.' },
    'skincare': { name: 'Paket Skincare', price: 350000, type: 'gift', affection: 25, stress: -40, desc: 'Bikin glowing.' },
    'tas': { name: 'Tas Branded', price: 15000000, type: 'gift', affection: 50, stress: -80, desc: 'Mewah.' },
    'berlian': { name: 'Cincin Berlian', price: 50000000, type: 'gift', affection: 100, stress: -100, desc: 'Cinta mati.' }
};

const JOBS = {
    'nyuci': { name: 'Laundry', salary: 50000, stress: 10, cooldown: 3600000, minAff: 0 },
    'masak': { name: 'Koki', salary: 150000, stress: 25, cooldown: 7200000, minAff: 20 },
    'kantor': { name: 'Admin', salary: 300000, stress: 50, cooldown: 14400000, minAff: 50 },
    'model': { name: 'Model', salary: 1000000, stress: 80, cooldown: 21600000, minAff: 80 }
};

// --- DIALOG ---
const DIALOG_LOW = ["Apa sih? Aku sibuk.", "Jangan ganggu aku dulu.", "Huft... pusing mikirin cicilan."];
const DIALOG_MID = ["Hai sayang, sudah makan?", "Anak-anak sehat kan?", "Semangat kerjanya ya!"];
const DIALOG_HIGH = ["Aku kangen banget sama kamu...", "Rumah ini terasa hangat karena kamu.", "Sini peluk aku ❤️"];

const DIALOG_HOT = [
    "Ahhh... terus sayang... jangan berhenti... ❤️💦",
    "Sayang... kamu kuat banget malam ini... bikin aku lemas...",
    "Masukin semuanya sayang... aku milikmu malam ini... ❤️",
    "Ohh... di situ enak banget... lagi sayang... ahhh...",
    "Badanku panas banget... tolong puasin aku sayang... 💋",
    "Desahan kamu bikin aku makin basah... ayo lebih cepat...",
    "Aku nggak kuat... kamu hebat banget... ahhh... keluarin di dalem..."
];

const DIALOG_NAKAL = [
    "Sayang, liat deh... aku nggak pake daleman loh sekarang... 😏",
    "Badanku rasanya aneh... butuh sentuhan kamu nih...",
    "Sini dong... raba punyaku, udah basah nungguin kamu...",
    "Mau main kasar atau lembut malam ini, Daddy? 💋"
];


// --- [ 3. HELPER VISUAL & UTILS ] ---

function createBar(current, max = 100) {
    const percent = Math.min(100, Math.max(0, (current / max) * 100));
    const filled = Math.floor((percent / 100) * 10);
    return '█'.repeat(filled) + '░'.repeat(10 - filled);
}

function formatRemainingTime(ms) {
    const h = Math.floor(ms / 3600000);
    const m = Math.floor((ms % 3600000) / 60000);
    const s = Math.floor((ms % 60000) / 1000);
    if (h > 0) return `${h}j ${m}m`;
    if (m > 0) return `${m}m ${s}d`;
    return `${s} detik`;
}

function formatRupiah(number) {
    return 'Rp ' + number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

async function sendImageFallback(sock, jid, msg, url, caption, mentions = []) {
    try {
        if (!url) throw new Error("No URL");
        await sock.sendMessage(jid, { image: { url: url }, caption: caption, mentions: mentions }, { quoted: msg });
    } catch (e) {
        await sock.sendMessage(jid, { text: caption, mentions: mentions }, { quoted: msg });
    }
}

async function safeUploadCatbox(filePath) {
    try {
        if (!fsSync.existsSync(filePath)) return null;
        return await uploadCatbox(filePath);
    } catch (e) { return null; }
}

async function downloadMedia(mediaInfo, mimeType) {
    const mediaTypeForDownload = mimeType.includes('image') ? 'image' : 'document';
    const filePath = path.join(tmpdir(), `${Crypto.randomBytes(6).toString('hex')}.jpg`);
    const stream = await downloadContentFromMessage(mediaInfo, mediaTypeForDownload);
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);
    await fs.writeFile(filePath, Buffer.concat(chunks));
    return filePath;
}

function getTargetWaifu(userId, args) {
    const waifus = userData[userId]?.waifus || [];
    if (waifus.length === 0) return null;
    const targetArg = args[0]?.trim();
    const targetNumber = parseInt(targetArg);

    if (!isNaN(targetNumber) && targetNumber >= 1 && targetNumber <= waifus.length) {
        return { wife: waifus[targetNumber - 1], wifeIndex: targetNumber - 1 };
    }
    const targetName = args.join(' ').trim().toLowerCase();
    if (targetName) {
        const index = waifus.findIndex(w => w.name.toLowerCase().includes(targetName));
        if (index !== -1) return { wife: waifus[index], wifeIndex: index };
    }
    if (waifus.length === 1) return { wife: waifus[0], wifeIndex: 0 };
    return null; 
}

async function updateLifeStats(userId) {
    const data = userData[userId];
    if (!data) return;
    const now = Date.now();
    let changed = false;

    data.waifus.forEach(w => {
        if ((now - (w.lastFeed || 0)) > 21600000) { 
            w.hunger = Math.min(100, (w.hunger || 0) + 15);
            w.health = Math.max(0, (w.health || 100) - 5);
            w.lastFeed = now;
            changed = true;
        }
        if (w.stress > 80 || w.hunger > 80) {
            if (Math.random() < 0.1) w.isSick = true;
            changed = true;
        }
    });

    data.children.forEach(c => {
        if ((now - (c.lastFeed || 0)) > 14400000) { 
            c.hunger = Math.min(100, (c.hunger || 0) + 20);
            c.health = Math.max(0, (c.health || 100) - 5);
            c.lastFeed = now;
            changed = true;
        }
    });

    if (changed) await saveUserData();
}


// --- [ 4. HANDLER UTAMA ] ---

const handler = async ({ sock, msg, from, args, command, pushName, sender, isPremium, isOwner, db, saveDatabase }) => {
    if (!sender) return; 
    const user = sender; 
    
    try {
        if (!isOwner) {
            const lastTime = commandCooldown.get(user);
            if (lastTime && Date.now() - lastTime < GLOBAL_COOLDOWN_TIME) return;
            commandCooldown.set(user, Date.now());
        }

        const mainCmd = command?.toLowerCase(); 
        const subCommand = args[0]?.toLowerCase(); 

        if (!userData[user]) userData[user] = { waifus: [], children: [], inventory: { bahan: 0, obat: 0, susu: 0 } };
        await updateLifeStats(user);
        
        const waifus = userData[user].waifus;
        const children = userData[user].children;
        const inv = userData[user].inventory || { bahan: 0, obat: 0, susu: 0 };
        const isUnlimited = isPremium || isOwner;

        const addDoubleXp = (amount) => {
            if (db && db[user]) { db[user].xp = (db[user].xp || 0) + (amount * 2); saveDatabase(); }
        };


        // ===========================================
        // A. COMMAND: MENIKAH
        // ===========================================
        if (mainCmd === 'marry') { 
            if (!isUnlimited && waifus.length >= MAX_WAIFU_GUEST) return msg.reply(`🛑 *LIMIT TERCAPAI*\nUser Gratis maks ${MAX_WAIFU_GUEST} Waifu.`);

            const newWaifuName = args.join(' ').trim();
            const mediaMessage = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage || msg.message;
            const mimeType = Object.keys(mediaMessage || {}).find(k => k.endsWith('Message')) || '';

            if (!mimeType.includes('image')) return msg.reply(`❌ Kirim/Reply gambar waifu dengan caption: *.marry NamaWaifu*`);
            if (!newWaifuName) return msg.reply(`❌ Masukkan nama waifu!`);
            
            if (waifus.length >= 1 && waifus[0].affection < 70) return msg.reply(`💔 *${waifus[0].name}* cemburu! Naikkan kasih sayangnya ke 70% dulu.`);
            
            await sock.sendMessage(from, { react: { text: '💍', key: msg.key } });

            let mediaPath = '';
            try {
                mediaPath = await downloadMedia(mediaMessage[mimeType], mimeType);
                const waifuUrl = await safeUploadCatbox(mediaPath);

                const newWaifu = {
                    id: Crypto.randomBytes(4).toString('hex'), name: newWaifuName, url: waifuUrl,
                    dateMarried: new Date().toISOString().split('T')[0],
                    affection: 50, status: 'Married', stress: 0, 
                    hunger: 0, health: 100, isSick: false,
                    isPregnant: false, dueDate: null, childrenCount: 0
                };

                userData[user].waifus.push(newWaifu);
                await saveUserData();
                addDoubleXp(100);

                let caption = `╭───「 💍 *JUST MARRIED* 」\n│ 👰 *${newWaifuName}*\n│ ❤️ Cinta: [█████░░░░░] 50%\n╰─────────────────────`;
                await sendImageFallback(sock, from, msg, waifuUrl, caption, [user]);
                await generateAndStoreCertificate(sock, from, msg, newWaifu, pushName, user);

            } catch (e) { msg.reply(`❌ Gagal: ${e.message}`); } 
            finally { if (mediaPath) await fs.unlink(mediaPath).catch(()=>{}); }
            return;
        }

        // ===========================================
        // B. COMMAND: STATUS
        // ===========================================
        if (mainCmd === 'waifustatus' || (mainCmd === 'waifu' && subCommand === 'status')) {
            const limitText = isUnlimited ? '∞ (Premium)' : `${MAX_WAIFU_GUEST} (Free)`;
            let text = `╭───「 👨‍👩‍👧‍👦 *FAMILY STATUS* 」\n`;
            text += `│ 👤 Suami: @${user.split('@')[0]}\n`;
            text += `│ 💍 Istri: ${waifus.length} / ${limitText}\n`;
            text += `│ 👶 Anak : ${children.length}\n`;
            text += `│ 💰 Uang : ${formatRupiah(db[user].money || 0)}\n`;
            text += `│ 🎒 Tas  : ${inv.bahan} Bahan, ${inv.obat} Obat, ${inv.susu} Susu\n`;
            text += `╰─────────────────────\n`;
            
            if (waifus.length === 0) return msg.reply(text + "\n❌ Belum punya istri. Ketik *.marry*");

            let firstImg = null;
            waifus.forEach((w, index) => {
                if (index === 0) firstImg = w.url;
                const statusHamil = w.isPregnant ? (Date.now() > w.dueDate ? "🤰 SIAP LAHIR" : "🤰 HAMIL") : "❌ TIDAK";
                
                text += `\n╭──「 *ISTRI #${index + 1}* 」\n│ 👰 *${w.name}*\n│ ❤️ Cinta : [${createBar(w.affection)}] ${w.affection}%\n│ 🏥 Sehat : [${createBar(w.health||100)}] ${w.health||100}%\n│ 🍗 Lapar : [${createBar(w.hunger||0)}] ${w.hunger||0}%\n│ 😫 Stress: [${createBar(w.stress||0)}] ${w.stress||0}%\n│ 🤰 Hamil : ${statusHamil}\n╰─────────────────────`;
            });
            await sendImageFallback(sock, from, msg, firstImg, text, [user]);
            return;
        }

        // --- CHILD LIST ---
        if ((mainCmd === 'child' && subCommand === 'list') || (mainCmd === 'waifu' && subCommand === 'child')) {
            if (children.length === 0) return msg.reply("❌ Belum punya anak.");
            let text = `👶 *DAFTAR ANAK (${children.length})*\n\n`;
            children.forEach((c, index) => {
                const happyIcon = c.happiness >= 80 ? '😄' : c.happiness >= 50 ? '🙂' : '😔';
                const sickIcon = c.isSick ? '🤒 SAKIT' : '✅ SEHAT';
                text += `*${index + 1}. ${c.name}* (${c.gender === 'Laki-laki'?'♂':'♀'})\n   - Ibu: ${c.mother}\n   - Happy: ${c.happiness}% ${happyIcon} | Pintar: ${c.smart||0}\n   - Sehat: ${c.health}% (${sickIcon})\n--------------------------\n`;
            });
            return sock.sendMessage(from, { text: text, mentions: [user] }, { quoted: msg });
        }

        // ===========================================
        // C. INTERAKSI
        // ===========================================
        const interaksi = ['kiss', 'hug', 'patpat', 'date', 'senggama', 'istrinakal', 'masak', 'mandi', 'genjot', 'ngobrol', 'tidur', 'belanja', 'olahraga', 'obati'];
        
        if (interaksi.includes(mainCmd) || (mainCmd === 'waifu' && interaksi.includes(subCommand))) {
            const action = (mainCmd !== 'waifu') ? mainCmd : subCommand;
            const target = getTargetWaifu(user, (mainCmd !== 'waifu') ? args : args.slice(1));
            if (!target) return msg.reply(`❌ Waifu tidak ditemukan.`);
            const { wife, wifeIndex } = target;

            // Health/Hunger Check
            if (wife.isSick && action !== 'obati') return msg.reply(`🤒 *${wife.name}* sedang sakit! Gunakan *.obati* dulu.`);
            if ((wife.hunger || 0) > 80 && action !== 'masak' && action !== 'belanja') return msg.reply(`🍗 *${wife.name}* kelaparan! Suruh dia *.masak* dulu.`);

            let cdTime = COOLDOWN_LIGHT, affGain = 5, stressLoss = 0, stressGain = 0, lastKey = 'lastKiss', emoji = '😘', responseText = '';
            
            // --- BASIC ---
            if (action === 'hug') { lastKey='lastHug'; stressLoss=5; emoji='🤗'; }
            else if (action === 'patpat') { lastKey='lastPatpat'; stressLoss=5; emoji='👋'; }
            else if (action === 'date') { lastKey='lastDate'; affGain=15; stressLoss=20; cdTime=COOLDOWN_DATE; emoji='🥂'; }
            else if (action === 'istrinakal') { 
                lastKey='lastNaughtyInteraction'; affGain=4; cdTime=COOLDOWN_LIGHT; emoji='😏'; 
                responseText = DIALOG_NAKAL[Math.floor(Math.random() * DIALOG_NAKAL.length)];
            }
            else if (action === 'olahraga') {
                const h = getWIBHour();
                if (!((h >= 5 && h <= 9) || (h >= 16 && h <= 18))) return msg.reply("☀️ Olahraga Pagi (05-09) atau Sore (16-18) WIB.");
                lastKey = 'lastSport'; affGain = 8; stressLoss = 10; cdTime = COOLDOWN_MEDIUM; emoji = '🏃‍♀️'; responseText = "Jogging bareng bikin sehat!"; wife.health = Math.min(100, (wife.health||100) + 5);
            }
            else if (action === 'tidur') {
                const h = getWIBHour();
                if (h >= 6 && h < 20) return msg.reply("☀️ Belum malam! Tidur jam 20:00+ WIB.");
                lastKey = 'lastSleep'; affGain = 5; stressLoss = 30; cdTime = COOLDOWN_EXTREME; emoji = '💤'; responseText = "Tidur nyenyak... Zzz...";
            }
            
            // --- BERBAYAR & CONSUMABLE (CEK CD DULUAN) ---
            
            else if (action === 'genjot') {
                const h = getWIBHour(); 
                if (h >= 5 && h < 18) return msg.reply(`☀️ Tunggu malam (18:00+ WIB). Sekarang jam ${h}.`);
                if ((db[user].money || 0) < COST_GENJOT) return msg.reply(`💸 Uang kurang! Butuh ${formatRupiah(COST_GENJOT)}.`);
                if (wife.affection < 80) return msg.reply(`🔒 Butuh Cinta 80%.`);
                
                // CEK CD MANUAL AGAR UANG TIDAK HILANG
                if (Date.now() - (wife.lastExtreme || 0) < COOLDOWN_EXTREME) {
                    return msg.reply(`⏳ Tunggu ${formatRemainingTime((wife.lastExtreme + COOLDOWN_EXTREME) - Date.now())}.`);
                }

                db[user].money -= COST_GENJOT; saveDatabase();
                lastKey = 'lastExtreme'; affGain = 30; stressGain = 30; cdTime = COOLDOWN_EXTREME; emoji = '🏩'; 
                responseText = DIALOG_HOT[Math.floor(Math.random() * DIALOG_HOT.length)];
            }

            else if (action === 'belanja') {
                if ((db[user].money || 0) < COST_BELANJA) return msg.reply(`💸 Uang kurang! Butuh ${formatRupiah(COST_BELANJA)}.`);
                // CEK CD
                if (Date.now() - (wife.lastShop || 0) < COOLDOWN_MEDIUM) {
                    return msg.reply(`⏳ Tunggu ${formatRemainingTime((wife.lastShop + COOLDOWN_MEDIUM) - Date.now())}.`);
                }
                db[user].money -= COST_BELANJA; saveDatabase();
                lastKey = 'lastShop'; affGain = 20; stressLoss = 20; cdTime = COOLDOWN_MEDIUM; emoji = '🛍️'; responseText = "Shopping time! Istri senang sekali.";
            }

            else if (action === 'masak') { 
                if (inv.bahan < 1) return msg.reply(`🥬 Tidak ada bahan masak! Beli di *.store*`);
                // CEK CD
                if (Date.now() - (wife.lastCook || 0) < COOLDOWN_LIGHT) {
                    return msg.reply(`⏳ Tunggu ${formatRemainingTime((wife.lastCook + COOLDOWN_LIGHT) - Date.now())}.`);
                }
                inv.bahan -= 1; wife.hunger = 0; lastKey='lastCook'; affGain=8; stressLoss=5; cdTime=COOLDOWN_LIGHT; emoji='🍳'; responseText = "Memasak makanan lezat keluarga! Kenyang!"; 
            }

            else if (action === 'obati') {
                if (inv.obat < 1) return msg.reply(`💊 Kamu tidak punya obat! Beli di *.store*`);
                inv.obat -= 1; wife.isSick = false; wife.health = 100; lastKey = 'lastHeal'; affGain = 10; stressLoss = 20; cdTime = COOLDOWN_LIGHT; emoji = '💊'; responseText = "Kamu merawat istri dengan penuh kasih sayang.";
            }

            else if (action === 'mandi') { lastKey='lastShower'; affGain=12; stressLoss=15; cdTime=COOLDOWN_MEDIUM; emoji='🚿'; responseText = "Mandi bareng yang menyegarkan..."; }
            else if (action === 'ngobrol') {
                lastKey = 'lastTalk'; affGain = 2; stressLoss = 2; cdTime = COOLDOWN_VERY_LIGHT; emoji = '🗣️';
                const dialogs = wife.affection < 40 ? DIALOG_LOW : (wife.affection < 80 ? DIALOG_MID : DIALOG_HIGH);
                responseText = `"${dialogs[Math.floor(Math.random() * dialogs.length)]}"`;
            }
            
            else if (action === 'senggama') { 
                lastKey='lastHeavyInteraction'; affGain=10; stressGain=5; cdTime=COOLDOWN_HEAVY; emoji='💦';
                responseText = DIALOG_HOT[Math.floor(Math.random() * DIALOG_HOT.length)];
            }

            // Apply Changes
            const lastTime = wife[lastKey] || 0;
            if (Date.now() - lastTime < cdTime) return msg.reply(`⏳ Tunggu ${formatRemainingTime((lastTime + cdTime) - Date.now())}.`);
            if (wife.isPregnant && ['senggama','istrinakal','genjot','olahraga'].includes(action)) return msg.reply(`⚠️ Istri sedang hamil! Jangan aneh-aneh.`);

            wife.affection = Math.min(100, wife.affection + affGain);
            if (stressLoss > 0) wife.stress = Math.max(0, (wife.stress || 0) - stressLoss);
            if (stressGain > 0) wife.stress = Math.min(100, (wife.stress || 0) + stressGain);
            wife[lastKey] = Date.now();

            let hasil = null;
            if (action === 'senggama' || action === 'genjot') {
                const chance = action === 'genjot' ? 0.6 : 0.3; 
                if (wife.affection > 60 && !wife.isPregnant && Math.random() < chance) {
                    wife.isPregnant = true; wife.dueDate = Date.now() + (3 * 3600000); hasil = true;
                } else hasil = false;
            }

            if (!responseText) responseText = `Interaksi ${action} berhasil.`;
            userData[user].waifus[wifeIndex] = wife; userData[user].inventory = inv;
            await saveUserData(); addDoubleXp(affGain*2);
            
            await sock.sendMessage(from, { react: { text: emoji, key: msg.key } });

            let card = `╭───「 ${emoji} *INTERAKSI* 」\n│ 👰 Target: *${wife.name}*\n│ 💬 "${responseText}"\n│\n`;
            if (action==='genjot') card += `│ 💸 Biaya: -${formatRupiah(COST_GENJOT)}\n`;
            card += `│ ❤️ Cinta : ${wife.affection-affGain} ➔ ${wife.affection}\n│ 😫 Stress: ${wife.stress}%\n`;
            if (hasil !== null) card += `│\n├──「 *PEMBUAHAN* 」\n│ ${hasil ? '🤰 POSITIF HAMIL (+)' : '❌ NEGATIF (-)'}\n`;
            card += `╰─────────────────────`;
            return sendImageFallback(sock, from, msg, wife.url, card, [user]);
        }

        // ===========================================
        // D. CHILD
        // ===========================================
        if (mainCmd === 'birth') {
            const t = getTargetWaifu(user, args);
            if (!t || !t.wife.isPregnant) return msg.reply(`❌ Tidak hamil/salah target.`);
            if (Date.now() < t.wife.dueDate) return msg.reply(`⏳ Belum waktunya.`);
            
            const childGender = Math.random() > 0.5 ? 'Laki-laki' : 'Perempuan';
            const childName = `Anak ${userData[user].children.length+1}`;
            const newChild = { 
                name: childName, gender: childGender, 
                mother: t.wife.name, birthDate: new Date().toISOString().split('T')[0], 
                happiness: 50, health: 100, hunger: 0, smart: 0, isSick: false
            };
            
            userData[user].children.push(newChild);
            t.wife.childrenCount++; t.wife.isPregnant = false; t.wife.dueDate = null;
            userData[user].waifus[t.wifeIndex] = t.wife; await saveUserData();
            return sendImageFallback(sock, from, msg, t.wife.url, `👶 *${childName}* (${childGender}) lahir dengan selamat!`, [user]);
        }

        if (mainCmd === 'child') {
            const action = args[0]?.toLowerCase();
            const idx = parseInt(args[1]) - 1;
            if (isNaN(idx) || !children[idx]) return msg.reply('❌ Salah anak.');
            const child = children[idx];

            if (child.isSick && action !== 'obati') return msg.reply(`🤒 Anak sedang sakit! Obati dulu.`);
            
            if (action === 'play') {
                if (Date.now() - (child.lastPlay||0) < COOLDOWN_PLAY) return msg.reply(`⏳ Anak lelah.`);
                child.happiness = Math.min(100, child.happiness + HAPPINESS_GAIN_CHILD); child.lastPlay = Date.now();
                const mother = waifus.find(w => w.name === child.mother); if (mother) mother.stress = Math.max(0, (mother.stress||0) - 10);
                msg.reply(`⚽ Main bola bareng *${child.name}*. Happy!`);
            }
            else if (action === 'suapi') {
                if (inv.susu < 1) return msg.reply(`🍼 Susu habis!`);
                inv.susu -= 1; child.hunger = 0; child.health = Math.min(100, (child.health||50) + 10);
                msg.reply(`🍼 *${child.name}* kenyang dan sehat!`);
            }
            else if (action === 'sekolah') {
                if ((db[user].money || 0) < COST_SEKOLAH) return msg.reply(`💸 Uang kurang.`);
                if (Date.now() - (child.lastSchool||0) < COOLDOWN_MEDIUM) return msg.reply(`⏳ Sekolah bubar.`);
                db[user].money -= COST_SEKOLAH; child.smart = (child.smart || 0) + Math.floor(Math.random() * 5) + 1; child.lastSchool = Date.now();
                msg.reply(`🎒 *${child.name}* sekolah. Pintar +${child.smart}!`);
            }
            else if (action === 'obati') {
                 if (inv.obat < 1) return msg.reply(`💊 Obat habis!`);
                 inv.obat -= 1; child.isSick = false; child.health = 100;
                 msg.reply(`💊 *${child.name}* sembuh!`);
            } 
            userData[user].children[idx] = child; userData[user].inventory = inv; userData[user].waifus = waifus; await saveUserData();
            return;
        }

        // ===========================================
        // E. STORE & JOBS
        // ===========================================
        if (mainCmd === 'store' || mainCmd === 'tokohadiah') {
            let text = `╭───「 🛍️ *SUPERMARKET* 」\n│ 💰 Saldo: ${formatRupiah(db[user].money || 0)}\n│ 🛒 Beli: *.buy [kode] [jumlah]*\n│\n`;
            for (const [key, item] of Object.entries(SHOP_ITEMS)) text += `│ • *${item.name}* (${key})\n│   ${formatRupiah(item.price)} | ${item.desc}\n`;
            text += `╰─────────────────────`;
            return msg.reply(text);
        }

        if (mainCmd === 'buy' || mainCmd === 'buygift') {
            const itemCode = args[0]?.toLowerCase();
            const amount = parseInt(args[1]) || 1;
            const item = SHOP_ITEMS[itemCode];
            if (!item) return msg.reply(`❌ Barang salah.`);
            const total = item.price * amount;
            if ((db[user].money || 0) < total) return msg.reply(`💸 Uang kurang.`);
            
            db[user].money -= total; saveDatabase();

            if (item.type === 'gift') {
                const t = getTargetWaifu(user, args.slice(2));
                if (!t) return msg.reply(`❌ Target siapa?`);
                t.wife.affection = Math.min(100, t.wife.affection + item.affection);
                t.wife.stress = Math.max(0, (t.wife.stress||0) + item.stress);
                userData[user].waifus[t.wifeIndex] = t.wife;
                msg.reply(`🎁 Kado ${item.name} terkirim ke ${t.wife.name}.`);
            } else {
                const key = itemCode === 'susu' ? 'susu' : (itemCode === 'bahan' ? 'bahan' : 'obat');
                userData[user].inventory[key] = (userData[user].inventory[key] || 0) + amount;
                msg.reply(`🛒 Beli ${amount}x ${item.name} sukses.`);
            }
            await saveUserData();
            return;
        }

        if (mainCmd === 'jobs') {
            let text = `╭───「 💼 *JOB CENTER* 」\n│ Cara: *.work [kode] [no_istri]*\n│\n`;
            for (const [key, job] of Object.entries(JOBS)) text += `│ • *${job.name}* (${key})\n│   Gaji ${formatRupiah(job.salary)}\n`;
            text += `╰─────────────────────`;
            return msg.reply(text);
        }

        if (mainCmd === 'work') {
            const job = JOBS[args[0]?.toLowerCase()];
            if (!job) return msg.reply(`❌ Job salah.`);
            const t = getTargetWaifu(user, args.slice(1));
            if (!t) return msg.reply(`❌ Target salah.`);
            
            if (t.wife.isSick || t.wife.hunger > 80) return msg.reply(`❌ Istri sakit/lapar.`);
            if (t.wife.affection < job.minAff) return msg.reply(`🔒 Affection kurang (${job.minAff}%).`);
            if (Date.now() - (t.wife.lastWork||0) < job.cooldown) return msg.reply(`⏳ Masih capek.`);

            db[user].money += job.salary; saveDatabase();
            t.wife.stress = Math.min(100, (t.wife.stress||0) + job.stress); t.wife.lastWork = Date.now();
            userData[user].waifus[t.wifeIndex] = t.wife; await saveUserData();
            return sendImageFallback(sock, from, msg, t.wife.url, `💼 Kerja *${job.name}* selesai!\n💰 +${formatRupiah(job.salary)}`, [user]);
        }

        if (mainCmd === 'renamechild') {
            const idx = parseInt(args[0]) - 1;
            if (isNaN(idx) || !userData[user].children[idx]) return msg.reply('❌ Salah anak.');
            userData[user].children[idx].name = args.slice(1).join(' '); await saveUserData();
            return msg.reply(`✅ Nama diganti.`);
        }

        if (mainCmd === 'cerai') {
            const t = getTargetWaifu(user, args);
            if (!t) return msg.reply(`❌ Salah target.`);
            if (args[args.length-1]!=='ya') return msg.reply(`⚠️ Ketik *.cerai [no] ya*`);
            userData[user].waifus.splice(t.wifeIndex, 1); await saveUserData();
            return msg.reply(`💔 Cerai berhasil.`);
        }

        if (mainCmd === 'waifu') {
            let text = `╭───「 🎮 *WAIFU DASHBOARD* 」\n│\n│ *💘 HUBUNGAN*\n│ • .marry [nama] (Reply Foto)\n│ • .waifustatus\n│\n│ *🏩 AKTIVITAS*\n│ • .ngobrol / .masak / .mandi\n│ • .kiss / .hug / .obati\n│ • .date / .senggama\n│ • .istrinakal / .tidur\n│ • .olahraga / .belanja\n│ • .genjot (Malam Only)\n│\n│ *💰 EKONOMI*\n│ • .store / .buy [item]\n│ • .jobs / .work\n│\n│ *👶 KELUARGA*\n│ • .child list\n│ • .child play/suapi/sekolah\n╰─────────────────────`;
            return msg.reply(text);
        }

    } catch (e) { console.error('[WAIFU ERROR]', e); msg.reply(`❌ Error: ${e.message}`); }
};

export default {
    command: ['waifu', 'marry', 'kiss', 'hug', 'patpat', 'senggama', 'birth', 'waifustatus', 'istrinakal', 'cerai', 'talak', 'date', 'renamechild', 'store', 'tokohadiah', 'buy', 'buygift', 'jobs', 'work', 'masak', 'mandi', 'genjot', 'ngobrol', 'tidur', 'belanja', 'olahraga', 'child', 'obati', 'sekolah', 'suapi'],
    description: 'Simulasi Keluarga (RPG + Ekonomi).',
    category: 'rpg',
    handler,
};