import axios from 'axios';
import cfg from '../config/config.json' with { type: 'json' };
import log from '../lib/logger.js';

// --- HELPER UNTUK REAKSI ---
async function sendReaction(sock, msg, reactionEmoji) {
    if (!msg.key) return;
    return sock.sendMessage(msg.key.remoteJid, {
        react: {
            text: reactionEmoji,
            key: msg.key
        }
    });
}

// --- EXPORT BAILEYS HANDLER ---
export default {
    command: ['ig', 'igdl', 'instagram'],
    category: 'downloader',

    handler: async function ({ sock, msg, args }) {
        const url = args[0];
        const jid = msg.key.remoteJid;

        // 1. Validasi Input URL
        if (!url) {
            const prefix = cfg.prefix || '.';
            return msg.reply(`*Instagram Downloader* 📥\n\nCara penggunaan:\n${prefix}ig <link_instagram>\n\nContoh:\n${prefix}ig https://www.instagram.com/reel/DXe1Z5OtSpn/`);
        }

        if (!url.includes('instagram.com')) {
            return msg.reply('❌ Link tidak valid! Pastikan itu adalah link dari Instagram.');
        }

        try {
            await sendReaction(sock, msg, '⏳');

            // 2. Request ke API Siputzx (Endpoint Igram)
            const apiUrl = `https://api.siputzx.my.id/api/d/igram?url=${encodeURIComponent(url)}`;
            
            const response = await axios.get(apiUrl, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Accept': 'application/json, text/plain, */*'
                },
                timeout: 15000 // Timeout 15 detik
            });
            const result = response.data;

            // 3. Cek Status Response
            if (!result.status || !result.data || !result.data.url || result.data.url.length === 0) {
                throw new Error("Gagal mengambil media. Pastikan akun tidak di-private atau link benar.");
            }

            const meta = result.data.meta || {};
            const mediaUrls = result.data.url;
            
            // 4. Susun Caption (Hanya dikirim di media pertama agar tidak spam)
            let captionText = `*H͟a͟r͟u͟k͟a͟ INSTAGRAM DOWNLOADER* 📥\n\n`;
            captionText += `👤 *Username:* @${meta.username || 'Tidak diketahui'}\n`;
            captionText += `❤️ *Likes:* ${meta.like_count || 0}\n`;
            captionText += `💬 *Comments:* ${meta.comment_count || 0}\n\n`;
            captionText += `📝 *Caption:*\n${meta.title || ''}`;

            // 5. Looping & Kirim Semua Media
            for (let i = 0; i < mediaUrls.length; i++) {
                const mediaItem = mediaUrls[i];
                const mediaUrl = mediaItem.url;

                // Deteksi dari properti "ext" bawaan JSON
                const isVideo = mediaItem.ext === 'mp4' || mediaItem.type === 'mp4';

                if (isVideo) {
                    await sock.sendMessage(jid, { 
                        video: { url: mediaUrl }, 
                        caption: captionText 
                    }, { quoted: msg });
                } else {
                    await sock.sendMessage(jid, { 
                        image: { url: mediaUrl }, 
                        caption: captionText 
                    }, { quoted: msg });
                }

                // Kosongkan caption untuk file kedua dan seterusnya
                captionText = ""; 
            }

            await sendReaction(sock, msg, '✅');

        } catch (e) {
            log.err("IG Downloader Error:", e.message);
            await sendReaction(sock, msg, '❌');
            
            let errMsg = e.response?.data?.message || e.message;
            if (e.code === 'ECONNABORTED' || errMsg.includes('timeout')) {
                errMsg = "Server API terlalu lama merespons. Silakan coba lagi nanti.";
            }
            
            return sock.sendMessage(jid, { 
                text: `❌ Terjadi kesalahan saat mengunduh:\n${errMsg}` 
            }, { quoted: msg });
        }
    }
};