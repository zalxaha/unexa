import fs from 'fs';
import path from 'path';
import { tmpdir } from 'os';
import Crypto from 'crypto';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { uploadCatbox } from '../lib/uploader.js'; // Pastikan path ini benar

// --- HELPER FUNCTIONS (Diambil dari kode sebelumnya) ---
function generateFileName(ext = '') {
  return path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}${ext}`);
}

// --- HANDLER UTAMA ---
const handler = async ({ sock, msg, from }) => {
    
    const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
    const quoted = contextInfo?.quotedMessage;
    
    // Ambil media dari pesan yang di-reply atau pesan saat ini (caption)
    const mediaMessage = quoted || msg.message;
    
    // Cari tipe message yang mengandung media (imageMessage, videoMessage, dll.)
    const mimeType = Object.keys(mediaMessage || {}).find(k => k.endsWith('Message')) || '';

    // Cek apakah itu gambar atau video
    if (!mimeType.includes('image') && !mimeType.includes('video') && !mimeType.includes('sticker')) {
      return sock.sendMessage(from, {
        text: '❌ Kirim atau reply gambar, video, atau stiker dengan perintah *.tourl*'
      }, { quoted: msg })
    }

    const mediaInfo = mediaMessage[mimeType];
    
    // Tentukan tipe untuk fungsi download
    const mediaTypeForDownload = mimeType.includes('image') ? 'image' 
                              : mimeType.includes('video') ? 'video' 
                              : mimeType.includes('sticker') ? 'image' : 'document';
                              
    // Tentukan ekstensi untuk file sementara
    let fileExt = '.bin';
    if (mimeType.includes('image')) fileExt = '.jpg';
    else if (mimeType.includes('video')) fileExt = '.mp4';
    else if (mimeType.includes('sticker')) fileExt = '.webp';


    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } })

    let mediaBuffer;
    const filePath = generateFileName(fileExt);

    // --- 1. UNDUH MEDIA ---
    try {
      const stream = await downloadContentFromMessage(mediaInfo, mediaTypeForDownload);
      
      const chunks = [];
      for await (const chunk of stream) {
          chunks.push(chunk);
      }
      mediaBuffer = Buffer.concat(chunks);
      fs.writeFileSync(filePath, mediaBuffer); // Simpan ke file sementara

    } catch (e) {
      console.error('[TOURL DOWNLOAD ERROR]', e)
      await sock.sendMessage(from, { react: { text: '❌', key: msg.key } })
      return sock.sendMessage(from, {
        text: `❌ Gagal mengunduh media.`
      }, { quoted: msg })
    }

    // --- 2. UPLOAD KE CATBOX ---
    let resultUrl = '';
    try {
      resultUrl = await uploadCatbox(filePath);

      await sock.sendMessage(from, {
        text: `✅ Media berhasil diunggah ke Catbox:\n\n${resultUrl}`
      }, { quoted: msg })

      await sock.sendMessage(from, { react: { text: '✅', key: msg.key } })

    } catch (e) {
      console.error('[TOURL UPLOAD ERROR]', e)
      await sock.sendMessage(from, { react: { text: '❌', key: msg.key } })
      sock.sendMessage(from, {
        text: `❌ Gagal mengunggah media: ${e.message}`
      }, { quoted: msg })
    } finally {
        // --- 3. CLEANUP ---
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }
    }
}

export default {
    command: ['tourl', 'upload'],
    description: 'Mengunggah gambar/video/stiker ke URL publik (Catbox.moe).',
    category: 'Media',
    handler,
};