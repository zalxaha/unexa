import axios from 'axios';
import FormData from 'form-data';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { Buffer } from 'buffer';
import fs from 'fs';
import path from 'path';
import { tmpdir } from 'os';
import Crypto from 'crypto';

// --- HELPER FUNCTIONS ---

function generateFileName(ext = '.png') {
  return path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}${ext}`);
}

// --- IMGUPSCALER API FUNCTIONS (Digabungkan) ---

const availableScaleRatio = [ 2, 4 ];

const imgupscale = {
  
  req: async (imagePath, scaleRatio) => {
    try {
      const data = new FormData();
      data.append('myfile', fs.createReadStream(imagePath));
      data.append('scaleRadio', scaleRatio.toString());

      const config = {
        method: 'POST',
        url: 'https://get1.imglarger.com/api/UpscalerNew/UploadNew',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',
          'Accept': 'application/json, text/plain, */*',
          'sec-ch-ua-platform': '"Android"',
          'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
          'dnt': '1',
          'sec-ch-ua-mobile': '?1',
          'origin': 'https://imgupscaler.com',
          'sec-fetch-site': 'cross-site',
          'sec-fetch-mode': 'cors',
          'sec-fetch-dest': 'empty',
          'referer': 'https://imgupscaler.com/',
          'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
          'priority': 'u=1, i',
          ...data.getHeaders()
        },
        data: data
      };

      const response = await axios.request(config);
      return response.data;
    } catch (error) {
      throw new Error(`Upload failed: ${error.message}`);
    }
  },
  
  cek: async (code, scaleRatio) => {
    try {
      const data = JSON.stringify({
        "code": code,
        "scaleRadio": scaleRatio
      });

      const config = {
        method: 'POST',
        url: 'https://get1.imglarger.com/api/UpscalerNew/CheckStatusNew',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',
          'Accept': 'application/json, text/plain, */*',
          'Content-Type': 'application/json',
          'sec-ch-ua-platform': '"Android"',
          'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Google Chrome";v="138"',
          'dnt': '1',
          'sec-ch-ua-mobile': '?1',
          'origin': 'https://imgupscaler.com',
          'sec-fetch-site': 'cross-site',
          'sec-fetch-mode': 'cors',
          'sec-fetch-dest': 'empty',
          'referer': 'https://imgupscaler.com/',
          'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
          'priority': 'u=1, i'
        },
        data: data
      };

      const response = await axios.request(config);
      return response.data;
    } catch (error) {
      throw new Error(`Status check failed: ${error.message}`);
    }
  },
  
  upscale: async (imagePath, scaleRatio, maxRetries = 30, retryDelay = 2000) => {
    try {
      console.log('Uploading image...');
      const uploadResult = await imgupscale.req(imagePath, scaleRatio);
      
      if (uploadResult.code !== 200) {
        throw new Error(`Upload failed: ${uploadResult.msg || JSON.stringify(uploadResult)}`);
      }

      const code = uploadResult.data.code;
      for (let i = 0; i < maxRetries; i++) {
        const statusResult = await imgupscale.cek(code, scaleRatio);
        
        if (statusResult.code === 200 && statusResult.data.status === 'success') {
          console.log('Processing completed!');
          return {
            status: true,
            imageUrl: statusResult.data.downloadUrls[0],
            filesize: statusResult.data.filesize,
          };
        }
        
        if (statusResult.data.status === 'error') {
          throw new Error('Processing failed on server');
        }
        await new Promise(resolve => setTimeout(resolve, retryDelay));
      }

      throw new Error('Processing timeout - maximum retries exceeded');
    } catch (error) {
      throw new Error(`Upscale failed: ${error.message}`);
    }
  }
};


// --- HANDLER UTAMA ---

export default {
  command: ['hdr', 'hd', 'remini', 'upscale'],
  description: 'Meningkatkan kualitas foto (Upscale/Remini) menggunakan ImgLarger API, mendukung 2x dan 4x.',
  category: 'tools',
  
  handler: async ({ sock, msg, args, from, command }) => {
    
    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    // 1. Parsing Argumen dan Validasi Skala
    const scale = args[0] ? parseInt(args[0]) : 2; 

    if (!availableScaleRatio.includes(scale)) {
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        return msg.reply(`❌ *Skala tidak valid!* Nilai untuk scale harus salah satu dari: ${availableScaleRatio.join(", ")}. \nContoh: *.hdr 4*`);
    }

    // 2. Dapatkan Objek Pesan dan Unduh Gambar ke Buffer
    const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
      ? { message: msg.message.extendedTextMessage.contextInfo.quotedMessage }
      : msg;
      
    const mimeType = Object.keys(quoted.message || {}).find(k => k.endsWith('Message')) || '';

    let imageBuffer;
    let filePath = null;
    
    try {
        if (!mimeType.includes('image')) {
            await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
            return msg.reply('❌ Harap kirim atau balas *gambar* untuk diproses HD/Remini.');
        }
        
        const media = quoted.message[mimeType];
        
        // Unduh media ke Buffer
        const stream = await downloadContentFromMessage(media, 'image');
        let chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        imageBuffer = Buffer.concat(chunks);

        if (!imageBuffer) throw new Error('Gagal mendapatkan gambar buffer.');

        // 3. Simpan Buffer ke file sementara (DIPERLUKAN oleh imgupscale.req)
        filePath = generateFileName('.png');
        fs.writeFileSync(filePath, imageBuffer);

    } catch (error) {
        console.error('[HD DOWNLOAD ERROR]', error);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        return msg.reply('❌ Gagal mengunduh gambar: ' + error.message);
    }
    
    // 4. Proses Gambar menggunakan fungsi 'imgupscale'
    let response;
    try {
        response = await imgupscale.upscale(filePath, scale);
    } catch (error) {
        response = { status: false, message: error.message }; 
    } finally {
        // Hapus file sementara setelah selesai upload
        if (filePath && fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }
    }

    // 5. Kirim Hasil
    if (!response || !response.status || !response.imageUrl) {
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        return msg.reply(`❌ Gagal memproses HD: ${response.message || "Terjadi kesalahan yang tidak terduga."}`);
    }

    let resultUrl = response.imageUrl;
    let resultBuffer;
    
    try {
        // 6. Unduh Gambar Hasil dari ImgLarger
        const resultResponse = await axios.get(resultUrl, { responseType: 'arraybuffer' });
        resultBuffer = Buffer.from(resultResponse.data);
        
        const captionText = `✨ *HD Upscale Result* (${scale}x) ✨\n\n(Diproses oleh Zhu)\nUkuran File: ${(resultBuffer.length / (1024 * 1024)).toFixed(2)} MB`;

        // 7. Cek ukuran file dan kirim
        const MAX_SIZE_WA = 10 * 1024 * 1024; 
        
        if (resultBuffer.length > MAX_SIZE_WA) {
            await sock.sendMessage(from, {
                text: `${captionText}\n\n*⚠️ File terlalu besar!* Hasil diunggah ke:\n${resultUrl}`
            }, { quoted: msg });

        } else {
            await sock.sendMessage(from, { 
                image: resultBuffer, 
                caption: captionText
            }, { quoted: msg });
        }
        
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (e) {
        console.error('[HD SEND/DOWNLOAD FINAL ERROR]', e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        return msg.reply('❌ Gagal mengunduh atau mengirim gambar hasil akhir: ' + e.message);
    }
  }
};
