import fs from 'fs';
import path from 'path';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';
import { tmpdir } from 'os';
import Crypto from 'crypto';
import FormData from 'form-data'; 

// Fungsi Delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

function generateFileName(ext = '') {
  return path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}${ext}`);
}

async function uploadToTmpFiles(buffer) {
    const ext = 'jpg'; 
    const mime = 'image/jpeg';
    
    const form = new FormData(); 

    form.append("file", buffer, {
        filename: `tmp.${ext}`,
        contentType: mime
    });

    const url = "https://tmpfiles.org/api/v1/upload";

    try {
        const res = await fetch(url, {
            method: 'POST',
            body: form,
            headers: form.getHeaders ? form.getHeaders() : {}
        });
        
        if (!res.ok) {
            throw new Error(`Upload API returned status ${res.status}`);
        }
        
        const data = await res.json();
        
        if (data.status !== 'success' || !data.data || !data.data.url) {
             throw new Error(`tmpfiles.org response error: ${data.data?.error?.message || JSON.stringify(data)}`);
        }

        const match = /https?:\/\/tmpfiles.org\/(.*)/.exec(data.data.url);

        if (!match || !match[1]) {
             throw new Error(`Failed to parse download URL from: ${data.data.url}`);
        }

        return `https://tmpfiles.org/dl/${match[1]}`;
    } catch (error) {
        console.error('[TMPFILES UPLOAD ERROR]', error);
        throw new Error("Gagal mengunggah file ke tmpfiles.org.");
    }
}


const handler = async ({ sock, msg, from, args }) => {
    
    const DEFAULT_PROMPT = "change skin to black"; 
    const MAX_ATTEMPTS = 5; // Maksimal percobaan polling
    const POLLING_INTERVAL = 5000; // Jeda 5 detik

    const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
    const quoted = contextInfo?.quotedMessage;

    const mediaMessage = quoted || msg.message;

    const mimeType = Object.keys(mediaMessage || {}).find(k => k.endsWith('Message')) || '';
        
    if (!mimeType.includes('image')) {
        return sock.sendMessage(from, {
            text: '❌ Reply/kirim *gambar* dengan caption *.hitamkan*.'
        }, { quoted: msg })
    }

    const inputPrompt = args.join(' ').trim();
    const promptText = inputPrompt.length > 0 ? inputPrompt : DEFAULT_PROMPT;
    
    const mediaInfo = mediaMessage[mimeType];
    
    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } })

    let mediaBuffer;
    const filePath = generateFileName('.jpg');
    let uploadedUrl = '';
    
    // 1. UNDUH MEDIA
    try {
        const stream = await downloadContentFromMessage(mediaInfo, 'image');
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        mediaBuffer = Buffer.concat(chunks);
        fs.writeFileSync(filePath, mediaBuffer);
    } catch (e) {
        console.error('[DARKSKIN DOWNLOAD ERROR]', e)
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } })
        return sock.sendMessage(from, {
            text: `❌ Gagal mengunduh media.`
        }, { quoted: msg })
    }
    
    // 2. UPLOAD KE TMPFILES.ORG
    try {
        uploadedUrl = await uploadToTmpFiles(mediaBuffer);
    } catch (e) {
        console.error('[DARKSKIN UPLOAD ERROR]', e)
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } })
        return sock.sendMessage(from, {
            text: `❌ Gagal mengunggah media ke tmpfiles.org: ${e.message}`
        }, { quoted: msg })
    } finally {
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }
    }
    
    if (!uploadedUrl) {
        return sock.sendMessage(from, {
            text: '❌ Gagal mendapatkan URL dari tmpfiles.org.'
        }, { quoted: msg })
    }
    
    // 3. PANGGIL NANO BANANA API - CREATE TASK
    const nanoBananaEndpoint = "https://chocomilk.amira.us.kg/v1/i2i/nano-banana";
    const apiUrlCreateTask = `${nanoBananaEndpoint}?prompt=${encodeURIComponent(promptText)}&image=${encodeURIComponent(uploadedUrl)}`;

    let taskId;
    
    try {
        // Panggilan Pertama: Create Task (GET)
        const resTask = await fetch(apiUrlCreateTask, {
            method: 'GET'
        });

        if (!resTask.ok) {
            throw new Error(`API Nano Banana (Task) mengembalikan status ${resTask.status}`);
        }
        
        const dataTask = await resTask.json();

        if (!dataTask.success || !dataTask.data || !dataTask.data.taskId) {
            throw new Error(`Nano Banana Task Error: Gagal membuat task. ${dataTask.error || JSON.stringify(dataTask)}`);
        }
        
        taskId = dataTask.data.taskId; 

        let finalImageUrl = null;
        let attempts = 0;

        // Panggilan Kedua (Polling): Ambil Hasil (GET task=taskId)
        while (attempts < MAX_ATTEMPTS && finalImageUrl === null) {
            attempts++;

            if (attempts > 1) {
                // Tunggu sebelum mencoba lagi
                await delay(POLLING_INTERVAL);
                await sock.sendMessage(from, { react: { text: '🔄', key: msg.key } })
            }

            const resultUrl = `${nanoBananaEndpoint}?task=${encodeURIComponent(taskId)}`;
            
            const resResult = await fetch(resultUrl, {
                method: 'GET'
            });

            if (!resResult.ok) {
                // Jangan throw, coba lagi.
                console.error(`[NANO BANANA POLLING FAILED] Status: ${resResult.status}`);
                continue; 
            }
            
            const taskResult = await resResult.json();

            if (taskResult.success && taskResult.data && taskResult.data.state === 'success' && taskResult.data.images && taskResult.data.images.length > 0) {
                finalImageUrl = taskResult.data.images[0];
                break; // Keluar dari loop jika sukses
            }
            
            // Jika state 'waiting' atau gagal, loop akan berlanjut ke percobaan berikutnya.
            if (attempts === MAX_ATTEMPTS) {
                throw new Error(`Waktu tunggu habis. Nano Banana API tidak menyelesaikan tugas setelah ${MAX_ATTEMPTS * POLLING_INTERVAL / 1000} detik. State terakhir: ${taskResult.data?.state || 'unknown'}`);
            }
        }
        
        if (!finalImageUrl) {
            throw new Error("Gagal mendapatkan URL gambar hasil setelah beberapa kali percobaan.");
        }
        
        // 4. DOWNLOAD GAMBAR HASIL DAN KIRIM
        const resImage = await fetch(finalImageUrl);

        if (resImage.ok) {
            const finalImageBuffer = await resImage.buffer();
            
            await sock.sendMessage(from, {
                image: finalImageBuffer,
                caption: `✅ Hasil dari penghitam kulit\n\n_Powered by Nano Banana AI_`
            }, { quoted: msg });

            await sock.sendMessage(from, { react: { text: '✨', key: msg.key } }); 

        } else {
            const errorText = await resImage.text();
            console.error(`[NANO BANANA DOWNLOAD FAILED] Status: ${resImage.status}, Body: ${errorText.substring(0, 100)}...`);
            throw new Error(`Gagal mengunduh hasil gambar dari Nano Banana (Status: ${resImage.status}).`);
        }

    } catch (e) {
        console.error('[NANO BANANA API ERROR]', e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        sock.sendMessage(from, {
            text: `❌ Gagal memproses Gambar menggunakan Nano Banana API: ${e.message}`
        }, { quoted: msg });
    } 
}

export default {
    command: ['hitamkan', 'darkskin'], 
    description: 'Transformasi gambar menggunakan Nano Banana API dengan prompt default "hitam legam".',
    category: 'tools',
    handler,
};