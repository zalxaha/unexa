import fs from 'fs';
import fetch from 'node-fetch';
import { writeExifImg } from '../lib/exif.js';
import cfg from '../config/config.json' with { type: "json" };

const handler = async ({ sock, msg, from, args, sender, db, isPremium, saveDatabase }) => {
    const text = args.join(" ");
    if (!text) return sock.sendMessage(from, { text: "Format:\n.brat teks" }, { quoted: msg });

    // --- [A] LOGIKA RATE LIMIT (1 RPM) ---
    const user = db[sender];
    const cooldownTime = 60 * 1000; // 1 Menit dalam milidetik
    const now = Date.now();

    if (!isPremium) {
        if (user.lastBrat && (now - user.lastBrat) < cooldownTime) {
            const remaining = Math.ceil((cooldownTime - (now - user.lastBrat)) / 1000);
            
            const limitMsg = `⚠️ *LIMIT SPAM DETECTED*\n\n` +
                `Fitur ini dibatasi *1 RPM* (1 request per menit) untuk user gratis.\n` +
                `Tunggu *${remaining} detik* lagi atau upgrade ke *Premium* untuk bypass limit.\n\n` +
                `Contact Owner: .owner`;

            return sock.sendMessage(from, { 
                text: limitMsg,
                contextInfo: {
                    externalAdReply: {
                        title: "SISTEM LIMIT HARUKA",
                        body: "Gak mau antri? Upgrade ke Premium yuk!",
                        thumbnailUrl: "https://files.catbox.moe/xbasea.jpg", // Kamu bisa ganti image ini
                        mediaType: 1,
                        renderLargerThumbnail: false
                    }
                }
            }, { quoted: msg });
        }
    }

    // --- [B] PROSES PEMBUATAN STIKER ---
    await sock.sendMessage(from, { react: { text: "⏳", key: msg.key } });

    const url = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}&delay=500`;
    const temp = `./temp/brat_${Date.now()}.png`;
    let result = "";

    try {
        const res = await fetch(url);
        if (!res.ok) throw new Error("Gagal mengambil gambar dari API");
        
        const buffer = await res.buffer();
        fs.writeFileSync(temp, buffer);

        const meta = { pack: cfg.botName || "Haruka", author: "https://zalxzhu.my.id" };
        result = await writeExifImg(fs.readFileSync(temp), meta);
        const sticker = fs.readFileSync(result);

        // --- [C] UPDATE DATABASE & KIRIM ---
        await sock.sendMessage(from, { sticker }, { quoted: msg });
        await sock.sendMessage(from, { react: { text: "✨", key: msg.key } });

        // Simpan waktu penggunaan terakhir
        user.lastBrat = now;
        await saveDatabase();

    } catch (e) {
        console.error(e);
        await sock.sendMessage(from, { react: { text: "❌", key: msg.key } });
        sock.sendMessage(from, { text: "Terjadi kesalahan sistem atau API down." }, { quoted: msg });
    } finally {
        if (fs.existsSync(temp)) fs.unlinkSync(temp);
        if (result && fs.existsSync(result)) fs.unlinkSync(result);
    }
};

export default {
    command: ["brat"],
    category: "Sticker",
    description: "Buat stiker brat dari teks (Limit 1 RPM for free user)",
    handler
};