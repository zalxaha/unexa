import axios from "axios";
import crypto from "crypto";
import * as fsp from 'fs/promises';
import fs from 'fs';
import * as path from 'path';
import NodeID3 from 'node-id3';
import fetch from 'node-fetch';

/**
 * Scraper Savetube Class
 */
class Savetube {
  constructor() {
    this.ky = 'C5D58EF67A7584E4A29F6C35BBC4EB12';
    this.m = /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(?:embed\/)?(?:v\/)?(?:shorts\/)?([a-zA-Z0-9_-]{11})/;
    this.is = axios.create({
      headers: {
        'content-type': 'application/json',
        'origin': 'https://yt.savetube.me',
        'user-agent': 'Mozilla/5.0 (Android 15; Mobile; SM-F958; rv:130.0) Gecko/130.0 Firefox/130.0'
      }
    });
  }
  
  async decrypt(enc) {
    const sr = Buffer.from(enc, 'base64');
    const ky = Buffer.from(this.ky, 'hex');
    const iv = sr.slice(0, 16);
    const dt = sr.slice(16);
    const dc = crypto.createDecipheriv('aes-128-cbc', ky, iv);
    return JSON.parse(Buffer.concat([dc.update(dt), dc.final()]).toString());
  }
  
  async getCdn() {
    const response = await this.is.get("https://media.savetube.vip/api/random-cdn");
    return response.data.cdn;
  }
  
  async download(url, format = 'mp3', quality = '128') {
    const id = url.match(this.m)?.[3];
    if (!id) throw new Error("ID video tidak ditemukan dari URL");
    
    const cdn = await this.getCdn();
    const res = await this.is.post(`https://${cdn}/v2/info`, { url: `https://www.youtube.com/watch?v=${id}` });
    const dec = await this.decrypt(res.data.data);
    
    const dl = await this.is.post(`https://${cdn}/download`, {
      id: id,
      downloadType: format === 'mp3' ? 'audio' : 'video',
      quality: quality,
      key: dec.key
    });

    return {
      title: dec.title,
      thumb: dec.thumbnail || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
      duration: dec.durationLabel,
      dl: dl.data.data.downloadUrl,
      channel: dec.channelName,
      formats: dec.audio_formats || []
    };
  }
}

async function downloadAndSave(url, filePath) {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Gagal mengunduh file`);
    const buffer = await response.buffer();
    await fsp.writeFile(filePath, buffer); 
}

async function embedMetadata(audioPath, imagePath, tags) {
    const imageBuffer = await fsp.readFile(imagePath);
    const defaultTags = {
        title: tags.title,
        artist: tags.artist || 'YouTube Downloader',
        image: {
            mime: 'image/jpeg',
            type: { id: 3, name: 'front cover' },
            description: 'Cover Art',
            imageBuffer: imageBuffer
        }
    };
    return NodeID3.write(defaultTags, audioPath);
}

const handler = async ({ sock, msg, args, from }) => {
  const text = args.join(' ');
  const parts = text.trim().split(' ');
  const url = parts[0];
  const selectedQuality = parts[1] || '128'; 
  
  const tempId = Date.now();
  const audioTempPath = path.join('/tmp', `${tempId}-audio.mp3`); 
  const imageTempPath = path.join('/tmp', `${tempId}-thumb.jpg`);

  if (!url) return sock.sendMessage(from, { text: 'Masukkan link YouTube.\nContoh: .yta https://youtu.be/xyz 128' }, { quoted: msg });

  await sock.sendMessage(from, { react: { text: '🎧', key: msg.key } });

  try {
    const st = new Savetube();
    const result = await st.download(url, 'mp3', selectedQuality);

    const availableQualities = result.formats.map(f => `• ${f.label} (${f.quality || '128'})`).join('\n');
    const caption = `*YOUTUBE AUDIO*\n\n• *Judul:* ${result.title}\n• *Durasi:* ${result.duration}\n\n*Kualitas Tersedia:*\n${availableQualities}`;

    await sock.sendMessage(from, { image: { url: result.thumb }, caption }, { quoted: msg });

    // [1/2] Versi Audio M4A
    await sock.sendMessage(from, {
        audio: { url: result.dl },
        mimetype: 'audio/mp4',
        fileName: `${result.title}.m4a`
    }, { quoted: msg });
    
    // [2/2] Versi MP3 Metadata
    await downloadAndSave(result.dl, audioTempPath);
    await downloadAndSave(result.thumb, imageTempPath);
    await embedMetadata(audioTempPath, imageTempPath, { title: result.title, artist: result.channel });
    
    await sock.sendMessage(from, {
        document: { stream: fs.createReadStream(audioTempPath) }, 
        mimetype: 'audio/mpeg', 
        fileName: `${result.title}.mp3`,
        caption: `✅ *File MP3 Berhasil Diproses*`
    }, { quoted: msg });

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
  } catch (err) {
    await sock.sendMessage(from, { text: `❌ Error: ${err.message}` }, { quoted: msg });
  } finally {
    try {
      if (fs.existsSync(audioTempPath)) await fsp.unlink(audioTempPath); 
      if (fs.existsSync(imageTempPath)) await fsp.unlink(imageTempPath); 
    } catch (e) {}
  }
};

export default {
  command: ['ytmp3', 'yta'],
  description: 'Download audio YouTube via Savetube',
  category: 'Downloader',
  handler,
};