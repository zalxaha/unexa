export default {
    command: ['profile', 'ceklevel', 'level', 'me', 'myprofile', 'dompet', 'saldo', 'balance'],
    category: 'User',
    description: 'Cek profil, level, dan saldo uang',
    isOwner: false,
    isAdmin: false,
    isBotAdmin: false,
    isPremium: false,

    handler: async ({ sock, msg, sender, db, reply, sendImage, pushName }) => {
        // Ambil data user dari database
        const user = db[sender];

        if (!user) return reply('❌ Data user tidak ditemukan. Coba chat bot dulu.');

        // --- LOGIKA NAMA ---
        const displayName = user.nama || pushName || 'User';

        // --- LOGIKA PREMIUM ---
        const isPremium = user.premiumUntil > Date.now();
        const premiumStatus = isPremium 
            ? `✅ Aktif (Exp: ${new Date(user.premiumUntil).toLocaleDateString('id-ID')})`
            : '❌ Tidak Aktif';

        // --- LOGIKA LEVEL & XP ---
        const currentLevel = user.level || 0;
        const nextLevel = currentLevel + 1;
        // Rumus XP (sama dengan handler.js): Level = 0.1 * sqrt(XP)  =>  XP = (Level / 0.1)^2
        const xpForNextLevel = Math.pow(nextLevel / 0.1, 2);
        
        // Cek jika XP user minus atau error
        const currentXP = user.xp || 0;
        const xpNeeded = Math.max(0, Math.ceil(xpForNextLevel - currentXP));
        
        let progressPercent = 0;
        if (xpForNextLevel > 0) {
            progressPercent = Math.floor((currentXP / xpForNextLevel) * 100);
        }
        if (progressPercent > 100) progressPercent = 100;

        // Progress Bar Visual
        const barLength = 10;
        const filledLength = Math.min(Math.floor((progressPercent / 100) * barLength), barLength);
        const progressBar = '█'.repeat(filledLength) + '░'.repeat(barLength - filledLength);

        // --- LOGIKA UANG (MONEY) ---
        // Format angka jadi Rupiah (Rp 1.000.000)
        const moneyFormatted = new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
        }).format(user.money || 0);

        // --- SUSUN PESAN ---
        const profileText = `
👤 *USER PROFILE*

🔖 *Nama:* ${displayName}
🏷️ *Title:* ${user.role || 'Warga Baru'}
💰 *Uang:* ${moneyFormatted}
🆙 *Level:* ${currentLevel}
✨ *XP:* ${currentXP}
📉 *Progress:* [${progressBar}] ${progressPercent}%
_Butuh ${xpNeeded} XP lagi untuk naik level_

---------------------------

💳 *Limit Harian:* ${user.limit} / ${db.globalSettings?.privateLimit || 20}
💎 *Status Premium:* ${premiumStatus}

_Ingin ganti nama? Ketik .setname NamaKamu_
`.trim();

        try {
            // Coba ambil foto profil user
            const ppUrl = await sock.profilePictureUrl(sender, 'image');
            await sendImage(ppUrl, profileText);
        } catch {
            // Jika user tidak punya PP / privasi, kirim teks saja
            await reply(profileText);
        }
    }
};