export default {
    command: ['lebaran', 'idulfitri', 'eid', 'countdownlebaran'],
    category: 'Info',
    description: 'Hitung mundur menuju Idul Fitri 1447 H (2026)',

    handler: async ({ sock, msg, reply }) => {
        // --- KONFIGURASI ---
        const targetDateStr = '2026-03-20T00:00:00+07:00'; 
        
        // Daftar Gambar Random
        const thumbnails = [
            'https://files.catbox.moe/h87vr4.jpg',
            'https://files.catbox.moe/wp4vtq.jpg',
            'https://files.catbox.moe/bgd2jh.jpg'
        ];
        // Pilih salah satu secara acak
        const randomThumb = thumbnails[Math.floor(Math.random() * thumbnails.length)];
        // -------------------

        await sock.sendMessage(msg.key.remoteJid, { react: { text: '⏳', key: msg.key } });

        const targetTime = new Date(targetDateStr).getTime();
        const now = Date.now();
        const difference = targetTime - now;

        if (difference <= 0) {
            const passedText = `
🎉 *SELAMAT HARI RAYA IDUL FITRI 1447 H* 🎉

Taqabbalallahu minna wa minkum, shiyamana wa shiyamakum.
Minal aidin wal faizin, mohon maaf lahir dan batin.
Semoga kita dipertemukan kembali dengan Ramadhan berikutnya.
`.trim();

            return sock.sendMessage(msg.key.remoteJid, {
                text: passedText,
                contextInfo: {
                    externalAdReply: {
                        title: "✨ Eid Mubarak!",
                        body: "Mohon Maaf Lahir & Batin",
                        thumbnailUrl: randomThumb, // Gambar Random
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: msg });
        }

        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);

        const targetDateReadable = new Date(targetDateStr).toLocaleDateString('id-ID', { 
            weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: 'Asia/Jakarta' 
        });

        const countdownText = `
🎉 *COUNTDOWN IDUL FITRI 1447 H* 🎉

Menuju 1 Syawal (${targetDateReadable}):

🗓️ *${days}* Hari
⏰ *${hours}* Jam
⏱️ *${minutes}* Menit
🕰️ *${seconds}* Detik

_Semoga kita sampai pada hari kemenangan._
*(Tanggal bersifat tentatif menunggu sidang isbat)*
`.trim();

        await sock.sendMessage(msg.key.remoteJid, {
            text: countdownText,
            contextInfo: {
                externalAdReply: {
                    title: `🕌 Menuju Lebaran: ${days} Hari Lagi`,
                    body: "Siapkan THR-nya! 🤭",
                    thumbnailUrl: randomThumb, // Gambar Random
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: msg });
    }
};