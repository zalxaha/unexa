import axios from 'axios';
import sharp from 'sharp';

// --- HELPER: RESIZE STICKER ---
// Output API 512x768 -> Resize ke 512x512 (Contain) agar tidak gepeng
async function createStickerBuffer(buffer) {
    return await sharp(buffer)
        .resize(512, 512, {
            fit: 'contain',
            background: { r: 0, g: 0, b: 0, alpha: 0 }
        })
        .toFormat('webp')
        .toBuffer();
}

async function getProfilePicture(sock, jid) {
    try {
        return await sock.profilePictureUrl(jid, 'image');
    } catch {
        // Default Avatar sesuai contohmu
        return 'https://telegra.ph/file/a3fdac3ba48f3f363e696.png'; 
    }
}

// --- API QC (Text Only) ---
async function generateQC(obj) {
    const { text, name, avatar } = obj;
    
    // JSON Payload Murni (Sesuai Dokumentasi)
    const json = {
        "type": "quote",
        "format": "png",
        "backgroundColor": "#FFFFFF",
        "width": 512,
        "height": 768,
        "scale": 2,
        "messages": [
            {
                "entities": [],
                "avatar": true,
                "from": {
                    "id": 1,
                    "name": name,
                    "photo": {
                        "url": avatar
                    }
                },
                "text": text,
                "replyMessage": {}
            }
        ]
    };

    try {
        const response = await axios.post('https://qc.botcahx.eu.org/generate', json, {
            headers: { 'Content-Type': 'application/json' }
        });
        return Buffer.from(response.data.result.image, 'base64');
    } catch (e) {
        throw new Error("Gagal request ke API Botcahx.");
    }
}

// --- MAIN EXPORT ---
export default {
    command: ['qc', 'quotechat'],
    category: 'Sticker',

    handler: async ({ sock, msg, args, sender, reply, sendSticker, sendReact }) => {
        let input = args.join(' ');
        
        let name = msg.pushName || 'User';
        let text = input;
        let targetJid = sender;

        // --- 1. LOGIKA REPLY ---
        if (msg.quoted) {
            targetJid = msg.quoted.sender;
            // Ambil Nama: PushName -> Notify -> No HP
            name = msg.quoted.pushName || msg.quoted.notify || msg.quoted.sender.split('@')[0];
            
            // Ambil Text dari reply jika input kosong
            if (!text) {
                text = msg.quoted.text || msg.quoted.caption || '';
            }
        }

        // --- 2. CUSTOM NAMA (|) ---
        if (input.includes('|')) {
            const split = input.split('|');
            text = split[0].trim();
            name = split[1].trim();
        }

        // --- 3. VALIDASI ---
        if (!text) {
            return reply(
`💬 *QUOTE CHAT*

📌 *Cara Pakai:*
• qc text
• qc text | nama custom
• Reply chat orang dengan qc`
            );
        }

        await sendReact('⏳');

        try {
            // Ambil PP Target
            const pp = await getProfilePicture(sock, targetJid);

            // Generate QC
            const rawBuffer = await generateQC({
                text: text,
                name: name,
                avatar: pp
            });

            // Resize & Kirim
            const sticker = await createStickerBuffer(rawBuffer);
            
            await sendSticker(sticker);
            await sendReact('✅');

        } catch (e) {
            console.error(e);
            await sendReact('❌');
            reply('❌ Gagal membuat sticker QC.');
        }
    }
};
