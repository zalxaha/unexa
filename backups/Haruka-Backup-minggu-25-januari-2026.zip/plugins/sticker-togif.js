import path from 'path';
import { tmpdir } from 'os';
import Crypto from 'crypto';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';

import { webp2mp4 } from '../lib/webp2mp4.js'; 

function generateFileName(ext = '') {
  return path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}${ext}`);
}

async function getStickerBuffer(stickerMessage) {
  const stream = await downloadContentFromMessage(stickerMessage, 'image');
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

async function togif_tomp4(sock, msg, from, stickerMessage, outputType) {
  let success = false;

  try {
    const mediaBuffer = await getStickerBuffer(stickerMessage);

    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
    const mp4Url = await webp2mp4(mediaBuffer);

    if (!mp4Url) {
      throw new Error('Gagal mendapatkan URL MP4 dari konverter.');
    }
    
    const isGif = outputType === 'togif';
    const caption = isGif 
      ? '✅ Stiker diubah ke GIF (Video loop).' 
      : '✅ Stiker diubah ke Video (MP4).';
      
    await sock.sendMessage(from, {
      video: { url: mp4Url },
      caption: caption,
      gifPlayback: isGif 
    }, { quoted: msg });
    success = true;

  } catch (err) {
    console.error(`[${outputType.toUpperCase()} ERROR]`, err);
    const failMessage = (err.message && err.message.includes('No such file'))
        ? '❌ Stiker ini tampaknya statis atau bukan stiker animasi.'
        : `❌ Gagal mengubah stiker ke ${outputType === 'togif' ? 'GIF' : 'video'}. Mungkin stiker ini statis.`;
        
    await sock.sendMessage(from, { text: failMessage }, { quoted: msg });
  }
  return success;
}


const handler = async ({ sock, msg, from }) => {
  const body =
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    '';
  const cmd = body.trim().split(/\s+/)[0].toLowerCase().replace(/^\.|^\//, ''); 
  const allowedCommands = ['togif', 'tomp4'];

  const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  const stickerMessage = quoted?.stickerMessage;
  let conversionSuccess = false;

  if (!stickerMessage) {
    if (allowedCommands.includes(cmd)) {
      return sock.sendMessage(from, { text: `❌ Reply stiker yang ingin diubah menggunakan .${cmd}.` }, { quoted: msg });
    }
    return;
  }
  
  if (!allowedCommands.includes(cmd)) {
    return;
  }

  try {
    conversionSuccess = await togif_tomp4(sock, msg, from, stickerMessage, cmd);

    if (conversionSuccess) {
      await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
    } else {
      if (msg.key) {
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
      }
    }
  } catch (err) {
    console.error('[HANDLER ERROR]', err);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    await sock.sendMessage(from, { text: '❌ Terjadi kesalahan saat memproses stiker.' }, { quoted: msg });
  }
};

export default {
  command: ['togif', 'tomp4'],
  description: 'Ubah stiker animasi (WebP) menjadi video (MP4) atau GIF.',
  category: 'Media',
  handler,
};
