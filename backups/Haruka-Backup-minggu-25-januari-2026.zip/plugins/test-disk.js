import { exec } from 'child_process';
import cfg from '../config/config.json' with { type: 'json' };

export default {
    command: ['disk', 'storage'],
    category: 'server',

    isOwner: true,      // 🔐 DISARANKAN owner only
    isAdmin: false,
    isBotAdmin: false,
    isPremium: false,

    handler: async ({
        reply,
        sendReact
    }) => {
        try {
            await sendReact('⏳');

            exec('df -h /', (err, stdout) => {
                if (err) {
                    return reply('❌ Gagal membaca disk server');
                }

                const lines = stdout.trim().split('\n');
                const data = lines[1].split(/\s+/);

                const filesystem = data[0];
                const total = data[1];
                const used = data[2];
                const available = data[3];
                const percent = data[4];
                const mount = data[5];

                const text = `
🖥️ *STATUS DISK SERVER*

📦 Total      : ${total}
📂 Terpakai   : ${used}
📭 Sisa       : ${available}
📊 Persentase : ${percent}

🧩 Mount      : ${mount}
`;

                reply(text.trim());
            });

        } catch (e) {
            reply('❌ Terjadi kesalahan saat cek disk');
        }
    }
};