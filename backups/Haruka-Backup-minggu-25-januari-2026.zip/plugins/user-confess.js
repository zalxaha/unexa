import { jidNormalizedUser, downloadContentFromMessage } from '@whiskeysockets/baileys';
import cfg from '../config/config.json' with { type: 'json' };

const cooldowns = new Map();
const COOLDOWN_SECONDS = 60; 

// Fungsi Helper untuk download media
const downloadMedia = async (message, type) => {
    const stream = await downloadContentFromMessage(message, type);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
}

export default {
    command: ['confes', 'menfess', 'confess'],
    category: 'User', 
    isOwner: false, 
    isPremium: false,
    
    handler: async ({ sock, msg, args, sender, confessMap }) => {
        
        const now = Date.now();
        const realSender = jidNormalizedUser(sender);

        // --- 1. CEK COOLDOWN ---
        if (cooldowns.has(realSender)) {
            const expirationTime = cooldowns.get(realSender) + COOLDOWN_SECONDS * 1000;
            if (now < expirationTime) {
                const timeLeft = Math.ceil((expirationTime - now) / 1000);
                return msg.reply(`🚫 Tunggu *${timeLeft} detik* sebelum mengirim konfesi lagi.`);
            }
        }

        // --- 2. CEK INPUT NOMOR & PESAN ---
        // Minimal harus ada nomor target
        if (args.length < 1) {
            return msg.reply(`
❌ Format salah.
*Gunakan:* ${cfg.prefix}confes [nomor target] [pesan]
*Atau:* Kirim gambar dengan caption ${cfg.prefix}confes [nomor] [pesan]

Contoh: 
${cfg.prefix}confes 08123456789 Aku suka kamu...
            `.trim());
        }

        // --- 3. NORMALISASI NOMOR (FITUR BARU) ---
        // Menghapus spasi, strip, simbol, dan merapikan prefix 08/62
        let inputNumber = args[0].replace(/[^0-9]/g, ""); // Hapus selain angka
        
        if (inputNumber.startsWith('08')) {
            inputNumber = '62' + inputNumber.slice(1);
        } else if (inputNumber.startsWith('8')) {
            inputNumber = '62' + inputNumber;
        } else if (inputNumber.startsWith('62')) {
            // Sudah benar
        } else {
            // Jika nomor tidak diawali 08, 8, atau 62 (misal nomor luar negri), biarkan (asal angka)
            // Tapi biasanya untuk user indo ini sudah cukup
        }

        const targetJid = inputNumber + '@s.whatsapp.net';

        // Cek self-confess
        if (targetJid === realSender) {
            return msg.reply("❌ Gak bisa kirim ke diri sendiri, sadboy...");
        }

        // --- 4. DETEKSI MEDIA & TEXT ---
        const messageContent = args.slice(1).join(' ').trim();
        
        // Cek Quoted Media atau Media yang dikirim langsung
        const q = msg.quoted ? msg.quoted : msg;
        const mime = (q.msg || q).mimetype || '';
        const isMedia = /image|video|sticker|audio|document/.test(mime);
        
        // Validasi panjang pesan (hanya jika text only)
        if (!isMedia && messageContent.length < 5) {
            return msg.reply("❌ Pesan terlalu pendek. Minimal 5 karakter.");
        }

        // Header Pesan
        const headerText = `H͟a͟r͟u͟k͟a͟\n
💌 *confession message* 💌

Seseorang mengirim pesan rahasia untukmu:
----------------------------------------

📝 *Pesan:*
${messageContent || '(Hanya mengirim media)'}

----------------------------------------
*Catatan:* Balas pesan ini untuk membalas konfesi secara anonim.
`.trim();

        try {
            // --- 5. LOGIKA PENGIRIMAN ---
            let sentMsg;

            if (isMedia) {
                // Download Media
                const messageType = Object.keys(q.message || {})[0]; // imageMessage, videoMessage, etc
                const streamType = mime.split('/')[0]; // image, video, audio
                
                // Ambil buffer media
                // Kita gunakan helper downloadMedia agar lebih bersih
                // Pastikan tipe download sesuai (image, video, sticker, audio, document)
                let typeForDownload = streamType;
                if (mime.includes('sticker')) typeForDownload = 'sticker';
                
                // Untuk document kadang butuh handling khusus, tapi coba default dulu
                const buffer = await downloadMedia(q.message[messageType], typeForDownload);

                if (mime.includes('image') || mime.includes('video')) {
                    // Jika Gambar/Video -> Kirim sebagai Caption
                    sentMsg = await sock.sendMessage(targetJid, { 
                        [streamType]: buffer, 
                        caption: headerText 
                    });
                } else if (mime.includes('sticker')) {
                    // Jika Stiker -> Kirim Stiker Dulu, Lalu Teks
                    await sock.sendMessage(targetJid, { sticker: buffer });
                    sentMsg = await sock.sendMessage(targetJid, { text: headerText + "\n\n(Mengirim Stiker 👆)" });
                } else if (mime.includes('audio')) {
                    // Jika Audio/VN -> Kirim Audio Dulu, Lalu Teks
                    await sock.sendMessage(targetJid, { audio: buffer, mimetype: 'audio/mp4', ptt: true }); // Kirim sbg VN
                    sentMsg = await sock.sendMessage(targetJid, { text: headerText + "\n\n(Mengirim Voice Note 👆)" });
                } else {
                    // Dokumen lain
                    sentMsg = await sock.sendMessage(targetJid, { document: buffer, mimetype: mime, caption: headerText });
                }

            } else {
                // TEXT ONLY
                sentMsg = await sock.sendMessage(targetJid, { text: headerText });
            }

            // --- 6. SIMPAN LOGIC BALASAN (ConfessMap) ---
            if (sentMsg?.key?.id) {
                confessMap.set(sentMsg.key.id, realSender);
                cooldowns.set(realSender, now);
                
                await msg.reply(`✅ Konfesi berhasil dikirim ke @${targetJid.split('@')[0]}!`);
            } else {
                throw new Error("Gagal mendapatkan ID pesan terkirim.");
            }

        } catch (e) {
            console.error("[CONFESS ERROR]", e);
            await msg.reply(`❌ Gagal mengirim. Pastikan nomor benar dan target bisa dihubungi WA.\nError: ${e.message}`);
        }
    }
};
