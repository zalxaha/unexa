import cfg from '../config/config.json' with { type: 'json' };
import axios from 'axios';
import FormData from 'form-data';

// --- Class HDVideo ditaruh di luar export default agar rapi ---
class HDVideo {
    constructor() {
        this.baseUrl = 'https://hdvideo.tr';
        this.headers = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',
            'Accept': '*/*',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Origin': this.baseUrl,
            'Referer': `${this.baseUrl}/`,
            'Sec-Ch-Ua': '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"',
            'Sec-Ch-Ua-Mobile': '?0',
            'Sec-Ch-Ua-Platform': '"Linux"',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            'Connection': 'keep-alive'
        };
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async prepareDownload(url, formatType = 'mp3') {
        const formData = new FormData();
        formData.append('url', url);
        formData.append('format_type', formatType);
        formData.append('agree_terms', 'on');
        
        const response = await axios.post(`${this.baseUrl}/api/prepare`, formData, {
            headers: {
                ...this.headers,
                ...formData.getHeaders()
            }
        });
        
        return response.data;
    }

    async checkStatus(jobId) {
        const response = await axios.get(`${this.baseUrl}/api/status/${jobId}`, {
            headers: this.headers
        });
        
        return response.data;
    }

    async waitForCompletion(jobId, maxAttempts = 30, interval = 2000) {
        for (let i = 0; i < maxAttempts; i++) {
            const result = await this.checkStatus(jobId);
            
            if (result.status === 'completed') {
                return result;
            }
            
            if (result.status === 'failed' || result.status === 'error') {
                return result;
            }
            
            await this.sleep(interval);
        }
        
        return { status: 'timeout', message: 'Download preparation timeout' };
    }

    async downloadVideo(url, formatType = 'mp4') {
        const prepareResult = await this.prepareDownload(url, formatType);
        
        if (prepareResult.status !== 'started') {
            return {
                success: false,
                message: 'Failed to start download preparation',
                prepareResult: prepareResult
            };
        }
        
        const jobId = prepareResult.job_id;
        const finalResult = await this.waitForCompletion(jobId);
        
        return {
            success: finalResult.status === 'completed',
            jobId: jobId,
            url: url,
            formatType: formatType,
            result: finalResult
        };
    }
}

// --- Handler Utama Bot ---
export default {
    // 1. Array Command
    command: ['ytest'],
    
    // 2. Kategori untuk Menu
    category: 'Downloader',
    
    // 3. Setting Permission
    isOwner: false,      
    isAdmin: false,      
    isBotAdmin: false,   
    isPremium: false,    

    // 4. Handler Utama
    handler: async ({ 
        args,           
        command,        
        reply,          
        sendVideo,      
        sendReact       
    }) => {
        
        // Validasi Input
        if (!args[0]) return reply(`❌ Masukkan link YouTube!\n*Contoh:* .${command} https://youtu.be/th_4MEy_ZAk`);
        if (!args[0].includes('youtu')) return reply('❌ Link yang kamu masukkan sepertinya bukan link YouTube yang valid.');

        // Kirim reaksi loading
        await sendReact('⏳');
        await reply('⏳ Sedang memproses video, tunggu sebentar ya...');

        try {
            // Inisialisasi downloader
            const downloader = new HDVideo();
            const videoUrl = args[0];
            
            // Proses download
            const result = await downloader.downloadVideo(videoUrl, 'mp4');

            // Cek apakah sukses dan link download tersedia
            if (result.success && result.result && result.result.download_url) {
                
                // Susun caption
                const title = result.result.title || 'Video YouTube';
                const captionText = `✅ *Berhasil Didownload!*\n\n🎬 *Judul:* ${title}\n🌐 *Kualitas:* ${result.result.quality || 'HD'}\n🔗 *Link Asli:* ${videoUrl}`;
                
                // Kirim Video menggunakan helper sendVideo (asumsi sendVideo menerima param (url, caption))
                await sendVideo(result.result.download_url, { caption: captionText });
                
                // Ubah reaksi jadi sukses
                await sendReact('✅');
                
            } else {
                // Jika server API gagal
                await sendReact('❌');
                await reply(`❌ Gagal mendownload video.\n*Pesan Error:* ${result.message || 'Server API bermasalah atau timeout.'}`);
            }
            
        } catch (error) {
            // Tangkap error jika API mati atau request gagal
            await sendReact('❌');
            await reply('❌ Terjadi kesalahan pada sistem saat menghubungi server downloader.');
            console.error('[HDVideo Error]:', error);
        }
    }
};