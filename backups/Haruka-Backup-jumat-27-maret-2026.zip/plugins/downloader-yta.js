import axios from "axios";
import * as fsp from 'fs/promises';
import fs from 'fs';
import * as path from 'path';
import NodeID3 from 'node-id3';
import yts from 'yt-search';

/**
 * Utility: Unduh file langsung ke local storage (/tmp)
 */
async function downloadAndSave(url, filePath) {
    const response = await axios({
        method: 'get',
        url: url,
        responseType: 'arraybuffer'
    });
    await fsp.writeFile(filePath, response.data); 
}

/**
 * Main Handler
 */
const handler = async ({ sock, msg, args, from }) => {
  const text = args.join(' ');
  const parts = text.trim().split(' ');
  const url = parts[0];

  if (!url) {
    return sock.sendMessage(from, { 
        text: '❌ Masukkan link YouTube.\nContoh: `.yta https://youtu.be/xyz`' 
    }, { quoted: msg });
  }

  // Validasi URL YouTube
  const ytRegex = /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)/;
  if (!ytRegex.test(url)) {
    return sock.sendMessage(from, { 
        text: '❌ Link tidak valid. Pastikan menggunakan link YouTube.' 
    }, { quoted: msg });
  }
  
  const tempId = Date.now();
  const audioTempPath = path.join('/tmp', `${tempId}-audio.mp3`); 
  const imageTempPath = path.join('/tmp', `${tempId}-thumb.jpg`);

  await sock.sendMessage(from, { react: { text: '🎧', key: msg.key } });

  try {
    // 1. Ekstrak Video ID dan ambil metadata detail via yt-search
    const videoIdMatch = url.match(/(?:v=|\/)([a-zA-Z0-9_-]{11})/);
    const videoId = videoIdMatch ? videoIdMatch[1] : null;
    
    let videoTitle = "YouTube Audio";
    let videoThumbnail = "https://i.ytimg.com/vi/default/hqdefault.jpg";
    let videoDuration = "Unknown";
    let videoChannel = "Haruka Downloader";

    if (videoId) {
        const videoData = await yts({ videoId });
        if (videoData) {
            videoTitle = videoData.title;
            videoThumbnail = videoData.thumbnail;
            videoDuration = videoData.duration.timestamp;
            videoChannel = videoData.author.name;
        }
    }

    await sock.sendMessage(from, { react: { text: '🔄', key: msg.key } });

    // 2. Request link download dari API NexRay
    const apiUrl = `https://api.nexray.web.id/downloader/ytmp3?url=${encodeURIComponent(url)}`;
    const { data } = await axios.get(apiUrl);

    if (!data.status || !data.result) {
        throw new Error(data.message || 'Gagal mengambil data audio dari server NexRay.');
    }

    const result = data.result;
    const finalTitle = videoTitle !== "YouTube Audio" ? videoTitle : (result.title || "YouTube Audio");

    // 3. Kirim UI Detail Info
    const caption = `*YOUTUBE AUDIO*\n\n` +
                    `• *Judul:* ${finalTitle}\n` +
                    `• *Channel:* ${videoChannel}\n` +
                    `• *Durasi:* ${videoDuration}\n` +
                    `• *Kualitas:* ${result.quality || '320'} kbps\n\n` +
                    `_Sedang memproses audio, mohon tunggu..._`;

    await sock.sendMessage(from, { image: { url: videoThumbnail }, caption }, { quoted: msg });

    await sock.sendMessage(from, { react: { text: '⬇️', key: msg.key } });

    // 4. Download file audio dan thumbnail ke temp file
    await downloadAndSave(result.url, audioTempPath);
    
    let hasThumbnail = false;
    try {
        await downloadAndSave(videoThumbnail, imageTempPath);
        hasThumbnail = true;
    } catch (e) {
        console.log("Peringatan: Gagal mengunduh thumbnail untuk ID3 tag:", e.message);
    }
    
    // 5. Inject ID3 Metadata (Cover, Judul, Artist)
    const tags = {
        title: finalTitle,
        artist: videoChannel,
    };

    if (hasThumbnail) {
        const imageBuffer = await fsp.readFile(imageTempPath);
        tags.image = {
            mime: 'image/jpeg',
            type: { id: 3, name: 'front cover' },
            description: 'Cover Art',
            imageBuffer: imageBuffer
        };
    }
    
    NodeID3.write(tags, audioTempPath);
    
    await sock.sendMessage(from, { react: { text: '📤', key: msg.key } });

    // Baca ulang file yang sudah disuntik metadata
    const finalAudioBuffer = await fsp.readFile(audioTempPath);
    const safeFileName = finalTitle.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);

    // 6. [1/2] Kirim Versi Audio Langsung (Voice Note style)
    await sock.sendMessage(from, {
        audio: finalAudioBuffer,
        mimetype: 'audio/mpeg',
        ptt: false
    }, { quoted: msg });
    
    // 7. [2/2] Kirim Versi Dokumen MP3
    await sock.sendMessage(from, {
        document: finalAudioBuffer, 
        mimetype: 'audio/mpeg', 
        fileName: `${safeFileName}.mp3`,
        caption: `✅ *File MP3 Berhasil Diproses*`
    }, { quoted: msg });

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (err) {
    console.error("Handler Error:", err);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    
    let errorMsg = err.message;
    if (err.response?.data?.message) errorMsg = err.response.data.message;
    
    await sock.sendMessage(from, { 
        text: `❌ *Error:* ${errorMsg}\n\n💡 Pastikan video publik dan bukan sesi live streaming.` 
    }, { quoted: msg });
  } finally {
    // 8. Cleanup File Temporary
    try {
      if (fs.existsSync(audioTempPath)) await fsp.unlink(audioTempPath); 
      if (fs.existsSync(imageTempPath)) await fsp.unlink(imageTempPath); 
    } catch (e) {
        // Abaikan error cleanup
    }
  }
};

export default {
  command: ['ytmp3', 'yta'],
  description: 'Download audio YouTube via NexRay (ID3 Metadata Terinjeksi)',
  category: 'Downloader',
  handler,
};