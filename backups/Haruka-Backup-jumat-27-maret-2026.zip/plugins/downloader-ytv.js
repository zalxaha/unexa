import axios from "axios";

// Format durasi dari detik (ex: 381) ke format MM:SS
const formatDuration = (seconds) => {
  if (!seconds || isNaN(seconds)) return "Unknown";
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${s < 10 ? '0' : ''}${s}`;
};

// --- HELPER: Download Video ke Buffer dengan Validasi ---
const downloadVideoBuffer = async (url, maxRetries = 3) => {
  console.log("\n[Video Download] Starting...");
  console.log("URL:", url.substring(0, 80) + "...");

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`   Attempt ${attempt}/${maxRetries}...`);
      
      const response = await axios({
        method: 'get',
        url: url,
        responseType: 'arraybuffer',
        timeout: 120000, // 2 menit untuk video besar
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'video/webm,video/mp4,video/*,*/*;q=0.9'
        },
        onDownloadProgress: (progressEvent) => {
          if (progressEvent.total) {
            const percent = Math.round((progressEvent.loaded * 100) / progressEvent.total);
            if (percent % 20 === 0) console.log(`   Progress: ${percent}%`);
          }
        }
      });

      const buffer = Buffer.from(response.data);
      const sizeMB = (buffer.length / 1024 / 1024).toFixed(2);
      console.log(`   Downloaded: ${sizeMB} MB`);

      // Validasi magic bytes
      const magic = buffer.slice(0, 16).toString('hex');
      const isMP4 = magic.includes('66747970') || magic.startsWith('00000018'); // ftyp atau mvhd
      const isWebM = magic.startsWith('1a45dfa3'); // EBML
      const isFLV = magic.startsWith('464c56'); // FLV
      
      console.log(`   Format: ${isMP4 ? 'MP4' : isWebM ? 'WebM' : isFLV ? 'FLV' : 'Unknown'}`);

      // Validasi ukuran minimum (100KB) agar tidak mendownload halaman error HTML
      if (buffer.length < 100000) {
        throw new Error(`File terlalu kecil (${buffer.length} bytes), kemungkinan link error atau expired.`);
      }

      return {
        buffer,
        size: buffer.length,
        contentType: isWebM ? 'video/webm' : 'video/mp4',
        format: isMP4 ? 'mp4' : isWebM ? 'webm' : 'unknown'
      };

    } catch (err) {
      console.error(`   Attempt ${attempt} failed:`, err.message);
      if (attempt === maxRetries) throw err;
      await new Promise(r => setTimeout(r, 2000 * attempt));
    }
  }
};

const handler = async ({ sock, msg, args, from }) => {
  const text = args.join(' ');
  const parts = text.trim().split(' ');
  const url = parts[0];
  const userReso = parts[1]; // Tangkap jika user request resolusi spesifik

  if (!url) {
    return sock.sendMessage(from, { 
      text: '❌ Masukkan link YouTube.\n\nContoh: `.ytv https://youtu.be/xyz`\n*(Otomatis 360p, akan mencari resolusi lain jika gagal)*\n\nAtau request resolusi: `.ytv link 720`' 
    }, { quoted: msg });
  }

  // Validasi URL YouTube
  const ytRegex = /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)/;
  if (!ytRegex.test(url)) {
    return sock.sendMessage(from, { 
      text: '❌ Link tidak valid. Pastikan menggunakan link YouTube.' 
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });

  // Urutan fallback resolusi: default mulai dari 360
  const defaultPriority = ['360', '480', '720', '144', '1080'];
  let resolutionsToTry = [];

  // Jika user memasukkan resolusi spesifik (contoh .ytv link 720), prioritaskan itu dulu
  // Jika gagal baru coba resolusi yang lain.
  if (userReso) {
    resolutionsToTry.push(userReso);
    resolutionsToTry.push(...defaultPriority.filter(r => r !== userReso));
  } else {
    resolutionsToTry = defaultPriority;
  }

  let finalVideoData = null;
  let finalResData = null;
  let successReso = null;
  let lastErrorMessage = "";

  // Loop untuk mencoba resolusi satu per satu (Fallback System)
  for (const reso of resolutionsToTry) {
    try {
      const apiUrl = `https://api.nexray.web.id/downloader/ytmp4?url=${encodeURIComponent(url)}&resolusi=${reso}`;
      console.log(`\n[NexRay API] Mencoba resolusi: ${reso}p -> ${apiUrl}`);
      
      const { data } = await axios.get(apiUrl);
      
      if (!data.status || !data.result || !data.result.url) {
        throw new Error(data.message || `Resolusi ${reso}p tidak tersedia di API.`);
      }

      await sock.sendMessage(from, { react: { text: '⬇️', key: msg.key } });
      
      // Coba download buffer video-nya
      const videoData = await downloadVideoBuffer(data.result.url);
      
      // Jika lolos tanpa error, simpan data ke variabel luar dan HENTIKAN loop
      finalVideoData = videoData;
      finalResData = data.result;
      successReso = reso;
      break; 
      
    } catch (err) {
      console.error(`[Fallback] Gagal di resolusi ${reso}p:`, err.message);
      lastErrorMessage = err.message;
      // Jika error, loop berlanjut ke resolusi selanjutnya di dalam array resolutionsToTry
    }
  }

  try {
    // Jika setelah semua resolusi dicoba tapi finalVideoData masih kosong (gagal semua)
    if (!finalVideoData || !finalResData) {
      throw new Error(`Semua resolusi gagal dicoba.\nError terakhir: ${lastErrorMessage}`);
    }

    await sock.sendMessage(from, { react: { text: '📤', key: msg.key } });
    
    // Siapkan detail untuk caption WhatsApp menggunakan data dari percobaan yang BERHASIL
    const safeTitle = (finalResData.title || 'video').replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);
    const fileSizeMB = (finalVideoData.size / 1024 / 1024).toFixed(2);
    const formattedDuration = formatDuration(finalResData.duration);
    
    // Strategi: File besar kirim sebagai document, kecil sebagai video (Batas 60MB untuk WA)
    const isLargeFile = finalVideoData.size > 60 * 1024 * 1024; 
    
    let captionText = `✅ *YouTube Video*\n\n` +
                      `📌 *Judul:* ${finalResData.title}\n` +
                      `⏱️ *Durasi:* ${formattedDuration}\n` +
                      `🎥 *Kualitas:* ${successReso}p\n` +
                      `📦 *Ukuran:* ${fileSizeMB} MB`;

    // Beri tahu user jika ternyata resolusi yang didapat berbeda dari request karena fallback
    if (userReso && userReso !== successReso) {
        captionText += `\n\n⚠️ _(Resolusi ${userReso}p gagal/tidak tersedia. Otomatis menggunakan ${successReso}p)_`;
    }

    if (isLargeFile) {
      captionText += `\n💡 _File besar dikirim sebagai document agar tidak corrupt._`;
      await sock.sendMessage(from, {
        document: finalVideoData.buffer,
        mimetype: 'video/mp4',
        fileName: `${safeTitle}_${successReso}p.mp4`,
        caption: captionText
      }, { quoted: msg });
    } else {
      await sock.sendMessage(from, {
        video: finalVideoData.buffer,
        mimetype: 'video/mp4',
        fileName: `${safeTitle}_${successReso}p.mp4`,
        caption: captionText
      }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (err) {
    console.error("Handler Error Output:", err);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    
    await sock.sendMessage(from, { 
      text: `❌ *Gagal Mendownload Video*\n\nDetail: ${err.message}\n\n💡 _Kemungkinan API bermasalah atau video diprivate._` 
    }, { quoted: msg });
  }
};

export default {
  command: ['ytv', 'ytmp4', 'ytvideo'],
  description: 'Download video YouTube via NexRay API (Auto Fallback)',
  category: 'Downloader',
  handler,
};