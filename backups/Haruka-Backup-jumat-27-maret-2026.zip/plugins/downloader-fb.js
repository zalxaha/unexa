import axios from 'axios';
import * as cheerio from 'cheerio';

// ==========================================
// FUNGSI SCRAPER GETMYFB
// ==========================================
async function fbDownload(url) {
    const formData = new URLSearchParams();
    formData.append('id', url);
    formData.append('locale', 'id');

    const { data } = await axios({
        method: 'POST',
        url: 'https://getmyfb.com/process',
        headers: {
            'HX-Request': 'true',
            'HX-Trigger': 'form',
            'HX-Target': 'target',
            'HX-Current-URL': 'https://getmyfb.com/id',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
        },
        data: formData.toString()
    });

    const $ = cheerio.load(data);
    
    // Mengambil link download pertama (biasanya HD jika tersedia)
    const downloadLink = $('.results-list-item a').first().attr('href');
    if (!downloadLink) throw new Error('Video download link not found');
    
    // Mencoba mengambil teks deskripsi/judul video jika ada
    const title = $('.results-item-text').text().trim() || 'Facebook Video';

    return { url: downloadLink, title };
}
// ==========================================

const handler = async ({ sock, msg, args, from }) => {
  const url = args[0];
  const sender = msg.key.participant || msg.key.remoteJid;
  const senderNumber = sender.split('@')[0];

  // Validasi Input URL
  if (!url) {
    return sock.sendMessage(from, {
      text: '📌 Masukkan URL video Facebook!\nContoh: *.fb https://www.facebook.com/xxx*'
    }, { quoted: msg });
  }

  // Cek apakah URL valid Facebook
  if (!url.match(/facebook\.com|fb\.watch|fb\.gg|fb\.me/i)) {
    return sock.sendMessage(from, { text: '❌ URL tidak valid. Gunakan link Facebook yang benar.' }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

  try {
    // 1. Mengambil data dari Scraper
    const fbData = await fbDownload(url);
    const videoUrl = fbData.url;
    const title = fbData.title;

    const caption = `*FACEBOOK DOWNLOADER*\n\n` +
                    `📝 *Judul:* ${title}\n` +
                    `🔗 *Source:* Facebook\n\n` +
                    `H͟a͟r͟u͟k͟a͟ @${senderNumber}`;

    // 2. Fetch video menjadi buffer menggunakan axios dengan header User-Agent
    const videoResponse = await axios.get(videoUrl, {
      responseType: 'arraybuffer',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
        'Referer': 'https://www.facebook.com/'
      }
    });

    const videoBuffer = Buffer.from(videoResponse.data);

    // 3. Kirim buffer video ke WhatsApp
    await sock.sendMessage(
      from, {
        video: videoBuffer,
        mimetype: "video/mp4",
        fileName: `FB_Video_${Date.now()}.mp4`, 
        caption: caption,
        mentions: [sender]
      }, {
        quoted: msg
      }
    );

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (e) {
    console.error('[FB SCRAPE ERROR]', e);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    
    // Tampilkan pesan error yang lebih jelas jika gagal
    const errorMessage = e.response ? `HTTP ${e.response.status}` : e.message;
    return sock.sendMessage(from, {
      text: `❌ Gagal mengunduh video.\nDetail: ${errorMessage}`
    }, { quoted: msg });
  }
};

export default {
  command: ['facebook', 'fb', 'fbdownload', 'fbdl'],
  description: 'Download video dari Facebook via GetMyFB Scraper',
  category: 'Downloader',
  handler,
};