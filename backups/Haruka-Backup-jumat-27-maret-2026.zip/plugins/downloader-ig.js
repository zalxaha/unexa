import axios from 'axios';
import cfg from '../config/config.json' with { type: 'json' };
import log from '../lib/logger.js';

// --- HELPER UNTUK REAKSI ---
async function sendReaction(sock, msg, reactionEmoji) {
    if (!msg.key) return;
    return sock.sendMessage(msg.key.remoteJid, {
        react: {
            text: reactionEmoji,
            key: msg.key
        }
    });
}

// --- EXPORT BAILEYS HANDLER ---
export default {
    command: ['ig', 'igdl', 'instagram'],
    category: 'downloader',

    handler: async function ({ sock, msg, args }) {
        const url = args[0];
        const jid = msg.key.remoteJid; // <-- Pake ini, dijamin valid 100%

        // 1. Validasi Input URL
        if (!url) {
            const prefix = cfg.prefix || '.';
            return msg.reply(`*Instagram Downloader* 📥\n\nCara penggunaan:\n${prefix}ig <link_instagram>\n\nContoh:\n${prefix}ig https://www.instagram.com/reel/DVYMA6NEy9e/`);
        }

        if (!url.includes('instagram.com')) {
            return msg.reply('❌ Link tidak valid! Pastikan itu adalah link dari Instagram.');
        }

        try {
            await sendReaction(sock, msg, '⏳');

            // 2. Request ke API Siputzx
            const apiUrl = `https://api.siputzx.my.id/api/d/sssinstagram?url=${encodeURIComponent(url)}`;
            const response = await axios.get(apiUrl);
            const result = response.data;

            // 3. Cek Status Response
            if (!result.status || !result.data || !result.data.url || result.data.url.length === 0) {
                throw new Error("Gagal mengambil media. Pastikan akun tidak di-private atau link benar.");
            }

            const meta = result.data.meta;
            
            // 4. Susun Caption (Hanya dikirim di media pertama agar tidak spam)
            let captionText = `*INSTAGRAM DOWNLOADER* 📥\n\n`;
            captionText += `👤 *Username:* @${meta.username || 'Tidak diketahui'}\n`;
            captionText += `❤️ *Likes:* ${meta.like_count || 0}\n`;
            captionText += `💬 *Comments:* ${meta.comment_count || 0}\n\n`;
            captionText += `📝 *Caption:*\n${meta.title || ''}`;

            // 5. Looping & Kirim Semua Media (Support Carousel/Banyak Slide)
            const mediaList = result.data.url;
            
            for (let i = 0; i < mediaList.length; i++) {
                // Di dalam response API [ [Object] ], biasanya url aslinya ada di properti .url 
                const mediaUrl = mediaList[i].url || mediaList[i]; 

                // Deteksi file gambar vs video (Berdasarkan ekstensi di URL)
                const isImage = mediaUrl.match(/\.(jpg|jpeg|png|webp)/i);

                if (isImage) {
                    await sock.sendMessage(jid, { 
                        image: { url: mediaUrl }, 
                        caption: captionText 
                    }, { quoted: msg });
                } else {
                    await sock.sendMessage(jid, { 
                        video: { url: mediaUrl }, 
                        caption: captionText 
                    }, { quoted: msg });
                }

                // Kosongkan caption untuk file kedua dan seterusnya
                captionText = ""; 
            }

            await sendReaction(sock, msg, '✅');

        } catch (e) {
            log.err("IG Downloader Error:", e.message);
            await sendReaction(sock, msg, '❌');
            
            const errMsg = e.response?.data?.message || e.message;
            
            // Perbaikan reply saat error, memastikan jid valid
            return sock.sendMessage(jid, { 
                text: `❌ Terjadi kesalahan saat mengunduh:\n${errMsg}` 
            }, { quoted: msg });
        }
    }
};