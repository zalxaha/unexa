import axios from "axios";
import * as fsp from 'fs/promises';
import fs from 'fs';
import * as path from 'path';
import NodeID3 from 'node-id3';
import yts from 'yt-search';

/**
 * Utility Functions
 */
async function downloadAndSave(url, filePath) {
    const response = await axios({
        method: 'get',
        url: url,
        responseType: 'arraybuffer'
    });
    await fsp.writeFile(filePath, response.data); 
}

/**
 * Main Handler
 */
const handler = async ({ sock, msg, args, from }) => {
  const text = args.join(' ');
  
  // Menggunakan /tmp agar aman digunakan di platform serverless/VPS
  const tempId = Date.now();
  const audioTempPath = path.join('/tmp', `${tempId}-audio.mp3`); 
  const imageTempPath = path.join('/tmp', `${tempId}-thumb.jpg`);

  if (!text) {
    return sock.sendMessage(from, {
      text: '❌ Masukkan teks pencarian atau link YouTube.\nContoh: `.play mockingbird`'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🔎', key: msg.key } });

  try {
    let videoUrl, videoTitle, videoThumbnail, videoDuration;
    const isURL = text.trim().match(/(?:youtube\.com|youtu\.be)/);
    
    // 1. Ambil metadata video (Thumbnail, Title, Duration) via yt-search
    if (!isURL) {
      const results = await yts(text);
      if (!results.videos || results.videos.length === 0) throw new Error('Video tidak ditemukan.');
      const video = results.videos[0];
      videoUrl = video.url;
      videoTitle = video.title;
      videoThumbnail = video.thumbnail;
      videoDuration = video.timestamp; // Format string e.g., "3:45"
    } else {
      videoUrl = text.trim().split(' ')[0];
      // Jika input berupa URL, ekstrak ID-nya untuk ambil thumbnail & durasi via yts
      const videoIdMatch = videoUrl.match(/(?:v=|\/)([a-zA-Z0-9_-]{11})/);
      if (videoIdMatch && videoIdMatch[1]) {
        const videoData = await yts({ videoId: videoIdMatch[1] });
        videoTitle = videoData.title;
        videoThumbnail = videoData.thumbnail;
        videoDuration = videoData.duration.timestamp;
      } else {
        // Fallback jika gagal ekstrak ID
        videoTitle = "YouTube Audio";
        videoThumbnail = "https://i.ytimg.com/vi/default/hqdefault.jpg";
        videoDuration = "Unknown";
      }
    }

    await sock.sendMessage(from, { react: { text: '🔄', key: msg.key } });

    // 2. Mengambil link download menggunakan API NexRay
    const apiUrl = `https://api.nexray.web.id/downloader/ytmp3?url=${encodeURIComponent(videoUrl)}`;
    const { data } = await axios.get(apiUrl);

    if (!data.status || !data.result) {
      throw new Error(data.message || 'Gagal mengambil data audio dari server NexRay.');
    }

    const result = data.result; 
    // Gunakan judul dari yts jika ada, jika tidak fallback ke API
    const finalTitle = videoTitle || result.title;

    // 3. Kirim Informasi Video & Thumbnail
    const captionThumbnail = `*YOUTUBE PLAY - HARUKA DOWNLOADER*\n\n` +
                             `• *Judul:* ${finalTitle}\n` +
                             `• *Durasi:* ${videoDuration}\n` +
                             `• *Kualitas:* ${result.quality || '320'}kbps\n\n` +
                             `*Sedang memproses audio, mohon tunggu...*`;

    await sock.sendMessage(from, {
      image: { url: videoThumbnail },
      caption: captionThumbnail
    }, { quoted: msg });

    await sock.sendMessage(from, { react: { text: '⬇️', key: msg.key } });

    // 4. Download file audio dan thumbnail untuk diproses ID3
    await downloadAndSave(result.url, audioTempPath);
    
    let hasThumbnail = false;
    try {
        await downloadAndSave(videoThumbnail, imageTempPath);
        hasThumbnail = true;
    } catch (e) {
        console.log("Gagal mengunduh thumbnail untuk ID3 tag:", e.message);
    }
    
    // 5. Menyisipkan Metadata (ID3 Tags - Cover Art & Title)
    const tags = {
        title: finalTitle,
        artist: 'Haruka Downloader',
    };

    if (hasThumbnail) {
        const imageBuffer = await fsp.readFile(imageTempPath);
        tags.image = {
            mime: 'image/jpeg',
            type: { id: 3, name: 'front cover' },
            description: 'Cover Art',
            imageBuffer: imageBuffer
        };
    }
    
    NodeID3.write(tags, audioTempPath);

    await sock.sendMessage(from, { react: { text: '📤', key: msg.key } });

    // Membaca file audio yang sudah disisipkan metadata
    const finalAudioBuffer = await fsp.readFile(audioTempPath);

    // 6. Kirim Audio Langsung (Bisa diputar di background WA)
    await sock.sendMessage(from, {
        audio: finalAudioBuffer,
        mimetype: 'audio/mpeg', 
        ptt: false 
    }, { quoted: msg });
    
    // 7. Kirim Audio sebagai Dokumen
    const safeFileName = finalTitle.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);
    await sock.sendMessage(from, {
        document: finalAudioBuffer,
        mimetype: 'audio/mpeg', 
        fileName: `${safeFileName}.mp3`,
        caption: `✅ *File Audio Berhasil Diproses*`
    }, { quoted: msg });

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (err) {
    console.error("Handler Error:", err);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    
    let errorMsg = err.message || 'Terjadi kesalahan pada sistem.';
    if (err.response?.data?.message) errorMsg = err.response.data.message;
    
    sock.sendMessage(from, {
      text: `❌ *Kesalahan:* ${errorMsg}`
    }, { quoted: msg });
  } finally {
    // 8. Cleanup File Temporary
    try {
        if (fs.existsSync(audioTempPath)) await fsp.unlink(audioTempPath); 
        if (fs.existsSync(imageTempPath)) await fsp.unlink(imageTempPath); 
    } catch (e) {
        // Abaikan error saat penghapusan
    }
  }
};

export default {
  command: ['play'],
  description: 'Mencari dan mengunduh audio YouTube via NexRay',
  category: 'Downloader',
  handler,
};