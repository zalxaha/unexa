import { Client } from "@gradio/client";

export default {
    command: ['animagine2', 'txt2img'],
    category: 'AI',
    description: 'Generate Anime Image (Linaqruf Official /run)',
    
    handler: async ({ sock, msg, args, reply, sendImage }) => {
        const prompt = args.join(" ");
        if (!prompt) return reply("❌ Masukkan prompt!\nContoh: .animagine2 1girl, white hair");

        // 1. React tanda mulai
        await sock.sendMessage(msg.key.remoteJid, { react: { text: '🔌', key: msg.key } });
        await reply(`⏳ *Menghubungkan ke Server...*\nTarget: Linaqruf/animagine-xl [Endpoint: /run]`);

        try {
            // --- KONEKSI ---
            const app = await Client.connect("Linaqruf/animagine-xl");
            
            await sock.sendMessage(msg.key.remoteJid, { react: { text: '🎨', key: msg.key } });
            console.log(`[AI] Connected! Sending prompt to /run...`);

            // --- KIRIM PROMPT (Sesuai JSON kamu) ---
            // Urutan parameter HARUS persis seperti di JSON (ada 15 parameter)
            const result = await app.predict("/run", [     
                prompt,         // 1. Prompt
                "lowres, bad anatomy, bad hands, text, error, missing fingers, extra digit, fewer digits, cropped, worst quality, low quality, normal quality, jpeg artifacts, signature, watermark, username, blurry", // 2. Negative Prompt
                Math.floor(Math.random() * 2147483647), // 3. Seed
                1024,           // 4. Width
                1024,           // 5. Height
                7,              // 6. Guidance scale
                28,             // 7. Number of inference steps
                "Euler a",      // 8. Sampler
                "1024 x 1024",  // 9. Aspect Ratio
                "Anime",        // 10. Style Preset
                "Standard",     // 11. Quality Tags Presets
                false,          // 12. Use Upscaler
                0.55,           // 13. Strength
                1.5,            // 14. Upscale by
                true            // 15. Add Quality Tags
            ]);

            // --- DEBUG HASIL ---
            // Cek terminal bot kalau error parsing
            console.log("[AI RESULT]", JSON.stringify(result, null, 2));

            // --- AMBIL HASIL (Gallery Component) ---
            const data = result?.data;
            
            if (data && Array.isArray(data) && data[0]) {
                // Return type JSON bilang: List[Dict(image: filepath, caption: str)]
                // Jadi gambar ada di index 0 dari result, lalu index 0 dari gallery list
                const galleryItem = data[0][0]; 
                let finalUrl = null;

                // Cek variasi output Gallery Gradio
                if (galleryItem?.image?.url) {
                    finalUrl = galleryItem.image.url;
                } else if (galleryItem?.image?.path) {
                    finalUrl = galleryItem.image.path;
                } else if (galleryItem?.url) {
                    finalUrl = galleryItem.url;
                } else if (typeof galleryItem === 'string') {
                    finalUrl = galleryItem; // Kadang cuma balikin path string
                }

                if (finalUrl) {
                    await sendImage(finalUrl, `✅ *Generate Success*\n\n*Prompt:* ${prompt}\n*Source:* Linaqruf Official`);
                    await sock.sendMessage(msg.key.remoteJid, { react: { text: '✨', key: msg.key } });
                } else {
                    console.error("Gallery Item Structure:", galleryItem);
                    throw new Error("Struktur gambar tidak dikenali dalam respon API.");
                }
            } else {
                throw new Error("Data respon kosong atau format berubah.");
            }

        } catch (e) {
            console.error("Gradio Error Full:", e);
            await reply(`❌ *Gagal:* ${e.message}`);
            await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
        }
    }
};