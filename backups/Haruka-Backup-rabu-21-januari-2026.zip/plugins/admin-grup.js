import { jidNormalizedUser } from '@whiskeysockets/baileys';

export default {
    command: ['promote', 'promosi', 'demote', 'turunkan', 'admin', 'unadmin'], 
    category: 'Group', 
    
    // KONFIGURASI HANDLER BARU
    isGroup: true,       // Hanya di grup
    isAdmin: true,       // Pengirim harus Admin
    isBotAdmin: true,    // Bot harus Admin (agar bisa promote/demote)

    handler: async function ({ sock, msg, args, from, command, participants, sendReact, reply }) {
        
        // 1. Tentukan Aksi (Promote atau Demote)
        const cmd = command.toLowerCase();
        const isPromote = ['promote', 'promosi', 'admin'].includes(cmd);
        const action = isPromote ? 'promote' : 'demote';
        const actionText = isPromote ? 'dijadikan Admin' : 'diturunkan jadi Member';
        const emoji = isPromote ? '👑' : '⬇️';

        // 2. Cari Target (Reply > Mention > Text Input)
        let targetUser = null;

        if (msg.quoted) {
            targetUser = msg.quoted.sender;
        } else if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
            targetUser = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
        } else if (args.length > 0) {
            // Bersihkan input (hanya ambil angka)
            const cleanNumber = args[0].replace(/[^0-9]/g, '');
            if (cleanNumber.length > 0) {
                targetUser = cleanNumber + '@s.whatsapp.net';
            }
        }

        if (!targetUser) {
            return reply(`⚠️ Harap reply pesan, tag orangnya, atau ketik nomornya.\nContoh: *.${cmd} @user*`);
        }

        // 3. Validasi Target dengan Data Participants (PENTING)
        // Kita cari JID yang VALID di dalam grup berdasarkan nomor HP target
        const targetNum = jidNormalizedUser(targetUser).split('@')[0];
        const member = participants.find(p => jidNormalizedUser(p.id).split('@')[0] === targetNum);

        if (!member) {
            return reply(`❌ User @${targetNum} tidak ditemukan di grup ini.`, { mentions: [targetUser] });
        }
        
        const finalJid = member.id; // Gunakan ID asli dari metadata grup (bisa @lid atau @s.whatsapp.net)

        // 4. Eksekusi
        try {
            await sendReact('⏳'); // Loading

            // Cek apakah status sudah sesuai?
            const isTargetAdmin = member.admin === 'admin' || member.admin === 'superadmin';
            if (isPromote && isTargetAdmin) {
                await sendReact('🤷‍♂️');
                return reply(`⚠️ @${targetNum} sudah menjadi Admin.`, { mentions: [finalJid] });
            }
            if (!isPromote && !isTargetAdmin) {
                await sendReact('🤷‍♂️');
                return reply(`⚠️ @${targetNum} bukan Admin.`, { mentions: [finalJid] });
            }

            // Lakukan Update
            const response = await sock.groupParticipantsUpdate(from, [finalJid], action);
            
            // Cek status respon Baileys
            // Biasanya return array object [{ status: '200', jid: ... }]
            const status = response[0]?.status;

            if (status === '200') {
                await sendReact(emoji);
                await sock.sendMessage(from, { 
                    text: `✅ Sukses! @${targetNum} telah ${actionText}.`,
                    mentions: [finalJid]
                }, { quoted: msg });
            } else if (status === '403') {
                await sendReact('🚫');
                reply('❌ Gagal. Bot tidak memiliki izin (Mungkin target adalah pembuat grup/superadmin).');
            } else {
                await sendReact('❌');
                reply(`❌ Gagal mengubah status user.`);
            }

        } catch (e) {
            console.error(e);
            await sendReact('❌');
            reply(`❌ Terjadi kesalahan sistem: ${e.message}`);
        }
    }
};