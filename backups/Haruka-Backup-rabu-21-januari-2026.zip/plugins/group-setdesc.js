export default {
    command: [
        'setdeskgc',
        'setdesc',
        'setdescgc',
        'setdeskripsi',
        'setdesk'
    ],
    description: 'Mengubah deskripsi grup (Admin Only).',
    category: 'Group',

    isGroup: true,
    isAdmin: true,
    isBotAdmin: true,

    handler: async ({ sock, msg, from, args }) => {
        try {
            const text = args.join(' ').trim();

            // Validasi input
            if (!text) {
                return msg.reply(
                    `⚠️ CARA PAKAI\n\n` +
                    `• .setdeskgc <deskripsi baru>\n` +
                    `• .setdeskgc clear (hapus deskripsi)`
                );
            }

            const newDesc = text.toLowerCase() === 'clear' ? '' : text;

            if (newDesc.length > 2048) {
                return msg.reply(
                    `⚠️ Deskripsi maksimal 2048 karakter.`
                );
            }

            // React proses
            await sock.sendMessage(from, {
                react: { text: '⏳', key: msg.key }
            });

            // Update deskripsi grup
            await sock.groupUpdateDescription(from, newDesc);

            // React sukses
            await sock.sendMessage(from, {
                react: { text: '✅', key: msg.key }
            });

            if (newDesc) {
                await msg.reply(
                    `✅ Deskripsi grup berhasil diperbarui.`
                );
            } else {
                await msg.reply(
                    `✅ Deskripsi grup berhasil dihapus.`
                );
            }

        } catch (e) {
            console.error('[SET DESC GC ERROR]', e);

            await sock.sendMessage(from, {
                react: { text: '❌', key: msg.key }
            });

            if (e.message?.includes('not-authorized')) {
                return msg.reply(
                    `❌ Bot harus menjadi admin grup.`
                );
            }

            msg.reply(`❌ Gagal mengubah deskripsi grup.\n${e.message}`);
        }
    }
};