export default {
    command: ['setname', 'gantinama', 'reg', 'daftar'],
    category: 'User',
    description: 'Mengubah nama profil di bot',
    isOwner: false,

    handler: async ({ msg, args, sender, db, saveDatabase, reply, pushName }) => {
        const newName = args.join(' ');

        if (!newName) {
            // Jika user tidak memasukkan nama, kembalikan ke nama WA asli
            const currentName = db[sender].nama || pushName || 'User';
            return reply(`
📝 *GANTI NAMA PROFIL*

Nama saat ini: *${currentName}*

Cara ganti nama:
👉 *${args[0] || '.setname'} Fano* (Untuk set nama jadi Fano)
👉 *${args[0] || '.setname'} reset* (Untuk kembali ke nama WhatsApp asli)
            `.trim());
        }

        // Fitur Reset Nama ke Pushname WA
        if (newName.toLowerCase() === 'reset') {
            db[sender].nama = pushName || 'User'; // Gunakan nama WA
            await saveDatabase();
            return reply(`✅ Nama profil berhasil di-reset ke nama WhatsApp asli: *${pushName || 'User'}*`);
        }

        // Validasi Panjang Nama
        if (newName.length > 25) {
            return reply('❌ Nama terlalu panjang! Maksimal 25 karakter.');
        }

        // Simpan ke Database
        db[sender].nama = newName;
        await saveDatabase();

        reply(`✅ Sukses! Nama profil kamu sekarang adalah: *${newName}*`);
    }
};