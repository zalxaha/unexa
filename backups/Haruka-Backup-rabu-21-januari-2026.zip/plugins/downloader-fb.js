import { fbdown } from 'btch-downloader';

const handler = async ({ sock, msg, args, from }) => {
  const url = args[0];
  const sender = msg.key.participant || msg.key.remoteJid;
  const senderNumber = sender.split('@')[0];

  // Validasi Input URL
  if (!url) {
    return sock.sendMessage(from, {
      text: '📌 Masukkan URL video Facebook!\nContoh: *.fb https://www.facebook.com/xxx*'
    }, { quoted: msg });
  }

  // Cek apakah URL valid Facebook
  if (!url.match(/facebook\.com|fb\.watch/i)) {
    return sock.sendMessage(from, { text: '❌ URL tidak valid. Gunakan link Facebook yang benar.' }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

  try {
    // Menggunakan btch-downloader
    const result = await fbdown(url);

    // Validasi data dari btch
    if (!result || !result.status) {
      throw new Error('Gagal mendapatkan data video. Pastikan link publik.');
    }

    // Prioritaskan HD, jika tidak ada gunakan Normal (SD)
    const videoUrl = result.HD || result.Normal_video;
    const quality = result.HD ? 'High Definition (HD)' : 'Standard (SD)';

    if (!videoUrl) {
      throw new Error('Link download tidak ditemukan.');
    }
    
    const caption = `H͟a͟r͟u͟k͟a͟ *FACEBOOK DOWNLOADER*\n\n` +
                    `⚙️ *Kualitas:* ${quality}\n` +
                    `🔗 *Source:* Facebook\n\n` +
                    `Ini kak videonya @${senderNumber}`;

    await sock.sendMessage(
      from, {
        video: { url: videoUrl },
        mimetype: "video/mp4",
        fileName: `fb_download.mp4`, 
        caption: caption,
        mentions: [sender]
      }, {
        quoted: msg
      }
    );

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (e) {
    console.error('[FB BTCH ERROR]', e);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    return sock.sendMessage(from, {
      text: `❌ Gagal mengunduh video.\nDetail: ${e.message}`
    }, { quoted: msg });
  }
};

export default {
  command: ['facebook', 'fb', 'fbdownload', 'fbdl'],
  description: 'Download video dari Facebook via BTCH',
  category: 'Downloader',
  handler,
};