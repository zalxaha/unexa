import axios from 'axios';
import FormData from 'form-data';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { Buffer } from 'buffer';

// --- FUNGSI REMOVE BG ---
/**
 * Mengirim buffer gambar ke API removebg.one untuk menghilangkan latar belakang.
 * @param {Buffer} buffer Buffer gambar yang akan diproses.
 * @returns {Promise<string>} URL hasil gambar tanpa latar belakang.
 */
async function removeBg(buffer) {
  const form = new FormData();
  form.append("file", buffer, "image.png");
  
  try {
      let { data } = await axios.post("https://removebg.one/api/predict/v2", form, {
        headers: {
          ...form.getHeaders(),
          "accept": "application/json, text/plain, */*",
          "locale": "en-US",
          "platform": "PC",
          "product": "REMOVEBG",
          // Headers ini penting untuk bypass perlindungan web
          "sec-ch-ua": "\"Chromium\";v=\"127\", \"Not)A;Brand\";v=\"99\", \"Microsoft Edge Simulate\";v=\"127\", \"Lemur\";v=\"127\"",
          "sec-ch-ua-mobile": "?1",
          "sec-ch-ua-platform": "\"Android\"",
          "Referer": "https://removebg.one/upload",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36"
        }
      });

      // DEBUG: Tampilkan respons asli dari API di terminal Pterodactyl/Console Anda
      console.log("[DEBUG API REMOVEBG] Respons:", JSON.stringify(data, null, 2));

      // Menangkap error jika server API sedang sibuk / kehabisan GPU (Code 500)
      if (data?.code === 500 || (data?.message && data.message.includes('GPU'))) {
          throw new Error(`Server API pihak ketiga sedang penuh/sibuk (No available GPU). Silakan coba lagi beberapa saat kemudian.`);
      }

      // Mencoba mencari URL dari beberapa kemungkinan key JSON
      const resultUrl = data?.data?.cutoutUrl || data?.data?.url || data?.url || data?.result;
      
      if (!resultUrl) {
        throw new Error('API membalas, tetapi struktur URL tidak ditemukan. Silakan cek console log.');
      }
      
      return resultUrl;
      
  } catch (error) {
      // Tangkap jika terjadi error HTTP (misal 403 Forbidden atau 500 dari jaringan)
      if (error.response) {
          console.error("[AXIOS ERROR DATA]:", error.response.data);
          throw new Error(`Ditolak oleh API (Status: ${error.response.status}).`);
      }
      // Lempar error lainnya (termasuk custom error GPU yang kita buat di atas)
      throw error;
  }
}

// --- HANDLER UTAMA ---
export default {
    command: ['removebg', 'rmbg', 'hapusbg'],
    description: 'Menghilangkan latar belakang (background) dari gambar.',
    category: 'tools',
    
    handler: async ({ sock, msg, from, command }) => {
        
        await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

        // 1. Tentukan pesan mana yang berisi media (pesan saat ini atau pesan yang di-reply)
        const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
        const quoted = contextInfo?.quotedMessage;
        const mediaMessage = quoted || msg.message;

        // 2. Cari tipe message yang mengandung media (imageMessage)
        const mimeType = Object.keys(mediaMessage || {}).find(k => k.endsWith('Message')) || '';

        if (!mimeType.includes('image')) {
            await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
            return sock.sendMessage(from, {
                text: '❌ Kirim atau reply gambar dengan perintah *.' + command + '*'
            }, { quoted: msg });
        }
        
        // 3. Unduh media
        let imageBuffer;
        try {
            const mediaInfo = mediaMessage[mimeType];
            
            const stream = await downloadContentFromMessage(mediaInfo, 'image');
            
            const chunks = [];
            for await (const chunk of stream) {
                chunks.push(chunk);
            }
            imageBuffer = Buffer.concat(chunks);

            if (!imageBuffer) throw new Error('Gagal mendapatkan gambar buffer.');
            
        } catch (downloadError) {
            console.error('[REMOVEBG DOWNLOAD ERROR]', downloadError);
            await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
            return sock.sendMessage(from, {
                text: `❌ Gagal mengunduh gambar: ${downloadError.message}`
            }, { quoted: msg });
        }

        // 4. Proses Remove BG
        let resultUrl;
        try {
            resultUrl = await removeBg(imageBuffer);

            // 5. Kirim Hasil (URL langsung dikirim sebagai gambar)
            await sock.sendMessage(from, {
                image: { url: resultUrl },
                caption: '✅ Remove BG Selesai! (Powered by removebg.one)'
            }, { quoted: msg });

            await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

        } catch (apiError) {
            console.error('[REMOVEBG API ERROR]', apiError.message);
            await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
            sock.sendMessage(from, {
                text: `❌ Gagal memproses Remove BG:\n\n_${apiError.message}_`
            }, { quoted: msg });
        }
    }
};