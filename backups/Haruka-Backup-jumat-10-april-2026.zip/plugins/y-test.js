import cfg from '../config/config.json' with { type: 'json' };
import axios from 'axios';

// --- Fungsi Downloader Menggunakan RapidAPI ---
async function ytdl(url) {
    try {
        if (!/^https?:\/\//i.test(url)) throw new Error('Invalid url.');
        
        const patterns = [
            /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
            /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
            /youtube\.com\/v\/([a-zA-Z0-9_-]{11})/,
            /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
            /youtu\.be\/([a-zA-Z0-9_-]{11})/
        ];
        const id = patterns.find(p => p.test(url))?.[Symbol.match](url)?.[1];
        if (!id) throw new Error('Failed to extract link.');
        
        const { data } = await axios.get(`https://ytstream-download-youtube-videos.p.rapidapi.com/dl?id=${id}`, {
            headers: {
                'x-rapidapi-host': 'ytstream-download-youtube-videos.p.rapidapi.com',
                'x-rapidapi-key': '6fabfe3ba0msha10853256d5c5f9p1c1247jsnf1625ea46cb6' // Catatan: Sebaiknya API Key ini dipindahkan ke config.json agar aman
            }
        });
        
        return data;
    } catch (error) {
        throw new Error(error.message);
    }
}

// --- Handler Utama Bot ---
export default {
    // 1. Array Command
    command: ['ytest'],
    
    // 2. Kategori untuk Menu
    category: 'Downloader',
    
    // 3. Setting Permission
    isOwner: false,      
    isAdmin: false,      
    isBotAdmin: false,   
    isPremium: false,    

    // 4. Handler Utama
    handler: async ({ 
        args,           
        command,        
        reply,          
        sendVideo,      
        sendReact       
    }) => {
        
        // Validasi Input
        if (!args[0]) return reply(`❌ Masukkan link YouTube!\n*Contoh:* .${command} https://youtu.be/th_4MEy_ZAk`);
        if (!args[0].includes('youtu')) return reply('❌ Link yang kamu masukkan sepertinya bukan link YouTube yang valid.');

        // Kirim reaksi loading
        await sendReact('⏳');
        await reply('⏳ Sedang memproses video, tunggu sebentar ya...');

        try {
            const videoUrl = args[0];
            
            // Proses download menggunakan API RapidAPI
            const result = await ytdl(videoUrl);

            // Cek struktur response dari RapidAPI.
            // (Sesuaikan variabel di bawah ini jika struktur JSON dari API berbeda)
            const downloadUrl = result.link || result.url || result.download_url || (result.data && (result.data.link || result.data.url));
            const title = result.title || (result.data && result.data.title) || 'Video YouTube';

            // Cek apakah sukses dan link download tersedia
            if (downloadUrl) {
                
                // Susun caption
                const captionText = `✅ *Berhasil Didownload!*\n\n🎬 *Judul:* ${title}\n🔗 *Link Asli:* ${videoUrl}`;
                
                // Kirim Video menggunakan helper sendVideo
                await sendVideo(downloadUrl, { caption: captionText });
                
                // Ubah reaksi jadi sukses
                await sendReact('✅');
                
            } else {
                // Jika API berhasil dihubungi tapi link download tidak ditemukan di struktur JSON
                await sendReact('❌');
                console.log('[DEBUG RESPONSE API]:', result); // Tetap print di terminal
                
                // Ubah data JSON menjadi teks yang rapi
                const jsonString = JSON.stringify(result, null, 2);
                
                // Batasi panjang teks maksimal 3000 karakter agar tidak gagal dikirim oleh WhatsApp/Bot
                const debugText = jsonString.length > 3000 
                    ? jsonString.substring(0, 3000) + '\n\n...[TEKS TERPOTONG KARENA TERLALU PANJANG]...' 
                    : jsonString;

                // Kirim data mentah ke chat untuk dicek
                await reply(`❌ *Gagal mendapatkan link video dari API.*\n\nBerikut adalah hasil data dari API untuk keperluan debug:\n\n\`\`\`json\n${debugText}\n\`\`\``);
            }
            
        } catch (error) {
            // Tangkap error jika API mati, limit habis, atau request gagal
            await sendReact('❌');
            await reply(`❌ Terjadi kesalahan pada sistem saat menghubungi server downloader.\n*Pesan Error:* ${error.message}`);
            console.error('[YTDL RapidAPI Error]:', error);
        }
    }
};