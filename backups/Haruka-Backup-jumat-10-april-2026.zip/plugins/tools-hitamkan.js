import fs from 'fs';
import path from 'path';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';
import { tmpdir } from 'os';
import Crypto from 'crypto';
import FormData from 'form-data'; 

// Fungsi Delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

function generateFileName(ext = '') {
  return path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}${ext}`);
}

// Menggunakan filePath (stream) bukan buffer agar form-data tidak gagal
async function uploadToTmpFiles(filePath) {
    const form = new FormData(); 

    // Menggunakan stream membuat header boundaries dan content-length terdeteksi otomatis
    form.append("file", fs.createReadStream(filePath));

    const url = "https://tmpfiles.org/api/v1/upload";

    try {
        const res = await fetch(url, {
            method: 'POST',
            body: form,
            headers: form.getHeaders ? form.getHeaders() : {}
        });
        
        if (!res.ok) {
            throw new Error(`Upload API returned status ${res.status}`);
        }
        
        const data = await res.json();
        
        if (data.status !== 'success' || !data.data || !data.data.url) {
             throw new Error(`tmpfiles.org response error: ${data.data?.error?.message || JSON.stringify(data)}`);
        }

        const match = /https?:\/\/tmpfiles.org\/(.*)/.exec(data.data.url);

        if (!match || !match[1]) {
             throw new Error(`Failed to parse download URL from: ${data.data.url}`);
        }

        // Return direct download link
        return `https://tmpfiles.org/dl/${match[1]}`;
    } catch (error) {
        console.error('[TMPFILES UPLOAD ERROR]', error);
        throw new Error("Gagal mengunggah file ke tmpfiles.org. Pastikan server tidak memblokir IP bot.");
    }
}


const handler = async ({ sock, msg, from, args }) => {
    
    // PERBAIKAN PROMPT: Dibuat sangat hitam (charcoal black) tapi dikunci agar wajah/ras tidak berubah
    const DEFAULT_PROMPT = "turn skin tone to extreme dark charcoal black, extremely dark skin, perfectly preserve exact original facial structure, preserve original ethnicity and identity, retain original face shape, strictly do not alter facial features"; 
    
    // Waktu tunggu (20 x 5 = 100 detik maksimum)
    const MAX_ATTEMPTS = 20; 
    const POLLING_INTERVAL = 5000; // Jeda 5 detik antar pengecekan

    const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
    const quoted = contextInfo?.quotedMessage;

    const mediaMessage = quoted || msg.message;

    const mimeType = Object.keys(mediaMessage || {}).find(k => k.endsWith('Message')) || '';
        
    if (!mimeType.includes('image')) {
        return sock.sendMessage(from, {
            text: '❌ Reply/kirim *gambar* dengan caption *.hitamkan*.'
        }, { quoted: msg })
    }

    const inputPrompt = args.join(' ').trim();
    const promptText = inputPrompt.length > 0 ? inputPrompt : DEFAULT_PROMPT;
    
    const mediaInfo = mediaMessage[mimeType];
    
    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } })

    const filePath = generateFileName('.jpg');
    let uploadedUrl = '';
    
    // 1. UNDUH MEDIA
    try {
        const stream = await downloadContentFromMessage(mediaInfo, 'image');
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        const mediaBuffer = Buffer.concat(chunks);
        // Simpan ke file lokal dulu
        fs.writeFileSync(filePath, mediaBuffer);
    } catch (e) {
        console.error('[DARKSKIN DOWNLOAD ERROR]', e)
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } })
        return sock.sendMessage(from, {
            text: `❌ Gagal mengunduh media dari pesan.`
        }, { quoted: msg })
    }
    
    // 2. UPLOAD KE TMPFILES.ORG 
    try {
        uploadedUrl = await uploadToTmpFiles(filePath);
    } catch (e) {
        console.error('[DARKSKIN UPLOAD ERROR]', e)
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } })
        return sock.sendMessage(from, {
            text: `❌ ${e.message}`
        }, { quoted: msg })
    } finally {
        // Bersihkan file sementara dari server untuk hemat memori
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }
    }
    
    if (!uploadedUrl) {
        return sock.sendMessage(from, {
            text: '❌ Gagal mendapatkan URL dari tmpfiles.org.'
        }, { quoted: msg })
    }
    
    // 3. PANGGIL NANO BANANA API - CREATE TASK
    const nanoBananaEndpoint = "https://chocomilk.amira.us.kg/v1/i2i/nano-banana";
    const apiUrlCreateTask = `${nanoBananaEndpoint}?prompt=${encodeURIComponent(promptText)}&image=${encodeURIComponent(uploadedUrl)}`;

    let taskId;
    
    try {
        // Panggilan Pertama: Create Task (GET)
        const resTask = await fetch(apiUrlCreateTask, { method: 'GET' });

        if (!resTask.ok) {
            throw new Error(`API Nano Banana mengembalikan status ${resTask.status}`);
        }
        
        const dataTask = await resTask.json();

        if (!dataTask.success || !dataTask.data || !dataTask.data.taskId) {
            throw new Error(`Gagal membuat task di Nano Banana: ${dataTask.error || JSON.stringify(dataTask)}`);
        }
        
        taskId = dataTask.data.taskId; 

        let finalImageUrl = null;
        let attempts = 0;

        // Panggilan Kedua (Polling): Ambil Hasil (GET task=taskId)
        while (attempts < MAX_ATTEMPTS && finalImageUrl === null) {
            attempts++;

            if (attempts > 1) {
                // Tunggu 5 detik sebelum mencoba lagi
                await delay(POLLING_INTERVAL);
                await sock.sendMessage(from, { react: { text: '🔄', key: msg.key } })
            }

            const resultUrl = `${nanoBananaEndpoint}?task=${encodeURIComponent(taskId)}`;
            const resResult = await fetch(resultUrl, { method: 'GET' });

            if (!resResult.ok) {
                console.error(`[NANO BANANA POLLING FAILED] Status: ${resResult.status}`);
                continue; 
            }
            
            const taskResult = await resResult.json();

            if (taskResult.success && taskResult.data && taskResult.data.state === 'success' && taskResult.data.images && taskResult.data.images.length > 0) {
                finalImageUrl = taskResult.data.images[0];
                break; 
            }
            
            if (attempts === MAX_ATTEMPTS) {
                throw new Error(`Waktu tunggu habis (100 detik). AI sedang sibuk atau antrean panjang. State terakhir: ${taskResult.data?.state || 'unknown'}`);
            }
        }
        
        if (!finalImageUrl) {
            throw new Error("Gagal mendapatkan URL gambar hasil setelah mencoba maksimal.");
        }
        
        // 4. DOWNLOAD GAMBAR HASIL DAN KIRIM
        const resImage = await fetch(finalImageUrl);

        if (resImage.ok) {
            const finalImageBuffer = await resImage.buffer();
            
            await sock.sendMessage(from, {
                image: finalImageBuffer,
                caption: `✅ Hasil dari penghitam kulit\n\n_Powered by Nano Banana AI_`
            }, { quoted: msg });

            await sock.sendMessage(from, { react: { text: '✨', key: msg.key } }); 

        } else {
            const errorText = await resImage.text();
            console.error(`[NANO BANANA DOWNLOAD FAILED] Status: ${resImage.status}, Body: ${errorText.substring(0, 100)}...`);
            throw new Error(`Gagal mengunduh hasil gambar (Status: ${resImage.status}).`);
        }

    } catch (e) {
        console.error('[NANO BANANA API ERROR]', e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        sock.sendMessage(from, {
            text: `❌ Gagal memproses: ${e.message}`
        }, { quoted: msg });
    } 
}

export default {
    command: ['hitamkan', 'darkskin'], 
    description: 'Transformasi tone warna kulit menjadi sangat hitam (charcoal) tanpa mengubah struktur asli wajah.',
    category: 'tools',
    handler,
};