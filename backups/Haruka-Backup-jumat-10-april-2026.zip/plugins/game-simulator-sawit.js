export default {
    command: ['sawit', 'sawitsimulator'],
    category: 'Game',
    description: 'Simulasi Juragan Sawit dengan sistem Mitra, Mandiri, Cuaca & Perawatan proporsional',

    handler: async ({ sock, msg, args, db, sender, saveDatabase, reply, pushName }) => {
        const user = db[sender];
        
        const COOLDOWN_CMD = 10000; 

        if (user.lastSawitCmd && (Date.now() - user.lastSawitCmd) < COOLDOWN_CMD) {
            const sisaWaktu = Math.ceil((user.lastSawitCmd + COOLDOWN_CMD - Date.now()) / 1000);
            return reply(`⏳ Tunggu ${sisaWaktu} detik sebelum menggunakan perintah ini lagi.`);
        }
        user.lastSawitCmd = Date.now();

        const subCmd = args[0]?.toLowerCase();
        const arg2 = args[1]?.toLowerCase();
        const arg3 = parseInt(args[2]);

        const generateCuaca = () => {
            const r = Math.random();
            if (r < 0.40) return 'Cerah';
            if (r < 0.65) return 'Hujan';
            if (r < 0.90) return 'Kemarau';
            return 'Ekstrem';
        };

        const defaultValues = {
            sawit_lahan: 0, sawit_bibit: 0, sawit_pohon: 0, sawit_pekerja: 0, 
            sawit_mess: 0, sawit_truk: 0, sawit_drainase: 0, sawit_pompa: 0, 
            sawit_pupuk: 0, sawit_pestisida: 0, sawit_keamanan: 0, sawit_riset: 0, 
            xp: 0, money: 0, sawit_panen_count: 0, sawit_last_panen: 0,
            sawit_pupuk_aktif: false, sawit_pestisida_aktif: false, sawit_hutang: 0
        };

        for (const key in defaultValues) {
            if (typeof user[key] === 'undefined' || (typeof defaultValues[key] === 'number' && isNaN(user[key]))) {
                user[key] = defaultValues[key];
            }
        }
        if (typeof user.sawit_has_claimed_loan === 'undefined') user.sawit_has_claimed_loan = false;
        if (typeof user.sawit_is_loan === 'undefined') user.sawit_is_loan = false;
        if (!user.sawit_cuaca_next) user.sawit_cuaca_next = generateCuaca();

        const baseUrl = "https://cdn.jsdelivr.net/gh/rhamt24/zalxzhu.github.io/images/";
        const img = {
            default: baseUrl + "sawit.png",
            modal: baseUrl + "sawit-beri-uang.png",     
            nomodal: baseUrl + "sawit-gaboleh.png",     
            beli: baseUrl + "sawit-beli-bibit.png",     
            pajak: baseUrl + "sawit-setor-pajak.png",   
            mandiri: baseUrl + "sawit-mandiri.png"
        };

        const sendSawitCard = async (text, headerTitle, imageUrl) => {
            await sock.sendMessage(msg.key.remoteJid, {
                text: text,
                contextInfo: {
                    externalAdReply: {
                        title: headerTitle || "SAWIT SIMULATOR",
                        body: "Juragan Sawit Mobile - RPG Tycoon",
                        thumbnailUrl: imageUrl || img.default,
                        sourceUrl: 'https://whatsapp.com/channel/0029VaoNbbHAInPfk5U20C12',
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: msg });
        };

        const COOLDOWN_PANEN = 20 * 60 * 1000; 
        const MAX_POHON_PER_HA = 256;          
        const BASE_PEKERJA = 20;
        const PEKERJA_PER_MESS = 50;
        const GAJI_POKOK = 40000; 
        const BONUS_PANEN_PERSEN = 0.05; 
        const KAPASITAS_TRUK = 1000; 
        const BIAYA_TRUK_PRIBADI = 1000; 
        const BIAYA_SEWA_TRUK = 5000; 

        // HARGA STATIS
        const HARGA = {
            bibit: 30000, pekerja: 2000000, drainase: 15000000, 
            pompa: 20000000, pupuk: 25000, pestisida: 30000
        };

        // HARGA DINAMIS (Inflasi)
        const getHargaDinamis = (item) => {
            if (item === 'lahan') {
                const kepemilikan = user.sawit_lahan > 0 ? user.sawit_lahan - 1 : 0;
                return Math.floor(50000000 * Math.pow(1.35, kepemilikan)); 
            }
            if (item === 'mess') return Math.floor(40000000 * Math.pow(1.25, user.sawit_mess));
            if (item === 'truk') {
                const kepemilikanTruk = user.sawit_truk > 0 ? user.sawit_truk - 1 : 0;
                return Math.floor(120000000 * Math.pow(1.15, kepemilikanTruk));
            }
            return HARGA[item] || null;
        };

        const BIAYA_UPGRADE = {
            keamanan: [0, 50000000, 150000000, 300000000],
            riset: [0, 100000000, 250000000, 500000000, 1000000000, 2500000000]
        };

        const formatMoney = (angka) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(angka);
        const addXp = (amount) => { user.xp += amount; return amount; };

        // 1. MENU UTAMA
        if (!subCmd) {
            const menuText = `
🌴 *SAWIT SIMULATOR RPG* 🌴

👤 Owner: ${pushName}
🏷️ Status: *${user.sawit_lahan > 0 ? (user.sawit_is_loan ? "🤝 Mitra" : "👑 Mandiri") : "Belum Main"}*
⭐ XP: ${user.xp}

🎮 *PANDUAN JURAGAN:*
👉 \`.sawit daftar\` (Mulai)
👉 \`.sawit status\` (Cek Kebun)
👉 \`.sawit cuaca\` (Cek BMKG)
👉 \`.sawit beli\` (Toko Aset)
👉 \`.sawit upgrade\` (Riset & Aman)
👉 \`.sawit tanam [jml]\` 
👉 \`.sawit rawat [pupuk/pestisida]\`
👉 \`.sawit panen\` (Kirim CPO)
👉 \`.sawit lunasi\` (Bebas Mitra)
`.trim();
            return sendSawitCard(menuText, "MANUAL BOOK JURAGAN", img.default);
        }

        // 2. DAFTAR
        if (subCmd === 'daftar') {
            if (user.sawit_lahan > 0) return reply('❌ Kebun kamu sudah jalan.');
            let message = "", header = "", currentImage = img.default, xpGain = 0;

            if (!user.sawit_has_claimed_loan) {
                user.money += 10000000;
                user.sawit_lahan = 1; user.sawit_bibit = 200; user.sawit_pekerja = 2; user.sawit_truk = 1;
                user.sawit_hutang = 250000000; 
                user.sawit_has_claimed_loan = true; 
                xpGain = addXp(1000); 
                message = `🤝 *KONTRAK MITRA DISETUJUI!*\n\nBank memberikan pinjaman kebun dan aset senilai Rp 250.000.000.\nSetiap panen akan dipotong 40% (15% Bunga Pabrik + 25% Cicilan Utang otomatis).\n\n💰 Modal Cash: Rp 10.000.000\n📦 Aset: 1 Ha, 200 Bibit, 2 Buruh, 1 Truk.\n⭐ XP: +${xpGain}`;
                header = "KONTRAK MITRA BARU"; currentImage = img.modal;
            } else {
                user.money += 500000;
                user.sawit_lahan = 1; user.sawit_bibit = 100; user.sawit_pekerja = 1; 
                xpGain = addXp(100); 
                message = `📉 *PAKET BANGKIT*\n\n📦 Aset: 1 Ha Lahan, 100 Bibit, 1 Buruh.\n💰 Uang Saku: Rp 500.000`;
                header = "KONTRAK PEMULIHAN"; currentImage = img.nomodal;
            }
            user.sawit_is_loan = true;
            await saveDatabase();
            return sendSawitCard(message, header, currentImage);
        }

        if (user.sawit_lahan === 0 && subCmd !== 'reset') return reply('❌ Ketik *.sawit daftar* untuk mulai.');

        // 3. STATUS
        if (subCmd === 'status') {
            const now = Date.now();
            const timeLeft = COOLDOWN_PANEN - (now - user.sawit_last_panen);
            
            const maxPekerja = BASE_PEKERJA + (user.sawit_mess * PEKERJA_PER_MESS);
            let iconCuaca = user.sawit_cuaca_next === 'Cerah' ? '☀️' : (user.sawit_cuaca_next === 'Hujan' ? '🌧️' : (user.sawit_cuaca_next === 'Kemarau' ? '🏜️' : '🌪️'));

            let rasioDrainase = Math.min(100, Math.floor((user.sawit_drainase / user.sawit_lahan) * 100));
            let rasioPompa = Math.min(100, Math.floor((user.sawit_pompa / user.sawit_lahan) * 100));

            const statusText = `
📊 *LAPORAN HARIAN JURAGAN*

🌳 Pohon: ${user.sawit_pohon} / ${user.sawit_lahan * MAX_POHON_PER_HA} (${user.sawit_lahan} Ha)
👷 Buruh: ${user.sawit_pekerja} / ${maxPekerja} | 🚛 Truk: ${user.sawit_truk}

🌦️ *Prediksi Cuaca Panen:* ${iconCuaca} ${user.sawit_cuaca_next}
🧪 *Status Perawatan Lahan:*
- Pupuk (+20%): ${user.sawit_pupuk_aktif ? "✅ Sudah Ditebar" : "❌ Belum (.sawit rawat pupuk)"}
- Pestisida (Anti Hama): ${user.sawit_pestisida_aktif ? "✅ Sudah Disemprot" : "❌ Belum (.sawit rawat pestisida)"}

🎒 *Gudang:* Pupuk ${user.sawit_pupuk} Sak | Pestisida ${user.sawit_pestisida} L
🛡️ *Infrastruktur (Proteksi per Ha):* - Drainase: ${user.sawit_drainase} Unit (${rasioDrainase}% Lahan Aman)
- Pompa: ${user.sawit_pompa} Unit (${rasioPompa}% Lahan Aman)

🕒 Panen: ${timeLeft > 0 ? Math.ceil(timeLeft/60000) + " Menit" : "✅ SIAP!"}
💰 Saldo: ${formatMoney(user.money)}
${user.sawit_is_loan ? `🏦 Sisa Utang: ${formatMoney(user.sawit_hutang)}` : ""}
`.trim();
            return sendSawitCard(statusText, "STATUS KEBUN", img.default);
        }

        // 4. BMKG / CUACA
        if (['cuaca', 'ramalan', 'bmkg'].includes(subCmd)) {
            let infoCuaca = '';
            if (user.sawit_cuaca_next === 'Cerah') infoCuaca = '☀️ *Cerah* - Cuaca bersahabat, panen aman dari penyusutan alam.';
            if (user.sawit_cuaca_next === 'Hujan') infoCuaca = '🌧️ *Hujan Lebat* - Waspada BANJIR! Pastikan jumlah Unit Drainase sebanding dengan jumlah Hektar lahanmu.';
            if (user.sawit_cuaca_next === 'Kemarau') infoCuaca = '🏜️ *Kemarau Panjang* - Waspada KEKERINGAN! Buah menyusut jika Unit Pompa Air lebih sedikit dari Hektar lahan.';
            if (user.sawit_cuaca_next === 'Ekstrem') infoCuaca = '🌪️ *Cuaca Ekstrem* - BADAI ANGIN! Sebagian pohon bisa tumbang tanpa pandang bulu.';

            return sendSawitCard(`📡 *LAPORAN BMKG JURAGAN*\n\nPrediksi cuaca panen berikutnya:\n\n${infoCuaca}\n\n💡 *Tips:* Rasio aman adalah 1 Fasilitas untuk 1 Hektar Lahan.`, "PREDIKSI CUACA", img.default);
        }

        // 5. BELI & UPGRADE
        if (subCmd === 'beli') {
            if (!arg2) {
                return sendSawitCard(`🛒 *TOKO JURAGAN (Harga Dinamis)*
1. *bibit*: ${formatMoney(HARGA.bibit)}
2. *pekerja*: ${formatMoney(HARGA.pekerja)}
3. *mess*: ${formatMoney(getHargaDinamis('mess'))} (+50 Kaps Buruh)
4. *lahan*: ${formatMoney(getHargaDinamis('lahan'))} / Ha
5. *truk*: ${formatMoney(getHargaDinamis('truk'))} (Kaps 1000)
6. *drainase*: ${formatMoney(HARGA.drainase)} (Pelindung 1 Ha)
7. *pompa*: ${formatMoney(HARGA.pompa)} (Pelindung 1 Ha)
8. *pupuk*: ${formatMoney(HARGA.pupuk)} (Untuk 100 Pohon)
9. *pestisida*: ${formatMoney(HARGA.pestisida)} (Untuk 100 Pohon)`, "MARKETPLACE ASET", img.beli);
            }
            
            let jumlah = arg3 && arg3 > 0 ? arg3 : 1; 
            let hargaSatuan = getHargaDinamis(arg2);
            let itemStr = `sawit_${arg2}`;
            
            if (!hargaSatuan) return reply('❌ Item tidak valid.');
            if (arg2 === 'pekerja' && user.sawit_pekerja + jumlah > BASE_PEKERJA + (user.sawit_mess * PEKERJA_PER_MESS)) return reply(`❌ Mess buruh penuh! Beli Mess dulu.`);
            
            let totalBiaya = 0;
            if (['lahan', 'mess', 'truk'].includes(arg2)) {
                for (let i = 0; i < jumlah; i++) {
                    let tempVal = user[itemStr] + i;
                    if (arg2 === 'lahan') totalBiaya += Math.floor(50000000 * Math.pow(1.35, tempVal > 0 ? tempVal - 1 : 0));
                    if (arg2 === 'mess') totalBiaya += Math.floor(40000000 * Math.pow(1.25, tempVal));
                    if (arg2 === 'truk') totalBiaya += Math.floor(120000000 * Math.pow(1.15, tempVal > 0 ? tempVal - 1 : 0));
                }
            } else {
                totalBiaya = hargaSatuan * jumlah;
            }

            if (user.money < totalBiaya) return reply(`❌ Saldo kurang! Butuh ${formatMoney(totalBiaya)} untuk ${jumlah} ${arg2}.`);
            
            user.money -= totalBiaya; 
            user[itemStr] += jumlah; 
            await saveDatabase();
            return sendSawitCard(`🛒 *STRUK BELI*\nItem: ${arg2} (x${jumlah})\nTotal Biaya: ${formatMoney(totalBiaya)}\nSisa Saldo: ${formatMoney(user.money)}`, "TRANSAKSI BERHASIL", img.beli);
        }

        if (subCmd === 'upgrade') {
            if (!arg2) return sendSawitCard(`⬆️ *PUSAT UPGRADE*\n\n🛡️ *1. keamanan* (Cegah Maling)\n🔬 *2. riset* (+Rp2.500/Pohon)\n\nKetik: *.sawit upgrade [keamanan/riset]*`, "UPGRADE SYSTEM", img.beli);
            let lvlKey = `sawit_${arg2}`; let max = arg2 === 'keamanan' ? 3 : 5;
            let nextLvl = user[lvlKey] + 1;
            if (nextLvl > max) return reply(`✅ ${arg2} sudah Max Level!`);
            let cost = BIAYA_UPGRADE[arg2][nextLvl];
            if (arg2 === 'riset' && (!args[2] || args[2] !== 'yakin')) return reply(`🔬 *Riset Lvl ${nextLvl}*\nBiaya: ${formatMoney(cost)}\nKetik: *.sawit upgrade riset yakin* untuk konfirmasi.`);
            if (user.money < cost) return reply(`❌ Saldo kurang! Butuh ${formatMoney(cost)}`);
            user.money -= cost; user[lvlKey] = nextLvl; await saveDatabase();
            return reply(`✅ ${arg2} berhasil di-upgrade ke Level ${nextLvl}!`);
        }

        // 6. TANAM
        if (subCmd === 'tanam') {
            let jumlah = (arg2 && !isNaN(parseInt(arg2))) ? parseInt(arg2) : user.sawit_bibit; 
            if (jumlah < 1) return reply(`❌ Kamu tidak punya bibit.`);
            if (user.sawit_bibit < jumlah) return reply(`❌ Stok bibit kurang.`);
            if ((user.sawit_pohon + jumlah) > (user.sawit_lahan * MAX_POHON_PER_HA)) return reply(`❌ Kapasitas Hektar penuh! Beli lahan lagi.`);
            const butuhPekerja = Math.ceil((user.sawit_pohon + jumlah) / 100);
            if (user.sawit_pekerja < butuhPekerja) return reply(`❌ Kurang buruh! Tiap kelipatan 100 pohon butuh 1 buruh. Kamu butuh minimal ${butuhPekerja} buruh.`);

            user.sawit_bibit -= jumlah; user.sawit_pohon += jumlah; await saveDatabase();
            return reply(`🌱 Menanam ${jumlah} pohon berhasil.\nTotal pohon sekarang: ${user.sawit_pohon}`);
        }

        // 7. RAWAT MANUAL
        if (['rawat', 'pupuk', 'semprot'].includes(subCmd)) {
            if (user.sawit_pohon === 0) return reply('❌ Belum ada pohon yang ditanam!');
            
            let tipe = arg2;
            if (subCmd === 'pupuk') tipe = 'pupuk';
            if (subCmd === 'semprot') tipe = 'pestisida';

            if (tipe === 'pupuk') {
                if (user.sawit_pupuk_aktif) return reply('✅ Kebun sudah dipupuk penuh! Tunggu masa panen.');
                let butuhPupuk = Math.ceil(user.sawit_pohon / 100);
                if (user.sawit_pupuk < butuhPupuk) return reply(`❌ Pupuk kurang! Butuh ${butuhPupuk} sak untuk mengcover ${user.sawit_pohon} pohon.`);
                user.sawit_pupuk -= butuhPupuk; user.sawit_pupuk_aktif = true; await saveDatabase();
                return reply(`✨ Berhasil menebar ${butuhPupuk} sak pupuk! Omzet panen dipastikan +20%.`);
            }
            if (tipe === 'pestisida') {
                if (user.sawit_pestisida_aktif) return reply('✅ Kebun sudah disemprot pestisida!');
                let butuhPestisida = Math.ceil(user.sawit_pohon / 100);
                if (user.sawit_pestisida < butuhPestisida) return reply(`❌ Pestisida kurang! Butuh ${butuhPestisida} liter untuk ${user.sawit_pohon} pohon.`);
                user.sawit_pestisida -= butuhPestisida; user.sawit_pestisida_aktif = true; await saveDatabase();
                return reply(`🛡️ Berhasil menyemprot ${butuhPestisida} liter pestisida! Kebun aman dari hama.`);
            }
            return reply(`❓ Cara penggunaan:\n👉 *.sawit rawat pupuk*\n👉 *.sawit rawat pestisida*`);
        }

        // 8. PANEN & LOGISTIK
        if (subCmd === 'panen') {
            if (user.sawit_pohon === 0) return reply('❌ Belum ada pohon berbuah.');
            const now = Date.now();
            if (now - user.sawit_last_panen < COOLDOWN_PANEN) return reply('⏳ Buah belum matang.');

            let eventText = "", kerugianCuaca = 0, kerugianMaling = 0, pohonMati = 0;
            let randHama = Math.random() * 100;
            let randMaling = Math.random() * 100;

            let rasioBanjirMaut = Math.max(0, 1 - (user.sawit_drainase / user.sawit_lahan)); 
            let rasioKeringMaut = Math.max(0, 1 - (user.sawit_pompa / user.sawit_lahan));

            if (user.sawit_cuaca_next === 'Hujan') {
                if (rasioBanjirMaut > 0) {
                    let persentaseRusak = (Math.random() * 0.2 + 0.1) * rasioBanjirMaut; 
                    kerugianCuaca += persentaseRusak; 
                    eventText += `🌊 Banjir merendam ${Math.floor(rasioBanjirMaut * 100)}% lahan rentan! Kualitas buah turun.\n`;
                } else { eventText += `🌧️ Hujan Lebat. Drainase 100% menahan banjir.\n`; }
            } else if (user.sawit_cuaca_next === 'Kemarau') {
                if (rasioKeringMaut > 0) {
                    let persentaseKering = (Math.random() * 0.25 + 0.15) * rasioKeringMaut; 
                    kerugianCuaca += persentaseKering; 
                    eventText += `☀️ Kekeringan di ${Math.floor(rasioKeringMaut * 100)}% area tanpa pompa! Bobot buah menyusut.\n`;
                } else { eventText += `☀️ Panas Terik. Pompa air mendinginkan seluruh lahan.\n`; }
            } else if (user.sawit_cuaca_next === 'Ekstrem') {
                if (Math.random() < 0.6) { 
                    pohonMati = Math.floor(Math.random() * (user.sawit_pohon * 0.05)) + 1; 
                    user.sawit_pohon -= pohonMati; 
                    eventText += `🌪️ BADAI MENGAMUK! ${pohonMati} Pohon tumbang tercabut angin!\n`; 
                } else { eventText += `🌪️ Angin Kencang berlalu, kebun selamat.\n`; }
            }

            if (!user.sawit_pestisida_aktif && randHama < 35) {
                let pohonDimakan = Math.floor(user.sawit_pohon * (Math.random() * 0.1 + 0.05)); 
                kerugianCuaca += (pohonDimakan / user.sawit_pohon); 
                eventText += `🐀 HAMA MENYERANG! Kamu lupa semprot Pestisida, buah rusak dimakan hama.\n`;
            } else if (user.sawit_pestisida_aktif) {
                eventText += `🛡️ Kebun bersih dari hama.\n`;
            }

            if (randMaling < 15) {
                let bobolDasar = 0.15; 
                let mitigasi = user.sawit_keamanan * 0.05; 
                if (user.sawit_keamanan >= 3) { eventText += `🥷 Maling tertangkap basah oleh Guard!\n`; } 
                else { kerugianMaling = bobolDasar - mitigasi; eventText += `🥷 Kebun Kebobolan Ninja Sawit!\n`; }
            }

            let baseHarga = Math.floor(Math.random() * (22000 - 12000 + 1)) + 12000;
            baseHarga += (user.sawit_riset * 2500); 
            
            let pohonPanen = user.sawit_pohon;
            let grossAwal = pohonPanen * baseHarga;
            
            let nilaiRugiCuaca = Math.floor(grossAwal * kerugianCuaca);
            let nilaiRugiMaling = Math.floor(grossAwal * kerugianMaling);
            let totalPenalti = nilaiRugiCuaca + nilaiRugiMaling;
            
            let gross = grossAwal - totalPenalti;

            if (user.sawit_pupuk_aktif) {
                gross = Math.floor(gross * 1.2); eventText += `✨ Hasil optimal berkat Pupuk (+20% Harga Jual)\n`;
            }

            let totalGaji = (user.sawit_pekerja * GAJI_POKOK) + Math.floor(gross * BONUS_PANEN_PERSEN);

            let pohonTercoverTruk = Math.min(pohonPanen, user.sawit_truk * KAPASITAS_TRUK);
            let pohonSisaSewa = pohonPanen - pohonTercoverTruk;
            let totalLogistik = (pohonTercoverTruk * BIAYA_TRUK_PRIBADI) + (pohonSisaSewa > 0 ? (pohonSisaSewa * BIAYA_SEWA_TRUK) : 0);

            // PAJAK NEGARA & CICILAN MITRA
            let totalPajakAtauCicilan = 0;
            let labelPotongan = "";

            if (user.sawit_is_loan) {
                let bungaPabrik = Math.floor(gross * 0.15); 
                let cicilan = Math.floor(gross * 0.25);     
                
                if (cicilan > user.sawit_hutang) {
                    cicilan = user.sawit_hutang;
                }
                
                totalPajakAtauCicilan = bungaPabrik + cicilan;
                user.sawit_hutang -= cicilan;
                labelPotongan = `Potongan Mitra (-${formatMoney(bungaPabrik)} Bunga, -${formatMoney(cicilan)} Cicilan)`;

                if (user.sawit_hutang <= 0) {
                    user.sawit_is_loan = false;
                    user.sawit_hutang = 0;
                    eventText += `\n🎉 *SELAMAT!* Utang kebunmu LUNAS sepenuhnya dari cicilan panen! Kamu sekarang Juragan Mandiri!\n`;
                }
            } else {
                if (user.sawit_lahan <= 4) {
                    totalPajakAtauCicilan = Math.floor(gross * 0.021);
                    labelPotongan = "Pajak UMKM (2.1%)";
                } else {
                    totalPajakAtauCicilan = Math.floor(gross * 0.1135);
                    labelPotongan = "Pajak Ekspor (11.35%)";
                }
            }

            let net = gross - (totalGaji + totalLogistik + totalPajakAtauCicilan);
            let totalXp = 200 + Math.floor(net / 1000000);

            user.money += net;
            user.sawit_last_panen = now;
            user.sawit_panen_count += 1;
            
            user.sawit_pupuk_aktif = false;
            user.sawit_pestisida_aktif = false;
            user.sawit_cuaca_next = generateCuaca();

            addXp(totalXp);
            await saveDatabase();

            const panenText = `
🚛 *PENGIRIMAN CPO #${user.sawit_panen_count}*
${eventText ? `\n🔔 *LOG HARIAN:*\n${eventText}` : ""}
📈 Omzet Kotor: ${formatMoney(grossAwal)}
${totalPenalti > 0 ? `📉 Penalti Bencana/Maling: -${formatMoney(totalPenalti)}` : ""}

🛑 *OPERASIONAL & PAJAK:*
- Gaji & Premi Buruh: -${formatMoney(totalGaji)}
- Transport Logistik: -${formatMoney(totalLogistik)}
- ${labelPotongan}
-------------------------------
💰 *NET PROFIT: ${formatMoney(net)}*
⭐ *XP EARNED: +${totalXp}*

☁️ *BMKG UPDATE:* Cuaca panen berikutnya diperkirakan *${user.sawit_cuaca_next}*.
`.trim();
            return sendSawitCard(panenText, "PANEN RAYA", user.sawit_is_loan ? img.pajak : img.mandiri);
        }

        // 9. LUNASI & RESET
        if (subCmd === 'lunasi') {
            if (!user.sawit_is_loan) return reply('✅ Kamu sudah berstatus Mandiri, tidak ada utang pabrik.');
            if (user.sawit_hutang <= 0) return reply('✅ Utangmu sudah Rp 0. Tunggu panen berikutnya untuk update status!');
            
            if (user.money < user.sawit_hutang) {
                return reply(`❌ Saldo tidak cukup untuk pelunasan instan.\nSisa utangmu: ${formatMoney(user.sawit_hutang)}\nSaldo saat ini: ${formatMoney(user.money)}`);
            }
            
            user.money -= user.sawit_hutang; 
            user.sawit_hutang = 0;
            user.sawit_is_loan = false; 
            await saveDatabase();
            
            return sendSawitCard(`🎉 *KEBEBASAN FINANSIAL!*\nSisa utang berhasil dilunasi secara tunai. Status Mitra dicabut, kamu sekarang 100% Juragan Mandiri!`, "PELUNASAN SUKSES", img.mandiri);
        }

        if (subCmd === 'reset') {
            if (arg2 !== 'confirm') return reply(`⚠️ *PERINGATAN!* Reset akan menghapus SEMUA aset.\nKetik: *.sawit reset confirm* jika yakin.`);
            for (const key in defaultValues) if (key !== 'money' && key !== 'xp') user[key] = defaultValues[key];
            user.sawit_is_loan = false; await saveDatabase();
            return reply('✅ Game Sawit di-reset! Ketik *.sawit daftar* untuk main lagi.');
        }
    }
};