import fs from 'fs';
import fetch from 'node-fetch';
import { writeExifVid } from '../lib/exif.js';
import cfg from '../config/config.json' assert { type:"json" };

const handler = async({ sock,msg,from,args })=>{
    const text=args.join(" ");
    if(!text) return sock.sendMessage(from,{text:"Format:\n.bratvid teks"},{quoted:msg});
    await sock.sendMessage(from,{react:{text:"⏳",key:msg.key}});
    const url=`https://anabot.my.id/api/maker/bratGif?text=${encodeURIComponent(text)}&apikey=freeApikey`;
    const temp=`./temp/bratGif_${Date.now()}.gif`;
    let out="";
    try{
        const res=await fetch(url);
        const buffer=await res.buffer();
        fs.writeFileSync(temp,buffer)
    }catch{
        await sock.sendMessage(from,{react:{text:"❌",key:msg.key}});
        return sock.sendMessage(from,{text:"API error / tidak merespon"},{quoted:msg})
    }
    const meta={pack:cfg.botName||"Haruka",author:"https://zalxzhu.my.id"};
    try{
        out=await writeExifVid(fs.readFileSync(temp),meta);
        const sticker=fs.readFileSync(out);
        await sock.sendMessage(from,{sticker},{quoted:msg});
        await sock.sendMessage(from,{react:{text:"✨",key:msg.key}})
    }catch{
        await sock.sendMessage(from,{react:{text:"❌",key:msg.key}});
        sock.sendMessage(from,{text:"Gagal convert — cek ffmpeg/lib/exif.js"},{quoted:msg})
    }finally{
        if(fs.existsSync(temp)) fs.unlinkSync(temp);
        if(out&&fs.existsSync(out)) fs.unlinkSync(out)
    }
};

export default{
    command:["bratvid","bratgif","bratv","brat-gif"],
    category:"Sticker",
    description:"Generate brat GIF → sticker WebP",
    handler
};