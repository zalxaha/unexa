import 'dotenv/config';
import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore
} from '@whiskeysockets/baileys';

import qr from 'qrcode-terminal';
import pino from 'pino';
import path from 'path';
import fs from 'fs/promises';
import * as fsSync from 'fs';
import { fileURLToPath } from 'url';
import { parsePhoneNumber } from 'libphonenumber-js';
import chalk from 'chalk';
import NodeCache from 'node-cache';

import log from './lib/logger.js';

let MsgHandler;
let loadPlugins;
let loadDisabledFeatures;
let config = {}; 

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const groupCache = new NodeCache({ stdTTL: 5 * 60, checkperiod: 60 }); 

async function initHandler() {
  try {
    const configPath = path.join(__dirname, 'config/config.json');
    const configFileContent = await fs.readFile(configPath, 'utf8');
    config = JSON.parse(configFileContent);
    console.log(chalk.blue('⚙️ Config loaded successfully.'));

    const MsgModule = await import('./handlers/messageHandler.js');
    
    await MsgModule.loadDisabledFeatures();
    await MsgModule.loadPlugins(); 
    
    MsgHandler = MsgModule.default;
    loadPlugins = MsgModule.loadPlugins;
    loadDisabledFeatures = MsgModule.loadDisabledFeatures;

    console.log(chalk.green('✅ Handler & Plugins loaded successfully.'));
  } catch (e) {
    console.error(chalk.red('⚠️ Warning: Gagal import config atau messageHandler.'), e);
    process.exit(1); 
  }
}

await initHandler();

import CallHandler from './lib/call.js';

const sessionFolder = path.join(__dirname, 'session');
const dbPath = path.join(__dirname, 'database/users.json');

const msgRetryCounterCache = new NodeCache();

async function validatePhoneNumber(input) {
  if (!input) return null;
  try {
    let phone = String(input).replace(/[^0-9]/g, "");
    if (!phone.startsWith('+')) phone = '+' + phone;
    const pn = parsePhoneNumber(phone);
    if (!pn || !pn.isValid()) return null;
    return pn.number.replace('+', '');
  } catch {
    return null;
  }
}

async function checkDatabase() {
  try {
    await fs.access(dbPath);
    if ((await fs.readFile(dbPath, 'utf8')).trim().length === 0) {
      await fs.writeFile(dbPath, JSON.stringify({}));
    }
  } catch (err) {
    if (err.code === "ENOENT") {
      await fs.mkdir(path.dirname(dbPath), { recursive: true });
      await fs.writeFile(dbPath, JSON.stringify({}));
    }
  }
}

async function Start() {
  await checkDatabase();

  try {
    await fs.access(sessionFolder);
  } catch {
    await fs.mkdir(sessionFolder, { recursive: true });
  }

  const { state, saveCreds } = await useMultiFileAuthState(sessionFolder);
  const { version, isLatest } = await fetchLatestBaileysVersion();

  log.info(`Baileys v${version.join('.')}, latest: ${isLatest}`);
  config.version = version.join('.');

  const usePairing = config.system?.pairing === true;

  const getMessageFallback = async () => undefined;

  const sock = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" })),
    },
    logger: pino({ level: "silent" }),
    printQRInTerminal: !usePairing,
    syncFullHistory: false, 
    shouldSyncHistoryMessage: () => false,
    generateHighQualityLinkPreview: true,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    connectTimeoutMs: 60000,
    retryRequestDelayMs: 2000,
    msgRetryCounterCache,
    getMessage: getMessageFallback
  });

  if (usePairing && !sock.authState.creds.registered) {
    setTimeout(async () => {
      const number = await validatePhoneNumber(config.system.number);
      if (!number) return log.err("Nomor pairing invalid!");

      try {
        let code = await sock.requestPairingCode(number);
        code = code?.match(/.{1,4}/g)?.join('-') || code;
        console.log(chalk.bgGreen.black(`\n📞 KODE PAIRING:`));
        console.log(chalk.white.bold(code));
      } catch (err) {
        log.err("Gagal request pairing: " + err.message);
      }
    }, 3000);
  }

  sock.ev.on("connection.update", async ({ connection, lastDisconnect, qr: code }) => {
    if (code && !usePairing && !sock.authState.creds.registered) {
      qr.generate(code, { small: true });
    }

    if (connection === "open") {
      log.ok("Bot Online!");
      try {
        await sock.sendMessage(config.owner + "@s.whatsapp.net", {
          text: `✅ Bot Online\nVersi Baileys: ${config.version}`
        });
      } catch {}
    }

    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode || 0;
      if (code === DisconnectReason.loggedOut) {
        log.err("Session logout → hapus folder session...");
        await fs.rm(sessionFolder, { recursive: true, force: true });
        process.exit(1);
      }
      log.warn("Reconnecting...");
      Start();
    }
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("messages.upsert", async (m) => {
    if (!m.messages) return;
    
    const msg = m.messages[0];
    
    if (!msg.message) return;
    if (msg.messageStubType) return;
    if (m.type === "append") return; 
    if (msg.key.remoteJid === "status@broadcast") return;
    if (!MsgHandler) return;

    try {
      MsgHandler(sock, msg); 
    } catch (err) {
      log.err("Handler Error: " + err.message);
    }
    
    try {
        const from = msg.key.remoteJid;
        const isGroup = from.endsWith('@g.us');
        const pushName = msg.pushName || "Unknown";
        let sender = isGroup ? (msg.key.participant || from) : from;
        sender = sender.replace('@s.whatsapp.net', '');
        
        let groupName = "";
        
        if (isGroup) {
            if (groupCache.has(from)) {
                groupName = groupCache.get(from);
            } else {
                try {
                    const metadata = await sock.groupMetadata(from);
                    groupName = metadata.subject;
                    groupCache.set(from, groupName);
                } catch {
                    groupName = "Unknown Group (Fetching...)";
                }
            }
        }

        const type = Object.keys(msg.message).find(key => !['senderKeyDistributionMessage', 'messageContextInfo'].includes(key));
        
        const body = (type === 'conversation') ? msg.message.conversation :
                     (type === 'extendedTextMessage') ? msg.message.extendedTextMessage.text :
                     (type === 'imageMessage') ? (msg.message.imageMessage.caption || '[Image]') :
                     (type === 'videoMessage') ? (msg.message.videoMessage.caption || '[Video]') :
                     (type === 'stickerMessage') ? '[Sticker]' : 
                     (type === 'audioMessage') ? '[Audio]' : '';

        const isCmd = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&./]/gi.test(body);
        const logTime = new Date().toLocaleTimeString();

        console.log(chalk.gray('--------------------------------------------------'));
        if (isGroup) {
            console.log(
                chalk.bgBlack.white(`⏰ ${logTime}`), 
                chalk.magenta(`[ ${groupName} ]`),
                chalk.green(pushName), 
                chalk.yellow(`(${sender})`)
            );
        } else {
            console.log(
                chalk.bgBlack.white(`⏰ ${logTime}`), 
                chalk.green(pushName), 
                chalk.yellow(`(${sender})`)
            );
        }

        if (isCmd) {
            console.log(chalk.bgRed.white.bold(`[ COMMAND ]`), chalk.white(body));
        } else {
            console.log(chalk.bgBlue.white(`[ MESSAGE ]`), chalk.cyan(type), chalk.white(body));
        }

    } catch (e) {
    }
  });

  sock.ev.on("call", async (calls) => {
    try {
      await CallHandler.code(sock, calls);
    } catch {}
  });

  fsSync.watch(path.join(__dirname, "plugins"), async (evt, filename) => {
    if (filename && filename.endsWith(".js")) {
      const ts = Date.now();
      try {
        log.info(`[RELOAD START] Mendeteksi perubahan: ${filename}`);
        
        const reload = await import(`./handlers/messageHandler.js?v=${ts}`);
        
        if (reload.loadDisabledFeatures) await reload.loadDisabledFeatures();
        if (reload.loadPlugins) await reload.loadPlugins();

        MsgHandler = reload.default;
        loadPlugins = reload.loadPlugins;
        loadDisabledFeatures = reload.loadDisabledFeatures;

        log.ok(`[RELOAD SUCCESS] Plugin berhasil diperbarui.`);
      } catch (e) {
        log.err("Reload gagal: " + e.message);
      }
    }
  });
}

process.on("unhandledRejection", e => {
  if (String(e).includes("Bad MAC")) return;
  console.error(e);
});
process.on("uncaughtException", e => {
  if (String(e).includes("Bad MAC")) return;
  console.error(e);
});

Start();
