import { igdl } from 'btch-downloader';

const handler = async ({ sock, msg, from, command, args }) => {
    
    const text = args.join(' ').trim();
    
    // Regex validasi URL Instagram
    const IG_URL_REGEX = /(instagram\.com|instagr\.am|threads\.net|threads\.com)/i;
    
    if (!text || !text.match(IG_URL_REGEX)) {
        return sock.sendMessage(from, { 
            text: `❌ URL tidak valid. Masukkan link Instagram atau Threads!\n\nContoh:\n*.${command} https://www.instagram.com/reel/xxx/*` 
        }, { quoted: msg });
    }

    try {
        // Beri reaksi proses
        await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

        // Panggil fungsi dari btch-downloader
        const data = await igdl(text);
        
        // Validasi hasil
        if (!data || !data.result || data.result.length === 0) {
            await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
            return sock.sendMessage(from, { text: "Media tidak ditemukan atau link bersifat privat." }, { quoted: msg });
        }

        // Loop setiap media yang ditemukan (untuk slide/carousel)
        for (const item of data.result) {
            const mediaUrl = item.url;
            
            // Logika Deteksi Tipe Media (Video/Image)
            // Karena btch kadang tidak memberikan tipe spesifik, kita coba kirim sebagai Video dulu.
            // Jika gagal (error), maka kita kirim sebagai Gambar.
            
            try {
                // Coba kirim sebagai Video
                await sock.sendMessage(from, { 
                    video: { url: mediaUrl }, 
                    caption: `H͟a͟r͟u͟k͟a͟ *Instagram  downloader*` 
                }, { quoted: msg });
            } catch (videoErr) {
                try {
                    // Jika gagal video, Coba kirim sebagai Gambar
                    await sock.sendMessage(from, { 
                        image: { url: mediaUrl }, 
                        caption: `H͟a͟r͟u͟k͟a͟ *Instagram downloader*` 
                    }, { quoted: msg });
                } catch (imgErr) {
                    // Jika gambar juga gagal (mungkin file dokumen/gif aneh), kirim sebagai dokumen
                    console.error(`Gagal mengirim media IG: ${mediaUrl}`);
                }
            }
        }

        // Beri reaksi sukses
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (e) {
        console.error(`[IG DL ERROR] ${e.message}`);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        await sock.sendMessage(from, { text: `❌ Gagal mengambil data.\nPesan Error: ${e.message}` }, { quoted: msg });
    }
};

export default {
    command: ["ig", "igdl", "instagram"], 
    description: 'Download media (gambar/video) dari Instagram menggunakan btch-downloader.', 
    category: 'downloader', 
    handler,
};