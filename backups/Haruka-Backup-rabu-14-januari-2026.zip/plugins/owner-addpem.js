import { jidNormalizedUser } from '@whiskeysockets/baileys';

export default {
    command: ['addprem', 'tambahpremium', 'setprem'],
    category: 'Owner',
    isOwner: true,
    description: 'Menambahkan status premium ke user.',

    handler: async ({ sock, msg, args, db, saveDatabase, reply }) => {

        // --- 1. Helper: Cari JID Utama dari Database ---
        // Fungsi ini mencari apakah LID yang ditag sudah terhubung ke Nomor HP di database
        const resolveToMainJid = (targetJid) => {
            const norm = jidNormalizedUser(targetJid);
            
            // 1. Cek jika ini sudah JID utama
            if (db[norm]) return norm;

            // 2. Cek apakah ini ada di altJids milik orang lain (Mapping LID -> Phone)
            for (const mainJid in db) {
                const user = db[mainJid];
                if (user.altJids && user.altJids.includes(norm)) {
                    return mainJid; // Ketemu! Kembalikan Phone JID
                }
            }

            // 3. Jika tidak ketemu, kembalikan aslinya (berarti user baru/belum pernah chat)
            return norm;
        };

        // --- 2. Parse Target & Duration ---
        let target = null;
        let durationStr = null;

        if (msg.quoted) {
            target = msg.quoted.sender;
            durationStr = args[0];
        } else if (args.length > 0) {
            const isDuration = /^\d+[dmy]$/i.test(args[0]);
            if (isDuration) {
                return reply('❌ Harap reply pesan atau tag orangnya dulu baru masukkan durasi.');
            }

            // Cek Mention/Tag
            const mentions = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid;
            if (mentions && mentions.length > 0) {
                target = mentions[0]; // Ini biasanya @lid
                durationStr = args[1];
            } else {
                // Input Manual Nomor
                const rawInput = args[0].replace(/[^0-9]/g, '');
                if (rawInput) {
                    target = rawInput + '@s.whatsapp.net';
                    durationStr = args[1];
                }
            }
        }

        if (!target) return reply(`❌ *Format Salah!*\n\n• Reply pesan user, ketik .addprem 30d\n• Atau ketik .addprem 628xxx 30d\n• Atau tag .addprem @tag 30d`);
        if (!durationStr) return reply('❌ Masukkan durasi! (contoh: 30d, 1m)');

        // --- 3. Parse Durasi ---
        const match = durationStr.match(/^(\d+)([dmy])$/i);
        if (!match) return reply('❌ Format durasi salah. Gunakan: 1d (hari), 1m (bulan), 1y (tahun).');

        const amount = parseInt(match[1]);
        const unit = match[2].toLowerCase();
        let msToAdd = 0;

        switch (unit) {
            case 'd': msToAdd = amount * 24 * 60 * 60 * 1000; break;
            case 'm': msToAdd = amount * 30 * 24 * 60 * 60 * 1000; break;
            case 'y': msToAdd = amount * 365 * 24 * 60 * 60 * 1000; break;
        }

        // --- 4. Resolve JID & Update Database ---
        // INI BAGIAN PENTING: Konversi LID ke Phone JID
        const finalJid = resolveToMainJid(target); 
        const now = Date.now();

        if (!db[finalJid]) {
            db[finalJid] = {
                nama: 'User',
                limit: 10,
                premiumUntil: 0,
                altJids: []
            };
            // Jika target aslinya beda (misal LID), simpan ke altJids user baru ini
            if (target !== finalJid) {
                db[finalJid].altJids.push(target);
            }
        }

        const user = db[finalJid];
        const isExtend = user.premiumUntil > now;
        const startFrom = isExtend ? user.premiumUntil : now;
        
        user.premiumUntil = startFrom + msToAdd;
        user.limit = 99999;
        user.status = 'premium';
        
        // Pastikan altJid terhubung (Double check)
        if (target !== finalJid) {
            if (!user.altJids) user.altJids = [];
            if (!user.altJids.includes(target)) user.altJids.push(target);
        }

        await saveDatabase();

        // --- 5. Notifikasi ---
        const expiredDate = new Date(user.premiumUntil).toLocaleDateString('id-ID', {
            weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
        });

        const successMsg = `✅ *PREMIUM SUCCESS*\n\n` +
            `👤 *User Target:* @${finalJid.split('@')[0]}\n` +
            `🔹 *ID Asli:* ${finalJid}\n` +
            `📦 *Status:* ${isExtend ? 'Diperpanjang' : 'Aktif'}\n` +
            `⏳ *Durasi:* ${amount} ${unit === 'd' ? 'Hari' : unit === 'm' ? 'Bulan' : 'Tahun'}\n` +
            `📅 *Expired:* ${expiredDate}`;

        await reply(successMsg, { mentions: [finalJid] });

        try {
            await sock.sendMessage(finalJid, { 
                text: `🎉 *Selamat! Akun Anda kini Premium*\n\nBerlaku hingga: ${expiredDate}\nNikmati fitur tanpa limit!` 
            });
        } catch {}
    }
};