import axios from 'axios';

const handler = async ({ sock, msg, args, from }) => {
  const url = args[0];
  const sender = msg.key.participant || msg.key.remoteJid;
  const senderNumber = sender.split('@')[0];

  if (!url) {
    return sock.sendMessage(from, {
      text: '📌 Masukkan URL video Facebook!\nContoh: *.fb https://www.facebook.com/xxx*'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

  try {
    // Memanggil API baru
    const apiUrl = `https://ytdlpyton.nvlgroup.my.id/facebook?url=${encodeURIComponent(url)}`;
    const response = await axios.get(apiUrl);
    const result = response.data;

    // Validasi apakah link download tersedia
    if (!result || !result.links || result.links.length === 0) {
      throw new Error('❌ Gagal mendapatkan link download dari API.');
    }

    // Mengambil kualitas tertinggi (biasanya index pertama atau yang bertanda HD)
    // Di sini kita ambil index 0 (kualitas terbaik dari API tersebut)
    const videoData = result.links[0];
    const videoDownloadLink = videoData.url;
    
    // Ambil video sebagai buffer
    const videoBuffer = await axios.get(videoDownloadLink, { 
      responseType: 'arraybuffer',
      headers: { 
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36' 
      } 
    }).then(res => res.data);
    
    const caption = `H͟a͟r͟u͟k͟a͟ *FACEBOOK DOWNLOADER*\n\n` +
                    `📝 *Judul:* ${result.title || '-'}\n` +
                    `⏱️ *Durasi:* ${result.duration || '-'}\n` +
                    `⚙️ *Kualitas:* ${videoData.quality}\n\n` +
                    `Ini kak videonya @${senderNumber}`;

    await sock.sendMessage(
      from, {
        video: Buffer.from(videoBuffer),
        mimetype: "video/mp4",
        fileName: `facebook_video.mp4`, 
        caption: caption,
        mentions: [sender],
        thumbnail: { url: result.img } // Menambahkan thumbnail dari API
      }, {
        quoted: msg
      }
    );

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (e) {
    console.error('[FB DOWNLOAD ERROR]', e);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    return sock.sendMessage(from, {
      text: `❌ Gagal mengunduh video.\nDetail: ${e.message}`
    }, { quoted: msg });
  }
};

export default {
  command: ['facebook', 'fb', 'fbdownload', 'fbdl'],
  description: 'Download video dari Facebook via API',
  category: 'Downloader',
  handler,
};