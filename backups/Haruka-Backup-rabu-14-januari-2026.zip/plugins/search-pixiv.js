import fetch from 'node-fetch';
import sharp from 'sharp';
import { generateWAMessageContent, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';

const PIXIV_API_BASE = 'https://api.ryzumi.vip/api/search/pixiv?query='; 

function clockString(ms) {
  let h = isNaN(ms) ? "--" : Math.floor(ms / 3600000);
  let m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
  let s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
  return [h, m, s].map((v) => v.toString().padStart(2, 0)).join(":");
}

const handler = async ({ sock, msg, args, command, pushName, sender, from, isGroup }) => { 
    
    if (args.length < 1) {
        return msg.reply(`*Usage:*
${process.env.PREFIX || '.'}${command} Nao Tomori
Atau gunakan link:
${process.env.PREFIX || '.'}${command} https://www.pixiv.net/en/artworks/92445569`);
    }

    const startTime = Date.now();
    
    const reactionKey = {
        remoteJid: from,
        id: msg.key.id,
        fromMe: msg.key.fromMe || false,
    };
    
    if (isGroup && sender) {
        reactionKey.participant = sender; 
    } 
    
    try {
        await sock.sendMessage(from, { react: { text: '🔎', key: reactionKey } });

        const query = encodeURIComponent(args.join(' '));
        const apiUrl = `${PIXIV_API_BASE}${query}`;
        
        const response = await fetch(apiUrl);
        if (!response.ok) {
            throw new Error(`API Pixiv Error: ${response.status} ${response.statusText}`);
        }
        
        const data = await response.json();

        if (!data || !data.Media || !Array.isArray(data.Media) || data.Media.length < 1) {
            await sock.sendMessage(from, { react: { text: '❌', key: reactionKey } });
            return msg.reply("Error: Foto tidak ditemukan di Pixiv atau format data tidak valid.");
        }

        const images = data.Media;
        
        let pageLink;
        if (args[0].includes('pixiv.net')) { 
            pageLink = args[0]; 
        } else if (data.link) { 
            pageLink = data.link;
        } else { 
            pageLink = `https://www.pixiv.net/search.php?s_mode=s_tag&word=${query}`;
        }

        const caption = data.caption || '';
        const artist = data.artist || 'Tidak Diketahui';
        const tags = data.tags ? data.tags.join(', ') : 'Tidak ada tag';

        const pushCards = [];

        async function createImageMessage(url) {
            const res = await fetch(url);
            let buffer = Buffer.from(await res.arrayBuffer());
            
            const threshold = 12 * 1024 * 1024; 
            if (buffer.length > threshold) {
                buffer = await sharp(buffer).jpeg({ quality: 80 }).toBuffer();
            }

            const { imageMessage } = await generateWAMessageContent({ image: buffer }, { upload: sock.waUploadToServer });
            return imageMessage;
        }

        for (const imageUrl of images) {
            if (pushCards.length >= 10) break;
            
            try {
                const imageMsg = await createImageMessage(imageUrl);
                
                pushCards.push({
                    body: proto.Message.InteractiveMessage.Body.create({ text: caption || 'Hasil Pixiv' }),
                    footer: proto.Message.InteractiveMessage.Footer.create({ text: `Artist: ${artist}\nTags: ${tags}` }),
                    header: proto.Message.InteractiveMessage.Header.create({ title: '', hasMediaAttachment: true, imageMessage: imageMsg }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "View on Pixiv", cta_type: "1", url: pageLink }) }
                        ]
                    })
                });
            } catch (e) {
                console.error(`[PIXIV LOOP ERROR] Gagal memproses gambar ${imageUrl}: ${e.message}`);
                continue; 
            }
        }
        
        if (pushCards.length === 0) {
            await sock.sendMessage(from, { react: { text: '❌', key: reactionKey } });
            return msg.reply("Error: Tidak ada gambar yang berhasil diproses dari API.");
        }

        const endTime = Date.now();
        const responseTime = clockString(endTime - startTime);

        const messagePayload = generateWAMessageFromContent(from, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: `Total hasil: ${pushCards.length}${images.length > pushCards.length ? '+' : ''}` }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: `Hai ${pushName},\nDibawah ini adalah hasil pencarian Pixiv kamu.\nRespon: ${responseTime}` }),
                        header: proto.Message.InteractiveMessage.Header.create({ hasMediaAttachment: false }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.create({ cards: pushCards })
                    })
                }
            }
        }, { quoted: msg });

        await sock.relayMessage(from, messagePayload.message, { messageId: messagePayload.key.id });
        
        await sock.sendMessage(from, { react: { text: '✅', key: reactionKey } });

    } catch (e) {
        console.error("=========================================");
        console.error("FATAL PIXIV ERROR:", e.stack || e.message);
        console.error("=========================================");
        
        try {
            await sock.sendMessage(from, { react: { text: '❌', key: reactionKey } });
        } catch (re) {
             console.error("Gagal mengirim reaction error:", re.message);
        }
        
        msg.reply(`❌ Terjadi error saat memproses Pixiv: ${e.message}.`);
    }
};

export default {
    command: ['pixiv', 'px'],
    category: 'internet',
    handler: handler,
    isOwner: false,
    isPremium: false,
    description: 'Mencari ilustrasi dari Pixiv dan menampilkan hasilnya dalam bentuk carousel interaktif.',
};