import axios from 'axios';
import { Buffer } from 'buffer'; 

/**
 * Mengirim request ke downr.org API dan mengembalikan array media objects.
 * Media yang dikembalikan sudah difilter: hanya 'video' atau 'image', dan
 * tidak menyertakan track 'audio' terpisah.
 */
async function downr(url) {
    try {
        if (!url.includes('https://')) throw new Error('URL harus dimulai dengan "https://".');
        
        // Tetap menggunakan API Downr.org sesuai permintaan pengguna
        const { data } = await axios.post('https://downr.org/.netlify/functions/download', {
            url: url
        }, {
            headers: {
                'content-type': 'application/json',
                origin: 'https://downr.org',
                referer: 'https://downr.org/',
                'user-agent': 'Mozilla/5.0 (Linux; Android 15; SM-F958 Build/AP3A.240905.015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36'
            }
        });
        
        if (!data || data.error || !data.medias || data.medias.length === 0) {
             throw new Error("Media tidak ditemukan atau API gagal memproses.");
        }
        
        // Filter media: HANYA ambil 'video' atau 'image' dan pastikan ada URL.
        const filteredMedias = data.medias.filter(media => {
            const type = media.type?.toLowerCase();
            return (type === 'video' || type === 'image') && media.url;
        });

        // Jika tidak ada media utama (video/gambar) yang tersisa setelah filtering
        if (filteredMedias.length === 0) {
             throw new Error("Tidak ada media video atau gambar yang valid ditemukan.");
        }
        
        return filteredMedias;
        
    } catch (error) {
        const errorMessage = error.response?.data ? JSON.stringify(error.response.data) : error.message;
        throw new Error(`Gagal request ke Downr API: ${errorMessage}`);
    }
}


/**
 * Handler utama X/Twitter Downloader (menggunakan API Downr.org)
 */
const handler = async ({ sock, msg, from, command, args }) => {
    
    const text = args.join(' ').trim();
    
    // REGEX baru untuk X/Twitter
    const X_URL_REGEX = /(twitter\.com|x\.com)\/.*?\/status\/\d+/i;
    
    if (!text || !text.match(X_URL_REGEX)) {
        // Pesan error diubah ke X/Twitter
        return sock.sendMessage(from, { text: `❌ URL tidak valid. Masukkan link X/Twitter!\n\nContoh:\n*.${command} https://x.com/user/status/123456789*` }, { quoted: msg });
    }

    const MAX_OUTER_RETRIES = 2; 
    let sentCount = 0;
    let finalError = null;
    
    // --- START OUTER RETRY LOOP ---
    for (let outerAttempt = 1; outerAttempt <= MAX_OUTER_RETRIES; outerAttempt++) {
        try {
            await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

            // 1. Dapatkan array objek media
            const medias = await downr(text);
            
            if (medias.length === 0) {
                await sock.sendMessage(from, { text: "Tidak ada media video atau gambar yang valid ditemukan di postingan ini." }, { quoted: msg });
                sentCount = 1; 
                break; 
            }
                
            let currentSentCount = 0;
            const MAX_INNER_RETRIES = 3; 
            
            // 2. Loop dan Unduh media yang sudah terfilter
            for (const media of medias) {
                const url = media.url;

                let mediaBuffer = null;
                const isVideo = media.type === 'video';
                let innerAttempt = 0;
                
                // Inner Retry Loop (3x)
                while (innerAttempt < MAX_INNER_RETRIES) {
                    innerAttempt++;
                    try {
                        const response = await axios.get(url, {
                            responseType: 'arraybuffer'
                        });
                        mediaBuffer = Buffer.from(response.data);
                        break; 
                    } catch (bufferError) {
                        console.error(`[DOWNLOAD BUFFER ERROR] Percobaan ${innerAttempt}/${MAX_INNER_RETRIES} gagal untuk URL: ${url}.`);
                        
                        if (innerAttempt < MAX_INNER_RETRIES) {
                            await new Promise(resolve => setTimeout(resolve, 1000 * innerAttempt)); 
                        }
                    }
                }
                
                // Pastikan buffer berhasil didapatkan sebelum mengirim
                if (!mediaBuffer) {
                    console.error(`Gagal mendapatkan media buffer setelah ${MAX_INNER_RETRIES} kali percobaan: ${url}`);
                    continue; // Lanjut ke media berikutnya
                }
                
                // Pengiriman pesan: HANYA MENGIRIM FILE VIDEO ATAU GAMBAR
                const finalCaption = isVideo ? "Ini kak video X/Twitter nya" : "Ini kak gambar X/Twitter nya";

                if (isVideo) {
                    await sock.sendMessage(from, { video: mediaBuffer, caption: finalCaption }, { quoted: msg });
                } else {
                    await sock.sendMessage(from, { image: mediaBuffer, caption: finalCaption }, { quoted: msg });
                }
                currentSentCount++;
            }
            
            sentCount = currentSentCount;

            if (sentCount > 0) {
                break; 
            } else if (outerAttempt < MAX_OUTER_RETRIES) {
                 finalError = new Error(`Semua media gagal diunduh pada percobaan API ke-${outerAttempt}. Mencoba mengambil URL baru...`);
                 console.error(finalError.message);
                 await new Promise(resolve => setTimeout(resolve, 2000)); 
            }
            
        } catch (e) {
            finalError = e;
            console.error(`[X DL OUTER ERROR] Percobaan ${outerAttempt}/${MAX_OUTER_RETRIES} gagal: ${e.message}`);
            
            if (outerAttempt < MAX_OUTER_RETRIES) {
                await new Promise(resolve => setTimeout(resolve, 2000)); 
            }
        }
    }
    // --- END OUTER RETRY LOOP ---

    // Finalisasi respons setelah semua percobaan
    if (sentCount > 0) {
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
    } else {
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        const errorMessage = finalError ? finalError.message : `Tidak dapat menyelesaikan permintaan setelah ${MAX_OUTER_RETRIES} kali percobaan.`;
        await sock.sendMessage(from, { text: `❌ Gagal memproses: ${errorMessage}` }, { quoted: msg });
    }
};

export default {
    // Perintah diubah ke .x, .twit, dll.
    command: ["x", "twit", "twtdl", "twitterdl"], 
    // Deskripsi diubah
    description: 'Download media (gambar/video) dari postingan X/Twitter menggunakan Downr API.',
    category: 'downloader', 
    handler,
};