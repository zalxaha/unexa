import googleIt from 'google-it';

const handler = async ({ sock, msg, args, command, prefix }) => {

    const actualPrefix = prefix || process.env.PREFIX || '.';
    const full = /f$/i.test(command);
    const text = args.join(' ');

    // --- Usage Text ---
    const usage = `*Usage:*
${actualPrefix}google <pencarian>
${actualPrefix}googlef <pencarian> (Hasil lebih banyak)

*Contoh:*
${actualPrefix}google Teori Relativitas`;

    // --- Cek input pencarian ---
    if (!text) {
        return msg.reply(usage);
    }

    // --- Fitur Khusus: Hari ---
    if (/hari apa/i.test(text)) {
        const hariIni = new Date().toLocaleDateString('id-ID', { weekday: 'long' });
        return msg.reply(`🗓️ Hari ini adalah hari *${hariIni}*`);
    }

    // --- Fitur Khusus: Tanggal ---
    if (/tanggal berapa/i.test(text)) {
        const tanggalIni = new Date().toLocaleDateString('id-ID', {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        });
        return msg.reply(`📅 Tanggal hari ini adalah *${tanggalIni}*`);
    }

    // --- Reaksi Loading ---
    if (msg.react) msg.react('🕒');

    const googleUrl = 'https://google.com/search?q=' + encodeURIComponent(text);

    try {
        const results = await googleIt({ query: text });

        if (!results || results.length === 0) {
            return msg.reply(`😔 Tidak ditemukan hasil pencarian untuk *"${text}"*.`);
        }

        const limit = full ? 10 : 5;
        const sliced = results.slice(0, limit);

        let output = `*🌐 Google Search Results*\n\n*Pencarian:* ${text}\n\n`;

        output += sliced.map(({ title, link, snippet }) => {
            return `*${title.trim()}*
_${link.trim()}_
\`\`\`${snippet.trim()}\`\`\``;
        }).join('\n\n');

        output += `\n\n🔗 *Lihat lebih banyak di:* ${googleUrl}`;

        msg.reply(output);

    } catch (e) {
        console.error('Google-It Error:', e);
        msg.reply('❌ Terjadi kesalahan saat mencari di Google. Coba lagi nanti.');
    }
};

// --- Export Default Mirip addprem.js ---
export default {
    command: ['google', 'googlesearch'],
    category: 'internet',
    handler: handler,
    isOwner: false,
    isPremium: false,
    description: 'Melakukan pencarian di Google dan menampilkan hasil web.'
};