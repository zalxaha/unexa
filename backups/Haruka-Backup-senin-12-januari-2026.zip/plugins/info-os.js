import os from 'os';

// --- HELPER FUNCTION: Get CPU Info Robustly ---
// Fungsi ini mencoba mengambil speed dari os.cpus(), jika 0/null, dia akan ambil dari nama modelnya
const getCpuInfo = () => {
    const cpus = os.cpus();
    const model = cpus[0]?.model || 'Unknown CPU';
    let speed = cpus[0]?.speed;

    // Jika speed 0 atau tidak terdeteksi, coba parse dari nama model
    if (!speed || speed === 0) {
        const match = model.match(/@\s*(\d+\.?\d*)\s*GHz/i);
        if (match && match[1]) {
            speed = Math.round(parseFloat(match[1]) * 1000); // Konversi GHz ke MHz
        }
    }

    return {
        model,
        speed: speed > 0 ? speed : 'Unknown',
        cores: cpus.length
    };
};

const handler = async ({ sock, msg, from }) => {
    
    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    try {
        // AMBIL DATA CPU PAKAI HELPER
        const { model: cpuModel, speed: cpuSpeed, cores: coreCount } = getCpuInfo();

        const totalMemory = (os.totalmem() / (1024 ** 3)).toFixed(2);
        const freeMemory = (os.freemem() / (1024 ** 3)).toFixed(2);

        const osType = os.type();
        const osRelease = os.release();

        const uptime = os.uptime();
        const hours = Math.floor(uptime / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);

        const runtime = process.uptime();
        const runtimeHours = Math.floor(runtime / 3600);
        const runtimeMinutes = Math.floor((runtime % 3600) / 60);
        const runtimeSeconds = Math.floor(runtime % 60);

        const caption = `
📊 *System Information* (Node.js)

💻 *OS Type*: ${osType} (${osRelease})
🖥️ *CPU Model*: ${cpuModel}
⚡ *Speed*: ${cpuSpeed} MHz
✨ *Cores*: ${coreCount}
💾 *Total Memory*: ${totalMemory} GB
📑 *Free Memory*: ${freeMemory} GB

⏱️ *System Uptime*: ${hours}h ${minutes}m ${seconds}s
⚙️ *Bot Runtime*: ${runtimeHours}h ${runtimeMinutes}m ${runtimeSeconds}s
`.trim();

        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

        // Kirim sebagai teks biasa (quoted)
        await sock.sendMessage(
            from, 
            { text: caption }, 
            { quoted: msg }
        );

    } catch (error) {
        console.error("OS Info Error:", error);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        await sock.sendMessage(
            from, {
                text: `❌ Gagal mengambil info sistem: ${error.message}`
            }, {
                quoted: msg
            }
        );
    }
};

// --- EXPORT PLUGIN ---
export default {
    command: ['os', 'osinfo', 'systeminfo'],
    description: 'Menampilkan informasi sistem operasi dan sumber daya bot.',
    category: 'info',
    handler: handler
};