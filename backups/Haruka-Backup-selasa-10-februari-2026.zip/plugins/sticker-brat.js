import fs from 'fs';
import fetch from 'node-fetch';
import { writeExifImg } from '../lib/exif.js';
import cfg from '../config/config.json' with { type: "json" };

const handler = async ({ sock, msg, from, args, sender, db, isPremium, saveDatabase }) => {
    const text = args.join(" ");
    if (!text) return sock.sendMessage(from, { text: "Format:\n.brat teks" }, { quoted: msg });

    // Pastikan database user ada
    if (!db[sender]) db[sender] = {};
    const user = db[sender];

    // --- [A] CEK STATUS PROSES (HANYA UNTUK FREE USER) ---
    // User Premium di-bypass, jadi mereka bisa spam tanpa pesan "Tunggu sebentar"
    if (!isPremium && user.isBratProcessing) {
        return sock.sendMessage(from, { 
            text: "⚠️ Harap tunggu, request sebelumnya belum selesai diproses! Jangan spam ya." 
        }, { quoted: msg });
    }

    // --- [B] LOGIKA RATE LIMIT (HANYA UNTUK FREE USER) ---
    const cooldownTime = 20 * 1000; // 20 Detik
    const now = Date.now();

    if (!isPremium) {
        if (user.lastBrat && (now - user.lastBrat) < cooldownTime) {
            const remaining = Math.ceil((cooldownTime - (now - user.lastBrat)) / 1000);
            
            const limitMsg = `⚠️ *LIMIT TIME REACHED*\n\n` +
                `Tunggu *${remaining} detik* lagi sebelum membuat stiker baru.\n` +
                `Upgrade Premium agar bisa membuat stiker tanpa henti!`;

            return sock.sendMessage(from, { 
                text: limitMsg,
                contextInfo: {
                    externalAdReply: {
                        title: "SISTEM LIMIT HARUKA",
                        body: "Upgrade Premium yuk!",
                        thumbnailUrl: "https://files.catbox.moe/nfhuul.jpg", 
                        mediaType: 1,
                        renderLargerThumbnail: false 
                    }
                }
            }, { quoted: msg });
        }
        
        // Kunci proses hanya untuk user gratisan
        user.isBratProcessing = true;
    }

    // --- [C] PROSES STIKER ---
    await sock.sendMessage(from, { react: { text: "⏳", key: msg.key } });

    // URL API
    const url = `https://brat-gen-52pi.vercel.app/brat?text=${encodeURIComponent(text)}`;
    const temp = `./temp/brat_${Date.now()}.png`;
    let result = "";

    try {
        const res = await fetch(url);
        if (!res.ok) throw new Error("API Error / Down");
        
        const buffer = await res.buffer();
        fs.writeFileSync(temp, buffer);

        // Metadata Stiker
        const meta = { pack: cfg.botName || "Haruka", author: "https://zalxzhu.my.id" };
        
        // Konversi ke Stiker
        result = await writeExifImg(fs.readFileSync(temp), meta);
        const sticker = fs.readFileSync(result);

        // --- [D] KIRIM HASIL ---
        await sock.sendMessage(from, { sticker }, { quoted: msg });
        await sock.sendMessage(from, { react: { text: "✨", key: msg.key } });

        // Update waktu terakhir pakai (Hanya berpengaruh buat free user nantinya)
        if (!isPremium) {
            user.lastBrat = Date.now();
            await saveDatabase();
        }

    } catch (e) {
        console.error(e);
        await sock.sendMessage(from, { react: { text: "❌", key: msg.key } });
        sock.sendMessage(from, { text: "Maaf, terjadi kesalahan saat membuat stiker." }, { quoted: msg });
    } finally {
        // --- [E] BERSIH-BERSIH ---
        // Buka kunci proses (Hanya untuk free user)
        if (!isPremium) {
            user.isBratProcessing = false;
        }

        // Hapus file sampah
        if (fs.existsSync(temp)) fs.unlinkSync(temp);
        if (result && fs.existsSync(result)) fs.unlinkSync(result);
    }
};

export default {
    command: ["brat"],
    category: "Sticker",
    description: "Buat stiker brat (Premium No Limit)",
    handler
};