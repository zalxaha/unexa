import axios from 'axios';

/**
 * Class NekaAPI untuk berinteraksi dengan API NekoLabs.
 */
class NekaAPI {
    constructor() {
        this.client = axios.create({
            baseURL: 'https://api.nekolabs.web.id/discovery/nekopoi/v1',
        });
    }

    /**
     * Melakukan pencarian anime.
     * @param {string} query - Kata kunci pencarian.
     * @returns {Promise<Array<Object>>} Array hasil pencarian.
     */
    searchAnime = async function (query) {
        if (!query) throw new Error('Query pencarian diperlukan.');
        
        try {
            const { data } = await this.client(`/search?q=${encodeURIComponent(query)}`);
            
            if (data.success && Array.isArray(data.result)) {
                return data.result;
            } else if (data.success && data.result.length === 0) {
                 return [];
            } else {
                throw new Error(data.message || 'Format respons API pencarian tidak valid.');
            }
        } catch (error) {
            if (error.response) {
                console.error('Search API Error Response:', error.response.status, error.response.data);
            }
            throw new Error(error.message);
        }
    }

    /**
     * Mengambil detail dari URL post anime.
     * URL yang diberikan dari hasil search akan dipanggil ke endpoint /detail?url=
     * @param {string} postUrl - URL post anime dari hasil pencarian (misal: https://nekolabs.web.id/post/delivery-aunt-tante-subtitle-indonesia).
     * @returns {Promise<Object>} Objek detail hasil.
     */
    getDetail = async function (postUrl) {
        if (!postUrl) return { metadata: { synopsis: 'URL detail tidak tersedia.', stream: 'N/A' } };
        
        try {
            // Menggabungkan URL result pencarian ke parameter 'url' dari API detail
            const { data } = await this.client(`/detail?url=${encodeURIComponent(postUrl)}`);
            
            if (data.success && data.result) {
                return data.result;
            } else {
                throw new Error(data.message || 'Gagal mendapatkan detail.');
            }
        } catch (error) {
            console.error(`Gagal mengambil detail untuk ${postUrl}: ${error.message}`);
            // Mengembalikan placeholder agar loop utama tidak berhenti jika salah satu detail gagal
            return { metadata: { synopsis: 'Detail gagal dimuat.', stream: 'N/A' } };
        }
    }
}

// --- Handler untuk Perintah Pencarian Anime ---
const handler = async ({ sock, msg, args, command, prefix, from }) => {
    const actualPrefix = prefix || process.env.PREFIX || '.';
    const text = args.join(' ');

    const usage = `*Usage:*
${actualPrefix}nekopoi <query>
${actualPrefix}nekopoisearch <query>

*Contoh:*
${actualPrefix}nekopoi milf big ass`;

    if (!text) {
        return sock.sendMessage(from, { text: usage }, { quoted: msg });
    }
    
    // Reaksi Proses (⏳)
    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } }); 

    const api = new NekaAPI();
    let results;

    try {
        // 1. Lakukan pencarian awal
        results = await api.searchAnime(text);

        if (!results || results.length === 0) {
            await sock.sendMessage(from, { react: { text: '😔', key: msg.key } }); 
            return sock.sendMessage(from, { 
                text: `😔 Tidak ditemukan hasil pencarian anime untuk *"${text}"*.` 
            }, { quoted: msg });
        }
        
        // 2. Ambil semua detail secara konkuren menggunakan URL dari hasil pencarian
        const detailPromises = results.map(item => api.getDetail(item.url));
        const allDetails = await Promise.all(detailPromises);

        // 3. Gabungkan hasil pencarian dan detail untuk membuat output
        const output = results.map((item, index) => {
            const detail = allDetails[index];
            const meta = detail.metadata || {};
            
            // Cari link stream pertama yang valid (jika ada)
            const streamLink = meta.stream && meta.stream !== 'N/A' 
                               ? `\n\`Stream:\` ${meta.stream.trim()}` 
                               : '';
            
            // Format output termasuk Sinopsis dan Stream
            return `*${index + 1}. ${item.title.trim()}*
\`Tipe:\` ${item.type.trim() || 'N/A'}
\`Sinopsis:\` ${meta.synopsis ? meta.synopsis.trim() : 'Tidak tersedia.'}
\`Cover:\` ${item.cover.trim() || 'N/A'}
\`URL Post:\` ${item.url.trim() || 'N/A'}${streamLink}`;
        }).join('\n\n---\n\n');

        const finalMessage = `*📺 Hasil Pencarian Nekopoi (${results.length} ditemukan)*\n\n*Pencarian:* ${text}\n\n${output}`;

        // Mengirimkan pesan
        await sock.sendMessage(from, { text: finalMessage }, { quoted: msg });

        // Reaksi Sukses (✅)
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (e) {
        console.error('[NEKOPOI ANIME SEARCH ERROR]', e);
        // Reaksi Gagal (❌)
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        
        const errorMessage = e.message || 'Terjadi kesalahan tidak terduga.';
        return sock.sendMessage(from, {
            text: `❌ Terjadi kesalahan saat mencari anime.\nDetail: ${errorMessage}`
        }, { quoted: msg });
    }
};

// --- Export Default ---
export default {
    command: ['nekopoi', 'nekopoisearch'],
    category: 'nsfw',
    handler: handler,
    isOwner: false,
    isPremium: true,
    description: 'Melakukan pencarian anime lengkap (search + detail) menggunakan API NekoLabs.'
};