import axios from 'axios';
import fileType from 'file-type'; // UBAH: Import default
import { downloadContentFromMessage } from '@whiskeysockets/baileys';

import cfg from '../config/config.json' with { type: 'json' };
import log from '../lib/logger.js';

// --- KONFIGURASI BARU (DARI GEMMY WRAPPER) ---
const CONFIG = {
    GEMINI: {
        URL: "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent",
        API_KEY: "AIzaSyAKbxdxfyNoQMx9ft9xAVoQWrwpN9JnphY",
        HEADERS: {
            'User-Agent': 'okhttp/5.3.2',
            'Accept-Encoding': 'gzip',
            'x-goog-api-key': 'AIzaSyAKbxdxfyNoQMx9ft9xAVoQWrwpN9JnphY',
            'x-android-package': 'com.jetkite.gemmy',
            'x-android-cert': '037CD2976D308B4EFD63EC63C48DC6E7AB7E5AF2',
            'content-type': 'application/json; charset=UTF-8'
        }
    }
};

const SYSTEM_INSTRUCTION = {
    role: "user",
    parts: [{
        text: "You are a helpful assistant. Keep your answers concise. Provide no more than 3–4 paragraphs unless the user explicitly asks for a longer explanation. Avoid using LaTeX ($) for math, use plain text format."
    }]
};

/**
 * Fungsi Chat Wrapper menggunakan konfigurasi Gemmy
 */
const gemmyChat = async (prompt, mediaBuffer = null) => {
    try {
        let parts = [];

        // 1. Handle Media (Gambar) jika ada
        if (mediaBuffer) {
            let mimeType = 'image/jpeg'; // Default fallback
            try {
                // FIX: Menggunakan fileType.fromBuffer karena import default
                const type = await fileType.fromBuffer(mediaBuffer);
                if (type) mimeType = type.mime;
            } catch (e) {
                console.error("Gagal mendeteksi tipe file, menggunakan default jpeg.");
            }

            // Convert buffer ke base64 (Standard Gemini API)
            const base64Data = mediaBuffer.toString('base64');

            parts.push({
                inlineData: {
                    mimeType: mimeType,
                    data: base64Data
                }
            });
            
            // Tambahkan prompt teks setelah gambar
            parts.push({ text: prompt });
        } else {
            // 2. Jika hanya Teks
            parts.push({ text: prompt });
        }

        // Susun Payload sesuai source Gemmy
        const payload = {
            contents: [{
                role: "user",
                parts: parts
            }],
            generationConfig: {
                maxOutputTokens: 800,
                temperature: 0.9
            },
            systemInstruction: SYSTEM_INSTRUCTION
        };

        // Request ke API
        const response = await axios.post(CONFIG.GEMINI.URL, payload, {
            headers: CONFIG.GEMINI.HEADERS
        });

        const result = response.data;

        // Ambil respons kandidat pertama
        if (result.candidates && result.candidates.length > 0) {
            const replyText = result.candidates[0].content?.parts?.[0]?.text;
            if (replyText) return replyText;
        }

        throw new Error('Tidak ada respons dari AI (Candidates empty).');

    } catch (error) {
        // Handle error message dari axios atau API
        const errMsg = error.response?.data?.error?.message || error.message;
        throw new Error(errMsg);
    }
};

// --- HELPER UNTUK REAKSI ---
async function sendReaction(sock, msgKey, reactionEmoji) {
    const remoteJid = msgKey.remoteJid;
    const reactionKey = {
        id: msgKey.id,
        remoteJid: remoteJid,
        fromMe: msgKey.fromMe || false,
        ...(msgKey.participant ? { participant: msgKey.participant } : {})
    };

    return sock.sendMessage(remoteJid, {
        react: {
            text: reactionEmoji,
            key: reactionKey
        }
    });
}

// --- EXPORT BAILEYS HANDLER ---
export default {
    command: ['ai', 'ask', 'gemini', 'tanya'],
    category: 'ai',

    handler: async function ({ sock, msg, args, remoteJid }) {
        let question = args.join(' ');
        let mediaBuffer = null;
        const targetMsgKey = msg.key;

        // 1. Cek Media di Pesan Saat Ini (Image/Video Message)
        if (msg.message.imageMessage || msg.message.videoMessage) {
            try {
                const type = Object.keys(msg.message)[0];
                const stream = await downloadContentFromMessage(msg.message[type], type.replace('Message', ''));
                let buffer = Buffer.from([]);
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }
                mediaBuffer = buffer;
            } catch (e) {
                log.err("Gagal mengunduh media:", e.message);
                await sendReaction(sock, targetMsgKey, '❌');
                return msg.reply("❌ Gagal mengunduh media.");
            }
        }
        // 2. Cek Media di Pesan yang Dibalas (Quoted Message)
        else if (msg.quoted?.message && (msg.quoted.type.includes('Image') || msg.quoted.type.includes('Video'))) {
            try {
                mediaBuffer = await msg.quoted.download();
                // Jika user tidak mengetik pertanyaan baru, gunakan caption dari gambar yg dibalas (opsional)
                if (!question) question = msg.text.trim(); 
            } catch (e) {
                log.err("Gagal download quoted media:", e.message);
            }
        }

        // 3. Validasi: Harus ada pertanyaan ATAU gambar
        if (!question && !mediaBuffer) {
            const prefix = cfg.prefix || '.';
            return msg.reply(`*AI Gemmy (Flash Lite)* 🤖
Gunakan perintah ini untuk bertanya atau analisis gambar.

Contoh:
1. ${prefix}ai resep nasi goreng
2. Kirim gambar dengan caption: ${prefix}ai gambar apa ini?`);
        }

        // Default prompt jika user hanya mengirim gambar tanpa teks
        if (mediaBuffer && !question) {
            question = "Jelaskan secara detail apa yang ada di dalam gambar/media ini.";
        }

        try {
            await sendReaction(sock, targetMsgKey, '⏳');

            // Panggil fungsi AI baru
            const responseText = await gemmyChat(question, mediaBuffer);

            await sendReaction(sock, targetMsgKey, '✅');
            await msg.reply(responseText);

        } catch (e) {
            log.err("Gemmy API Error:", e.message);
            await sendReaction(sock, targetMsgKey, '❌');
            return msg.reply(`❌ Terjadi kesalahan pada layanan AI:\n${e.message}`);
        }
    }
};