import { exec } from 'child_process';
import fs from 'fs';
import path from 'path';
import { downloadMediaMessage } from '@whiskeysockets/baileys';

export default {
    command: ['resize', 'vresize'],
    category: 'tools',
    isOwner: false,
    isAdmin: false,
    isBotAdmin: false,
    isPremium: false,

    handler: async ({ 
        sock, 
        msg, 
        args, 
        reply, 
        sendVideo, 
        sendReact 
    }) => {
        const isQuoted = !!msg.quoted;
        const targetMsg = isQuoted ? msg.quoted : msg;
        const mime = (targetMsg.msg || targetMsg).mimetype || targetMsg.message?.videoMessage?.mimetype || targetMsg.mimetype || '';

        if (!/video/.test(mime)) return reply('❌ Balas video atau kirim video dengan caption command ini!');
        
        const percent = parseInt(args[0]);
        if (isNaN(percent) || percent < 10 || percent > 90) {
            return reply('❌ Masukkan angka rasio antara 10 - 90! Contoh: .resize 50');
        }

        await sendReact('⏳');

        const ratio = percent / 100;
        const tmpDir = path.join(process.cwd(), 'tmp');
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir);

        const inputPath = path.join(tmpDir, `input_${Date.now()}.mp4`);
        const outputPath = path.join(tmpDir, `output_${Date.now()}.mp4`);

        try {
            const buffer = await downloadMediaMessage(
                targetMsg,
                'buffer',
                {},
                {
                    reuploadRequest: sock.updateMediaMessage
                }
            );

            fs.writeFileSync(inputPath, buffer);

            const ffmpegCommand = `ffmpeg -i ${inputPath} -vf "scale=iw*${ratio}:-2" -c:v libx264 -crf 34 -preset veryfast -c:a aac -b:a 64k ${outputPath}`;

            exec(ffmpegCommand, async (error) => {
                if (error) {
                    cleanup(inputPath, outputPath);
                    return reply('❌ Gagal memproses video.');
                }

                try {
                    const videoBuffer = fs.readFileSync(outputPath);
                    await sendVideo(videoBuffer, 'Video Resized (Compressed) ✅');
                } catch (e) {
                    reply('❌ Gagal mengirim video hasil.');
                } finally {
                    cleanup(inputPath, outputPath);
                }
            });
        } catch (err) {
            cleanup(inputPath, outputPath);
            reply(`❌ Error: ${err.message}`);
        }

        function cleanup(inPath, outPath) {
            if (fs.existsSync(inPath)) fs.unlinkSync(inPath);
            if (fs.existsSync(outPath)) fs.unlinkSync(outPath);
        }
    }
};