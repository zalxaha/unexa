import axios from "axios";
import crypto from "crypto";

class Savetube {
  constructor() {
    this.ky = 'C5D58EF67A7584E4A29F6C35BBC4EB12';
    this.m = /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(?:embed\/)?(?:v\/)?(?:shorts\/)?([a-zA-Z0-9_-]{11})/;
    this.is = axios.create({
      headers: {
        'content-type': 'application/json',
        'origin': 'https://yt.savetube.me',
        'user-agent': 'Mozilla/5.0 (Android 15; Mobile; SM-F958; rv:130.0) Gecko/130.0 Firefox/130.0'
      }
    });
  }
  
  async decrypt(enc) {
    const sr = Buffer.from(enc, 'base64');
    const ky = Buffer.from(this.ky, 'hex');
    const iv = sr.slice(0, 16);
    const dt = sr.slice(16);
    const dc = crypto.createDecipheriv('aes-128-cbc', ky, iv);
    return JSON.parse(Buffer.concat([dc.update(dt), dc.final()]).toString());
  }
  
  async getCdn() {
    const response = await this.is.get("https://media.savetube.vip/api/random-cdn");
    return response.data.cdn;
  }
  
  async download(url, format = 'video', quality = '480') {
    const id = url.match(this.m)?.[3];
    if (!id) throw new Error("ID video tidak ditemukan");
    
    const cdn = await this.getCdn();
    const res = await this.is.post(`https://${cdn}/v2/info`, { url: `https://www.youtube.com/watch?v=${id}` });
    const dec = await this.decrypt(res.data.data);
    
    const dl = await this.is.post(`https://${cdn}/download`, {
      id: id,
      downloadType: format,
      quality: quality,
      key: dec.key
    });

    return {
      title: dec.title,
      duration: dec.durationLabel,
      dl: dl.data.data.downloadUrl,
      quality: quality
    };
  }
}

const handler = async ({ sock, msg, args, from }) => {
  const text = args.join(' ');
  const parts = text.trim().split(' ');
  const url = parts[0];
  const reso = parts[1] || '480';

  if (!url) return sock.sendMessage(from, { text: 'Masukkan link YouTube.\nContoh: .ytv https://youtu.be/xyz 720' }, { quoted: msg });

  await sock.sendMessage(from, { react: { text: '🎬', key: msg.key } });

  try {
    const st = new Savetube();
    const result = await st.download(url, 'video', reso);

    const caption = `*YOUTUBE VIDEO*\n\n• *Judul:* ${result.title}\n• *Durasi:* ${result.duration}\n• *Kualitas:* ${result.quality}p`;

    await sock.sendMessage(from, {
      video: { url: result.dl },
      mimetype: 'video/mp4',
      fileName: `${result.title}.mp4`,
      caption
    }, { quoted: msg });

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
  } catch (err) {
    await sock.sendMessage(from, { text: `❌ Error: ${err.message}` }, { quoted: msg });
  }
};

export default {
  command: ['ytmp4', 'ytv'],
  description: 'Download video YouTube via Savetube',
  category: 'Downloader',
  handler,
};