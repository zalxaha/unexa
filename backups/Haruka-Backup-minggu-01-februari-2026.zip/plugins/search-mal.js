import axios from 'axios';
import * as cheerio from 'cheerio';

// --- SCRAPER CLASS (Dari request Anda) ---
class MAL {
    topAnime = async function () {
        try {
            const { data } = await axios.get('https://myanimelist.net/topanime.php');
            const $ = cheerio.load(data);
            const animeList = [];
    
            $('.ranking-list').each((_, element) => {
                const rank = $(element).find('.rank').text().trim();
                const title = $(element).find('.title h3 a').text().trim();
                const url = $(element).find('.title h3 a').attr('href');
                const score = $(element).find('.score span').text().trim();
                const cover = $(element).find('.title img').attr('data-src') || $(element).find('.title img').attr('src');
                // Mengambil src jika data-src tidak ada
                
                animeList.push({ rank, title, score, cover, url });
            });
            return animeList;
        } catch (error) { throw new Error(error.message); }
    }
    
    animeSearch = async function (query) {
        try {
            const { data } = await axios.get(`https://myanimelist.net/anime.php?q=${query}&cat=anime`);
            const $ = cheerio.load(data);
            const animeList = [];
            $('table tbody tr').each((_, element) => {
                const cover = $(element).find('td:nth-child(1) img').attr('data-src') || $(element).find('td:nth-child(1) img').attr('src');
                const title = $(element).find('td:nth-child(2) strong').text().trim();
                const url = $(element).find('td:nth-child(2) a').attr('href');
                const type = $(element).find('td:nth-child(3)').text().trim();
                const episodes = $(element).find('td:nth-child(4)').text().trim();
                const score = $(element).find('td:nth-child(5)').text().trim();
                const description = $(element).find('td:nth-child(2) .pt4').text().replace('read more.', '').trim() || 'No Desc';
                if (title && url) animeList.push({ title, description, type, episodes, score, cover, url });
            });
            return animeList;
        } catch (error) { throw new Error(error.message); }
    }
    
    mangaSearch = async function (query) {
        try {
            const { data } = await axios.get(`https://myanimelist.net/manga.php?q=${query}&cat=manga`);
            const $ = cheerio.load(data);
            const mangaList = [];
            $('table tbody tr').each((_, element) => {
                const cover = $(element).find('td:nth-child(1) img').attr('data-src') || $(element).find('td:nth-child(1) img').attr('src');
                const title = $(element).find('td:nth-child(2) strong').text().trim();
                const url = $(element).find('td:nth-child(2) a').attr('href');
                const type = $(element).find('td:nth-child(3)').text().trim();
                const vol = $(element).find('td:nth-child(4)').text().trim();
                const score = $(element).find('td:nth-child(5)').text().trim();
                const description = $(element).find('td:nth-child(2) .pt4').text().replace('read more.', '').trim() || 'No Desc';
                if (title && url) mangaList.push({ title, description, type, vol, score, cover, url });
            });
            return mangaList;
        } catch (error) { throw new Error(error.message); }
    }
    
    charaSearch = async function (query) {
        try {
            const { data } = await axios.get(`https://myanimelist.net/character.php?q=${query}&cat=character`);
            const $ = cheerio.load(data);
            const characterData = [];
            $('table tbody tr').each((_, element) => {
                const cover = $(element).find('td .picSurround img').attr('data-src') || $(element).find('td .picSurround img').attr('src');
                const name = $(element).find('td:nth-child(2) a').text().trim();
                const url = $(element).find('td:nth-child(2) a').attr('href');
                if (name && url) characterData.push({ name, cover, url });
            });
            return characterData;
        } catch (error) { throw new Error(error.message); }
    }

    // Detail functions (opsional jika ingin deep fetch)
    animeDetail = async function (url) {
        try {
            const { data } = await axios.get(url);
            const $ = cheerio.load(data);
            const title = $("h1.title-name").text().trim();
            const cover = $(".leftside img").attr("data-src") || $(".leftside img").attr("src");
            const synopsis = $(".js-scrollfix-bottom-rel").find("p").first().text().trim();
            const score = $('span[itemprop="ratingValue"]').text().trim();
            const rank = $('.numbers.ranked strong').text().trim();
            const popularity = $('.numbers.popularity strong').text().trim();
            const members = $('.numbers.members strong').text().trim();
            
            // Info table
            const type = $('.spaceit_pad:contains("Type") a').text().trim();
            const episodes = $('.spaceit_pad:contains("Episodes")').contents().not('span').text().trim();
            const status = $('.spaceit_pad:contains("Status")').contents().not('span').text().trim();
            const genres = $("span:contains('Genres:')").nextAll("a").map((i, el) => $(el).text().trim()).get().join(', ');

            return { title, cover, synopsis, score, rank, popularity, members, type, episodes, status, genres, url };
        } catch (error) { throw new Error(error.message); }
    }
}

const mal = new MAL();

// --- HANDLER PLUGIN ---
const handler = async ({ sock, msg, args, command }) => {
    const type = args[0]?.toLowerCase();
    const query = args.slice(1).join(" ");

    const helpMessage = `
📚 *MyAnimeList Search*

Gunakan format:
• ${command} anime <judul>
• ${command} manga <judul>
• ${command} char <nama>
• ${command} top

Contoh:
${command} anime Naruto
${command} char Gojo Satoru
`;

    if (!type) return msg.reply(helpMessage);

    await sock.sendMessage(msg.key.remoteJid, { react: { text: '🔍', key: msg.key } });

    try {
        if (type === 'top') {
            const data = await mal.topAnime();
            if (!data.length) return msg.reply('Tidak ada data ditemukan.');
            
            // Ambil top 5
            const top5 = data.slice(0, 5);
            let text = `🏆 *TOP 5 ANIME (MAL)*\n\n`;
            
            for (let i of top5) {
                text += `*#${i.rank} ${i.title}*\n`;
                text += `⭐ Score: ${i.score}\n`;
                text += `🔗 ${i.url}\n\n`;
            }
            
            // Kirim gambar rank 1
            await sock.sendMessage(msg.key.remoteJid, {
                image: { url: top5[0].cover },
                caption: text
            }, { quoted: msg });

        } else if (type === 'anime') {
            if (!query) return msg.reply('Masukkan judul anime!');
            const searchResults = await mal.animeSearch(query);
            if (!searchResults.length) return msg.reply('Anime tidak ditemukan.');

            // Ambil detail hasil pertama agar lebih lengkap
            const firstResult = searchResults[0];
            const detail = await mal.animeDetail(firstResult.url);

            let text = `🎬 *ANIME DETAIL*\n\n`;
            text += `Title: *${detail.title}*\n`;
            text += `⭐ Score: ${detail.score} | Rank: #${detail.rank}\n`;
            text += `📺 Type: ${detail.type} (${detail.episodes} Eps)\n`;
            text += `📡 Status: ${detail.status}\n`;
            text += `🎭 Genres: ${detail.genres}\n`;
            text += `👥 Members: ${detail.members}\n\n`;
            text += `📝 *Synopsis:*\n${detail.synopsis}\n\n`;
            text += `🔗 ${detail.url}`;

            await sock.sendMessage(msg.key.remoteJid, {
                image: { url: detail.cover },
                caption: text
            }, { quoted: msg });

        } else if (type === 'manga') {
            if (!query) return msg.reply('Masukkan judul manga!');
            const searchResults = await mal.mangaSearch(query);
            if (!searchResults.length) return msg.reply('Manga tidak ditemukan.');

            const res = searchResults[0]; // Ambil hasil pertama
            let text = `📖 *MANGA SEARCH*\n\n`;
            text += `Title: *${res.title}*\n`;
            text += `⭐ Score: ${res.score}\n`;
            text += `📚 Type: ${res.type} (Vol: ${res.vol})\n`;
            text += `📝 *Desc:*\n${res.description}\n\n`;
            text += `🔗 ${res.url}`;

            await sock.sendMessage(msg.key.remoteJid, {
                image: { url: res.cover },
                caption: text
            }, { quoted: msg });

        } else if (type === 'char' || type === 'character') {
            if (!query) return msg.reply('Masukkan nama karakter!');
            const searchResults = await mal.charaSearch(query);
            if (!searchResults.length) return msg.reply('Karakter tidak ditemukan.');

            const res = searchResults[0];
            let text = `👤 *CHARACTER SEARCH*\n\n`;
            text += `Name: *${res.name}*\n`;
            text += `🔗 ${res.url}`;

            await sock.sendMessage(msg.key.remoteJid, {
                image: { url: res.cover },
                caption: text
            }, { quoted: msg });

        } else {
            msg.reply(helpMessage);
        }

    } catch (e) {
        console.error(e);
        msg.reply('❌ Terjadi kesalahan saat mengambil data MyAnimeList.');
    }
};

export default {
    command: ['mal', 'myanimelist'],
    category: 'Search',
    handler
};