import { twitter } from 'btch-downloader';
import axios from 'axios';

const handler = async ({ sock, msg, from, command, args }) => {
    
    const text = args.join(' ').trim();
    const X_URL_REGEX = /(twitter\.com|x\.com)\/.*?\/status\/\d+/i;
    
    if (!text || !text.match(X_URL_REGEX)) {
        return sock.sendMessage(from, { 
            text: `❌ URL tidak valid. Masukkan link X/Twitter!\n\nContoh:\n*.${command} https://x.com/user/status/123456789*` 
        }, { quoted: msg });
    }

    try {
        await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

        // 1. Ambil Data API
        const data = await twitter(text);

        if (!data || !data.url) {
            throw new Error("Struktur data tidak valid (URL tidak ditemukan).");
        }

        const mediaList = data.url;
        
        // Cari URL SD dan HD secara spesifik
        const sdObj = mediaList.find(item => item.sd);
        const hdObj = mediaList.find(item => item.hd);
        
        // Fallback jika tidak ada label sd/hd (ambil item pertama)
        const fallbackUrl = !sdObj && !hdObj && mediaList.length > 0 ? Object.values(mediaList[0])[0] : null;

        // Validasi
        if (!sdObj && !hdObj && !fallbackUrl) {
            throw new Error("Link video tidak ditemukan.");
        }

        // Fungsi Helper untuk Download & Kirim
        const sendMedia = async (url, quality, isDocument = false) => {
            try {
                // Download Buffer (Wajib agar tidak corrupt/error resolusi)
                const response = await axios.get(url, { 
                    responseType: 'arraybuffer',
                    headers: { 'User-Agent': 'Mozilla/5.0' }
                });
                const buffer = Buffer.from(response.data);

                const caption = `*H͟a͟r͟u͟k͟a͟ x/twitter downloader*\n\n` +
                                `📝 *Title:* ${data.title || '-'}\n` +
                                `🎞️ *Quality:* ${quality}`;

                if (isDocument) {
                    // Kirim sebagai Dokumen (Aman untuk HD/4K)
                    await sock.sendMessage(from, { 
                        document: buffer, 
                        mimetype: 'video/mp4',
                        fileName: `twitter_${quality}_${Date.now()}.mp4`,
                        caption: caption
                    }, { quoted: msg });
                } else {
                    // Kirim sebagai Video (Bisa di-play langsung)
                    await sock.sendMessage(from, { 
                        video: buffer, 
                        caption: caption,
                        mimetype: 'video/mp4'
                    }, { quoted: msg });
                }
            } catch (err) {
                console.error(`Gagal mengirim versi ${quality}:`, err.message);
                // Jangan throw error agar jika SD gagal, HD tetap dicoba (atau sebaliknya)
            }
        };

        // --- SKENARIO PENGIRIMAN ---

        // 1. Kirim Versi SD (Prioritas untuk Play Langsung)
        if (sdObj) {
            await sendMedia(sdObj.sd, 'SD (Standard)', false); // false = Kirim sebagai Video
        }

        // 2. Kirim Versi HD (Prioritas Kualitas)
        if (hdObj) {
            // Jika SD sudah dikirim, HD kita kirim sebagai Dokumen (opsional, biar variatif)
            // Atau tetap coba video dulu, kalau error baru dokumen (di dalam logic WA biasanya otomatis)
            // Tapi agar aman untuk 4K, kita set HD cenderung ke Dokumen jika SD sudah ada.
            
            // Logika: Jika resolusi HD-nya 4K (biasanya berat), lebih aman dokumen.
            // Tapi kita coba kirim sebagai Video dulu, kalau mau aman 100% jadikan true.
            // Disini saya buat false dulu (coba video), karena user minta "2 versi".
            // Jika Anda ingin HD PASTI jadi file, ubah 'false' di bawah jadi 'true'.
            
            await sendMedia(hdObj.hd, 'HD (High Quality)', false); 
        }

        // 3. Fallback (Jika tidak ada label SD/HD, misal video lama)
        if (!sdObj && !hdObj && fallbackUrl) {
            await sendMedia(fallbackUrl, 'Unknown Quality', false);
        }

        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (e) {
        console.error(`[X DL ERROR] ${e.message}`);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        await sock.sendMessage(from, { text: `❌ Gagal: ${e.message}` }, { quoted: msg });
    }
};

export default {
    command: ["x", "twit", "twtdl", "twitterdl"], 
    description: 'Download video Twitter/X (Kirim SD & HD).',
    category: 'downloader', 
    handler,
};