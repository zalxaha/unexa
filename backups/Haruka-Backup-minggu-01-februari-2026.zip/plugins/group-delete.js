export default {
    command: ['delete', 'del', 'hapus', 'd'],
    description: 'Menghapus pesan grup dengan reply (Admin Only).',
    category: 'Group',

    isGroup: true,
    isAdmin: true,
    isBotAdmin: true,

    handler: async ({ sock, msg, from }) => {
        try {
            // Harus reply pesan
            if (!msg.quoted) {
                return msg.reply(
                    '⚠️ Reply pesan yang ingin dihapus.'
                );
            }

            // React proses
            await sock.sendMessage(from, {
                react: { text: '⏳', key: msg.key }
            });

            // Hapus pesan yang di-reply
            await sock.sendMessage(from, {
                delete: msg.quoted.key
            });

            // React sukses
            await sock.sendMessage(from, {
                react: { text: '✅', key: msg.key }
            });

        } catch (e) {
            console.error('[DELETE MSG ERROR]', e);

            await sock.sendMessage(from, {
                react: { text: '❌', key: msg.key }
            });

            if (
                e.message?.includes('not-authorized') ||
                e.message?.includes('forbidden')
            ) {
                return msg.reply(
                    '❌ Bot harus menjadi admin grup.'
                );
            }

            if (e.message?.includes('not found')) {
                return msg.reply(
                    '❌ Pesan tidak ditemukan atau sudah terlalu lama.'
                );
            }

            msg.reply(`❌ Gagal menghapus pesan.\n${e.message}`);
        }
    }
};