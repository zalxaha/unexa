import axios from 'axios';

const Jawa = {
    /**
     * Menerjemahkan teks menggunakan translatejawa.id API.
     * @param {string} text Teks yang akan diterjemahkan.
     * @param {object} options Opsi terjemahan.
     * @param {string} options.from Bahasa sumber (default: 'indo').
     * @param {string} options.to Bahasa target (default: 'alus').
     * @returns {Promise<string>} Hasil terjemahan.
     */
    translate: async (text, { from = 'indo', to = 'alus' } = {}) => {
        try {
            if (!text) throw new Error('Text is required.');
            
            // Pemetaan Bahasa diubah: lugu -> kl, alus -> ka, ngoko -> ng
            const languageMap = {
                'indo': 'id',
                'jawa': 'jw',
                'lugu': 'kl',      // Sebelumnya krama-lugu
                'alus': 'ka',      // Sebelumnya krama-alus
                'ngoko': 'ng'
            };
            
            const fromCode = languageMap[from];
            const toCode = languageMap[to];
            
            if (!fromCode) throw new Error(`Invalid 'from' language: ${from}. Valid options: indo, jawa.`);
            if (!toCode) throw new Error(`Invalid 'to' language: ${to}. Valid options: indo, lugu, alus, ngoko.`);
            if (fromCode === 'id' && toCode === 'id') throw new Error('Cannot translate from indo to indo.');
            if (fromCode === 'jw' && toCode !== 'id') throw new Error('When translating from jawa, target must be indo.');
            
            const { data } = await axios.post('https://api.translatejawa.id/translate', {
                text: text.trim(),
                from: fromCode,
                to: toCode
            }, {
                headers: {
                    'content-type': 'application/json',
                    referer: 'https://translatejawa.id/',
                    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36'
                }
            });
            
            if (data && data.result) {
                return data.result;
            } else {
                throw new Error("API tidak mengembalikan hasil terjemahan yang valid.");
            }
        } catch (error) {
            throw new Error(`Terjemahan gagal: ${error.message}`);
        }
    },
    
    // Fungsi aksara dihilangkan dari tampilan ini agar lebih fokus ke terjemahan
};


// --- HANDLER BOT ---

const handler = async ({ sock, msg, args, from, command }) => {
    
    const validModes = ['lugu', 'alus', 'ngoko'];
    const mode = args[0] ? args[0].toLowerCase() : null;
    let textToTranslate = args.slice(1).join(' ').trim();
    
    let targetMode = 'alus'; // Default: Alus (Krama Alus)
    
    // Logika penentuan mode dan teks
    if (validModes.includes(mode)) {
        targetMode = mode;
        textToTranslate = args.slice(1).join(' ').trim();
    } else {
        // Jika argumen pertama bukan mode, anggap seluruh argumen adalah teks, dan gunakan mode default ('alus')
        textToTranslate = args.join(' ').trim();
    }
    
    // Dapatkan quoted message jika teks kosong
    if (!textToTranslate && msg.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
        const quoted = msg.message.extendedTextMessage.contextInfo.quotedMessage;
        textToTranslate = quoted.conversation || quoted.extendedTextMessage?.text || '';
    }

    if (!textToTranslate) {
        let helpText = `Terjemahkan teks Bahasa Indonesia ke Bahasa Jawa.`;
        helpText += `\n\n*Penggunaan:*\n`;
        helpText += `1. **Default (Alus):** .${command} [teks]\n`;
        helpText += `2. **Dengan Mode:** .${command} [mode] [teks]\n`;
        helpText += `\n*Mode yang tersedia:*\n`;
        helpText += ` - alus (Krama Inggil/Hormat)\n`;
        helpText += ` - lugu (Krama Biasa)\n`;
        helpText += ` - ngoko (Bahasa Kasar/Seharian)\n`;
        helpText += `\n*Contoh:*\n`;
        helpText += `.${command} Saya ingin makan nasi goreng\n`;
        helpText += `.${command} ngoko Saya ingin makan nasi goreng\n`;
        
        return sock.sendMessage(from, { text: helpText }, { quoted: msg });
    }

    try {
        await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

        const result = await Jawa.translate(textToTranslate, {
            from: 'indo',
            to: targetMode
        });
        
        // Kapitalisasi mode untuk tampilan
        const modeDisplay = targetMode.charAt(0).toUpperCase() + targetMode.slice(1);

        let responseText = `--- 🇮🇩 Terjemahan Jawa (${modeDisplay}) 🇯🇼 ---\n`;
        responseText += `\n*Teks Asli:*\n${textToTranslate}\n`;
        responseText += `\n*Hasil Terjemahan:*\n${result}\n`;
        
        await sock.sendMessage(from, { text: responseText }, { quoted: msg });
        
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
        
    } catch (e) {
        console.error('[JAWA TRANSLATOR ERROR]', e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        await sock.sendMessage(from, { text: `❌ Gagal menerjemahkan: ${e.message}` }, { quoted: msg });
    }
};

export default {
    command: ['tjawa', 'trjawa', 'jawatrans'],
    description: 'Terjemahkan Bahasa Indonesia ke Bahasa Jawa (Alus, Lugu, Ngoko).',
    category: 'tools', 
    handler,
};