import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore
} from '@whiskeysockets/baileys';

import qr from 'qrcode-terminal';
import pino from 'pino';
import path from 'path';
import fs from 'fs/promises';
import * as fsSync from 'fs';
import { fileURLToPath } from 'url';
// Pastikan sudah install ini: npm install libphonenumber-js
import { parsePhoneNumber } from 'libphonenumber-js'; 
import chalk from 'chalk';

import log from './lib/logger.js';
import config from './config/config.json' assert { type: 'json' };

// Dynamic import handler
let Msg;
try {
  Msg = await import('./handlers/messageHandler.js');
} catch (e) {
  console.error('⚠️ Warning: Gagal import messageHandler saat start awal.', e.message);
}

import CallHandler from './lib/call.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const sessionFolder = path.join(__dirname, 'session');
const dbPath = path.join(__dirname, 'database/users.json');

// -----------------------------------------------------
//  VALIDASI NOMOR (STABIL)
// -----------------------------------------------------
async function validatePhoneNumber(input) {
  if (!input) return null;
  try {
    let phone = String(input).replace(/[^0-9]/g, "");
    if (!phone.startsWith('+')) phone = '+' + phone;
    const pn = parsePhoneNumber(phone);
    if (!pn || !pn.isValid()) {
      log.err(chalk.redBright("❌ Nomor tidak valid. Cek config.json"));
      return null;
    }
    return pn.number.replace('+', '');
  } catch (error) {
    return null;
  }
}
// -----------------------------------------------------

async function checkDatabase() {
  try {
    await fs.access(dbPath);
    const fileContent = (await fs.readFile(dbPath, 'utf8')).trim();
    if (fileContent.length === 0) {
      await fs.writeFile(dbPath, JSON.stringify({}));
    }
  } catch (error) {
    if (error.code === 'ENOENT') {
      await fs.mkdir(path.dirname(dbPath), { recursive: true });
      await fs.writeFile(dbPath, JSON.stringify({}));
    }
  }
}

let isReady = false;

async function Start() {
  await checkDatabase();

  // Cek folder session
  try {
    await fs.access(sessionFolder);
  } catch (err) {
    if (err.code === "ENOENT") {
      await fs.mkdir(sessionFolder, { recursive: true });
    }
  }

  const { state, saveCreds } = await useMultiFileAuthState(sessionFolder);
  const { version, isLatest } = await fetchLatestBaileysVersion();

  log.info(`Baileys v${version.join('.')}, latest: ${isLatest}`);

  const usePairing = config.system?.pairing === true;

  const sock = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })),
    },
    logger: pino({ level: 'silent' }),
    printQRInTerminal: !usePairing,
    syncFullHistory: false,
    generateHighQualityLinkPreview: true,
    patch: ['status'],
    shouldSyncHistoryMessage: () => false,
    // FIX: Gunakan identitas Ubuntu/Chrome agar lebih tembus di Panel
    browser: ["Ubuntu", "Chrome", "20.0.04"], 
    retryRequestDelayMs: 500, 
    connectTimeoutMs: 60000,
  });

  // LOGIKA PAIRING CODE
  if (usePairing && !sock.authState.creds.registered) {
    // Delay 3 detik agar koneksi stabil dulu baru minta kode
    setTimeout(async () => {
        const phoneNumber = await validatePhoneNumber(config.system.number);
        if (phoneNumber) {
            try {
              let code = await sock.requestPairingCode(phoneNumber);
              code = code?.match(/.{1,4}/g)?.join('-') || code;

              console.log(chalk.bgGreen.black(`\n📞 KODE PAIRING BARU:`));
              console.log(chalk.white.bold(code));
              console.log(chalk.yellow(`\n⚠️ Segera ketik kode ini di HP (Perangkat Tertaut > Tautkan dengan Nomor)\n`));

            } catch (e) {
              log.err("❌ Gagal request kode: " + e.message);
            }
        } else {
            log.err("❌ Nomor di config.json salah format/kosong!");
        }
    }, 3000);
  }

  // KONEKSI & UPDATE
  sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr: code }) => {
    if (code && !usePairing && !sock.authState.creds.registered) {
      log.info("🔐 Scan QR Mode:");
      qr.generate(code, { small: true });
    }

    if (connection === "open") {
      isReady = true;
      log.ok("✅ Bot Terhubung!");

      const ownerJid = config.owner + "@s.whatsapp.net";
      try {
        await sock.sendMessage(ownerJid, { text: "✅ Bot berhasil login dan online!" });
      } catch {}
    }

    if (connection === "close") {
      isReady = false;
      const reason = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.message || "Unknown";
      
      log.warn(`❌ Terputus: ${reason}`);

      // Jika sesi rusak (Logged Out / 401), hapus session otomatis
      if (reason === DisconnectReason.loggedOut || reason === 401 || reason === 403) {
        log.err("🚪 Sesi rusak (Logged Out). Menghapus folder session...");
        try {
          await fs.rm(sessionFolder, { recursive: true, force: true });
          console.log("✅ Session terhapus. Silakan restart bot untuk scan ulang.");
          process.exit(1); 
        } catch {}

      } else {
        log.info("🔁 Menghubungkan ulang...");
        Start();
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  // HANDLER PESAN
  sock.ev.on("messages.upsert", async ({ messages }) => {
    if (!isReady || !messages) return;
    const m = messages[0];
    if (!m || !m.message) return;

    try {
      if (Msg && Msg.default) await Msg.default(sock, m, config);
    } catch (err) {
      log.err(`Handler Error: ${err.message}`);
    }
  });

  // HANDLER CALL
  sock.ev.on("call", async (calls) => {
    if (!isReady) return;
    try {
      await CallHandler.code(sock, calls);
    } catch (err) {
      // Silent error
    }
  });

  // HOT RELOAD
  fsSync.watch(path.join(__dirname, "plugins"), (evt, filename) => {
    if (filename && filename.endsWith(".js")) {
      const timestamp = Date.now();
      import(`./handlers/messageHandler.js?v=${timestamp}`)
        .then(r => { Msg = r; log.ok(`[RELOAD] ${filename}`); })
        .catch(e => log.err("Reload gagal: " + e.message));
    }
  });

  process.on("unhandledRejection", e => console.error(e));
  process.on("uncaughtException", e => console.error(e));
}

Start();
