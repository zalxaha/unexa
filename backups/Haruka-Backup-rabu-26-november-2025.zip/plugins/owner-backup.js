import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import os from 'os';
import archiver from 'archiver';
import { fileURLToPath } from 'url';
import { Octokit } from "@octokit/rest";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import cfg from '../config/config.json' assert { type: 'json' };

const GH_TOKEN = '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'; 
const GH_OWNER = 'zalxaha';
const GH_REPO = 'unexa';
const BRANCH = 'main'; 

const octokit = new Octokit({ auth: GH_TOKEN });

const PROJECT_ROOT = path.join(__dirname, '..');
const SESSION_FOLDER_NAME = 'session'; 

const handler = async ({ sock, msg, args, from }) => {
    const sender = msg.key.participant || msg.key.remoteJid;
    
    const authorizedJids = [
        `${cfg.owner}@s.whatsapp.net`,
        ...(cfg.ownerAltJids || [])
    ];
    
    if (!authorizedJids.includes(sender)) {
        return sock.sendMessage(from, { text: "Akses ditolak. Perintah ini hanya untuk Owner." }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '📦', key: msg.key } });

    const today = new Date();
    const dateOptions = { 
        weekday: 'long', 
        day: '2-digit', 
        month: 'long', 
        year: 'numeric' 
    };
    const formattedDate = today.toLocaleDateString('id-ID', dateOptions).replace(/,/g, ''); 
    
    const zipName = `${cfg.botName.replace(/\s/g, '_')}-Backup-${formattedDate.replace(/\s/g, '-')}.zip`;
    const outputPath = path.join(os.tmpdir(), zipName);
    const output = fs.createWriteStream(outputPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    let fileCreated = false;
    let success = false;

    const archivePromise = new Promise((resolve, reject) => {
        output.on('close', resolve);
        archive.on('error', reject);
    });

    try {
        archive.pipe(output);
        fileCreated = true;

        archive.glob('**/*', {
            cwd: PROJECT_ROOT,
            ignore: [
                '**/node_modules/**',
                '**/.npm/**',
                '**/.git/**',
                `**/${SESSION_FOLDER_NAME}/**`, 
                '**/.cache/**', 
                zipName,
                '*.zip',
                '*.log',
            ],
            dot: true 
        });

        const credsPath = path.join(PROJECT_ROOT, SESSION_FOLDER_NAME, 'creds.json');
        try {
            await fsp.access(credsPath);
            archive.file(credsPath, { name: `${SESSION_FOLDER_NAME}/creds.json` });
            console.log("creds.json berhasil ditambahkan.");
        } catch (e) {
            console.warn("creds.json tidak ditemukan atau tidak dapat diakses, melanjutkan tanpa file ini.");
        }

        await archive.finalize();
        await archivePromise;
        success = true;

        await sock.sendMessage(from, { react: { text: '💾', key: msg.key } });

        console.log(`[BACKUP] Mengirim file lokal: ${zipName}`);
        await sock.sendMessage(from, {
            document: { url: outputPath },
            fileName: zipName,
            mimetype: 'application/zip',
            caption: `✅ Backup bot *${cfg.botName}* berhasil dibuat.\n\n⏳ Melanjutkan proses upload ke GitHub...`
        }, { quoted: msg });

        await sock.sendMessage(from, { react: { text: '📤', key: msg.key } });

        const fileContent = await fsp.readFile(outputPath);
        const base64 = fileContent.toString("base64");
        const githubPath = `backups/${zipName}`;
        let fileUrl = '';
        
        console.log(`[BACKUP] Mulai upload ke GitHub: ${zipName}`);

        await octokit.repos.createOrUpdateFileContents({
            owner: GH_OWNER,
            repo: GH_REPO,
            path: githubPath,
            message: `Automated backup: ${zipName}`,
            content: base64,
            branch: BRANCH,
            committer: { name: 'Bot Backup Service', email: 'bot@example.com' }
        });

        fileUrl = `https://raw.githubusercontent.com/${GH_OWNER}/${GH_REPO}/${BRANCH}/${githubPath}`;
        
        console.log(`[BACKUP] Selesai upload. URL: ${fileUrl}`);

        await sock.sendMessage(from, {
            text: `✅ Backup berhasil diupload ke GitHub.\n\n🔗 *URL Download:* ${fileUrl}`
        }, { quoted: msg });

    } catch (e) {
        console.error('[BACKUP PROCESS ERROR]', e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        
        let errorMessage = `❌ Gagal menyelesaikan proses backup.\nDetail: ${e.message}`;
        if (success) {
             errorMessage = `⚠️ Peringatan: Backup berhasil dibuat dan dikirim secara lokal, tetapi gagal diupload ke GitHub.\nDetail: ${e.message}`;
        }

        return sock.sendMessage(from, { text: errorMessage }, { quoted: msg });
    } finally {
        if (fileCreated) {
            try {
                await fsp.unlink(outputPath);
                console.log(`[CLEANUP] File ${zipName} dihapus dari direktori sementara.`);
            } catch (e) {
                console.error(`Gagal menghapus file sementara ${outputPath}:`, e);
            }
        }
    }
};

export default {
    command: ['backup', 'arsip'],
    description: 'Membuat backup seluruh proyek bot dan mengunggahnya ke GitHub (Owner Only)',
    category: 'owner',
    handler,
};