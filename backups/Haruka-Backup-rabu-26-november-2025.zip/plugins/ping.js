export default {
  command: ['ping', 'p', 'bot'],
  description: 'Mengukur kecepatan respons bot (latency).',
  category: 'main',
  handler: async ({ sock, msg, from }) => {
    // 1. Mencatat waktu saat pesan diterima oleh handler
    const startTime = Date.now();
    
    // 2. Mengirim balasan
    const replyText = '⚡ *Mengukur kecepatan...*';
    const sentMsg = await sock.sendMessage(from, { text: replyText }, { quoted: msg });
    
    // 3. Mencatat waktu saat balasan berhasil dikirim
    const endTime = Date.now();
    
    // 4. Menghitung Latency (waktu yang dihabiskan dalam milidetik)
    const latency = endTime - startTime;
    
    // 5. Menyusun teks hasil
    const resultText = `Pong! 🚀\nKecepatan Respon (Latency): *${latency} ms*`;

    // 6. Mengedit pesan balasan yang sudah dikirim dengan hasil akhir
    // Mengedit pesan membutuhkan ID pesan yang dikirim sebelumnya (sentMsg.key)
    await sock.sendMessage(from, { text: resultText, edit: sentMsg.key });
  }
};