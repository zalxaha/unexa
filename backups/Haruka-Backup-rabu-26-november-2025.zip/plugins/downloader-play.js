import fetch from 'node-fetch';
import * as crypto from 'crypto';
import * as fsp from 'fs/promises';
import fs from 'fs';
import * as path from 'path';
import NodeID3 from 'node-id3';
import yts from 'yt-search';

async function downloadAndSave(url, filePath) {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Gagal mengunduh: ${response.statusText}`);
    
    const buffer = await response.buffer();
    await fsp.writeFile(filePath, buffer); 
}

async function embedMetadata(audioPath, imagePath, tags) {
    const imageBuffer = await fsp.readFile(imagePath);
    
    const defaultTags = {
        title: tags.title,
        artist: tags.artist || 'YouTube Downloader',
        image: {
            mime: 'image/jpeg',
            type: { id: 3, name: 'front cover' },
            description: 'Cover Art',
            imageBuffer: imageBuffer
        }
    };
    
    return NodeID3.write(defaultTags, audioPath);
}

class Youtubers {
  
  constructor() {
    this.hex = "C5D58EF67A7584E4A29F6C35BBC4EB12";
  }

  async uint8(hex) {
    const pecahan = hex.match(/[\dA-F]{2}/gi);
    if (!pecahan) throw new Error("Format tidak valid");
    return new Uint8Array(pecahan.map(h => parseInt(h, 16)));
  }

  b64Byte(b64) {
    const bersih = b64.replace(/\s/g, "");
    const biner = Buffer.from(bersih, 'base64');
    return new Uint8Array(biner);
  }

  async key() {
    const raw = await this.uint8(this.hex);
    return crypto.webcrypto.subtle.importKey("raw", raw, { name: "AES-CBC" }, false, ["decrypt"]);
  }

  async Data(base64Terenkripsi) {
    const byteData = this.b64Byte(base64Terenkripsi);
    if (byteData.length < 16) throw new Error("Data terlalu pendek");

    const iv = byteData.slice(0, 16);
    const data = byteData.slice(16);
    const kunci = await this.key();
    const hasil = await crypto.webcrypto.subtle.decrypt({ name: "AES-CBC", iv }, kunci, data);
    const teks = new TextDecoder().decode(new Uint8Array(hasil));
    return JSON.parse(teks);
  }

  async getCDN() {
    const res = await fetch("https://media.savetube.me/api/random-cdn");
    const data = await res.json();
    return data.cdn;
  }

  async infoVideo(linkYoutube) {
    const cdn = await this.getCDN();
    const res = await fetch(`https://${cdn}/v2/info`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: linkYoutube }),
    });

    const hasil = await res.json();
    if (!hasil.status) throw new Error(hasil.message || "Gagal ambil data video");

    const isi = await this.Data(hasil.data);
    return {
      judul: isi.title,
      durasi: isi.durationLabel,
      thumbnail: isi.thumbnail,
      kode: isi.key,
      kualitas: isi.video_formats.map(f => ({
        label: f.label,
        kualitas: f.height,
        default: f.default_selected
      })),
      infoLengkap: isi 
    };
  }

  async getDownloadLink(kodeVideo, kualitas, type) {
    const cdn = await this.getCDN();
    const res = await fetch(`https://${cdn}/download`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        downloadType: kualitas === "128" ? "audio" : type,
        quality: kualitas,
        key: kodeVideo,
      }),
    });

    const json = await res.json();
    if (!json.status) throw new Error(json.message);
    return json.data.downloadUrl;
  }

  async downloadyt(linkYoutube, kualitas, type) {
    try {
      const data = await this.infoVideo(linkYoutube);
      const linkUnduh = await this.getDownloadLink(data.kode, kualitas, type);
      return {
        status: true,
        judul: data.judul,
        kualitasTersedia: data.kualitas,
        thumbnail: data.thumbnail,
        durasi: data.durasi,
        url: linkUnduh,
      };
    } catch (err) {
      return {
        status: false,
        pesan: err.message
      };
    }
  }
}

const handler = async ({ sock, msg, args, from, command }) => {
  const text = args.join(' ');
  
  const tempId = Date.now();
  const audioTempPath = path.join('/tmp', `${tempId}-audio.mp3`); 
  const imageTempPath = path.join('/tmp', `${tempId}-thumb.jpg`);

  if (!text) {
    return sock.sendMessage(from, {
      text: 'Masukkan teks pencarian atau link YouTube.\nContoh: .play mockingbird atau .play https://youtu.be/xyz123'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🔎', key: msg.key } });

  let url;
  let selectedQuality = '128'; 
  const isURL = text.trim().startsWith('http');
  
  try {
    const yt = new Youtubers();
    
    if (!isURL) {
      const results = await yts(text);
      const videos = results.videos;
      
      if (!videos || videos.length === 0) {
        throw new Error('Video tidak ditemukan.');
      }
      
      const firstVideo = videos[0];
      url = firstVideo.url;
      
      await sock.sendMessage(from, { 
        text: `🎶 *Memutar Lagu:* ${firstVideo.title} dari ${firstVideo.author.name}\n🔗 *URL:* ${url}` 
      }, { quoted: msg });

    } else {
      const parts = text.trim().split(' ');
      url = parts[0];
      selectedQuality = parts[1] || '128';
    }

    const data = await yt.infoVideo(url); 
    const result = await yt.downloadyt(url, selectedQuality, 'audio');

    if (!result.status) throw new Error(result.pesan);

    const audioFormats = data.infoLengkap.audio_formats || [];
    const availableQualities = audioFormats.map(f => {
      return `• ${f.label} (Kode: ${f.quality || '128'})`; 
    }).join('\n');

    const captionThumbnail = `*YOUTUBE AUDIO DOWNLOADER*\n\n` +
                             `• *Judul:* ${data.judul}\n` +
                             `• *Durasi:* ${data.durasi}\n\n` +
                             `*Kualitas Audio Tersedia:*\n${availableQualities}\n\n` +
                             `*Mengunduh Kualitas:* ${selectedQuality} (Mengirim 2 Versi Audio)`;

    await sock.sendMessage(from, {
      image: { url: data.thumbnail },
      caption: captionThumbnail
    }, { quoted: msg });

    await sock.sendMessage(from, {
        audio: { url: result.url },
        mimetype: 'audio/mp4', 
        caption: `[1/2] ✅ Audio Langsung Putar (M4A):\n*${data.judul}*`
    }, { quoted: msg });
    
    await downloadAndSave(result.url, audioTempPath);
    
    await downloadAndSave(data.thumbnail, imageTempPath);
    
    await embedMetadata(audioTempPath, imageTempPath, {
        title: data.judul,
        artist: data.infoLengkap.channelName || 'YouTube' 
    });
    
    await sock.sendMessage(from, {
        document: { stream: fs.createReadStream(audioTempPath) }, 
        mimetype: 'audio/mp3', 
        fileName: `${data.judul}.mp3`,
        caption: `[2/2] ✅ File MP3 dengan Sampul Metadata:\n*${data.judul}*`
    }, { quoted: msg });

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (err) {
    console.error(err);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    sock.sendMessage(from, {
      text: `❌ Gagal memproses atau mengunduh audio.\n\n${err.message}`
    }, { quoted: msg });
  } finally {
    try {
        await fsp.unlink(audioTempPath); 
        await fsp.unlink(imageTempPath); 
    } catch (e) {
    }
  }
};

export default {
  command: ['play'],
  description: 'Mencari video YouTube dan mengunduh audio MP3/M4A',
  category: 'Downloader',
  handler,
};