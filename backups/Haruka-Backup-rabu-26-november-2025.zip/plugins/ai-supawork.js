import axios from 'axios';
import fs from 'fs/promises'; // Menggunakan fs/promises untuk async/await
import fsSync from 'fs'; // Menggunakan fs sinkron untuk pengecekan dan penghapusan file sementara
import path from 'path';
import { tmpdir } from 'os';
import Crypto from 'crypto';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';

// Import sharp hanya jika Anda benar-benar membutuhkannya (untuk konversi, tapi di fitur ini tidak dipakai)
// Karena kita hanya butuh download dan save, sharp tidak diperlukan.
// Namun, jika ada kebutuhan format lain, Anda mungkin perlu sharp.
// Untuk kasus ini, kita hapus sharp karena input sudah gambar.
// import sharp from 'sharp'; 

// --- [ BAGIAN 1: FUNGSI UTILITAS UMUM ] ---

const COMMON_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',
  'Accept': 'application/json',
  'sec-ch-ua-platform': '"Android"',
  'authorization': 'null',
  'sec-ch-ua': '"Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
  'sec-ch-ua-mobile': '?1',
  'dnt': '1',
  'content-type': 'application/json',
  'sec-fetch-site': 'same-origin',
  'sec-fetch-mode': 'cors',
  'sec-fetch-dest': 'empty',
  'referer': 'https://supawork.ai/id/nano-banana',
  'accept-language': 'id,en-US;q=0.9,en;q=0.8,ja;q=0.7',
  'priority': 'u=1, i'
};

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

function generateFileName(ext = '') {
  return path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}${ext}`);
}

/**
 * Mengunduh gambar yang di-reply dan menyimpannya sebagai file sementara.
 * @param {object} imageMessage - Objek pesan gambar Baileys.
 * @returns {string} Path ke file gambar sementara.
 */
async function downloadAndSaveImage(imageMessage) {
  const tmpPath = generateFileName('.tmp'); // Ekstensi sementara
  
  try {
    // 1. Unduh konten gambar
    const stream = await downloadContentFromMessage(imageMessage, 'image'); 
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);
    const mediaBuffer = Buffer.concat(chunks);
    
    // 2. Simpan buffer ke file sementara
    await fs.writeFile(tmpPath, mediaBuffer);
    
    return tmpPath; // Mengembalikan path file gambar
    
  } catch (err) {
    // Hapus file sementara jika terjadi error
    if (fsSync.existsSync(tmpPath)) fsSync.unlinkSync(tmpPath);
    throw new Error(`Gagal mengunduh dan menyimpan gambar: ${err.message}`);
  }
}

// --- [ BAGIAN 2: MODUL SUPAWORK (API INTERACTION) ] ---

export const supawork = {
  getPresigned: async () => {
    const config = {
      method: 'GET',
      url: 'https://supawork.ai/supawork/headshot/api/sys/oss/token?f_suffix=png&get_num=3&unsafe=1',
      headers: COMMON_HEADERS
    };

    try {
      const response = await axios.request(config);
      if (response.data && response.data.code === 100000 && response.data.data.length > 0) {
        const urls = response.data.data[0];
        return urls;
      } else {
        throw new Error('Presig url nya ga dapet');
      }
    } catch (error) {
      console.error('Error (getPresigned):', error.response ? error.response.data : error.message);
      throw error;
    }
  },

  upload: async (path) => {
    try {
      const urls = await supawork.getPresigned();
      const fileBuffer = await fs.readFile(path); // Membaca file gambar dari path lokal

      const config = {
        method: 'PUT',
        url: urls.put,
        headers: {
          // Headers spesifik untuk upload
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36',
          'Accept-Encoding': 'gzip, deflate, br, zstd',
          'Content-Type': 'image/png', // Penting: Supawork meminta format ini
          'sec-ch-ua-platform': '"Android"',
          'sec-ch-ua': '"Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
          'DNT': '1',
          'sec-ch-ua-mobile': '?1',
          'Origin': 'https://supawork.ai',
          'Sec-Fetch-Site': 'cross-site',
          'Sec-Fetch-Mode': 'cors',
          'Sec-Fetch-Dest': 'empty',
          'Referer': 'https://supawork.ai/',
          'Accept-Language': 'id,en-US;q=0.9,en;q=0.8,ja;q=0.7',
          'Content-Length': fileBuffer.length
        },
        data: fileBuffer // Menggunakan buffer sebagai data
      };

      const response = await axios.request(config);
      if (response.status === 200) {
        return urls.get; // Mengembalikan URL untuk Generate
      } else {
        throw new Error(`Upload gagal, status: ${response.status}`);
      }
    } catch (error) {
      console.error('Error (upload):', error.response ? error.response.statusText : error.message);
      throw error;
    }
  },

  generate: async (imageUrl, identity, prompt) => {
    const data = JSON.stringify({
      "identity_id": identity,
      "aigc_app_code": "image_to_image_generator",
      "model_code": "google_nano_banana",
      "custom_prompt": prompt,
      "aspect_ratio": "match_input_image",
      "image_urls": [imageUrl], // Menggunakan URL gambar yang sudah diunggah
      "currency_type": "silver"
    });

    const config = {
      method: 'POST',
      url: 'https://supawork.ai/supawork/headshot/api/media/image/generator',
      headers: {
        ...COMMON_HEADERS,
        'origin': 'https://supawork.ai'
      },
      data: data
    };

    try {
      const response = await axios.request(config);
      if (response.data && response.data.code === 100000) {
        return response.data.data;
      } else {
        throw new Error(`Generate Gagal: ${response.data.message || 'Unknown API Error'}`);
      }
    } catch (error) {
      console.error('Error (generate):', error.response ? error.response.data : error.message);
      throw error;
    }
  },

  check: async (identity) => {
    const config = {
      method: 'GET',
      url: `https://supawork.ai/supawork/headshot/api/media/aigc/result/list/v1?page_no=1&page_size=10&identity_id=${identity}`,
      headers: COMMON_HEADERS
    };

    const maxAttempts = 15;
    const pollInterval = 5000; // 5 detik

    for (let i = 0; i < maxAttempts; i++) {
      try {
        const response = await axios.request(config);
        const data = response.data.data;

        if (data && data.list && data.list.length > 0) {
          const mainTask = data.list[0];
          // Status 1 = Selesai
          if (mainTask.status === 1 && mainTask.list && mainTask.list.length > 0) {
            const subTask = mainTask.list[0];
            if (subTask.status === 1 && subTask.url && subTask.url.length > 0) {
              return subTask.url[0]; // Mengembalikan URL hasil generate
            }
          }
        }
        await delay(pollInterval);
      } catch (error) {
        console.error(`Error (check attempt ${i + 1}):`, error.response ? error.response.data : error.message);
        await delay(pollInterval);
      }
    }

    throw new Error('Timeout. Hasil generate tidak tersedia setelah batas waktu.');
  },

  /**
   * Fungsi komposit: Upload, Generate, dan Check Hasil.
   * @param {string} localImagePath - Path file gambar lokal.
   * @param {string} prompt - Prompt untuk AI.
   * @returns {object} Hasil generate.
   */
  create: async (localImagePath, prompt) => {
    let identityId;
    try {
      identityId = Crypto.randomUUID();
      const sUrl = await supawork.upload(localImagePath); // 1. Upload
      await supawork.generate(sUrl, identityId, prompt);  // 2. Generate
      const rUrl = await supawork.check(identityId);      // 3. Check Hasil
      return { success: true, author: 'shannz', result: rUrl };
    } catch (error) {
      console.error(`Error (create):`, error.message);
      return { success: false, author: 'shannz', result: error };
    }
  }
};

// --- [ BAGIAN 3: HANDLER BOT UTAMA ] ---

// ---------------------- supaworkgen (Fitur Utama) ----------------------
async function supaworkgen(sock, msg, from, imageMessage, prompt) {
  let imageFilePath = null;
  let resultUrl = null;
  let success = false;
  
  try {
    // 1. Unduh dan Simpan Gambar lokal
    await sock.sendMessage(from, { text: '⏳ Mengunduh gambar...' }, { quoted: msg });
    imageFilePath = await downloadAndSaveImage(imageMessage);
    
    // 2. Upload dan Generate Gambar via Supawork API
    await sock.sendMessage(from, { text: '⏳ Mengunggah dan memulai proses Generate (Memakan waktu 10-20 detik)...' }, { quoted: msg });
    
    // Panggil fungsi supawork.create menggunakan path file gambar
    const supaworkResult = await supawork.create(imageFilePath, prompt);

    if (supaworkResult.success && supaworkResult.result) {
      resultUrl = supaworkResult.result;
      
      // 3. Kirim Hasil
      await sock.sendMessage(from, { 
        image: { url: resultUrl }, 
        caption: `✅ **Generate Berhasil!**\nPrompt: ${prompt}\n\n[Powered by Supawork AI]`
      }, { quoted: msg });
      
      success = true;
    } else {
      // Menangani error jika supawork.create gagal
      const errorMessage = supaworkResult.result?.message || supaworkResult.result?.toString() || 'Respon API tidak sukses';
      throw new Error(`Supawork Gagal: ${errorMessage}`);
    }

  } catch (err) {
    console.error('[SUPAWORKGEN ERROR]', err);
    await sock.sendMessage(from, { text: `❌ Gagal memproses gambar:\n\n${err.message}` }, { quoted: msg });
  } finally {
    // Hapus file sementara setelah selesai
    if (imageFilePath && fsSync.existsSync(imageFilePath)) {
      await fs.unlink(imageFilePath); // Menggunakan fs/promises.unlink
    }
  }
  return success;
}

// ---------------------- handler utama ----------------------
const handler = async ({ sock, msg, from }) => {
  const body =
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    '';
  
  // Mengambil command dan prompt
  const [cmd, ...args] = body.trim().split(/\s+/).map(s => s.toLowerCase().replace(/^\.|^\//, ''));
  const prompt = args.join(' '); 

  const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  
  // Cek apakah yang di-reply adalah gambar
  const imageMessage = quoted?.imageMessage;
  
  if (cmd !== 'supaworkgen') {
    return; // Abaikan jika bukan command ini
  }
  
  // Cek apakah ada gambar yang direply
  if (!imageMessage) {
    return sock.sendMessage(from, { text: '❌ Reply **gambar** dan sertakan *prompt* untuk di-*generate*.\nContoh: `.supaworkgen a handsome cyborg wearing a tuxedo`' }, { quoted: msg });
  }
  
  // Cek apakah prompt ada
  if (!prompt) {
    return sock.sendMessage(from, { text: '❌ Masukkan *prompt* setelah perintah.\nContoh: `.supaworkgen a beautiful anime girl in futuristic suit`' }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

  let success = false;
  try {
    success = await supaworkgen(sock, msg, from, imageMessage, prompt);

    // Kirim reaksi akhir berdasarkan hasil
    await sock.sendMessage(from, { react: { text: success ? '✅' : '❌', key: msg.key } });
  } catch (err) {
    console.error('[FINAL HANDLER ERROR]', err);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
  }
};

// ---------------------- export default ----------------------
export default {
  command: ['supaworkgen'],
  description: 'Ubah gambar menjadi hasil generate AI Supawork berdasarkan prompt.',
  category: 'AI',
  handler,
};