import fetch from 'node-fetch';

export default {
  command: ['checkweb', 'statusweb', 'webstat'],
  description: 'Memeriksa ketersediaan dan status HTTP dari URL web tertentu.',
  category: 'tools',

  // PASTIKAN ADA 'args' DI SINI
  handler: async ({ sock, msg, from, args }) => { 
    
    // Ambil input langsung dari args (mirip dengan yang dilakukan plugin 'ai')
    const cleanedMessage = args.join(' ').trim(); 

    // Kalau kosong, kasih panduan
    if (!cleanedMessage) {
      const usageText =
        '🚫 *Kesalahan Input!*\n\nAnda harus menyertakan URL yang ingin diuji.\n\nContoh Penggunaan:\n' +
        '`!checkweb google.com`\n' +
        '`!webstat https://example.net/`';
      return sock.sendMessage(from, { text: usageText }, { quoted: msg });
    }

    // Ambil kata pertama (URL)
    let inputUrl = cleanedMessage.split(/\s+/)[0]; 
    
    // --- LOGIKA VALIDASI SAMA SEPERTI PERBAIKAN SEBELUMNYA ---

    // Periksa apakah inputUrl berhasil diekstrak
    if (!inputUrl || inputUrl.length < 2) {
      const invalidUrlText =
        '⚠️ *URL Tidak Valid*\n\nURL yang Anda berikan (`' + inputUrl + '`) tidak dapat diproses.\n\nContoh URL yang benar:\n' +
        '`google.com` atau `https://example.net`';
      return sock.sendMessage(from, { text: invalidUrlText }, { quoted: msg });
    }

    // Tambahkan protokol jika belum ada, dan validasi menggunakan constructor URL
    let urlToValidate = inputUrl;
    if (!/^https?:\/\//i.test(urlToValidate)) {
      urlToValidate = 'https://' + urlToValidate;
    }

    let targetUrl;
    try {
        targetUrl = new URL(urlToValidate).href;
    } catch (e) {
        // Jika pembuatan URL gagal, tangani error
        const invalidUrlText =
            '⚠️ *URL Tidak Valid (Final Check)*\n\nURL yang Anda berikan (`' + inputUrl + '`) tidak dapat diproses.\n\nContoh URL yang benar:\n' +
            '`google.com` atau `https://example.net`';
        return sock.sendMessage(from, { text: invalidUrlText }, { quoted: msg });
    }

    // Kirim pesan awal
    const sentMsg = await sock.sendMessage(
      from,
      { text: `🌐 *Memulai Pemeriksaan URL...*\nTarget: ${targetUrl}` },
      { quoted: msg }
    );
    
    // ... (Sisa logika fetch dan try/catch) ...
    let resultText;
    const startTime = Date.now();

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);

      const response = await fetch(targetUrl, {
        method: 'HEAD',
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      const latency = Date.now() - startTime;
      const status = response.status;
      let statusEmoji, statusDescription;
      if (status >= 200 && status < 300) {
        statusEmoji = '🟢 (Beroperasi Penuh)';
        statusDescription = 'Server berhasil memproses permintaan.';
      } else if (status === 404) {
        statusEmoji = '🟡 (Tidak Ditemukan)';
        statusDescription = 'URL tidak ada atau halaman hilang.';
      } else if (status >= 400 && status < 500) {
        statusEmoji = '🟠 (Kesalahan Klien)';
        statusDescription = 'Permintaan ditolak (URL salah atau butuh autentikasi).';
      } else if (status >= 500) {
        statusEmoji = '🔴 (Kesalahan Server)';
        statusDescription = 'Server mengalami kesalahan internal.';
      } else if (status >= 300 && status < 400) {
        statusEmoji = '🔵 (Pengalihan)';
        statusDescription = 'URL mengalihkan ke alamat lain.';
      } else {
        statusEmoji = '❓ (Status Tidak Diketahui)';
        statusDescription = 'Respons berhasil diterima, tetapi tidak umum.';
      }

      resultText =
        `*-- Laporan Ketersediaan Web --*\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `🏷️ *URL Target:* \`${targetUrl}\`\n\n` +
        `✅ *STATUS:* ${statusEmoji}\n` +
        `   *Deskripsi:* ${statusDescription}\n\n` +
        `🔢 *Kode HTTP:* *${status} ${response.statusText}*\n` +
        `⏱️ *Waktu Respon:* *${latency} ms*`;
    } catch (error) {
      const latency = Date.now() - startTime;
      let errorDescription;

      if (error.name === 'AbortError') {
        errorDescription = '⏳ Timeout: Server tidak merespon dalam 15 detik.';
      } else if (error.message.includes('ECONNREFUSED')) {
        errorDescription = 'Koneksi Ditolak (Firewall atau port tertutup).';
      } else if (error.message.includes('ENOTFOUND')) {
        errorDescription = 'Alamat Tidak Ditemukan (Domain tidak ada/salah ketik).';
      } else {
        errorDescription = `Terjadi Kesalahan: ${error.message}`;
      }

      resultText =
        `*-- Laporan Pemeriksaan Gagal --*\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n` +
        `🏷️ *URL Target:* \`${targetUrl}\`\n\n` +
        `❌ *STATUS:* Koneksi Gagal / Diblokir\n` +
        `   *Kesalahan:* ${errorDescription}\n\n` +
        `❓ *Waktu Kegagalan:* *${latency} ms*`;
    }

    await sock.sendMessage(from, { text: resultText, edit: sentMsg.key });
  },
};