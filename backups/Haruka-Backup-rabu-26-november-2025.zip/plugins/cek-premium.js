import fs from 'fs/promises';

const handler = async ({ sock, msg, sender, db, isPremium, isOwner }) => {
    
    // Ambil data user dari database menggunakan sender JID
    const userDbEntry = db[sender];

    // Pastikan entri user ada (seharusnya selalu ada karena sudah di-handle oleh Msg.js)
    if (!userDbEntry) {
        return msg.reply('⚠️ Data pengguna tidak ditemukan di database. Coba kirimkan command lain terlebih dahulu.');
    }
    
    let replyText = '✨ *STATUS PREMIUM ANDA* ✨\n\n';
    
    // 1. Cek apakah pengguna adalah Owner
    if (isOwner) {
        replyText += '👑 *Status:* OWNER (PREMIUM PERMANEN)\n';
        replyText += '🗓️ *Berakhir:* Tidak Terbatas';
    } 
    // 2. Cek apakah pengguna adalah Premium (non-Owner)
    else if (isPremium) {
        const premiumUntil = userDbEntry.premiumUntil;
        
        if (premiumUntil && premiumUntil > Date.now()) {
            // Konversi waktu berakhir ke tanggal yang mudah dibaca
            const expiryDate = new Date(premiumUntil);
            const formattedDate = expiryDate.toLocaleDateString('id-ID', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                timeZoneName: 'short'
            });
            
            // Hitung sisa waktu
            const remainingTimeMs = premiumUntil - Date.now();
            
            // Konversi ke Hari, Jam, Menit (untuk display yang lebih user-friendly)
            const days = Math.floor(remainingTimeMs / (1000 * 60 * 60 * 24));
            const hours = Math.floor((remainingTimeMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((remainingTimeMs % (1000 * 60 * 60)) / (1000 * 60));

            replyText += '✅ *Status:* PREMIUM\n';
            replyText += `⏳ *Sisa Waktu:* ${days} Hari, ${hours} Jam, ${minutes} Menit\n`;
            replyText += `🗓️ *Berakhir pada:* ${formattedDate}`;

        } else {
            // Fallback jika isPremium true tapi premiumUntil sudah kadaluarsa (seharusnya sudah di-handle oleh Msg.js)
            replyText += '❌ *Status:* REGULER / GUEST\n';
            replyText += '❗ Status premium Anda baru saja berakhir atau terjadi kesalahan data.';
        }
    } 
    // 3. Status Reguler / Guest
    else {
        replyText += '❌ *Status:* REGULER / GUEST\n';
        replyText += '✨ *Kelebihan:* Anda dapat menggunakan command publik.\n';
        replyText += `💎 *Upgrade:* Gunakan command ${process.env.PREFIX || '.'}beli-premium untuk melihat penawaran!`;
    }

    // Kirim balasan status kepada pengguna
    msg.reply(replyText);
};

export default {
    command: ['checkprem', 'premiumstatus', 'myprem'],
    handler: handler,
    isOwner: false,
    isPremium: false,
    description: 'Mengecek status premium pengguna dan tanggal berakhirnya.'
};