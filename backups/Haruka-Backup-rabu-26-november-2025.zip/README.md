# CJS WhatsApp Bot Base

A modular WhatsApp bot base using CommonJS and [Baileys](https://github.com/WhiskeySockets/Baileys).

## Features
- Modular plugin system (drop JS files in `/plugins/`)
- Auto-reconnect, session storage
- QR code login in terminal
- Colored logs with `chalk`
- Command handler with prefix (default: `!`)
- Sample plugin: `!ping` replies with `pong!`
- Helper utilities: logger, time/date, media sender

## Folder Structure
```
Bot - CJS/
  ├── config/
  │   └── config.json
  ├── handlers/
  │   └── messageHandler.js
  ├── lib/
  │   ├── logger.js
  │   ├── time.js
  │   └── sendMedia.js
  ├── media/
  ├── plugins/
  │   └── ping.js
  ├── session/
  └── index.js
```

## Setup
1. Install dependencies:
   ```sh
   npm install
   ```
2. Edit `config/config.json` for your bot name, prefix, and owner number.
3. Start the bot:
   ```sh
   node index.js
   ```
4. Scan the QR code with WhatsApp.

## Adding Plugins
- Drop a JS file in `/plugins/` exporting:
  ```js
  module.exports = {
    command: 'yourcommand',
    description: 'What it does',
    category: 'Category',
    handler: async ({ sock, msg, args, from, pushName }) => {
      // Your code
    }
  }
  ```

## License
MIT 