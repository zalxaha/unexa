import { createRequire } from 'module';
import {
    default as makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    jidNormalizedUser,
    getContentType
} from '@whiskeysockets/baileys';
import pino from 'pino';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import NodeCache from 'node-cache';
import chalk from 'chalk';

const require = createRequire(import.meta.url);
const { hydratedTemplate } = require('baileys_helpers');

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const JADIBOT_DIR = path.join(__dirname, '../jadibots_sessions');

global.jadibots = global.jadibots || new Map();

let MsgHandler = null;
setTimeout(async () => {
    try {
        const handlerModule = await import('../handler.js');
        MsgHandler = handlerModule.default;
    } catch (e) {
        console.error('❌ Gagal meload MsgHandler:', e);
    }
}, 3000);

export async function startJadibot(targetNumber, mainSock = null, m = null) {
    if (global.jadibots.has(targetNumber)) return;

    const sessionPath = path.join(JADIBOT_DIR, targetNumber);
    try { await fs.mkdir(sessionPath, { recursive: true }); } catch {}

    const msgRetryCounterCache = new NodeCache();
    const simpleMessageStore = new Map(); 
    let codeRequested = false; 

    async function connect() {
        const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
        const { version } = await fetchLatestBaileysVersion();
        
        const jidBot = makeWASocket({
            version,
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" })),
            },
            logger: pino({ level: "silent" }),
            printQRInTerminal: false, 
            syncFullHistory: false, 
            generateHighQualityLinkPreview: true,
            markOnlineOnConnect: true,
            browser: ["Ubuntu", "Chrome", "20.0.04"],
            connectTimeoutMs: 60000,
            retryRequestDelayMs: 2000,
            msgRetryCounterCache,
            getMessage: async (key) => {
                const msgId = key.id;
                const cached = simpleMessageStore.get(msgId);
                if (cached) return cached.message;
                return undefined;
            }
        });

        jidBot.decodeJid = (jid) => {
            if (!jid) return jid;
            if (/:\d+@/gi.test(jid)) return jidNormalizedUser(jid);
            return jid;
        };

        jidBot.decodeLid = async (lid) => {
            if (!lid || !lid.endsWith('@lid')) return jidBot.decodeJid(lid);
            try {
                const key = jidBot.signalRepository?.lidMapping;
                if (key) {
                    const mapping = await key.getPNForLID(lid);
                    if (mapping) return jidBot.decodeJid(mapping);
                }
                return jidBot.decodeJid(lid);
            } catch (e) {
                return jidBot.decodeJid(lid);
            }
        };

        if (!jidBot.authState.creds.registered && !codeRequested && mainSock) {
            codeRequested = true;
            setTimeout(async () => {
                try {
                    let code = await jidBot.requestPairingCode(targetNumber);
                    code = code?.match(/.{1,4}/g)?.join('-') || code;
                    
                    const targetJid = `${targetNumber}@s.whatsapp.net`;
                    
                    await hydratedTemplate(
                        mainSock,
                        targetJid,
                        {
                            title: "🤖 *TAUTAN PERANGKAT JADIBOT*",
                            text: `Halo! Ini adalah kode tautan perangkat Jadibot kamu.\n\nSilakan klik tombol *Salin Kode* di bawah ini dan tempelkan ke notifikasi Tautkan Perangkat WhatsApp kamu.`,
                            footer: `Developed by Unixity`,
                            interactiveButtons: [
                                {
                                    name: 'cta_copy',
                                    buttonParamsJson: JSON.stringify({
                                        display_text: '📋 Salin Kode Pairing',
                                        copy_code: code
                                    })
                                }
                            ]
                        },
                        {} 
                    );
                    
                    if (m) await m.reply(`✅ Kode pairing berhasil dikirim ke nomor *${targetNumber}*.\nSilakan cek chat pribadi dari bot utama!`);

                } catch (err) {
                    if (m) await m.reply(`❌ Gagal request pairing code: ${err.message}`);
                    try { await fs.rm(sessionPath, { recursive: true, force: true }); } catch {}
                }
            }, 3000);
        }

        jidBot.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect } = update;
            
            if (connection === 'open') {
                global.jadibots.set(targetNumber, jidBot);
                console.log(chalk.green(`✅ [JADIBOT] ${targetNumber} Connected & Ready!`));
                
                try { await jidBot.sendPresenceUpdate('available'); } catch {}
                
                if (mainSock && codeRequested) {
                    await mainSock.sendMessage(`${targetNumber}@s.whatsapp.net`, { text: '✅ Selesai! Jadibot kamu sekarang aktif dan siap merespon perintah.' }).catch(()=>{});
                }
            }
            
            if (connection === 'close') {
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                if (statusCode === DisconnectReason.loggedOut || statusCode === 401 || statusCode === 403) {
                    global.jadibots.delete(targetNumber);
                    try { await fs.rm(sessionPath, { recursive: true, force: true }); } catch {}
                    console.log(chalk.red(`❌ [JADIBOT] ${targetNumber} Logged Out / Berhenti Berfungsi.`));
                } else {
                    console.log(chalk.yellow(`🔄 [JADIBOT] ${targetNumber} Reconnecting in 5s...`));
                    setTimeout(connect, 5000); 
                }
            }
        });

        jidBot.ev.on('creds.update', saveCreds);

        jidBot.ev.on("messages.upsert", async ({ messages, type }) => {
            if (type !== 'notify') return;

            for (const msg of messages) {
                try {
                    if (!msg.message || !msg.key) continue;

                    if (msg.key.id) {
                        simpleMessageStore.set(msg.key.id, {
                            message: msg.message,
                            timestamp: Date.now()
                        });
                    }

                    if (msg.key.fromMe) continue;
                    if (msg.key.remoteJid === "status@broadcast") continue;

                    let mContent = msg.message;
                    if (mContent.ephemeralMessage) mContent = mContent.ephemeralMessage.message;
                    if (mContent.viewOnceMessageV2) mContent = mContent.viewOnceMessageV2.message;
                    else if (mContent.viewOnceMessage) mContent = mContent.viewOnceMessage.message;
                    msg.message = mContent;

                    const msgType = getContentType(mContent);
                    const ignoreTypes = ['protocolMessage', 'senderKeyDistributionMessage', 'messageContextInfo', 'reactionMessage', 'pollUpdateMessage', 'keepInChatMessage'];
                    if (!msgType || ignoreTypes.includes(msgType)) continue;

                    const from = msg.key.remoteJid;
                    const isGroup = from.endsWith('@g.us');
                    let senderRaw = isGroup ? (msg.key.participant || from) : from;
                    if (isGroup && msg.key.participantPn) senderRaw = msg.key.participantPn;

                    let sender = senderRaw;
                    if (senderRaw.endsWith('@lid')) {
                        sender = await jidBot.decodeLid(senderRaw);
                    }
                    msg.sender = jidNormalizedUser(sender);

                    const pushName = msg.pushName || "Unknown";
                    let body = '';
                    if (msgType === 'conversation') body = mContent.conversation;
                    else if (msgType === 'imageMessage') body = mContent.imageMessage.caption;
                    else if (msgType === 'videoMessage') body = mContent.videoMessage.caption;
                    else if (msgType === 'extendedTextMessage') body = mContent.extendedTextMessage.text;

                    if (typeof body === 'string' && body.length > 0) {
                        const timeStr = chalk.bgBlack.white(`⏰ ${new Date().toLocaleTimeString()}`);
                        const ctxStr = isGroup ? chalk.magenta(`[Group]`) : chalk.blue(`[Private]`);
                        console.log(`${timeStr} ${chalk.bgBlue.white(`[JADIBOT ${targetNumber}]`)} ${chalk.cyan(`[${msgType}]`)} ${ctxStr} ${chalk.green(pushName)} : ${chalk.white(body.substring(0, 50).replace(/\n/g, ' '))}`);
                    }

                    if (msg.messageTimestamp && (Date.now() - (msg.messageTimestamp * 1000)) > 120000) continue;

                    if (MsgHandler) {
                        MsgHandler(jidBot, msg).catch(e => {
                            console.error(`❌ Jadibot Handler Error [${targetNumber}]:`, e);
                        });
                    }

                } catch (e) {
                    console.error("Error processing Jadibot msg:", e);
                }
            }
        });
    }

    connect();
}

export default {
    command: ['jadibot', 'listjadibot', 'stopjadibot', 'hapusjadibot'],
    category: 'Sistem',
    isOwner: false,

    handler: async ({ 
        sock, msg, args, command, sender, reply, sendReact, isOwner 
    }) => {
        
        try { await fs.access(JADIBOT_DIR); } catch { await fs.mkdir(JADIBOT_DIR, { recursive: true }); }

        if (command === 'jadibot') {
            if (!args[0]) return reply('❌ Masukkan nomor WhatsApp target!\n\n*Contoh:* .jadibot 62838xxxx');
            
            let targetNumber = args[0].replace(/[^0-9]/g, '');
            if (targetNumber.startsWith('0')) targetNumber = '62' + targetNumber.substring(1);

            if (global.jadibots.has(targetNumber)) {
                return reply(`⚠️ Nomor ${targetNumber} sudah menjadi bot dan sedang aktif!`);
            }

            await sendReact('⏳');
            startJadibot(targetNumber, sock, msg);
        }
        
        else if (command === 'listjadibot') {
            if (global.jadibots.size === 0) return reply('📭 Belum ada pengguna yang menjadi jadibot saat ini.');
            
            let txt = '🤖 *Daftar Jadibot Aktif:*\n\n';
            let i = 1;
            for (const [num, jidBot] of global.jadibots.entries()) {
                txt += `${i}. wa.me/${num}\n`;
                i++;
            }
            txt += `\n*Total:* ${global.jadibots.size} Jadibot`;
            
            await reply(txt);
        }

        else if (command === 'stopjadibot') {
            if (!isOwner) return reply('❌ Perintah ini khusus Owner!');
            if (!args[0]) return reply('❌ Masukkan nomor jadibot yang ingin distop!\n\n*Contoh:* .stopjadibot 62838xxxx');
            
            let targetNumber = args[0].replace(/[^0-9]/g, '');
            if (targetNumber.startsWith('0')) targetNumber = '62' + targetNumber.substring(1);

            if (!global.jadibots.has(targetNumber)) return reply(`⚠️ Nomor ${targetNumber} tidak aktif.`);
            
            await sendReact('⏳');
            const jidBot = global.jadibots.get(targetNumber);
            
            if (jidBot) {
                try {
                    await jidBot.logout();
                } catch {
                    if (jidBot.ws && jidBot.ws.close) {
                        jidBot.ws.close();
                    }
                }
            }
            
            global.jadibots.delete(targetNumber);
            const sessionPath = path.join(JADIBOT_DIR, targetNumber);
            try { await fs.rm(sessionPath, { recursive: true, force: true }); } catch {}

            await sendReact('✅');
            await reply(`✅ Sesi jadibot untuk nomor *${targetNumber}* berhasil dihentikan.`);
        }

        else if (command === 'hapusjadibot') {
            if (!isOwner) return reply('❌ Perintah ini khusus Owner!');
            await sendReact('⏳');

            for (const [num, bot] of global.jadibots.entries()) {
                if (bot) {
                    try {
                        await bot.logout();
                    } catch {
                        if (bot.ws && bot.ws.close) {
                            bot.ws.close();
                        }
                    }
                }
            }
            global.jadibots.clear(); 

            try {
                await fs.rm(JADIBOT_DIR, { recursive: true, force: true });
                await fs.mkdir(JADIBOT_DIR, { recursive: true });
                await sendReact('✅');
                await reply('🗑️ *Semua sesi Jadibot dan isi foldernya berhasil dibersihkan!*');
            } catch (err) {
                await reply(`❌ Gagal menghapus folder: ${err.message}`);
            }
        }
    }
};