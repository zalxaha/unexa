export default {
    command: ['hit', 'topcmd', 'dashboard', 'stats'],
    category: 'Info',
    description: 'Melihat statistik penggunaan command bot',
    
    isOwner: false,
    isAdmin: false, 
    isBotAdmin: false,
    isPremium: false,

    handler: async ({ reply, setting, sendReact }) => {
        const cmdStats = setting.commandHits || {};
        const totalCommands = Object.keys(cmdStats).length;

        if (totalCommands === 0) {
            return reply('⚠️ Belum ada data penggunaan command.');
        }

        await sendReact('📊');

        // 1. Sortir Data
        const sortedStats = Object.entries(cmdStats)
            .sort((a, b) => b[1] - a[1]) 
            .slice(0, 10); 

        // 2. Hitung Total Global
        const totalHits = Object.values(cmdStats).reduce((acc, curr) => acc + curr, 0);

        // 3. Fungsi Progress Bar Sederhana
        const createBar = (count, total) => {
            const percent = (count / total) * 100;
            // Panjang bar 10 balok
            const filled = Math.floor(percent / 10); 
            const empty = 10 - filled;
            return '█'.repeat(filled) + '░'.repeat(empty);
        }

        // 4. Susun Tampilan Baru
        let text = `╭───「 📊 *HIT STATISTIC* 」\n`;
        text += `│\n`;
        text += `│ 📂 *Cmd Used* : ${totalCommands}\n`;
        text += `│ 💥 *Total Hits* : ${totalHits}\n`;
        text += `│\n`;
        text += `╰────────────────────\n`;
        text += `╭───「 *MOST POPULAR* 」\n`;

        sortedStats.forEach((item, index) => {
            const cmdName = item[0];
            const count = item[1];
            const percentage = ((count / totalHits) * 100).toFixed(0); // Ambil % bulat

            let rankIcon = '▫️';
            if (index === 0) rankIcon = '🥇';
            if (index === 1) rankIcon = '🥈';
            if (index === 2) rankIcon = '🥉';

            text += `│\n`;
            text += `│ ${rankIcon} *${cmdName}*\n`;
            // Tampilan: [████░░░░░░] 9 (64%)
            text += `│ ${createBar(count, totalHits)} ${count} (${percentage}%)\n`;
        });

        text += `│\n`;
        text += `╰────────────────────\n`;
        text += `_🟢 Realtime Update_`;

        await reply(text);
    }
};