import { disabledFeatures } from '../lib/database.js'; // Pastikan path ini sesuai dengan struktur foldermu
import { pluginsCache } from '../lib/plugins.js';

export default {
    command: ['listdisable', 'disabled', 'cekdisable'],
    category: 'Owner',
    isOwner: true,      // Sebaiknya hanya Owner yang bisa melihat ini
    isAdmin: false,
    isBotAdmin: false,
    isPremium: false,

    handler: async ({ 
        sock, msg, args, command, sender, reply, sendReact 
    }) => {
        // 1. Ambil semua key dari disabledFeatures (yang nilainya true)
        const disabledList = Object.keys(disabledFeatures);

        if (disabledList.length === 0) {
            return reply('✅ *Aman!* Tidak ada fitur atau plugin yang sedang dinonaktifkan.');
        }

        await sendReact('🔍');

        // 2. Grouping berdasarkan Nama File
        // Struktur: { 'nama-file.js': ['cmd1', 'cmd2'], 'lainnya': ['cmd3'] }
        const grouped = {};

        disabledList.forEach(cmd => {
            const plugin = pluginsCache[cmd];
            
            // Jika plugin ditemukan di cache, ambil nama filenya.
            // Jika tidak (misal file sudah dihapus tapi database masih nyangkut), masukkan ke 'Unknown / System'.
            const filename = plugin && plugin.file ? plugin.file : '⚠️ Unknown / System';

            if (!grouped[filename]) {
                grouped[filename] = [];
            }
            grouped[filename].push(cmd);
        });

        // 3. Menyusun Pesan Output agar Rapi
        let text = `🚫 *DAFTAR PLUGIN NONAKTIF* 🚫\n`;
        text += `Total Command Mati: ${disabledList.length}\n\n`;

        // Loop setiap group file
        for (const [filename, commands] of Object.entries(grouped)) {
            text += `📂 *File:* ${filename}\n`;
            
            // Loop command di dalam file tersebut
            commands.forEach((cmd, index) => {
                const isLast = index === commands.length - 1;
                const tree = isLast ? '└' : '├';
                text += `${tree} ❌ ${cmd}\n`;
            });
            
            text += `\n`; // Spasi antar file
        }

        text += `_Gunakan .enable <command> untuk mengaktifkan kembali._`;

        // 4. Kirim
        await reply(text);
    }
};