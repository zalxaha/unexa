import { aio } from 'btch-downloader';

export default {
  command: ['dl', 'dwn', 'download'],
  description: 'All-in-One Downloader (Debug Mode)',
  category: 'Downloader',
  handler: async ({ sock, msg, args, from }) => {
    const text = args.join(' ').trim();
    
    if (!text) {
      return sock.sendMessage(from, {
        text: '📌 Masukkan link media untuk dicek JSON-nya.'
      }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });

    try {
      // Panggil API
      const data = await aio(text);

      // 1. LOG KE TERMINAL/CONSOLE (Agar bisa dilihat di panel)
      console.log('--- [DEBUG AIO JSON] ---');
      console.log(JSON.stringify(data, null, 2));
      console.log('------------------------');

      // 2. KIRIM HASIL JSON KE WA
      // Kita bungkus dengan ``` agar rapi
      await sock.sendMessage(from, { 
        text: `🔍 *DEBUG RESULT BTCH*\n\n\`\`\`${JSON.stringify(data, null, 2)}\`\`\`` 
      }, { quoted: msg });

      // Coba lakukan parsing sederhana (Optional, hanya untuk tes)
      // Jika JSON keluar tapi download gagal, kita tahu struktur path-nya salah
      const url = data.url || data.result?.url || data.medias?.[0]?.url;
      
      if(url) {
          await sock.sendMessage(from, { text: `✅ URL Terdeteksi pada path otomatis: ${url}` }, { quoted: msg });
      } else {
          await sock.sendMessage(from, { text: `⚠️ URL tidak ditemukan pada path standar (data.url / data.result.url). Silakan cek JSON di atas.` }, { quoted: msg });
      }

    } catch (e) {
      console.error(e);
      await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
      return sock.sendMessage(from, {
        text: `❌ Error Fetching: ${e.message}`
      }, { quoted: msg });
    }
  }
};