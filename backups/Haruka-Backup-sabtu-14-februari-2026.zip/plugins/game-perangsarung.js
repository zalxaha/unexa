import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { jidNormalizedUser } from '@whiskeysockets/baileys'; 

// --- [ 1. SETUP PATH & DATABASE ] ---

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const psDataFile = path.join(__dirname, '../data/perangSarung.json');

let psDb = {};
let isSaving = false;
const commandCooldown = new Map();
const challenges = new Map(); 

// Load Database Game
async function loadPsData() {
    try {
        await fs.mkdir(path.dirname(psDataFile), { recursive: true });
        try { await fs.access(psDataFile); } catch {
            await fs.writeFile(psDataFile, JSON.stringify({}, null, 2), 'utf8');
            psDb = {}; return;
        }
        const content = await fs.readFile(psDataFile, 'utf8');
        psDb = content.trim().length > 0 ? JSON.parse(content) : {};
    } catch (e) {
        console.error("[SARUNG DB ERROR]", e);
        psDb = {};
    }
}

async function savePsData() {
    if (isSaving) return;
    isSaving = true;
    try {
        const tempFile = psDataFile + '.tmp';
        await fs.writeFile(tempFile, JSON.stringify(psDb, null, 2), 'utf8');
        await fs.rename(tempFile, psDataFile);
    } catch (e) { console.error("[SARUNG SAVE ERROR]", e); } 
    finally { isSaving = false; }
}

(async () => { try { await loadPsData(); } catch (e) {} })();


// --- [ 2. HELPER VITAL: FIND REAL JID ] ---
// Ini fungsi kuncinya, mengadopsi logika mapTargetJid dari referensi Anda
function findRealJid(targetJid, globalDb) {
    // 1. Jika JID target langsung ketemu sebagai Key Utama (Nomor HP), return langsung
    if (globalDb[targetJid]) return targetJid;

    // 2. Jika tidak, cari di dalam daftar altJids milik semua user
    for (const mainJid in globalDb) {
        const user = globalDb[mainJid];
        // Cek apakah targetJid ada di dalam array altJids user ini
        if (user.altJids && Array.isArray(user.altJids) && user.altJids.includes(targetJid)) {
            return mainJid; // KETEMU! Kembalikan JID Utama (Dompet Asli)
        }
    }

    // 3. Jika benar-benar tidak ada, kembalikan JID awal (berarti user baru)
    return targetJid;
}

function formatRupiah(number) {
    return 'Rp ' + number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

function initGameUser(id) {
    if (!psDb[id]) {
        psDb[id] = { equipped: 'kain_perca', inventory: ['kain_perca'], level: 1, wins: 0, loses: 0 };
    }
}


// --- [ 3. KATALOG SARUNG & STATS ] ---

const SARUNG_LIST = {
    'kain_perca': { name: 'Kain Perca', price: 0, atk: 10, hp: 100, spd: 50, acc: 90, crit: 5, desc: 'Sarung gratisan.' },
    'gajah_duduk': { name: 'Gajah Duduk', price: 10000, atk: 25, hp: 200, spd: 40, acc: 95, crit: 10, desc: 'Klasik & Nyaman.' },
    'wadimor': { name: 'Wadimor', price: 25000, atk: 30, hp: 150, spd: 85, acc: 90, crit: 15, desc: 'Speed Tinggi.' },
    'atlas': { name: 'Atlas', price: 40000, atk: 35, hp: 350, spd: 30, acc: 85, crit: 10, desc: 'Tebal & Kuat.' },
    'sapphire': { name: 'Sapphire', price: 60000, atk: 45, hp: 200, spd: 60, acc: 90, crit: 25, desc: 'Crit Tinggi.' },
    'mangga': { name: 'Mangga', price: 50000, atk: 40, hp: 220, spd: 55, acc: 88, crit: 12, desc: 'Motif Segar.' },
    'lamiri': { name: 'Lamiri Sutra', price: 150000, atk: 60, hp: 180, spd: 95, acc: 95, crit: 20, desc: 'Halus Licin.' },
    'bhs': { name: 'B.H.S Masterpiece', price: 500000, atk: 85, hp: 300, spd: 50, acc: 100, crit: 30, desc: 'Sarung Sultan.' },
    'donggala': { name: 'Donggala', price: 120000, atk: 55, hp: 250, spd: 45, acc: 85, crit: 40, desc: 'Tenun Asli.' },
    'samarinda': { name: 'Samarinda', price: 90000, atk: 50, hp: 400, spd: 20, acc: 80, crit: 10, desc: 'Kokoh.' },
    'goyor': { name: 'Sarung Goyor', price: 75000, atk: 35, hp: 200, spd: 80, acc: 70, crit: 15, desc: 'Lentur.' },
    'batik_pekalongan': { name: 'Batik Tulis', price: 200000, atk: 65, hp: 250, spd: 60, acc: 90, crit: 15, desc: 'Seni Tinggi.' },
    'ketjubung': { name: 'Ketjubung', price: 300000, atk: 75, hp: 280, spd: 70, acc: 92, crit: 20, desc: 'Legendaris.' },
    'terpal_lele': { name: 'Terpal Pecel Lele', price: 15000, atk: 15, hp: 500, spd: 10, acc: 60, crit: 50, desc: 'Bau Amis.' },
    'karpet_masjid': { name: 'Gulungan Karpet', price: 1000000, atk: 250, hp: 600, spd: 5, acc: 35, crit: 5, desc: 'ONE HIT KILL.' }
};

function getStats(id) {
    initGameUser(id);
    const user = psDb[id];
    if (!SARUNG_LIST[user.equipped]) user.equipped = 'kain_perca';
    
    const base = SARUNG_LIST[user.equipped];
    const lvl = user.level;
    const multiplier = 1 + ((lvl - 1) * 0.1);

    return {
        name: base.name,
        atk: Math.floor(base.atk * multiplier),
        hp: Math.floor(base.hp * multiplier),
        spd: base.spd, acc: base.acc, crit: base.crit
    };
}


// --- [ 4. BATTLE ENGINE ] ---

async function startBattle(sock, chatID, p1Raw, p2Raw, betAmount, dbGlobal, saveDbGlobal) {
    // RESOLVE REAL JID (Untuk ambil uang & update stats)
    // Pastikan kita bertransaksi dengan JID UTAMA
    const realP1 = findRealJid(p1Raw, dbGlobal);
    const realP2 = findRealJid(p2Raw, dbGlobal);

    // Ambil stats berdasarkan ID Game (bisa ID asli atau LID, terserah, yg penting konsisten di psDb)
    // Disini kita pakai ID asli biar rapi
    const s1 = getStats(realP1);
    const s2 = getStats(realP2);
    
    let hp1 = s1.hp, hp2 = s2.hp;
    const name1 = `@${realP1.split('@')[0]}`;
    const name2 = `@${realP2.split('@')[0]}`;

    let log = `⚔️ *PERANG SARUNG DIMULAI!* ⚔️\n💰 Taruhan: ${formatRupiah(betAmount)}\n\n`;
    log += `🥊 ${name1} (${s1.name})\n      VS\n🥊 ${name2} (${s2.name})\n\n------------------------------\n`;

    let round = 1;
    let winnerRaw = null;

    while (hp1 > 0 && hp2 > 0 && round <= 10) {
        log += `*Ronde ${round}*\n`;
        const p1First = s1.spd >= s2.spd;
        const attackers = p1First ? [s1, s2] : [s2, s1];
        const names     = p1First ? [name1, name2] : [name2, name1];

        for (let i = 0; i < 2; i++) {
            if (hp1 <= 0 || hp2 <= 0) break;
            const atkStat = attackers[i];
            const attackerName = names[i];
            
            if (Math.random() * 100 > atkStat.acc) {
                log += `💨 ${attackerName} menyabet tapi *MELESET*!\n`;
                continue;
            }
            let damage = atkStat.atk;
            let msgAtk = "";
            if (Math.random() * 100 < atkStat.crit) {
                damage = Math.floor(damage * 1.5);
                msgAtk = "💥 *CRITICAL!* ";
            }
            damage = Math.floor(damage * (0.9 + Math.random() * 0.2));

            if (i === 0) { if (p1First) hp2 -= damage; else hp1 -= damage; } 
            else { if (p1First) hp1 -= damage; else hp2 -= damage; }

            log += `${msgAtk}🗡️ ${attackerName} deal *${damage}* dmg.\n`;
        }
        log += `\n`; round++;
    }

    if (hp1 <= 0) winnerRaw = realP2;
    else if (hp2 <= 0) winnerRaw = realP1;
    else winnerRaw = (hp1 > hp2) ? realP1 : realP2;

    const loserRaw = (winnerRaw === realP1) ? realP2 : realP1;
    
    // TRANSAKSI UANG (Gunakan Real JID yang sudah di-resolve)
    if (dbGlobal[loserRaw]) dbGlobal[loserRaw].money = Math.max(0, (dbGlobal[loserRaw].money || 0) - betAmount);
    if (dbGlobal[winnerRaw]) dbGlobal[winnerRaw].money = (dbGlobal[winnerRaw].money || 0) + betAmount;
    
    // UPDATE STATS (Local DB) - Gunakan Real JID
    initGameUser(winnerRaw);
    initGameUser(loserRaw);
    psDb[winnerRaw].wins += 1; 
    psDb[loserRaw].loses += 1;
    
    saveDbGlobal(); savePsData();

    log += `------------------------------\n🏆 *WINNER:* @${winnerRaw.split('@')[0]}\n💸 *${formatRupiah(betAmount)}* berhasil direbut!`;
    await sock.sendMessage(chatID, { text: log, mentions: [realP1, realP2] });
}


// --- [ 5. HANDLER UTAMA ] ---

const handler = async ({ sock, msg, args, command, sender, db, saveDatabase }) => {
    if (!sender) return;
    const chatID = msg.key.remoteJid;
    
    // Cari ID Asli Pengirim (jika pakai LID)
    const realSender = findRealJid(sender, db); 
    
    // Init User di Game DB
    initGameUser(realSender); 
    
    const subCmd = args[0]?.toLowerCase();

    // ===================================
    // 1. INFO STATS
    // ===================================
    if (!subCmd || subCmd === 'info' || subCmd === 'stats') {
        const stats = getStats(realSender);
        const myData = psDb[realSender];
        let text = `╭───「 🕌 *STATUS PERANG SARUNG* 」\n│ 👤 Player: @${realSender.split('@')[0]}\n│ 🧣 Sarung: *${stats.name}*\n│ 🔼 Level : ${myData.level}\n│ 🏆 W/L   : ${myData.wins} / ${myData.loses}\n│\n├──「 *STATS* 」\n│ ⚔️ Atk: ${stats.atk} | ❤️ HP: ${stats.hp}\n│ ⚡ Spd: ${stats.spd} | 🎯 Acc: ${stats.acc}%\n╰─────────────────────`;
        return sock.sendMessage(chatID, { text: text, mentions: [realSender] }, { quoted: msg });
    }

    // ===================================
    // 2. SHOP & BUY
    // ===================================
    if (subCmd === 'shop' || subCmd === 'toko') {
        let text = `╭───「 🛒 *TOKO SARUNG WADIMOR* 」\n│ Uangmu: ${formatRupiah(db[realSender]?.money || 0)}\n│\n`;
        for (const [key, item] of Object.entries(SARUNG_LIST)) {
            const isOwned = psDb[realSender].inventory.includes(key) ? '✅' : '';
            text += `│ • *${item.name}* ${isOwned}\n│   Harga: ${formatRupiah(item.price)}\n│   ⚔️${item.atk} ❤️${item.hp} ⚡${item.spd}\n│   Kode: *.sarung buy ${key}*\n│\n`;
        }
        text += `╰─────────────────────`;
        return msg.reply(text);
    }

    if (subCmd === 'buy') {
        const itemKey = args[1]?.toLowerCase();
        if (!itemKey || !SARUNG_LIST[itemKey]) return msg.reply(`❌ Kode sarung salah! Cek *.sarung shop*`);
        
        if (psDb[realSender].inventory.includes(itemKey)) {
            psDb[realSender].equipped = itemKey; await savePsData();
            return msg.reply(`✅ Sudah punya. Otomatis dipakai.`);
        }
        if ((db[realSender]?.money || 0) < SARUNG_LIST[itemKey].price) return msg.reply(`💸 Uang kurang!`);

        db[realSender].money -= SARUNG_LIST[itemKey].price; saveDatabase();
        psDb[realSender].inventory.push(itemKey); 
        psDb[realSender].equipped = itemKey; 
        await savePsData();
        return msg.reply(`✅ Terbeli: *${SARUNG_LIST[itemKey].name}*`);
    }

    // ===================================
    // 3. UPGRADE & EQUIP
    // ===================================
    if (subCmd === 'equip' || subCmd === 'pakai') {
        const itemKey = args[1]?.toLowerCase();
        if (!itemKey || !psDb[realSender].inventory.includes(itemKey)) return msg.reply(`❌ Belum punya.`);
        psDb[realSender].equipped = itemKey; await savePsData();
        return msg.reply(`✅ Memakai: *${SARUNG_LIST[itemKey].name}*`);
    }

    if (subCmd === 'upgrade') {
        const lvl = psDb[realSender].level; const cost = lvl * 15000;
        if (args[1] !== 'confirm') return msg.reply(`🛠️ *UPGRADE Lv.${lvl} ➔ ${lvl+1}*\nBiaya: ${formatRupiah(cost)}\nKetik: *.sarung upgrade confirm*`);
        if ((db[realSender]?.money || 0) < cost) return msg.reply(`💸 Uang kurang.`);
        db[realSender].money -= cost; saveDatabase();
        psDb[realSender].level += 1; await savePsData();
        return msg.reply(`🔥 Upgrade sukses! Level ${lvl+1}`);
    }

    // ===================================
    // 4. BATTLE (FIGHT) - MAPPING LOGIC APPLIED
    // ===================================
    if (subCmd === 'fight' || subCmd === 'serang') {
        const rawTarget = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        let bet = parseInt(args[args.length - 1]);
        if (isNaN(bet)) bet = 10000;

        if (!rawTarget) return msg.reply(`❌ Tag lawan! Contoh: *.sarung fight @tag 10000*`);
        
        // 1. Normalize ID
        const targetJid = jidNormalizedUser(rawTarget); 
        
        // 2. [VITAL FIX] CARI JID ASLI PEMILIK UANG (MAPPING)
        let realTarget = findRealJid(targetJid, db);

        if (realTarget === realSender) return msg.reply(`❌ Stress ya?`);
        if (bet < 1000) return msg.reply(`❌ Min bet Rp 1.000`);

        // Jika user benar-benar baru (tidak ada di key utama, tidak ada di altJids manapun)
        if (!realTarget || !db[realTarget]) {
            // Auto Register Target ke DB Global agar tidak error "Kismin"
            // Default pakai targetJid sebagai Key
            realTarget = targetJid; 
            db[realTarget] = { 
                money: 1000, 
                role: 'Warga Baru', 
                limit: 100,
                altJids: []
            };
            saveDatabase();
        }

        // Init Game Data Target
        initGameUser(realTarget); 
        await savePsData();

        // Cek Uang (Gunakan Real JID)
        if ((db[realSender]?.money || 0) < bet) return msg.reply(`💸 Uangmu kurang.`);
        
        // Cek Uang Lawan di Database yang BENAR
        const targetMoney = db[realTarget]?.money || 0;
        if (targetMoney < bet) return msg.reply(`❌ Lawanmu kismin! Uangnya cuma ${formatRupiah(targetMoney)}, ga cukup buat taruhan ${formatRupiah(bet)}.`);

        // Simpan Challenge menggunakan REAL JID agar konsisten saat accept
        challenges.set(realTarget, { challenger: realSender, bet: bet });
        
        setTimeout(() => { if (challenges.get(realTarget)?.challenger === realSender) challenges.delete(realTarget); }, 60000);

        return sock.sendMessage(chatID, { 
            text: `⚔️ *TANTANGAN DITERIMA*\n\nDari: @${realSender.split('@')[0]}\nKe: @${realTarget.split('@')[0]}\nBet: ${formatRupiah(bet)}\n\n👉 @${realTarget.split('@')[0]} ketik *.sarung accept*`, 
            mentions: [realSender, realTarget] 
        });
    }

    if (subCmd === 'accept' || subCmd === 'gas') {
        // Cek challenge di Real ID
        const challenge = challenges.get(realSender);
        if (!challenge) return msg.reply(`❌ Ga ada tantangan.`);
        
        const p1 = challenge.challenger; // Penantang (Sudah Real ID dari set diatas)
        const p2 = realSender; // Penerima (Saya - Real ID)
        const bet = challenge.bet;

        if ((db[p1]?.money || 0) < bet) return msg.reply(`❌ Penantang kehabisan uang.`);
        if ((db[p2]?.money || 0) < bet) return msg.reply(`❌ Uangmu kurang.`);

        challenges.delete(realSender);
        await startBattle(sock, chatID, p1, p2, bet, db, saveDatabase);
        return;
    }

    // HELP
    if (subCmd === 'help') {
        let text = `╭───「 🕌 *PANDUAN* 」\n│ .sarung info\n│ .sarung shop\n│ .sarung buy [kode]\n│ .sarung equip [kode]\n│ .sarung upgrade\n│ .sarung fight @tag [bet]\n│ .sarung accept\n╰─────────────────────`;
        return msg.reply(text);
    }
    
    return msg.reply(`❓ Salah command. Ketik *.sarung help*`);
};

export default {
    command: ['sarung', 'perangsarung'],
    description: 'Game PVP Perang Sarung Spesial Ramadhan.',
    category: 'game',
    handler,
};