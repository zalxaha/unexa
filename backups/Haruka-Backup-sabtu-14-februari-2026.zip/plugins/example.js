export default {
    command: ['example', 'contoh'],
    category: 'Tools',
    isOwner: true, 

    handler: async ({ reply }) => {
        // Isi template kode
        const template = `import cfg from '../config/config.json' with { type: 'json' };

export default {
    // 1. Array Command (Bisa lebih dari satu trigger)
    command: ['namacommand', 'alias'],
    
    // 2. Kategori untuk Menu
    category: 'NamaKategori',
    
    // 3. Setting Permission (True/False)
    isOwner: false,      // Khusus Owner?
    isAdmin: false,      // Khusus Admin Group?
    isBotAdmin: false,   // Bot harus jadi Admin?
    isPremium: false,    // Khusus User Premium?

    // 4. Handler Utama
    handler: async ({ 
        sock,           // Socket Baileys
        msg,            // Objek Pesan
        args,           // Array kata setelah command
        command,        // Kata command yang dipakai
        sender,         // Nomor HP pengirim (JID)
        isGroup,        // Boolean: grup atau bukan?
        db,             // Akses Database User
        saveDatabase,   // Fungsi simpan DB
        
        // Helper Functions (Otomatis dari Handler)
        reply,          // Balas teks
        sendImage,      // Kirim Gambar (URL/Buffer)
        sendVideo,      // Kirim Video
        sendSticker,    // Kirim Sticker
        sendReact       // Kirim Reaksi
    }) => {
        // --- LOGIKA PROGRAM DI SINI ---
        
        // Contoh: Ambil input user
        if (!args[0]) return reply('❌ Masukkan parameter!');
        
        // Contoh: Kirim reaksi loading
        await sendReact('⏳');
        
        // Contoh: Respon
        await reply(\`Halo kak, kamu mengetik perintah: \${command}\`);
    }
};`;

        // Kirim dengan format Markdown code block
        await reply("```javascript\n" + template + "\n```");
    }
};