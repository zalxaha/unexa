import cfg from '../config/config.json' with { type: 'json' };

export default {
    command: ['lb', 'leaderboard', 'top'],
    category: 'Rpg',
    description: 'Cek peringkat Top Global (Money/XP) dengan posisi user',

    handler: async ({ args, db, reply, sender }) => {
        let type = args[0]?.toLowerCase();
        
        if (type === 'xp') type = 'exp'; 
        if (!['money', 'exp'].includes(type)) {
            return reply(`❌ *Format Salah!*\nGunakan:\n• *.lb money* (Cek Kekayaan)\n• *.lb exp* (Cek Level)`);
        }

        const sortKey = type === 'exp' ? 'xp' : 'money';
        
        // Ubah DB jadi Array [[jid, userObj], ...] agar ID user tidak hilang saat sort
        const sorted = Object.entries(db)
            .sort((a, b) => (b[1][sortKey] || 0) - (a[1][sortKey] || 0));

        // Format angka (Rupiah / XP)
        const formatVal = (num) => {
            if (type === 'money') return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(num);
            return `${num.toLocaleString()} XP`;
        };

        let text = `🏆 *TOP 10 LEADERBOARD ${type.toUpperCase()}* 🏆\n\n`;

        // Loop Top 10
        const top10 = sorted.slice(0, 10);
        top10.forEach((data, i) => {
            const userObj = data[1];
            const name = userObj.nama || 'Unknown';
            const value = userObj[sortKey] || 0;
            
            let rank = `${i + 1}.`;
            if (i === 0) rank = '🥇';
            if (i === 1) rank = '🥈';
            if (i === 2) rank = '🥉';

            // Tandai jika itu user yang ngecek
            const isMe = data[0] === sender ? ' (Kamu)' : '';
            text += `${rank} *${name}*${isMe}\n   └ ${formatVal(value)}\n`;
        });

        // Cek Posisi User Sendiri
        const myRankIndex = sorted.findIndex(item => item[0] === sender);
        
        // Jika user ada di database tapi tidak masuk 10 besar
        if (myRankIndex > 9) {
            const myData = sorted[myRankIndex][1];
            const myValue = myData[sortKey] || 0;
            const myName = myData.nama || 'Unknown';

            text += `\n--------------------------\n`;
            text += `👤 *POSISI KAMU:*\n`;
            text += `#${myRankIndex + 1} *${myName}*\n   └ ${formatVal(myValue)}`;
        }

        await reply(text);
    }
};