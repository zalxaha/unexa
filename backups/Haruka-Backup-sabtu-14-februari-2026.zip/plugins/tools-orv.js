import { downloadMediaMessage } from '@whiskeysockets/baileys';

export default {
    command: ['orv', 'readview', 'openview', 'rv', 'bukapesa'],
    category: 'Tools',
    description: 'Membuka/Mendekripsi pesan sekali lihat (ViewOnce) Foto, Video, atau Suara',

    handler: async ({ sock, msg, reply }) => {
        // 1. Cek apakah user me-reply pesan
        if (!msg.quoted) {
            return reply('❌ Reply pesan *Sekali Lihat (ViewOnce)* yang ingin dibuka!');
        }

        try {
            // Beri reaksi sedang memproses
            await sock.sendMessage(msg.key.remoteJid, { react: { text: '🔓', key: msg.key } });

            // 2. UNWRAPPING (Kupas Kulit Pesan)
            // Pesan ViewOnce biasanya dibungkus dalam "viewOnceMessageV2" atau "viewOnceMessage".
            // Kita harus mengambil isinya (imageMessage/videoMessage) yang ada di dalamnya.
            
            let rawContent = msg.quoted.message;
            
            // Cek ViewOnce Versi 2 (Paling umum sekarang)
            if (rawContent.viewOnceMessageV2) {
                rawContent = rawContent.viewOnceMessageV2.message;
            } 
            // Cek ViewOnce Versi 1 (Lama)
            else if (rawContent.viewOnceMessage) {
                rawContent = rawContent.viewOnceMessage.message;
            }
            // Jika media biasa (bukan ViewOnce), tetap kita proses (rawContent tidak berubah)
            
            // 3. Validasi Tipe Media
            const msgType = Object.keys(rawContent)[0]; // misal: 'imageMessage'
            
            if (!['imageMessage', 'videoMessage', 'audioMessage'].includes(msgType)) {
                return reply('❌ Pesan yang di-reply bukan Foto, Video, atau Pesan Suara!');
            }

            // 4. Download & Decrypt
            // Kita buat objek pesan "Palsu" yang sudah dikupas kulit ViewOnce-nya
            // agar fungsi downloadMediaMessage bisa membaca kuncinya.
            const fakeMessage = {
                key: {
                    remoteJid: msg.key.remoteJid,
                    id: msg.quoted.id,
                    participant: msg.quoted.sender
                },
                message: rawContent // Gunakan konten yang sudah di-unwrap tadi
            };

            const buffer = await downloadMediaMessage(
                fakeMessage,
                'buffer',
                {},
                { 
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage 
                }
            );

            // 5. Kirim Balik sebagai Media Permanen
            if (msgType === 'imageMessage') {
                await sock.sendMessage(msg.key.remoteJid, { image: buffer, caption: '🔓 *Success Opened ViewOnce*' }, { quoted: msg });
            } 
            else if (msgType === 'videoMessage') {
                await sock.sendMessage(msg.key.remoteJid, { video: buffer, caption: '🔓 *Success Opened ViewOnce*' }, { quoted: msg });
            } 
            else if (msgType === 'audioMessage') {
                // ptt: true agar dikirim sebagai Voice Note (bukan file audio biasa)
                await sock.sendMessage(msg.key.remoteJid, { audio: buffer, ptt: true, mimetype: 'audio/mp4' }, { quoted: msg });
            }

        } catch (e) {
            console.error(e);
            return reply(`❌ Gagal membuka ViewOnce.\nPastikan media tersebut belum kadaluarsa di server WhatsApp.\nError: ${e.message}`);
        }
    }
};