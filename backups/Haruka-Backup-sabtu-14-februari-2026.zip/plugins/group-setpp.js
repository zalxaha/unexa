import { downloadContentFromMessage } from '@whiskeysockets/baileys';

async function downloadImageMessage(messageObject) {
    const stream = await downloadContentFromMessage(messageObject, 'image');
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
}

export default {
    command: ['setppgc', 'setppgroup', 'setgroupp', 'seticon'], 
    description: 'Mengubah foto profil grup (Admin Only).',
    category: 'Group',
    
    isGroup: true,
    isAdmin: true,
    isBotAdmin: true,

    handler: async ({ sock, msg, from }) => {
        try {
            let mediaBuffer = null;
            
            const imageMessage = msg.message?.imageMessage;
            const isQuotedImage = msg.quoted && (msg.quoted.type === 'imageMessage' || msg.quoted.mimetype?.includes('image'));

            if (imageMessage) {
                mediaBuffer = await downloadImageMessage(imageMessage);
            } else if (isQuotedImage) {
                if (typeof msg.quoted.download === 'function') {
                    mediaBuffer = await msg.quoted.download();
                } else {
                    const quotedMsgRaw = msg.quoted.message?.imageMessage || msg.quoted; 
                    mediaBuffer = await downloadImageMessage(quotedMsgRaw);
                }
            } else {
                return msg.reply(
                    `⚠️ *CARA PAKAI*\n\n` +
                    `1. Kirim gambar dengan caption *.setppgc*\n` +
                    `2. Atau reply gambar dengan command *.setppgc*`
                );
            }

            if (!mediaBuffer) {
                return msg.reply('❌ Gagal mengunduh gambar. Coba kirim ulang gambarnya.');
            }

            await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

            await sock.updateProfilePicture(from, mediaBuffer);

            await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            
            await msg.reply(
                `✅ *SUKSES*\n\n` +
                `Foto profil grup berhasil diperbarui!`
            );

        } catch (e) {
            console.error('[SETPP GC ERROR]', e);
            await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
            
            if (e.message.includes('not-authorized')) {
                return msg.reply('❌ Gagal: Bot harus menjadi Admin Grup dulu!');
            }
            
            msg.reply(`❌ Gagal: ${e.message}`);
        }
    }
};