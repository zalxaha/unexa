import axios from 'axios';
import crypto from 'crypto';

// --- HELPER 1: PoW Solver ---
const solvePoW = (challenge, difficulty) => {
    let nonce = 0;
    const prefix = '0'.repeat(difficulty);
    while (true) {
        const input = challenge + nonce;
        const hash = crypto.createHash('sha256').update(input).digest('hex');
        if (hash.startsWith(prefix)) return nonce;
        nonce++;
    }
};

// --- HELPER 2: Cookie Manager ---
const updateCookies = (currentCookies, newCookies) => {
    if (!newCookies) return currentCookies;
    const parsedNew = newCookies.map(c => c.split(';')[0]);
    const merged = [...currentCookies];
    parsedNew.forEach(nc => {
        const key = nc.split('=')[0];
        const index = merged.findIndex(oc => oc.startsWith(key + '='));
        if (index > -1) merged[index] = nc;
        else merged.push(nc);
    });
    return merged;
};

// --- HELPER 3: Delay (Tidur sebentar) ---
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export default {
    command: ['yttest', 'ytjson'],
    category: 'Downloader',
    handler: async ({ sock, msg, args, reply, sendReact }) => {
        const url = args[0];
        if (!url) return reply('❌ Masukkan URL YouTube!');
        
        await sendReact('⏳');

        const BASE_URL = 'https://youtubedl.siputzx.my.id';
        const HEADERS = {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
            'Referer': 'https://youdl.pages.dev/',
            'Origin': 'https://youdl.pages.dev',
            'Content-Type': 'application/json'
        };

        let myCookies = [];

        try {
            // [STEP 1] Minta Challenge
            console.log('1. Memulai sesi...');
            const res1 = await axios.post(`${BASE_URL}/akumaudownload`, 
                { url: url, type: 'audio' }, // Ganti 'video' jika ingin mp4
                { headers: HEADERS }
            );
            myCookies = updateCookies(myCookies, res1.headers['set-cookie']);

            // Jika butuh challenge (biasanya iya)
            if (res1.data.challenge) {
                const { challenge, difficulty } = res1.data;
                // [STEP 2] Solve PoW
                const nonce = solvePoW(challenge, difficulty);

                // [STEP 3] Verifikasi
                const res2 = await axios.post(`${BASE_URL}/cekpunyaku`, 
                    { url: url, type: 'audio', nonce: String(nonce) },
                    { headers: { ...HEADERS, 'Cookie': myCookies.join('; ') } }
                );
                myCookies = updateCookies(myCookies, res2.headers['set-cookie']);
            }

            // [STEP 4] POLLING (Looping sampai 'completed')
            console.log('4. Menunggu file siap...');
            let attempt = 0;
            let finalResult = null;

            while (attempt < 30) { // Maksimal cek 30 kali (60 detik)
                const resDownload = await axios.get(`${BASE_URL}/download`, {
                    params: { url: url, type: 'audio' },
                    headers: { ...HEADERS, 'Cookie': myCookies.join('; ') }
                });
                
                const data = resDownload.data;

                if (data.status === 'completed' && data.fileUrl) {
                    finalResult = data;
                    break; // Keluar dari loop jika selesai
                } else if (data.status === 'failed' || data.error) {
                    throw new Error(data.error || 'Gagal memproses video.');
                } else {
                    // Jika masih 'downloading' atau 'processing'
                    console.log(`   ⏳ Status: ${data.status} (${data.progress || '0%'})`);
                    await sleep(2000); // Tunggu 2 detik sebelum cek lagi
                    attempt++;
                }
            }

            if (!finalResult) return reply('❌ Waktu habis (Timeout). Coba lagi nanti.');

            // [STEP 5] KIRIM HASIL (LINK CLICKABLE)
            // Gabungkan Base URL dengan fileUrl dari JSON
            const directLink = BASE_URL + finalResult.fileUrl;

            const textResponse = `✅ *Download Selesai!*\n\n` +
                                 `📂 *Status:* ${finalResult.status}\n` +
                                 `🔗 *Link Download:* \n${directLink}`;

            // Kirim Teks berisi Link
            await reply(textResponse);

            // [OPSIONAL] Kirim File Langsung (Audio/Video)
            // Hapus tanda komentar di bawah jika ingin bot mengirim filenya langsung
            /*
            await sock.sendMessage(msg.chat, { 
                audio: { url: directLink }, 
                mimetype: 'audio/mp4',
                ptt: false 
            }, { quoted: msg });
            */

        } catch (error) {
            console.error('Error:', error.message);
            await reply(`❌ Terjadi kesalahan: ${error.message}`);
        }
    }
};