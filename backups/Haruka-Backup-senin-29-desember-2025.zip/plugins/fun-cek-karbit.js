import Crypto from 'crypto';

// --- DAFTAR GAMBAR BARU DENGAN PERUBAHAN ---
const KARBIT_IMAGES = [
  // 6 Foto Baru untuk Persentase Kecil (Setia)
  'https://files.catbox.moe/0wsyfo.jpg', // 0% - 10% (Ganti)
  'https://files.catbox.moe/pmvd8t.jpg', // 11% - 20% (Ganti)
  'https://files.catbox.moe/cs1mq1.jpg', // 21% - 30% (Ganti)
  'https://files.catbox.moe/2xrbwn.jpg', // 31% - 40% (Ganti)
  'https://files.catbox.moe/dubgh1.jpg', // 41% - 50% (Ganti)
  'https://files.catbox.moe/72um1i.jpg', // 51% - 60% (Ganti)
  
  // Sisa Gambar Lama (Mulai dari 61% - 70%)
  'https://files.catbox.moe/euv9q7.jpg', // 61% - 70% (Indeks 6)
  'https://files.catbox.moe/1zewvx.jpg', // 71% - 80% (Indeks 7)
  'https://files.catbox.moe/mosf0e.jpg', // 81% - 90% (Indeks 8)
  'https://files.catbox.moe/yqrqx4.jpg', // 91% - 100% (Indeks 9)
  'https://files.catbox.moe/xfs58i.jpg', // 101% - 150% (Indeks 10)
  'https://files.catbox.moe/gzcczm.jpg', // 151% - 250% (Indeks 11)
  'https://files.catbox.moe/bp8gnu.jpg', // 251% - 400% (Indeks 12)
  'https://files.catbox.moe/o7htw6.jpg', // 401% - 600% (Indeks 13)
  
  // 3 Foto Baru untuk Karbit Dewa (Indeks 14, 15, 16)
  'https://files.catbox.moe/nr6p9x.jpg', // 601% - 900% (Tambahan 1)
  'https://files.catbox.moe/4midbv.jpg', // 901% - 999% (Tambahan 2)
  'https://files.catbox.moe/7t23ma.jpg', // 1000% (Tambahan 3)
  
  // Foto lama yang tidak terpakai lagi (e4cz1v.jpg dan f2xyih.jpg dihapus dari tingkatan)
];

/**
 * Fungsi PRNG (Pseudo-Random Number Generator) yang konsisten
 * dengan mengonversi hash 64-bit ke angka float [0, 1].
 */
function seededRandom(seed) {
    const hash = Crypto.createHash('sha256').update(seed).digest();
    const high = hash.readUInt32LE(0);
    const low = hash.readUInt32LE(4);
    const max64Bit = 18446744073709551615; // 2^64 - 1
    const value = (high * 4294967296) + low;
    return value / max64Bit;
}

/**
 * Menghasilkan bar visual berdasarkan persentase.
 */
function createProgressBar(percent) {
    const maxBar = 20;
    const clampedPercent = Math.min(100, Math.max(0, percent));
    const filled = Math.floor(clampedPercent / (100 / maxBar));
    const empty = maxBar - filled;
    return `[${'█'.repeat(filled)}${'░'.repeat(empty)}]`;
}

/**
 * Menghitung dan menampilkan tingkat "Karbit" (Gonta-ganti Waifu)
 */
const handler = async ({ sock, msg, from, command, args, pushName }) => {
    
    let waifuName = args.join(' ').trim();

    if (!waifuName) {
        return sock.sendMessage(from, { text: `❌ Masukkan nama karakter waifu yang ingin dicek!\nContoh: *.${command} Miku Nakano*` }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    // --- SEEDING: Waifu + User ID ---
    const userIdJid = msg.key.participant || from; // Full JID (e.g., 62812xxxxxx@s.whatsapp.net)
    const userIdNumber = userIdJid.split('@')[0]; // Hanya angka ID

    const seedBase = `${waifuName.toLowerCase().replace(/[^a-z0-9]/g, '')}_${userIdNumber}`; 

    if (seedBase.length === 0) {
        return sock.sendMessage(from, { text: '❌ Nama karakter tidak valid.' }, { quoted: msg });
    }

    // --- 1. Kalkulasi Persentase (Seeded Random + Fluktuasi) ---
    const baseRand = seededRandom(seedBase); 
    
    const fluctuationRange = 0.1; 
    const currentRand = baseRand + (Math.random() - 0.5) * fluctuationRange; 
    const finalRand = Math.max(0, Math.min(1, currentRand));

    const exponent = 2.5; 
    const mappedRand = Math.pow(finalRand, exponent); 

    let percent = Math.floor(mappedRand * 1000);
    percent = Math.max(1, percent);
    percent = Math.min(1000, percent);


    // --- 2. Tentukan Tingkat Karbit dan Gambar (Indeks Gambar Disesuaikan) ---
    let karbitLevel;
    let imageIndex;

    // Catatan: Logika indexing disesuaikan karena total gambar sekarang 17 (0 sampai 16)
    
    if (percent <= 10) { imageIndex = 0; karbitLevel = "Sangat Setia"; }
    else if (percent <= 20) { imageIndex = 1; karbitLevel = "Setia"; }
    else if (percent <= 30) { imageIndex = 2; karbitLevel = "Agak Setia"; }
    else if (percent <= 40) { imageIndex = 3; karbitLevel = "Lumayan Setia"; }
    else if (percent <= 50) { imageIndex = 4; karbitLevel = "Hampir Setengah Karbit"; }
    else if (percent <= 60) { imageIndex = 5; karbitLevel = "Setengah Karbit"; }
    else if (percent <= 70) { imageIndex = 6; karbitLevel = "Rentan Karbit"; } // Indeks 6 (Lama)
    else if (percent <= 80) { imageIndex = 7; karbitLevel = "Karbit Akut"; } // Indeks 7
    else if (percent <= 90) { imageIndex = 8; karbitLevel = "Karbit Kronis"; } // Indeks 8
    else if (percent <= 100) { imageIndex = 9; karbitLevel = "Karbit Parah"; } // Indeks 9
    else if (percent <= 150) { imageIndex = 10; karbitLevel = "Level Karbit Super Saiyan"; } // Indeks 10
    else if (percent <= 250) { imageIndex = 11; karbitLevel = "Karbit Black Hole"; } // Indeks 11
    else if (percent <= 400) { imageIndex = 12; karbitLevel = "Karbit Multiverse"; } // Indeks 12
    else if (percent <= 600) { imageIndex = 13; karbitLevel = "Karbit Tak Terbatas"; } // Indeks 13
    
    // Tingkatan Baru untuk Karbit Dewa (Menggunakan 3 gambar baru)
    else if (percent <= 900) { imageIndex = 14; karbitLevel = "Karbit *LEGENDARIS DEWA*"; } // Indeks 14 (nr6p9x.jpg)
    else if (percent < 1000) { imageIndex = 15; karbitLevel = "Karbit *ALPHA DEWA*"; } // Indeks 15 (4midbv.jpg)
    else { imageIndex = 16; karbitLevel = "KARBIT TINGKAT *ABSOLUTE DEWA* (1000%!)"; } // Indeks 16 (7t23ma.jpg)


    const imageUrl = KARBIT_IMAGES[imageIndex];
    const progressBar = createProgressBar(percent);
    
    // --- 3. CAPTION ---
    const caption = `
*CEK KARBIT WAIFU* 😘🌹

@${userIdNumber}, ini adalah tingkat karbitmu terhadap *${waifuName}*:

Tingkat Karbit (Gonta-ganti Waifu): 
*${percent}%*
${progressBar}

Status Kesetiaan: 
*${karbitLevel}*
`;

    // --- 4. Kirim Hasil ---
    try {
        await sock.sendMessage(from, {
            image: { url: imageUrl },
            caption: caption,
            mentions: [userIdJid]
        }, { quoted: msg });
        
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
    } catch (e) {
        console.error('[CEK KARBIT ERROR]', e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        await sock.sendMessage(from, { text: `❌ Gagal memproses Cek Karbit: ${e.message}` }, { quoted: msg });
    }
}

export default {
    command: ['cekkarbit', 'karbit'],
    description: 'Mengecek seberapa besar tingkat gonta-ganti waifu (karbit) untuk karakter tertentu.',
    category: 'Fun',
    handler,
};