import log from '../lib/logger.js';

async function sendReaction(sock, msgKey, reactionEmoji) {
    const remoteJid = msgKey.remoteJid;
    const reactionKey = {
        id: msgKey.id,
        remoteJid: remoteJid,
        fromMe: msgKey.fromMe || false,
        ...(msgKey.participant ? { participant: msgKey.participant } : {}) 
    };

    if (!reactionKey.id || !reactionKey.remoteJid) {
        log.err('Gagal mengirim reaksi: ID pesan atau JID tidak terdefinisi.');
        return;
    }

    return sock.sendMessage(remoteJid, {
        react: {
            text: reactionEmoji,
            key: reactionKey
        }
    });
}

function getTargetJid(msg, quoted, senderJid) {
    let rawJid = null;
    
    if (quoted?.sender) {
        rawJid = quoted.sender;
    }
    
    const mentions = msg.message.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (mentions.length > 0) {
        rawJid = mentions[0];
    }

    if (!rawJid && msg.text && !msg.text.startsWith('.')) {
        const parts = msg.text.trim().split(/\s+/);
        for (let i = 1; i < parts.length; i++) {
            const numberMatch = parts[i].match(/\d+/);
            if (numberMatch) {
                return numberMatch[0] + '@s.whatsapp.net';
            }
        }
    }
    
    if (rawJid) {
        const numberPart = rawJid.split('@')[0];
        return numberPart + '@s.whatsapp.net';
    }
    
    return null;
}

async function getRawJidFromGroup(sock, remoteJid, targetJid) {
    try {
        const metadata = await sock.groupMetadata(remoteJid);
        const targetNumber = targetJid.split('@')[0];
        
        const matchedParticipant = metadata.participants.find(p => {
            const participantNumber = p.id.split('@')[0];
            return targetNumber === participantNumber;
        });

        if (matchedParticipant) {
            return matchedParticipant.id;
        }
        return null;
    } catch (e) {
        log.err("Gagal mendapatkan JID mentah partisipan:", e.message);
        return null;
    }
}


export default {
    command: ['promote', 'promosi', 'demote', 'turunkan'], 
    category: 'admin', 
    
    handler: async function ({ sock, msg, args, from, quoted, senderJid, command, isAdmin }) {
        
        const remoteJid = from;

        if (!remoteJid || !remoteJid.endsWith('@g.us')) { 
            return msg.reply("❌ Perintah ini hanya bisa digunakan di dalam grup.");
        }
        
        const targetMsgKey = msg.key;
        const targetJidStandard = getTargetJid(msg, quoted, senderJid);
        
        const commandUsed = command.toLowerCase();
        const isPromote = commandUsed === 'promote' || commandUsed === 'promosi';
        const action = isPromote ? 'promote' : 'demote';
        const actionVerb = isPromote ? 'dipromosikan' : 'diturunkan pangkatnya';
        const actionNoun = isPromote ? 'mempromosikan' : 'menurunkan pangkat';
        const requiredTargetMsg = isPromote ? "user yang ingin dipromosikan" : "admin yang ingin diturunkan pangkatnya";
        const successEmoji = isPromote ? '👑' : '✅';
        
        
        if (!targetJidStandard) {
            return msg.reply(`❗ Tag atau balas pesan ${requiredTargetMsg}!`);
        }

        try {
            await sendReaction(sock, targetMsgKey, '⏳');

            if (!isAdmin) {
                await sendReaction(sock, targetMsgKey, '🛡️');
                return msg.reply("❌ Anda harus menjadi Admin Grup untuk menggunakan perintah ini.");
            }
            
            const rawJid = await getRawJidFromGroup(sock, remoteJid, targetJidStandard);
            const targetNumberOnly = targetJidStandard.split('@')[0];
            
            if (!rawJid) {
                await sendReaction(sock, targetMsgKey, '❓');
                return msg.reply(`❌ Target @${targetNumberOnly} tidak ditemukan dalam daftar partisipan grup.`);
            }

            const [result] = await sock.groupParticipantsUpdate(remoteJid, [rawJid], action);

            if (result.status === '200') {
                await sendReaction(sock, targetMsgKey, successEmoji);
                
                const messageText = `✅ Berhasil! @${targetNumberOnly} kini ${actionVerb} dari Admin Grup.`;
                
                return sock.sendMessage(remoteJid, { 
                    text: messageText,
                    contextInfo: {
                        mentionedJid: [rawJid] 
                    }
                }, { quoted: msg });

            } else if (result.status === '403') {
                 await sendReaction(sock, targetMsgKey, '🚫');
                 return msg.reply(`❌ Gagal: Bot harus menjadi Admin Grup agar bisa ${actionNoun} anggota, atau bot tidak memiliki izin yang cukup.`);
            } else {
                await sendReaction(sock, targetMsgKey, '❓');
                return msg.reply(`❌ Gagal ${actionNoun} @${targetNumberOnly}. Status: ${result.status}.`);
            }

        } catch (e) {
            log.err(`Error saat groupParticipantsUpdate (${actionNoun}):`, e);
            await sendReaction(sock, targetMsgKey, '❌');
            
            if (e.output?.statusCode === 500 || e.message.includes('internal-server-error')) {
                 return msg.reply(`❌ Gagal: Server WhatsApp mengalami kesalahan (Internal Server Error 500). Mohon coba lagi dalam beberapa saat.`);
            }

            return msg.reply(`❌ Terjadi kesalahan tak terduga saat memproses perintah ${action}: ${e.message}`);
        }
    }
};