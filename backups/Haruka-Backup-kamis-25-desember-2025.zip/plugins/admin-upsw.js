import crypto from "node:crypto";
import * as baileys from "@whiskeysockets/baileys";

const cooldowns = new Map();

/**
 * Fungsi pembantu untuk mengunduh stream ke buffer dengan efisien (Hemat RAM)
 */
async function bufferFromStream(stream) {
    const chunks = [];
    for await (const chunk of stream) {
        chunks.push(chunk);
    }
    return Buffer.concat(chunks);
}

/**
 * Fungsi untuk membangun pesan status grup
 */
async function groupStatus(sock, jid, content) {
    const { backgroundColor } = content;
    const cleanContent = { ...content };
    if (cleanContent.backgroundColor) delete cleanContent.backgroundColor;

    const inside = await baileys.generateWAMessageContent(cleanContent, {
        upload: sock.waUploadToServer,
        backgroundColor
    });

    const messageSecret = crypto.randomBytes(32);

    const m = baileys.generateWAMessageFromContent(
        jid,
        {
            messageContextInfo: { messageSecret },
            groupStatusMessageV2: {
                message: {
                    ...inside,
                    messageContextInfo: { messageSecret }
                }
            }
        },
        { userJid: sock.user.id }
    );

    await sock.relayMessage(jid, m.message, { messageId: m.key.id });
    return m;
}

const handler = async ({ sock, msg, args, command, isGroup, isAdmin, isOwner, sender }) => {
    const remoteJid = msg.key.remoteJid;
    const q = msg.quoted ? msg.quoted : msg;
    const caption = args.join(' ').trim();

    // --- Validasi Dasar ---
    if (!isGroup) return msg.reply('❌ Perintah ini hanya bisa digunakan di dalam grup.');
    
    // [UPDATE] Validasi Admin Tanpa Pesan Manual Update
    // Karena sistem handler utama sudah melakukan force update metadata jika diperlukan
    if (!isAdmin && !isOwner) {
        return msg.reply('🛡️ Perintah ditolak. Khusus untuk Admin Grup.');
    }

    // --- Cooldown Logic ---
    if (!isOwner) {
        const now = Date.now();
        const cooldownAmount = 5000; 
        if (cooldowns.has(sender)) {
            const expirationTime = cooldowns.get(sender) + cooldownAmount;
            if (now < expirationTime) {
                const timeLeft = ((expirationTime - now) / 1000).toFixed(1);
                return msg.reply(`⏳ Tunggu ${timeLeft} detik lagi.`);
            }
        }
        cooldowns.set(sender, now);
        setTimeout(() => cooldowns.delete(sender), cooldownAmount);
    }

    try {
        await sock.sendMessage(remoteJid, { react: { text: "⏳", key: msg.key } });

        // Normalisasi objek pesan
        const messageObject = q.message || q.msg || q; 
        
        // Cari tipe media
        let msgType = Object.keys(messageObject).find(key => 
            /image|video|audio|viewOnce/i.test(key)
        );

        let finalMediaBuffer = null;
        let finalMediaType = null;
        let targetMessage = messageObject[msgType];

        // Handle ViewOnce
        if (msgType === 'viewOnceMessage' || msgType === 'viewOnceMessageV2') {
            const internalMsg = targetMessage.message;
            msgType = Object.keys(internalMsg)[0];
            targetMessage = internalMsg[msgType];
        }

        if (msgType && /image|video|audio/i.test(msgType)) {
            finalMediaType = msgType.replace('Message', '').replace('viewOnce', '').toLowerCase();
        }

        // Proses Output
        if (finalMediaType && targetMessage) {
            const stream = await baileys.downloadContentFromMessage(targetMessage, finalMediaType);
            finalMediaBuffer = await bufferFromStream(stream);

            if (finalMediaBuffer.length > 50 * 1024 * 1024) {
                return msg.reply("❌ Ukuran media terlalu besar (Max 50MB).");
            }

            let payload = {};
            if (finalMediaType === 'image') payload = { image: finalMediaBuffer, caption };
            else if (finalMediaType === 'video') payload = { video: finalMediaBuffer, caption };
            else if (finalMediaType === 'audio') payload = { audio: finalMediaBuffer, mimetype: 'audio/mp4', backgroundColor: "#000000" };

            await groupStatus(sock, remoteJid, payload);
            await sock.sendMessage(remoteJid, { react: { text: "✅", key: msg.key } });

        } else if (caption) {
            // Text only status
            await groupStatus(sock, remoteJid, { text: caption, backgroundColor: "#000000" });
            await sock.sendMessage(remoteJid, { react: { text: "✅", key: msg.key } });
        } else {
            return msg.reply(`⚠️ Reply media atau berikan teks.\nContoh: *${command} Info Grup*`);
        }

    } catch (e) {
        console.error("Error Admin UPSW:", e);
        await sock.sendMessage(remoteJid, { react: { text: "❌", key: msg.key } });
        msg.reply("❌ Gagal mengirim status. Pastikan bot memiliki izin yang cukup.");
    }
};

export default {
    command: ['upswgc', 'swgc', 'swgrup'], 
    description: 'Mengirim Status (Story) ke dalam grup.',
    category: 'admin',
    isAdmin: true, // PENTING: Agar handler utama mengecek admin secara ketat
    handler,
};