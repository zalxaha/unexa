import { remindersDb, saveReminders } from '../lib/database.js';

// Mapping nama bulan ke index (0-11)
const monthMap = {
    'januari': 0, 'jan': 0, 'februari': 1, 'feb': 1, 'maret': 2, 'mar': 2,
    'april': 3, 'apr': 3, 'mei': 4, 'juni': 5, 'jun': 5, 'juli': 6, 'jul': 6,
    'agustus': 7, 'agu': 7, 'aug': 7, 'september': 8, 'sep': 8, 'oktober': 9, 'okt': 9,
    'november': 10, 'nov': 10, 'desember': 11, 'des': 11
};

export default {
    command: ['reminder', 'ingatkan', 'remind'],
    category: 'User',
    description: 'Setel pengingat (Support Grup, Recurring & Timezone)',
    isGroup: true, 

    handler: async ({ sock, msg, args, sender, reply, isPremium, isOwner }) => {
        const text = args.join(' ');
        const subCmd = args[0]?.toLowerCase();

        // targetJid = Lokasi di mana bot akan mengirim pesan (Grup atau PC)
        const targetJid = msg.key.remoteJid; 

        // =================================================================
        // FITUR 1: LIST REMINDER
        // =================================================================
        if (subCmd === 'list') {
            // Filter reminder milik user INI di chat INI
            const userReminders = remindersDb.filter(r => r.jid === targetJid && r.userJid === sender);
            
            if (userReminders.length === 0) return reply('📭 Kamu tidak punya reminder aktif di chat ini.');
            
            let listTxt = `📋 *DAFTAR REMINDER KAMU*\n_(Di Chat Ini)_\n\n`;
            userReminders.forEach((r, i) => {
                const date = new Date(r.time).toLocaleDateString('id-ID', { 
                    timeZone: 'Asia/Jakarta', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' 
                });
                const typeIcon = r.type === 'recurring' ? '🔁 (Tiap Hari)' : '📅 (Sekali)';
                listTxt += `${i + 1}. 🆔 *${r.id}*\n   ⏰ ${date}\n   📝 "${r.message}"\n   ${typeIcon}\n\n`;
            });
            
            listTxt += `❌ *Hapus:* .reminder delete [ID]`;
            return reply(listTxt);
        }

        // =================================================================
        // FITUR 2: DELETE REMINDER
        // =================================================================
        if (subCmd === 'delete' || subCmd === 'del' || subCmd === 'hapus') {
            const idToDelete = args[1];
            if (!idToDelete) return reply('❌ Masukkan ID reminder. Cek dengan *.reminder list*');

            // Cari index reminder berdasarkan ID dan Pemilik
            const index = remindersDb.findIndex(r => r.id === idToDelete && r.userJid === sender);
            
            if (index === -1) return reply('❌ ID tidak ditemukan atau bukan milikmu.');

            // Hapus dari array dan Simpan Database
            remindersDb.splice(index, 1);
            await saveReminders(); // PENTING: Agar perubahan tersimpan permanen
            return reply(`✅ Reminder ID *${idToDelete}* berhasil dihapus.`);
        }

        // =================================================================
        // FITUR 3: BUAT REMINDER BARU
        // =================================================================
        if (!text) {
            return reply(`
⏰ *PANDUAN REMINDER BOT*

*1. Untuk Hari Ini:*
> .reminder hari ini jam 14.00 makan siang
> .reminder jam 17.00 pulang kerja

*2. Untuk Besok/Lusa:*
> .reminder besok jam 10.00 meeting
> .reminder 25 Oktober jam 08.00 bayar tagihan

*3. Reminder Berulang (Tiap Hari):*
> .reminder *setiap hari* jam 05.00 bangun pagi

*4. Manajemen:*
> .reminder list _(Lihat daftar)_
> .reminder delete [ID] _(Hapus)_
            `.trim());
        }

        // --- 1. Cek Recurring (Berulang) ---
        const isRecurring = text.toLowerCase().includes('setiap hari') || text.toLowerCase().includes('tiap hari');
        if (isRecurring && !isPremium && !isOwner) {
            return reply('🔒 Fitur reminder *Setiap Hari* khusus untuk User Premium & Owner.');
        }

        // --- 2. Persiapan Waktu (WIB Basis) ---
        // Kita gunakan string manipulation agar akurat dan tidak terpengaruh jam server (UTC/VPS)
        const now = new Date();
        const jakartaNow = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
        
        let targetYear = jakartaNow.getFullYear();
        let targetMonth = jakartaNow.getMonth(); // 0-11
        let targetDay = jakartaNow.getDate();
        
        const lowerText = text.toLowerCase();
        
        // --- 3. Parsing Jam (Format: jam 10.00 / 10:00) ---
        // Regex menangkap: jam 10.00 wib/wita/wit
        const timeMatch = lowerText.match(/(?:pukul|jam)?\s*(\d{1,2})[:.](\d{1,2})\s*(wib|wita|wit)?/);
        if (!timeMatch) return reply('❌ Format jam tidak ditemukan. Contoh: *jam 10.00*');

        const [fullMatch, hStr, mStr, zone] = timeMatch;
        let hours = parseInt(hStr);
        let minutes = parseInt(mStr);
        
        // Konversi Zona Waktu ke WIB (GMT+7)
        if (zone === 'wita') hours -= 1; // WITA (GMT+8) -> WIB
        if (zone === 'wit') hours -= 2;  // WIT (GMT+9)  -> WIB

        // Ambil pesan reminder (Hapus bagian jam dan keyword)
        const splitText = text.split(fullMatch);
        let rawMsg = (splitText[0] + " " + (splitText[1] || "")).trim(); // Gabung text sebelum dan sesudah jam
        let messageReminder = rawMsg
            .replace(/setiap hari|tiap hari|besok|hari ini/gi, '') // Hapus keyword waktu
            .replace(/\s+/g, ' ') // Hapus spasi ganda
            .trim();
            
        // Bersihkan jika ada tanggal di pesan (regex tanggal sederhana)
        messageReminder = messageReminder.replace(/\d{1,2}\s+(januari|februari|maret|april|mei|juni|juli|agustus|september|oktober|november|desember|jan|feb|mar|apr|mei|jun|jul|agu|sep|okt|nov|des)/gi, '').trim();

        if (!messageReminder || messageReminder.length < 2) messageReminder = "Reminder";

        // --- 4. Logic Tanggal (Besok / Tanggal Tertentu) ---
        if (lowerText.includes('besok')) {
            targetDay += 1;
        } else {
            // Cek jika ada tanggal spesifik (Contoh: 25 Oktober)
            const dateMatch = lowerText.match(/(\d{1,2})\s+([a-z]+)/);
            if (dateMatch && !lowerText.includes('hari ini')) {
                const dayInput = parseInt(dateMatch[1]);
                const monthName = dateMatch[2];
                if (monthMap[monthName] !== undefined) {
                    targetDay = dayInput;
                    targetMonth = monthMap[monthName];
                    
                    // Jika tanggal sudah lewat tahun ini (misal sekarang Nov, set Jan), otomatis tahun depan
                    if (targetMonth < jakartaNow.getMonth() || (targetMonth === jakartaNow.getMonth() && targetDay < jakartaNow.getDate())) {
                        targetYear += 1;
                    }
                }
            }
        }

        // --- 5. Konstruksi Timestamp yang Akurat (ISO String) ---
        // Kita buat Date object baru dari komponen tahun/bulan/hari yang sudah dihitung
        // Ini menangani otomatis jika tanggal > 31 (misal 32 Januari -> 1 Februari)
        const dateBuilder = new Date(targetYear, targetMonth, targetDay, hours, minutes, 0);
        
        // Format ke ISO string dengan Timezone WIB (+07:00) secara manual agar pasti
        const yyyy = dateBuilder.getFullYear();
        const mm = String(dateBuilder.getMonth() + 1).padStart(2, '0');
        const dd = String(dateBuilder.getDate()).padStart(2, '0');
        const hh = String(dateBuilder.getHours()).padStart(2, '0');
        const min = String(dateBuilder.getMinutes()).padStart(2, '0');
        
        // Buat string ISO valid: "2024-10-25T10:00:00+07:00"
        const isoString = `${yyyy}-${mm}-${dd}T${hh}:${min}:00+07:00`;
        let finalTime = new Date(isoString).getTime();

        if (isNaN(finalTime)) return reply('❌ Gagal memproses waktu. Coba format: *jam 10.00*');

        // --- 6. Handling Waktu Lewat ---
        const currentTimestamp = Date.now();
        let autoAdjusted = false;

        // Jika waktu target < waktu sekarang
        if (finalTime <= currentTimestamp) {
            if (isRecurring) {
                // Jika recurring, langsung set buat besok
                finalTime += (24 * 60 * 60 * 1000);
            } 
            else if (lowerText.includes('hari ini') || !lowerText.match(/(\d{1,2})\s+([a-z]+)/)) {
                // Jika user bilang "hari ini" tapi jam udah lewat -> Error
                // TAPI, jika user CUMA bilang "jam 10" (tanpa tanggal) dan udah jam 11, anggap besok
                 if (!lowerText.includes('hari ini')) {
                    finalTime += (24 * 60 * 60 * 1000);
                    autoAdjusted = true;
                 } else {
                    return reply('❌ Jam tersebut sudah lewat untuk hari ini.');
                 }
            } else {
                return reply('❌ Waktu yang kamu masukkan sudah lewat.');
            }
        }

        // --- 7. Cek Duplikat (Agar tidak spam) ---
        const isDuplicate = remindersDb.some(r => 
            r.userJid === sender && 
            r.jid === targetJid && 
            r.message.toLowerCase() === messageReminder.toLowerCase() &&
            Math.abs(r.time - finalTime) < 60000 // Toleransi beda < 1 menit
        );

        if (isDuplicate) {
            return reply(`⚠️ Reminder ini sudah terdaftar sebelumnya!`);
        }

        // --- 8. Simpan ke Database ---
        const uniqueId = Math.random().toString(36).substring(2, 6).toUpperCase(); // ID pendek huruf kapital

        const newReminder = {
            id: uniqueId,
            jid: targetJid, 
            userJid: sender, 
            time: finalTime,
            message: messageReminder,
            type: isRecurring ? 'recurring' : 'once',
            setAt: new Date().toLocaleDateString('id-ID', { timeZone: 'Asia/Jakarta' })
        };

        // Push ke memory array
        remindersDb.push(newReminder);
        
        // WRITE KE FILE JSON (Kunci agar tidak hilang)
        try {
            await saveReminders();
        } catch (err) {
            console.error('Gagal menyimpan reminder:', err);
            return reply('❌ Terjadi kesalahan sistem saat menyimpan database.');
        }

        // --- 9. Konfirmasi Sukses ---
        const dateDisplay = new Date(finalTime).toLocaleDateString('id-ID', { 
            timeZone: 'Asia/Jakarta', weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' 
        });
        
        let successMsg = `✅ *REMINDER BERHASIL DISIMPAN*\n\n`;
        successMsg += `📝 *Pesan:* "${messageReminder}"\n`;
        successMsg += `📅 *Waktu:* ${dateDisplay} WIB\n`;
        successMsg += `🔁 *Tipe:* ${isRecurring ? 'Setiap Hari' : 'Sekali'}\n`;
        successMsg += `🆔 *ID:* ${uniqueId}\n`;
        
        if (autoAdjusted) successMsg += `\n_💡 Waktu hari ini sudah lewat, otomatis diatur untuk besok._`;

        return reply(successMsg);
    }
};