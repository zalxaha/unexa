import { getContentType, jidNormalizedUser } from '@whiskeysockets/baileys';

export default {
    command: ['getm', 'quoted', 'metadata', 'inspect'],
    category: 'Tools',
    description: 'Cek metadata (Safe Fix)',

    handler: async ({ sock, msg, reply }) => {
        // 1. Cek Reply
        if (!msg.quoted) {
            return reply('❌ Reply pesan dulu!');
        }

        try {
            const quoted = msg.quoted;
            const messageContent = quoted.message;
            const type = getContentType(messageContent) || Object.keys(messageContent)[0];
            
            // --- SAFE CONTEXT EXTRACTION ---
            // Kita ambil konten spesifik berdasarkan tipe pesannya
            // (Menghindari error sintaks akses properti)
            const content = messageContent[type];
            const contextInfo = content ? content.contextInfo : null;

            // --- IMPLEMENTASI LOGIC LID FIX (Snippet Kamu) ---
            
            // 1. Ambil Sender ID mentah dari pesan yang direply
            const rawSender = quoted.sender;

            // 2. Ambil 'participantPn' (Nomor HP) jika tersedia di contextInfo
            //    Baileys kadang menaruhnya di contextInfo.participantPn
            const pnInContext = contextInfo ? contextInfo.participantPn : undefined;

            // 3. Ambil 'participant' (Biasanya LID) dari contextInfo
            const participantInContext = contextInfo ? contextInfo.participant : undefined;

            // 4. Logika Penentuan ID (Logic Snippet)
            //    Prioritas: participantPn -> participant -> sender biasa
            let finalId = pnInContext || participantInContext || rawSender;

            // 5. Normalisasi terakhir (biar aman)
            finalId = jidNormalizedUser(finalId);

            // -----------------------------------

            // Tentukan status untuk laporan
            let status = "";
            if (finalId.includes('@lid')) {
                status = "⚠️ Tetap LID (WA tidak mengirim participantPn di reply ini)";
            } else {
                status = "✅ Sukses Decode (Dapat Nomor HP)";
            }

            // Bersihkan JSON untuk display
            const jsonDisplay = JSON.parse(JSON.stringify(messageContent));
            if (jsonDisplay[type] && jsonDisplay[type].jpegThumbnail) {
                jsonDisplay[type].jpegThumbnail = "(Binary Hidden)";
            }

            const textResult = `
🔍 *METADATA INSPECTOR (FIX)*

🆔 *ID Pesan:* \`${quoted.id}\`
👻 *Sender ID (Raw):* \`${rawSender}\`
📞 *Sender ID (Final):* \`${finalId}\`
ℹ️ *Status:* ${status}
📄 *Tipe Pesan:* ${type}

📂 *Isi Pesan (JSON):*
\`\`\`json
${JSON.stringify(jsonDisplay, null, 2)}
\`\`\`
`.trim();

            await reply(textResult);

        } catch (e) {
            console.error(e);
            return reply('❌ Error saat inspect: ' + e.message);
        }
    }
};