const handler = async ({ msg, sender, db, isPremium, isOwner }) => {
    const user = db[sender];
    if (!user) return msg.reply('⚠️ Data pengguna tidak ditemukan.');
    
    let txt = '✨ *STATUS PREMIUM ANDA* ✨\n\n';
    
    if (isOwner) {
        txt += 'H͟a͟r͟u͟k͟a͟ \n\n👑 *Status:* OWNER (PERMANEN)\n';
        txt += '🗓️ *Berakhir:* Tidak Terbatas';
    } 
    else if (isPremium) {
        const premTime = user.premiumUntil;
        if (premTime && premTime > Date.now()) {
            const dateStr = new Date(premTime).toLocaleDateString('id-ID', {
                year: 'numeric', month: 'long', day: 'numeric',
                hour: '2-digit', minute: '2-digit',
                timeZone: 'Asia/Jakarta'
            });
            
            const ms = premTime - Date.now();
            const d = Math.floor(ms / 86400000);
            const h = Math.floor((ms % 86400000) / 3600000);
            const m = Math.floor((ms % 3600000) / 60000);

            txt += 'H͟a͟r͟u͟k͟a͟ \n\n💎 *Status:* PREMIUM\n';
            txt += `⏳ *Sisa:* ${d} Hari, ${h} Jam, ${m} Menit\n`;
            txt += `🗓️ *Expired:* ${dateStr}`;
        } else {
            txt += '❌ *Status:* REGULER / EXPIRED\n';
            txt += 'Masa aktif premium Anda telah habis.';
        }
    } else {
        txt += 'H͟a͟r͟u͟k͟a͟ \n\n👤 *Status:* REGULER (GUEST)\n';
        txt += 'Limitasi akses berlaku pada fitur tertentu.\n\n';
        txt += `💡 Ketik *.sewa* atau *.owner* untuk upgrade ke Premium!`;
    }

    msg.reply(txt);
};

export default {
    command: ['checkprem', 'cekprem', 'myprem'],
    handler: handler,
    description: 'Cek status dan sisa waktu premium.'
};
