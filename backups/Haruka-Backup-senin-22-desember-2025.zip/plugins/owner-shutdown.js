import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import cfg from '../config/config.json' with { type: 'json' };

const handler = async ({ sock, msg, args, from }) => {
    const sender = msg.key.participant || msg.key.remoteJid;
    
    // Konfigurasi otorisasi
    const authorizedJids = [
        `${cfg.owner}@s.whatsapp.net`,
        ...(cfg.ownerAltJids || [])
    ];
    
    // Pemeriksaan Otorisasi
    if (!authorizedJids.includes(sender)) {
        return sock.sendMessage(from, { text: "Akses ditolak. Perintah ini hanya untuk Owner." }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '💤', key: msg.key } }); // Reaksi 'Tidur'
    
    const shutdownMsg = `🔴 **Bot akan dimatikan sekarang.** Sampai jumpa! 👋`;
    
    try {
        await sock.sendMessage(from, { text: shutdownMsg }, { quoted: msg });
        
        // Timeout singkat untuk memastikan pesan terkirim sebelum proses berhenti
        await new Promise(resolve => setTimeout(resolve, 1500)); 

        // 🚨 KODE SHUTDOWN PAKSA 🚨
        console.log("Mematikan proses bot atas perintah Owner...");
        // process.exit(0) akan menghentikan proses dengan kode keberhasilan, 
        // yang biasanya tidak akan memicu manager proses (seperti PM2) untuk me-restart bot.
        process.exit(0); 

    } catch (e) {
        console.error("Gagal mengirim pesan atau mematikan:", e);
        // Jika ada error saat mengirim pesan atau exit
        sock.sendMessage(from, { text: `❌ Gagal memicu shutdown. Detail: ${e.message}` }, { quoted: msg });
    }
};

export default {
    command: ['shutdown', 'stop', 'matikan'], // Mengganti command ke 'shutdown'
    description: 'Menghentikan proses bot secara paksa (Owner Only)',
    category: 'owner',
    handler,
};