import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import cfg from '../config/config.json' with { type: 'json' };

const PLUGINS_DIR = path.join(__dirname);

const sanitizePath = (filename) => {
    const fullPath = path.join(PLUGINS_DIR, filename);
    // Pastikan file berada di dalam direktori plugins dan tidak mencoba path traversal
    if (!fullPath.startsWith(PLUGINS_DIR)) {
        throw new Error("Akses ditolak: Path traversal.");
    }
    return fullPath;
};

const handler = async ({ sock, msg, args, from }) => {
    const sender = msg.key.participant || msg.key.remoteJid;
    const filename = args[0];
    
    // --- Pengecekan Owner ---
    const authorizedJids = [
        `${cfg.owner}@s.whatsapp.net`,
        ...(cfg.ownerAltJids || [])
    ];
    
    if (!authorizedJids.includes(sender)) {
        return sock.sendMessage(from, { text: "Akses ditolak. Perintah ini hanya untuk Owner." }, { quoted: msg });
    }
    // ------------------------

    if (!filename || !filename.endsWith('.js')) {
        let helpText = `Gunakan format yang benar untuk mengambil kode file.\n`;
        helpText += `Contoh: *.getp menu.js*\n\n`;
        helpText += `Gunakan *.plugin list* untuk melihat daftar file.`;
        return sock.sendMessage(from, { text: helpText }, { quoted: msg });
    }

    try {
        const filePath = sanitizePath(filename);
        
        // Memastikan file ada sebelum mencoba membaca
        await fs.access(filePath);
        
        const codeContent = await fs.readFile(filePath, 'utf8');

        await sock.sendMessage(from, { react: { text: '📄', key: msg.key } });
        
        let responseText = `*Kode File: ${filename}*\n\n`;
        // Kirim kode dalam code block markdown
        responseText += '```javascript\n' + codeContent + '\n```';

        await sock.sendMessage(from, { text: responseText }, { quoted: msg });

    } catch (e) {
        if (e.code === 'ENOENT') {
            return sock.sendMessage(from, { text: `❌ File *${filename}* tidak ditemukan di direktori plugin.` }, { quoted: msg });
        }
        console.error('[GETP ERROR]', e);
        return sock.sendMessage(from, { text: `❌ Gagal mengambil kode file *${filename}*.\nDetail: ${e.message}` }, { quoted: msg });
    }
};

export default {
    command: ['getp', 'getcode'],
    description: 'Mengambil kode JavaScript dari file plugin (Owner Only)',
    category: 'owner',
    handler,
};