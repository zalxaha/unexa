import axios from 'axios';
import crypto from 'node:crypto';

// --- Scraper Function (Bylo AI) ---
async function sora(prompt, { ratio = 'portrait' } = {}) {
    return new Promise(async (resolve, reject) => {
        try {
            if (!prompt) throw new Error('Prompt is required.');
            if (!['portrait', 'landscape'].includes(ratio)) throw new Error('Available ratios: portrait, landscape.');
            
            // Header konfigurasi (Mimic Android Device)
            const headers = {
                accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
                'Accept-Encoding': 'gzip, deflate, br',
                'cache-control': 'max-age=0',
                connection: 'keep-alive',
                'content-type': 'application/json; charset=UTF-8',
                dnt: '1',
                origin: 'https://bylo.ai',
                pragma: 'no-cache',
                referer: 'https://bylo.ai/features/sora-2',
                'sec-ch-prefers-color-scheme': 'dark',
                'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
                'sec-ch-ua-mobile': '?1',
                'sec-ch-ua-platform': '"Android"',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',  
                'user-agent': 'Mozilla/5.0 (Linux; Android 15; SM-F958 Build/AP3A.240905.015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36',
                uniqueId: crypto.randomUUID().replace(/-/g, '')
            };

            const api = axios.create({
                baseURL: 'https://api.bylo.ai/aimodels/api/v1/ai',
                headers
            });
            
            // 1. Kirim Task Pembuatan Video
            const { data: task } = await api.post('/video/create', {
                prompt: prompt,
                channel: 'SORA2',
                pageId: 536,
                source: 'bylo.ai',
                watermarkFlag: true,
                privateFlag: true,
                isTemp: true,
                vipFlag: true,
                model: 'sora_video2',
                videoType: 'text-to-video',
                aspectRatio: ratio
            });
            
            if (!task || !task.data) throw new Error("Gagal membuat task video.");

            const taskId = task.data;
            let attempts = 0;
            const maxAttempts = 60; // Max tunggu sekitar 2 menit (60 * 2 detik)

            // 2. Polling Status (Cek apakah video sudah jadi)
            while (attempts < maxAttempts) {
                const { data: check } = await api.get(`/${taskId}?channel=SORA2`);
                
                // Jika state > 0 biasanya berarti selesai
                if (check.data && check.data.state > 0) {
                    const result = JSON.parse(check.data.completeData);
                    // Biasanya hasil ada di result.videoUrl atau sejenisnya, kita return full object dulu
                    resolve(result); 
                    return;
                }
                
                // Tunggu 2 detik sebelum cek lagi
                await new Promise(res => setTimeout(res, 2000));
                attempts++;
            }
            
            reject(new Error("Timeout: Video process took too long."));

        } catch (error) {
            reject(error);
        }
    });
};

// --- Handler Bot ---
const handler = async ({ sock, msg, args, command }) => {
    const text = args.join(" ");
    
    if (!text) {
        return msg.reply(`❌ Masukkan prompt deskripsi video.\n\nContoh:\n*${command} a cyberpunk cat walking in tokyo rain*`);
    }

    // Beritahu user sedang proses
    await msg.reply("🎥 *SORA AI*\nSedang men-generate video, proses memakan waktu 1-2 menit. Mohon bersabar...");
    await sock.sendMessage(msg.key.remoteJid, { react: { text: "⏳", key: msg.key } });

    try {
        // Panggil fungsi sora
        const result = await sora(text, { ratio: 'portrait' }); // Default portrait agar cocok di HP
        
        // Cek hasil URL (sesuaikan key json dari response API Bylo)
        // Biasanya result.videoUrl atau result.url. 
        // Jika result berupa string langsung URL, gunakan result.
        const videoUrl = result.videoUrl || result.url || result;

        if (!videoUrl) {
            throw new Error("URL Video tidak ditemukan dalam respon API.");
        }

        // Kirim Video
        await sock.sendMessage(msg.key.remoteJid, {
            video: { url: videoUrl },
            caption: `✅ *Sora AI Generated*\nPrompt: ${text}`,
            gifPlayback: false
        }, { quoted: msg });

        await sock.sendMessage(msg.key.remoteJid, { react: { text: "✅", key: msg.key } });

    } catch (e) {
        console.error("Error Sora AI:", e);
        await msg.reply("❌ Gagal membuat video. Server mungkin sedang sibuk atau prompt dilarang.");
        await sock.sendMessage(msg.key.remoteJid, { react: { text: "❌", key: msg.key } });
    }
};

export default {
    command: ['sora', 'soravideo', 'aisora'],
    description: 'Generate video realistis menggunakan Sora AI',
    category: 'ai',
    handler,
};