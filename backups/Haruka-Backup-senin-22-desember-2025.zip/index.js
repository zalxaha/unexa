import 'dotenv/config';
import makeWASocket, {
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore
} from '@whiskeysockets/baileys';

import qr from 'qrcode-terminal';
import pino from 'pino';
import path from 'path';
import fs from 'fs/promises';
import * as fsSync from 'fs';
import { fileURLToPath } from 'url';
import { parsePhoneNumber } from 'libphonenumber-js';
import chalk from 'chalk';
import NodeCache from 'node-cache';

import log from './lib/logger.js';

// --- GLOBAL VARIABLES ---
let MsgHandler;
let loadPlugins;
let loadDisabledFeatures;
let config = {};

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Cache Metadata Grup: TTL 1 jam, tapi akan di-update via event listener
const groupMetadataCache = new NodeCache({ stdTTL: 60 * 60, checkperiod: 60 });
// Cache sederhana untuk retry message (opsional tapi bagus untuk stabilitas)
const msgRetryCounterCache = new NodeCache();

// --- INITIALIZATION ---
async function initHandler() {
    try {
        const configPath = path.join(__dirname, 'config/config.json');
        const configFileContent = await fs.readFile(configPath, 'utf8');
        config = JSON.parse(configFileContent);
        console.log(chalk.blue('⚙️ Config loaded successfully.'));

        const MsgModule = await import('./handlers/messageHandler.js');
        await MsgModule.loadDisabledFeatures();
        await MsgModule.loadPlugins();

        MsgHandler = MsgModule.default;
        loadPlugins = MsgModule.loadPlugins;
        loadDisabledFeatures = MsgModule.loadDisabledFeatures;

        console.log(chalk.green('✅ Handler & Plugins loaded successfully.'));
    } catch (e) {
        console.error(chalk.red('⚠️ Warning: Gagal import config atau messageHandler.'), e);
        process.exit(1);
    }
}

await initHandler();

import CallHandler from './lib/call.js';

const sessionFolder = path.join(__dirname, 'session');
const dbPath = path.join(__dirname, 'database/users.json');

// --- UTILS ---
async function validatePhoneNumber(input) {
    if (!input) return null;
    try {
        let phone = String(input).replace(/[^0-9]/g, "");
        if (!phone.startsWith('+')) phone = '+' + phone;
        const pn = parsePhoneNumber(phone);
        if (!pn || !pn.isValid()) return null;
        return pn.number.replace('+', '');
    } catch {
        return null;
    }
}

async function checkDatabase() {
    try {
        await fs.access(dbPath);
        const data = await fs.readFile(dbPath, 'utf8');
        if (data.trim().length === 0) await fs.writeFile(dbPath, JSON.stringify({}));
    } catch (err) {
        if (err.code === "ENOENT") {
            await fs.mkdir(path.dirname(dbPath), { recursive: true });
            await fs.writeFile(dbPath, JSON.stringify({}));
        }
    }
}

// --- MAIN SOCKET FUNCTION ---
async function Start() {
    await checkDatabase();

    try { await fs.access(sessionFolder); } 
    catch { await fs.mkdir(sessionFolder, { recursive: true }); }

    const { state, saveCreds } = await useMultiFileAuthState(sessionFolder);
    const { version, isLatest } = await fetchLatestBaileysVersion();

    log.info(`Baileys v${version.join('.')}, latest: ${isLatest}`);
    config.version = version.join('.');

    const usePairing = config.system?.pairing === true;

    // Helper: Fetch Metadata dengan Cache & Fallback
    const getGroupMetadata = async (jid, sock) => {
        // Cek Cache dulu (Super Fast)
        if (groupMetadataCache.has(jid)) return groupMetadataCache.get(jid);
        
        try {
            // Fetch Network jika tidak ada di cache
            const metadata = await sock.groupMetadata(jid);
            // Simpan subject dan participant saja untuk hemat memori
            const minimalData = { subject: metadata.subject, id: metadata.id }; 
            groupMetadataCache.set(jid, minimalData);
            return minimalData;
        } catch (e) {
            // Jika gagal (koneksi belum stabil saat awal on), return null jangan throw error
            return { subject: "Unknown Group", id: jid };
        }
    };

    const sock = makeWASocket({
        version,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" })),
        },
        logger: pino({ level: "silent" }),
        printQRInTerminal: !usePairing,
        syncFullHistory: false,
        shouldSyncHistoryMessage: () => false, // Percepat load awal
        generateHighQualityLinkPreview: true,
        markOnlineOnConnect: true, // Membantu status online
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        connectTimeoutMs: 60000,
        retryRequestDelayMs: 2000,
        msgRetryCounterCache,
        getMessage: async () => { return { conversation: 'Hello' } } // Fallback safe
    });

    // --- PAIRING CODE ---
    if (usePairing && !sock.authState.creds.registered) {
        setTimeout(async () => {
            const number = await validatePhoneNumber(config.system.number);
            if (!number) return log.err("Nomor pairing invalid!");
            try {
                let code = await sock.requestPairingCode(number);
                code = code?.match(/.{1,4}/g)?.join('-') || code;
                console.log(chalk.bgGreen.black(`\n📞 KODE PAIRING:`));
                console.log(chalk.white.bold(code));
            } catch (err) {
                log.err("Gagal request pairing: " + err.message);
            }
        }, 3000);
    }

    // --- CONNECTION UPDATE ---
    sock.ev.on("connection.update", async ({ connection, lastDisconnect, qr: code }) => {
        if (code && !usePairing && !sock.authState.creds.registered) {
            qr.generate(code, { small: true });
        }
        if (connection === "open") {
            log.ok("Bot Online!");
            // Kirim notif ke owner (opsional, dibungkus try catch agar tidak blocking)
            try {
                await sock.sendMessage(config.owner + "@s.whatsapp.net", {
                    text: `✅ Bot Online\nVersi Baileys: ${config.version}`
                });
            } catch {}
        }
        if (connection === "close") {
            const code = lastDisconnect?.error?.output?.statusCode || 0;
            if (code === DisconnectReason.loggedOut) {
                log.err("Session logout → hapus folder session...");
                await fs.rm(sessionFolder, { recursive: true, force: true });
                process.exit(1);
            }
            log.warn("Reconnecting...");
            Start();
        }
    });

    sock.ev.on("creds.update", saveCreds);

    // --- GROUP CACHE AUTO-UPDATER ---
    // Update cache saat nama/deskripsi grup berubah
    sock.ev.on('groups.update', async (updates) => {
        for (const update of updates) {
            if (groupMetadataCache.has(update.id)) {
                // Invalidate cache lama agar fetch ulang saat pesan berikutnya masuk
                // Atau update manual jika data subject tersedia di event update
                if (update.subject) {
                     groupMetadataCache.set(update.id, { subject: update.subject, id: update.id });
                } else {
                     groupMetadataCache.del(update.id);
                }
            }
        }
    });

    // --- MESSAGE HANDLER (OPTIMIZED) ---
    sock.ev.on("messages.upsert", async (m) => {
        if (!m.messages || !m.messages[0]) return;
        
        const msg = m.messages[0];
        if (!msg.message) return;
        if (msg.messageStubType) return;
        if (m.type === "append") return; 
        if (msg.key.remoteJid === "status@broadcast") return;
        if (!MsgHandler) return;

        // 1. EKSEKUSI HANDLER TERLEBIH DAHULU (PRIORITAS UTAMA)
        // Jangan await Logging atau Metadata untuk memproses command!
        Promise.resolve().then(async () => {
             try {
                await MsgHandler(sock, msg); 
            } catch (err) {
                log.err("Handler Error: " + err.message);
            }
        });

        // 2. LOGGING & METADATA (BACKGROUND PROCESS)
        // Dijalankan terpisah agar tidak memblokir respon bot
        try {
            const from = msg.key.remoteJid;
            const isGroup = from.endsWith('@g.us');
            const pushName = msg.pushName || "Unknown";
            let sender = isGroup ? (msg.key.participant || from) : from;
            sender = sender.replace('@s.whatsapp.net', '');
            
            let groupName = "";
            
            // Fetch metadata hanya untuk logging (Non-blocking logic)
            if (isGroup) {
                const meta = await getGroupMetadata(from, sock);
                groupName = meta.subject;
            }

            const type = Object.keys(msg.message).find(key => !['senderKeyDistributionMessage', 'messageContextInfo'].includes(key));
            const body = (type === 'conversation') ? msg.message.conversation :
                        (type === 'extendedTextMessage') ? msg.message.extendedTextMessage.text :
                        (type === 'imageMessage') ? (msg.message.imageMessage.caption || '[Image]') :
                        (type === 'videoMessage') ? (msg.message.videoMessage.caption || '[Video]') :
                        (type === 'stickerMessage') ? '[Sticker]' : 
                        (type === 'audioMessage') ? '[Audio]' : '';

            const isCmd = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&./]/gi.test(body);
            const logTime = new Date().toLocaleTimeString();

            // Gunakan console.log standar dengan chalk (Process.stdout write lebih cepat dibanding logger berat)
            const logPrefix = chalk.bgBlack.white(`⏰ ${logTime}`);
            const senderInfo = chalk.green(pushName) + chalk.yellow(` (${sender})`);

            if (isGroup) {
                console.log(`${logPrefix} ${chalk.magenta(`[ ${groupName} ]`)} ${senderInfo}`);
            } else {
                console.log(`${logPrefix} ${senderInfo}`);
            }

            if (isCmd) {
                console.log(chalk.bgRed.white.bold(`[ COMMAND ]`), chalk.white(body));
            } else {
                console.log(chalk.bgBlue.white(`[ MESSAGE ]`), chalk.cyan(type), chalk.white(body));
            }

        } catch (e) {
            // Silent error for logging to avoid spam
        }
    });

    sock.ev.on("call", async (calls) => {
        try { await CallHandler.code(sock, calls); } catch {}
    });

    // --- HOT RELOAD ---
    fsSync.watch(path.join(__dirname, "plugins"), async (evt, filename) => {
        if (filename && filename.endsWith(".js")) {
            const ts = Date.now();
            try {
                log.info(`[RELOAD START] Mendeteksi perubahan: ${filename}`);
                const reload = await import(`./handlers/messageHandler.js?v=${ts}`);
                if (reload.loadDisabledFeatures) await reload.loadDisabledFeatures();
                if (reload.loadPlugins) await reload.loadPlugins();

                MsgHandler = reload.default;
                loadPlugins = reload.loadPlugins;
                loadDisabledFeatures = reload.loadDisabledFeatures;

                log.ok(`[RELOAD SUCCESS] Plugin berhasil diperbarui.`);
            } catch (e) {
                log.err("Reload gagal: " + e.message);
            }
        }
    });
}

// Error Handling Global
process.on("unhandledRejection", e => {
    // Abaikan error Bad MAC yg sering muncul
    if (String(e).includes("Bad MAC")) return;
    console.error(e);
});
process.on("uncaughtException", e => {
    if (String(e).includes("Bad MAC")) return;
    console.error(e);
});

Start();
