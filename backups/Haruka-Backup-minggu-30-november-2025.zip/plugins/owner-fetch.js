import fetch from 'node-fetch';
import util from 'util';
import { URL } from 'url';
import path from 'path';

const handler = async ({ sock, msg, from, command, args }) => {
    
    const text = args.join(' ').trim();

    if (!text) {
        return sock.sendMessage(from, { text: `❌ Berikan URL yang ingin diambil, contoh: *.${command} https://example.com/api*` }, { quoted: msg });
    }

    if (!/^https?:\/\//i.test(text)) {
        return sock.sendMessage(from, { text: '❌ Awali *URL* dengan http:// atau https://' }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    let res;
    let finalContent = '';
    const url = text;

    try {
        const _url = new URL(url);
        
        res = await fetch(url);

        const contentLength = res.headers.get('content-length');
        if (contentLength && parseInt(contentLength) > 50 * 1024 * 1024) { 
            await sock.sendMessage(from, { text: `❌ Konten terlalu besar (${(parseInt(contentLength) / (1024 * 1024)).toFixed(2)} MB). Batas maksimum 50MB.` }, { quoted: msg });
            return;
        }

        const contentType = res.headers.get('content-type');

        if (!/text|json|xml/i.test(contentType)) {
            const buffer = await res.buffer();
            
            await sock.sendMessage(from, { 
                document: buffer,
                fileName: path.basename(_url.pathname) || 'file',
                caption: `✅ Berhasil mengambil file dari:\n${url}\n\nType: ${contentType || 'Unknown'}`,
                mimetype: contentType || 'application/octet-stream'
            }, { quoted: msg });
            
            await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
            return;
        }

        let txt = await res.text();
        try {
            finalContent = util.format(JSON.parse(txt));
        } catch (e) {
            finalContent = txt;
        }

        await sock.sendMessage(from, { text: finalContent.slice(0, 65536) }, { quoted: msg });
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (e) {
        console.error('[FETCHER ERROR]', e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        await sock.sendMessage(from, { text: `❌ Gagal mengambil URL: ${e.message}` }, { quoted: msg });
    }
}

export default {
    command: ['fetch', 'get'],
    description: 'Mengambil konten dari URL yang diberikan.',
    category: 'Owner',
    owner: true,
    handler,
};