import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Path ke DB Gacha yang baru
const gachaDbPath = path.join(__dirname, '../database/gacha_log.json');
// Path ke DB User yang sudah ada
const userDbPath = path.join(__dirname, '../database/users.json');

const MS_IN_DAY = 24 * 60 * 60 * 1000;

// --- Helper Function: Membaca Database Gacha ---
async function readGachaDatabase() {
  let db = { gachaCodes: {}, userLog: {} };
  try {
    const fileContent = await fs.readFile(gachaDbPath, 'utf8');
    const trimmedContent = fileContent.trim();
    if (trimmedContent.length > 0) {
      db = JSON.parse(trimmedContent);
    } 
  } catch (error) {
    if (error.code === 'ENOENT') {
      // Inisialisasi DB Gacha default jika tidak ada
      db.gachaCodes = {
        "CODE_RARE_7D": { "days": 7, "probability": 0.005, "message": "🎉 Selamat! Anda memenangkan Premium 7 Hari! Jangan sampai terlewatkan!" },
        "CODE_UNCOMMON_3D": { "days": 3, "probability": 0.02, "message": "✨ Beruntung! Anda mendapatkan Premium 3 Hari!" },
        "CODE_COMMON_1D": { "days": 1, "probability": 0.05, "message": "🌟 Hore! Anda berhasil meraih Premium 1 Hari!" },
        "CODE_CONSOLATION": { "days": 0, "probability": 0.925, "message": "😔 Maaf, Anda belum beruntung. Coba lagi besok!" }
      };
      await fs.writeFile(gachaDbPath, JSON.stringify(db, null, 2));
    }
  }
  return db;
}

// --- Helper Function: Menulis Database Gacha ---
async function writeGachaDatabase(db) {
    await fs.writeFile(gachaDbPath, JSON.stringify(db, null, 2));
}

// --- Helper Function: Membaca Database User (diambil dari owner-addprem.js Anda) ---
async function readUserDatabase() {
  let db = {};
  try {
    const fileContent = await fs.readFile(userDbPath, 'utf8');
    const trimmedContent = fileContent.trim();
    if (trimmedContent.length > 0) {
      db = JSON.parse(trimmedContent);
    } 
  } catch (error) {
    if (error.code === 'ENOENT') {
      await fs.writeFile(userDbPath, JSON.stringify({}));
    }
    db = {};
  }
  return db;
}

// --- Helper Function: Menulis Database User ---
async function writeUserDatabase(db) {
    await fs.writeFile(userDbPath, JSON.stringify(db, null, 2));
}

// --- CORE LOGIC: Gacha Berbasis Probabilitas ---
function spinGacha(gachaCodes) {
    const codes = Object.values(gachaCodes);
    const rand = Math.random(); // Angka acak antara 0 dan 1
    let cumulativeProbability = 0;

    // Iterasi kode untuk menentukan hasil
    for (const code of codes) {
        cumulativeProbability += code.probability;
        if (rand < cumulativeProbability) {
            return code; // Kode yang dimenangkan
        }
    }

    // Sebagai fallback (seharusnya tidak tercapai jika total probabilitas 1)
    return codes[codes.length - 1]; 
}


// --- Handler Utama: gacha ---
const handler = async ({ sock, msg, args, sender, db: dbFromMsg }) => {
    
    const now = Date.now();
    const gachaDb = await readGachaDatabase();
    const userDb = await readUserDatabase();
    const userId = sender.split(':')[0]; // Bersihkan JID jika ada versi:device

    // 1. --- Pengecekan Cooldown Harian ---
    const lastClaim = gachaDb.userLog[userId] ? gachaDb.userLog[userId].lastClaim : 0;
    const timeElapsed = now - lastClaim;
    
    if (timeElapsed < MS_IN_DAY) {
        const timeLeftMs = MS_IN_DAY - timeElapsed;
        const hours = Math.floor(timeLeftMs / (60 * 60 * 1000));
        const minutes = Math.floor((timeLeftMs % (60 * 60 * 1000)) / (60 * 1000));
        
        return msg.reply(`⏳ Anda sudah menggunakan Gacha hari ini.
        
Coba lagi dalam *${hours} jam ${minutes} menit*!`);
    }

    // 2. --- Proses Gacha ---
    const result = spinGacha(gachaDb.gachaCodes);
    
    // 3. --- Update Log Penggunaan ---
    if (!gachaDb.userLog) gachaDb.userLog = {};
    gachaDb.userLog[userId] = { lastClaim: now };
    await writeGachaDatabase(gachaDb);

    // 4. --- Memberikan Premium jika Menang ---
    if (result.days > 0) {
        
        // Pastikan user ada di database user
        if (!userDb[userId]) {
            userDb[userId] = {
                nama: null,
                registered: false,
                lastReset: now,
                status: 'guest',
                premiumUntil: 0,
                altJids: []
            };
        }
        
        const userEntry = userDb[userId];
        
        // Hitung waktu premium baru
        const currentPremiumUntil = userEntry.premiumUntil || 0;
        const startTimestamp = currentPremiumUntil > now ? currentPremiumUntil : now;
        const newPremiumUntil = startTimestamp + (result.days * MS_IN_DAY);
        
        userEntry.premiumUntil = newPremiumUntil;
        userEntry.status = 'premium';
        
        await writeUserDatabase(userDb);
        
        // Format tanggal kedaluwarsa
        const expiryDate = new Date(newPremiumUntil);
        const formattedDate = expiryDate.toLocaleDateString('id-ID', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        
        // Kirim Balasan Kemenangan
        let replyText = `🌟 *HASIL GACHA PREMIUM* 🌟
        
${result.message}
        
🎁 *Hadiah:* ${result.days} Hari Premium
🗓️ *Berakhir pada:* ${formattedDate}
        
Selamat menikmati fitur premium!`;

        msg.reply(replyText.trim());
        
    } else {
        // Kirim Balasan Kekalahan/Hiburan
        msg.reply(`❌ *HASIL GACHA PREMIUM* ❌
        
${result.message}
        
Silakan coba lagi besok untuk kesempatan menang!`);
    }

};

export default {
    command: ['gacha', 'claimpremium'],
    category: 'user',
    handler: handler,
    isOwner: false,
    isPremium: false,
    description: 'Coba keberuntungan Anda untuk mendapatkan premium gratis (terbatas 1x sehari).',
    // Pastikan handler ini tidak bisa dijalankan oleh command lain jika di-import
    // atau tambahkan pemeriksaan 'sender' jika perlu
};