import axios from "axios";

// Format durasi dari detik (ex: 381) ke format MM:SS
const formatDuration = (seconds) => {
  if (!seconds || isNaN(seconds)) return "Unknown";
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${s < 10 ? '0' : ''}${s}`;
};

// --- HELPER: Download Video ke Buffer dengan Validasi ---
const downloadVideoBuffer = async (url, maxRetries = 3) => {
  console.log("\n[Video Download] Starting...");
  console.log("URL:", url.substring(0, 80) + "...");

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`   Attempt ${attempt}/${maxRetries}...`);
      
      const response = await axios({
        method: 'get',
        url: url,
        responseType: 'arraybuffer',
        timeout: 120000, // 2 menit untuk video besar
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'video/webm,video/mp4,video/*,*/*;q=0.9'
        },
        onDownloadProgress: (progressEvent) => {
          if (progressEvent.total) {
            const percent = Math.round((progressEvent.loaded * 100) / progressEvent.total);
            if (percent % 20 === 0) console.log(`   Progress: ${percent}%`);
          }
        }
      });

      const buffer = Buffer.from(response.data);
      const sizeMB = (buffer.length / 1024 / 1024).toFixed(2);
      console.log(`   Downloaded: ${sizeMB} MB`);

      // Validasi magic bytes
      const magic = buffer.slice(0, 16).toString('hex');
      const isMP4 = magic.includes('66747970') || magic.startsWith('00000018'); // ftyp atau mvhd
      const isWebM = magic.startsWith('1a45dfa3'); // EBML
      const isFLV = magic.startsWith('464c56'); // FLV
      
      console.log(`   Format: ${isMP4 ? 'MP4' : isWebM ? 'WebM' : isFLV ? 'FLV' : 'Unknown'}`);

      // Validasi ukuran minimum (100KB) agar tidak mendownload halaman error HTML
      if (buffer.length < 100000) {
        throw new Error(`File terlalu kecil (${buffer.length} bytes), kemungkinan link error atau expired.`);
      }

      return {
        buffer,
        size: buffer.length,
        contentType: isWebM ? 'video/webm' : 'video/mp4',
        format: isMP4 ? 'mp4' : isWebM ? 'webm' : 'unknown'
      };

    } catch (err) {
      console.error(`   Attempt ${attempt} failed:`, err.message);
      if (attempt === maxRetries) throw err;
      await new Promise(r => setTimeout(r, 2000 * attempt));
    }
  }
};

const handler = async ({ sock, msg, args, from, sendReact }) => {
  const text = args.join(' ');
  const parts = text.trim().split(' ');
  const url = parts[0];
  const reso = parts[1] || '720'; // Default resolusi 720p

  if (!url) {
    return sock.sendMessage(from, { 
      text: '❌ Masukkan link YouTube.\n\nContoh: `.ytv https://youtu.be/xyz 720`\n\nKualitas: 360, 480, 720, 1080' 
    }, { quoted: msg });
  }

  // Validasi URL YouTube
  const ytRegex = /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)/;
  if (!ytRegex.test(url)) {
    return sock.sendMessage(from, { 
      text: '❌ Link tidak valid. Pastikan menggunakan link YouTube.' 
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });

  try {
    // Memanggil API NexRay
    const apiUrl = `https://api.nexray.web.id/downloader/ytmp4?url=${encodeURIComponent(url)}&resolusi=${reso}`;
    console.log(`\n[NexRay API] Fetching: ${apiUrl}`);
    
    const { data } = await axios.get(apiUrl);
    
    if (!data.status || !data.result) {
      throw new Error(data.message || "Gagal mendapatkan respons valid dari API.");
    }

    const resData = data.result;
    await sock.sendMessage(from, { react: { text: '⬇️', key: msg.key } });
    
    // Download video URL dari hasil API ke buffer
    const videoData = await downloadVideoBuffer(resData.url);
    
    await sock.sendMessage(from, { react: { text: '📤', key: msg.key } });
    
    // Siapkan detail untuk caption WhatsApp
    const safeTitle = (resData.title || 'video').replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);
    const fileSizeMB = (videoData.size / 1024 / 1024).toFixed(2);
    const formattedDuration = formatDuration(resData.duration);
    
    // Strategi: File besar kirim sebagai document, kecil sebagai video (Batas 60MB untuk WA)
    const isLargeFile = videoData.size > 60 * 1024 * 1024; 
    
    let captionText = `✅ *YouTube Video*\n\n` +
                      `📌 *Judul:* ${resData.title}\n` +
                      `⏱️ *Durasi:* ${formattedDuration}\n` +
                      `🎥 *Kualitas:* ${resData.resolusi}p\n` +
                      `📦 *Ukuran:* ${fileSizeMB} MB`;

    if (isLargeFile) {
      captionText += `\n\n💡 _File besar dikirim sebagai document agar tidak corrupt._`;
      await sock.sendMessage(from, {
        document: videoData.buffer,
        mimetype: 'video/mp4',
        fileName: `${safeTitle}_${resData.resolusi}p.mp4`,
        caption: captionText
      }, { quoted: msg });
    } else {
      await sock.sendMessage(from, {
        video: videoData.buffer,
        mimetype: 'video/mp4',
        fileName: `${safeTitle}_${resData.resolusi}p.mp4`,
        caption: captionText
      }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (err) {
    console.error("Handler Error:", err);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    
    let errorMsg = err.message;
    if (err.response?.data?.message) errorMsg = err.response.data.message;
    else if (err.code === 'ECONNABORTED') errorMsg = 'Timeout: Server terlalu lama merespons';
    else if (err.code === 'ENOTFOUND') errorMsg = 'DNS Error: Tidak dapat terhubung ke server API';
    
    await sock.sendMessage(from, { 
      text: `❌ *Error:* ${errorMsg}\n\n💡 Tips:\n• Coba resolusi lain (contoh: 480)\n• Pastikan video tidak private/live stream\n• Coba lagi dalam beberapa saat` 
    }, { quoted: msg });
  }
};

export default {
  command: ['ytv', 'ytmp4', 'ytvideo'],
  description: 'Download video YouTube via NexRay API',
  category: 'Downloader',
  handler,
};