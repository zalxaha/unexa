import fs from 'fs';
import path from 'path';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';
import { writeExifImg } from '../lib/exif.js';
// import { uploadCatbox } from '../lib/uploader.js'; <--- DIGANTI
import { tmpdir } from 'os';
import Crypto from 'crypto';
import FormData from 'form-data'; // Diperlukan untuk multipart upload

import cfg from '../config/config.json' assert { type: 'json' };

function generateFileName(ext = '') {
  return path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}${ext}`);
}

// Fungsi upload baru (menggantikan uploadCatbox)
async function uploadToTmpFiles(buffer) {
    // Asumsi file adalah JPEG berdasarkan proses download sebelumnya
    const ext = 'jpg'; 
    const mime = 'image/jpeg';
    
    const form = new FormData(); 

    form.append("file", buffer, {
        filename: `tmp.${ext}`,
        contentType: mime
    });

    const url = "https://tmpfiles.org/api/v1/upload";

    try {
        const res = await fetch(url, {
            method: 'POST',
            body: form,
            // Header diambil dari form-data
            headers: form.getHeaders ? form.getHeaders() : {}
        });
        
        if (!res.ok) {
            throw new Error(`Upload API returned status ${res.status}`);
        }
        
        const data = await res.json();
        
        if (data.status !== 'success' || !data.data || !data.data.url) {
             throw new Error(`tmpfiles.org response error: ${data.data?.error?.message || JSON.stringify(data)}`);
        }

        const match = /https?:\/\/tmpfiles.org\/(.*)/.exec(data.data.url);

        if (!match || !match[1]) {
             throw new Error(`Failed to parse download URL from: ${data.data.url}`);
        }

        // Mengembalikan URL direct download
        return `https://tmpfiles.org/dl/${match[1]}`;
    } catch (error) {
        console.error('[TMPFILES UPLOAD ERROR]', error);
        throw new Error("Gagal mengunggah file ke tmpfiles.org.");
    }
}

const parseSmemeArgs = (args) => {
    const fullText = args.join(' ').trim();
    let text1 = '';
    let text2 = '';
    
    const EMPTY_CHAR = 'ㅤ'; 
    
    if (fullText.includes('|')) {
        [text1, text2] = fullText.split('|').map(t => t.trim());
        
        text1 = text1 || EMPTY_CHAR;
        text2 = text2 || EMPTY_CHAR;
        
    } else if (fullText.endsWith('_atas')) {
        text1 = fullText.substring(0, fullText.length - 5).trim();
        text2 = EMPTY_CHAR;
        
    } else if (fullText.endsWith('_bawah')) {
        text1 = EMPTY_CHAR;
        text2 = fullText.substring(0, fullText.length - 6).trim();

    } else {
        // Kasus Default: .smeme teks (teks bawah saja)
        text1 = EMPTY_CHAR;
        text2 = fullText;
    }

    // Mengganti karakter 'ㅤ' dengan spasi ' ' agar memegen menganggapnya kosong
    return { 
        text1: text1.trim() === EMPTY_CHAR ? ' ' : text1, 
        text2: text2.trim() === EMPTY_CHAR ? ' ' : text2
    };
};


const handler = async ({ sock, msg, from, pushName, args }) => {

    const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
    const quoted = contextInfo?.quotedMessage;

    const mediaMessage = quoted || msg.message;

    const mimeType = Object.keys(mediaMessage || {}).find(k => k.endsWith('Message')) || '';
        
    if (!mimeType.includes('image')) {
        return sock.sendMessage(from, {
            text: '❌ Reply/kirim **gambar** dengan caption **.smeme [teks]**.\n\nContoh format:\n`.smeme Halo | Dunia`\n`.smeme Atas Saja _atas`\n`.smeme Bawah Saja _bawah`'
        }, { quoted: msg })
    }

    if (args.length === 0) {
        return sock.sendMessage(from, {
            text: '❌ Masukkan teks untuk meme. Contoh:\n`.smeme Atas | Bawah`'
        }, { quoted: msg })
    }
    
    const { text1, text2 } = parseSmemeArgs(args);
    
    // Verifikasi apakah ada teks sama sekali (bukan hanya spasi)
    if (text1.trim() === ' ' && text2.trim() === ' ') {
        return sock.sendMessage(from, {
            text: '❌ Teks atas atau teks bawah harus diisi.'
        }, { quoted: msg })
    }
    
    const mediaInfo = mediaMessage[mimeType];
    
    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } })

    let mediaBuffer;
    const filePath = generateFileName('.jpg');
    let uploadedUrl = '';
    let resultPath = '';
    
    // 1. UNDUH MEDIA
    try {
        const stream = await downloadContentFromMessage(mediaInfo, 'image');
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        mediaBuffer = Buffer.concat(chunks);
        fs.writeFileSync(filePath, mediaBuffer);
    } catch (e) {
        console.error('[SMEME DOWNLOAD ERROR]', e)
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } })
        return sock.sendMessage(from, {
            text: `❌ Gagal mengunduh media.`
        }, { quoted: msg })
    }
    
    // 2. UPLOAD KE TMPFILES.ORG
    try {
        uploadedUrl = await uploadToTmpFiles(mediaBuffer);
    } catch (e) {
        console.error('[SMEME UPLOAD ERROR]', e)
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } })
        return sock.sendMessage(from, {
            text: `❌ Gagal mengunggah media ke tmpfiles.org: ${e.message}`
        }, { quoted: msg })
    } finally {
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }
    }
    
    if (!uploadedUrl) {
        return sock.sendMessage(from, {
            text: '❌ Gagal mendapatkan URL dari tmpfiles.org.'
        }, { quoted: msg })
    }
    
    // 3. BUAT URL MEMEGEN
    // Memegen.link menggunakan format: /images/custom/teks_atas/teks_bawah.png?background=URL_gambar
    
    // text1 dan text2 sudah di-konversi menjadi ' ' jika isinya kosong
    const memeUrl = `https://api.memegen.link/images/custom/${encodeURIComponent(text1)}/${encodeURIComponent(text2)}.png?background=${encodeURIComponent(uploadedUrl)}`;

    
    // 4. DOWNLOAD STIKER DAN KIRIM
    try {
        const res = await fetch(memeUrl);

        if (res.ok) {
            const finalStickerBuffer = await res.buffer();
            
            // Metadata EXIF
            const meta = { 
                pack: cfg.botName || "Haruka", 
                author: "https://zalxzhu.my.id" 
            };
            
            resultPath = await writeExifImg(finalStickerBuffer, meta);

            const finalBuffer = fs.readFileSync(resultPath);

            await sock.sendMessage(from, {
                sticker: finalBuffer
            }, { quoted: msg });

            await sock.sendMessage(from, { react: { text: '✨', key: msg.key } }); 

        } else {
            const errorText = await res.text();
            console.error(`[MEMEGEN FAILED] Status: ${res.status}, Body: ${errorText.substring(0, 100)}...`);
            throw new Error(`Gagal mendapatkan stiker dari memegen.link (Status: ${res.status}).`);
        }

    } catch (e) {
        console.error('[SMEME CONV ERROR]', e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        sock.sendMessage(from, {
            text: `❌ Gagal membuat Stiker Meme: ${e.message}`
        }, { quoted: msg });
    } finally {
        if (resultPath && fs.existsSync(resultPath)) {
            fs.unlinkSync(resultPath);
        }
    }
}

export default {
    command: ['smeme'], 
    description: 'Buat stiker meme dari gambar menggunakan memegen.link.',
    category: 'Media',
    handler,
};