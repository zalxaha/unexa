import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import os from 'os';
import archiver from 'archiver';
import { fileURLToPath } from 'url';
import { Octokit } from "@octokit/rest";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import cfg from '../config/config.json' assert { type: 'json' };

const GH_TOKEN = process.env.GH_TOKEN || 'ghp_ERROR_TOKEN'; 
const GH_OWNER = process.env.GH_OWNER || 'zalxaha';
const GH_REPO = process.env.GH_REPO || 'unexa';
const BRANCH = 'main'; 

if (GH_TOKEN === 'ghp_ERROR_TOKEN') {
    console.error("TOKEN GITHUB TIDAK DITEMUKAN. SILAKAN CEK FILE .env ATAU VARIABEL LINGKUNGAN ANDA.");
}

const octokit = new Octokit({ auth: GH_TOKEN });

const PROJECT_ROOT = path.join(__dirname, '..');
const SESSION_FOLDER_NAME = 'session'; 

const handler = async ({ sock, msg, args, from }) => {
    const sender = msg.key.participant || msg.key.remoteJid;
    
    const authorizedJids = [
        `${cfg.owner}@s.whatsapp.net`,
        ...(cfg.ownerAltJids || [])
    ];
    
    if (!authorizedJids.includes(sender)) {
        return sock.sendMessage(from, { text: "Akses ditolak. Perintah ini hanya untuk Owner." }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '📦', key: msg.key } });

    const today = new Date();
    
    const weekday = today.toLocaleDateString('id-ID', { weekday: 'long' }).toLowerCase(); 
    const day = today.toLocaleDateString('id-ID', { day: '2-digit' }); 
    const month = today.toLocaleDateString('id-ID', { month: 'long' }).toLowerCase();
    const year = today.toLocaleDateString('id-ID', { year: 'numeric' }); 

    const dateString = `${weekday}-${day}-${month}-${year}`;
    
    const zipName = `${cfg.botName.replace(/\s/g, '_')}-Backup-${dateString}.zip`;
    const outputPath = path.join(os.tmpdir(), zipName);
    const output = fs.createWriteStream(outputPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    let fileCreated = false;
    let localSuccess = false;

    const archivePromise = new Promise((resolve, reject) => {
        output.on('close', resolve);
        archive.on('error', reject);
    });

    try {
        archive.pipe(output);
        fileCreated = true;

        archive.glob('**/*', {
            cwd: PROJECT_ROOT,
            ignore: [
                '**/node_modules/**',
                '**/.npm/**',
                '**/.git/**',
                `**/${SESSION_FOLDER_NAME}/**`, 
                '**/.cache/**', 
                zipName,
                '*.zip',
                '*.log',
                // --- PENTING: Mengecualikan file .env dari backup ZIP ---
                '.env',
            ],
            dot: true 
        });

        const credsPath = path.join(PROJECT_ROOT, SESSION_FOLDER_NAME, 'creds.json');
        try {
            await fsp.access(credsPath);
            archive.file(credsPath, { name: `${SESSION_FOLDER_NAME}/creds.json` });
            console.log("creds.json berhasil ditambahkan.");
        } catch (e) {
            console.warn("creds.json tidak ditemukan atau tidak dapat diakses, melanjutkan tanpa file ini.");
        }

        await archive.finalize();
        await archivePromise;
        localSuccess = true;

        await sock.sendMessage(from, { react: { text: '💾', key: msg.key } });

        console.log(`[BACKUP] Mengirim file lokal: ${zipName}`);
        await sock.sendMessage(from, {
            document: { url: outputPath },
            fileName: zipName,
            mimetype: 'application/zip',
            caption: `✅ Backup bot *${cfg.botName}* berhasil dibuat dengan nama file:\n*${zipName}*\n\n⏳ Melanjutkan proses upload ke GitHub...`
        }, { quoted: msg });

        await sock.sendMessage(from, { react: { text: '📤', key: msg.key } });

        let fileUrl = '';
        const githubPath = `backups/${zipName}`;
        
        try {
            const fileContent = await fsp.readFile(outputPath);
            const base64 = fileContent.toString("base64");
            
            let sha = undefined;
            try {
                const { data } = await octokit.repos.getContent({
                    owner: GH_OWNER,
                    repo: GH_REPO,
                    path: githubPath,
                    ref: BRANCH
                });
                sha = data.sha;
                console.log(`[GITHUB] File sudah ada. SHA lama diambil: ${sha}`);
            } catch (e) {
                if (e.status !== 404) {
                    throw e; 
                }
                console.log(`[GITHUB] File baru, akan dibuat.`);
            }

            console.log(`[BACKUP] Mulai upload/update ke GitHub: ${zipName}`);

            await octokit.repos.createOrUpdateFileContents({
                owner: GH_OWNER,
                repo: GH_REPO,
                path: githubPath,
                message: (sha ? 'Update' : 'Upload') + ` automated backup: ${zipName}`,
                content: base64,
                sha: sha, 
                branch: BRANCH,
                committer: { name: 'Bot Backup Service', email: 'bot@example.com' }
            });

            fileUrl = `https://raw.githubusercontent.com/${GH_OWNER}/${GH_REPO}/${BRANCH}/${githubPath}`;
            
            console.log(`[BACKUP] Selesai upload. URL: ${fileUrl}`);

            await sock.sendMessage(from, {
                text: `✅ Backup berhasil diupload ke GitHub.\n\n🔗 *URL Download:* ${fileUrl}`
            }, { quoted: msg });

        } catch (e) {
            console.error('[GITHUB UPLOAD ERROR]', e);
            await sock.sendMessage(from, { react: { text: '⚠️', key: msg.key } });

            let ghErrorMsg = "Gagal mengupload ke GitHub. Periksa Token/Owner/Nama Repo Anda.";
            if (e.status === 401) {
                 ghErrorMsg = `⚠️ Upload GitHub gagal (Status 401 - Otentikasi Gagal). Pastikan GH_TOKEN yang Anda masukkan sudah valid dan memiliki scope 'repo'.`;
            } else if (e.status === 404) {
                 ghErrorMsg = `⚠️ Upload GitHub gagal (Status 404 - Repo/Owner Salah). Periksa kembali GH_OWNER atau GH_REPO.`;
            } else if (e.message) {
                 ghErrorMsg = `⚠️ Upload GitHub gagal.\nDetail Error: ${e.message}`;
            }

            return sock.sendMessage(from, { text: ghErrorMsg }, { quoted: msg });
        }

    } catch (e) {
        console.error('[BACKUP PROCESS ERROR]', e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        
        const errorMessage = `❌ Gagal menyelesaikan proses backup.\nDetail: ${e.message}`;
        return sock.sendMessage(from, { text: errorMessage }, { quoted: msg });
    } finally {
        if (fileCreated) {
            try {
                await fsp.unlink(outputPath);
                console.log(`[CLEANUP] File ${zipName} dihapus dari direktori sementara.`);
            } catch (e) {
                console.error(`Gagal menghapus file sementara ${outputPath}:`, e);
            }
        }
    }
};

export default {
    command: ['backup', 'arsip'],
    description: 'Membuat backup seluruh proyek bot dan mengunggahnya ke GitHub (Owner Only)',
    category: 'owner',
    handler,
};