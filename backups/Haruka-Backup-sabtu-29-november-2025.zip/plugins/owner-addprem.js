import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.join(__dirname, '../database/users.json');

const S_WHATSAPP_NET = '@s.whatsapp.net';

// --- Helper Function: Membaca Database ---
async function readDatabase() {
  let db = {};
  try {
    const fileContent = await fs.readFile(dbPath, 'utf8');
    const trimmedContent = fileContent.trim();
    if (trimmedContent.length > 0) {
      db = JSON.parse(trimmedContent);
    } 
  } catch (error) {
    if (error.code === 'ENOENT') {
      await fs.writeFile(dbPath, JSON.stringify({}));
    }
    db = {};
  }
  return db;
}

// --- Helper Function: Mapping JID Target ---
function mapTargetJid(incomingJid, db) {
  // 1. Cek apakah JID sudah menjadi JID utama
  if (db[incomingJid]) {
      return incomingJid;
  }
  
  // 2. Cek apakah JID adalah JID alternatif
  for (const realJid in db) {
    if (db[realJid].altJids && db[realJid].altJids.includes(incomingJid)) {
      return realJid; // Ditemukan JID utama
    }
  }
  
  // 3. Jika belum tercatat, gunakan JID aslinya
  return incomingJid;
}

// --- Handler Utama: addprem ---
const handler = async ({ sock, msg, args, isOwner, db: dbFromMsg }) => {
    
    if (!isOwner) {
        return msg.reply('🚫 *Command ini hanya untuk Owner.*');
    }

    const usage = `*Usage:*
${process.env.PREFIX || '.'}addprem <nomor/jid> <durasi>
Atau balas pesan user:
${process.env.PREFIX || '.'}addprem <durasi>
    
*Contoh:*
${process.env.PREFIX || '.'}addprem 6281234567890 30d
(Balas pesan user) ${process.env.PREFIX || '.'}addprem 7d
`;

    let targetJid = null;
    let durationString = null;
    let tempArgs = [...args]; 

    // 1. Ambil JID target dan Durasi
    
    // A. PRIORITY 1: DARI REPLY PESAN
    if (msg.quoted) {
        targetJid = msg.quoted.sender;
        durationString = tempArgs[0]; // Durasi adalah argumen pertama
    } 
    
    // B. PRIORITY 2: DARI ARGUMEN TEKS (JID LENGKAP ATAU NOMOR)
    else if (tempArgs[0]) {
        
        const possibleJidOrNumber = tempArgs[0];
        
        // Cek jika argumen pertama adalah JID lengkap atau hanya nomor
        if (possibleJidOrNumber.includes(S_WHATSAPP_NET) || /^\d+$/.test(possibleJidOrNumber)) {
            
            // Jika hanya nomor (contoh: 628xxxx), tambahkan server
            if (!possibleJidOrNumber.includes(S_WHATSAPP_NET)) {
                targetJid = possibleJidOrNumber.replace(/[^0-9]/g, '') + S_WHATSAPP_NET;
            } else {
                // Hapus karakter non-angka kecuali server JID
                targetJid = possibleJidOrNumber.split('@')[0].replace(/[^0-9]/g, '') + S_WHATSAPP_NET;
            }
            
            // Durasi adalah argumen kedua (index 1)
            durationString = tempArgs[1]; 

        } 
    }
    
    // PENGECEKAN FINAL JID DAN DURASI
    if (!targetJid || !durationString) {
        return msg.reply(usage);
    }
    
    // Bersihkan JID jika ada versi:device di belakangnya
    targetJid = targetJid.split(':')[0];

    // **********************************************
    // 2. MAPPING JID TARGET DARI DB
    const db = await readDatabase();
    const finalTargetJid = mapTargetJid(targetJid, db);
    // **********************************************
    
    // 3. Parse Durasi
    const match = durationString.match(/^(\d+)([dmy])$/i);
    if (!match) {
        return msg.reply('⚠️ Format durasi tidak valid. Gunakan: `1d`, `7d`, `1m`, `1y`.');
    }
    
    const [_, numStr, unit] = match;
    const num = parseInt(numStr, 10);
    const now = Date.now();
    let durationMs = 0;
    
    const MS_IN_DAY = 24 * 60 * 60 * 1000;
    switch (unit.toLowerCase()) {
        case 'd': durationMs = num * MS_IN_DAY; break;
        case 'm': durationMs = num * 30 * MS_IN_DAY; break;
        case 'y': durationMs = num * 365 * MS_IN_DAY; break;
        default: return msg.reply('⚠️ Satuan durasi tidak valid. Hanya `d`, `m`, atau `y`.');
    }

    if (durationMs < MS_IN_DAY) {
        return msg.reply('⚠️ Durasi premium minimal harus 1 hari (1d).');
    }

    // 4. Update Database menggunakan finalTargetJid
    if (!db[finalTargetJid]) {
         db[finalTargetJid] = {
            nama: null,
            registered: false,
            lastReset: now,
            status: 'guest',
            premiumUntil: 0,
            altJids: []
        };
    }
    
    const userEntry = db[finalTargetJid];
    
    // Hitung waktu premium baru
    const currentPremiumUntil = userEntry.premiumUntil || 0;
    const startTimestamp = currentPremiumUntil > now ? currentPremiumUntil : now;
    const newPremiumUntil = startTimestamp + durationMs;
    
    userEntry.premiumUntil = newPremiumUntil;
    userEntry.status = 'premium';
    
    // Pastikan JID yang digunakan dalam command tercatat sebagai altJids
    if (targetJid !== finalTargetJid) {
        if (!userEntry.altJids) userEntry.altJids = [];
        if (!userEntry.altJids.includes(targetJid)) {
            userEntry.altJids.push(targetJid);
        }
    }
    
    await fs.writeFile(dbPath, JSON.stringify(db, null, 2));

    // 5. Kirim Balasan
    const expiryDate = new Date(newPremiumUntil);
    const formattedDate = expiryDate.toLocaleDateString('id-ID', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });

    let replyText = `✅ *STATUS PREMIUM DIPERBARUI*
        
👤 *User:* ${finalTargetJid}
⏳ *Durasi:* ${num} ${unit.toUpperCase()}
🗓️ *Berakhir pada:* ${formattedDate}
        
${currentPremiumUntil > now ? 'Premium yang ada *diperpanjang*.' : 'Premium *baru* ditambahkan.'}`;

    msg.reply(replyText.trim());
};

export default {
    command: ['addprem', 'tambahpremium'],
    category: 'owner',
    handler: handler,
    isOwner: true,
    isPremium: false,
    description: 'Menambahkan status premium kepada user tertentu.'
};