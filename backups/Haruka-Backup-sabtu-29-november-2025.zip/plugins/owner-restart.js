import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import cfg from '../config/config.json' assert { type: 'json' };

const handler = async ({ sock, msg, args, from }) => {
    const sender = msg.key.participant || msg.key.remoteJid;
    
    const authorizedJids = [
        `${cfg.owner}@s.whatsapp.net`,
        ...(cfg.ownerAltJids || [])
    ];
    
    if (!authorizedJids.includes(sender)) {
        return sock.sendMessage(from, { text: "Akses ditolak. Perintah ini hanya untuk Owner." }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '🔄', key: msg.key } });
    
    const restartMsg = `✅ Bot akan di-restart. Tunggu beberapa saat...`;
    
    try {
        await sock.sendMessage(from, { text: restartMsg }, { quoted: msg });
        
        // Coba restart menggunakan sinyal process.send('reset')
        if (process.send) {
            process.send('reset');
        } else {
            // Fallback: keluar dari proses, biasanya memicu restart oleh manager (PM2/Supervisor)
            process.exit(1);
        }
    } catch (e) {
        console.error("Gagal mengirim pesan atau me-restart:", e);
        // Jika ada error saat mengirim pesan atau exit, kirim pesan error
        sock.sendMessage(from, { text: `❌ Gagal memicu restart. Detail: ${e.message}` }, { quoted: msg });
    }
};

export default {
    command: ['restart', 'r'],
    description: 'Memulai ulang proses bot (Owner Only)',
    category: 'owner',
    handler,
};