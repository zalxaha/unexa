import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.join(__dirname, '../database/users.json');

const S_WHATSAPP_NET = '@s.whatsapp.net';

// --- Helper Function: Membaca Database ---
async function readDatabase() {
  let db = {};
  try {
    const fileContent = await fs.readFile(dbPath, 'utf8');
    const trimmedContent = fileContent.trim();
    if (trimmedContent.length > 0) {
      db = JSON.parse(trimmedContent);
    } 
  } catch (error) {
    db = {};
  }
  return db;
}

// --- Helper Function: Mapping JID Target ---
function mapTargetJid(incomingJid, db) {
    if (db[incomingJid]) return incomingJid;
    
    for (const realJid in db) {
        if (db[realJid].altJids && db[realJid].altJids.includes(incomingJid)) {
            return realJid;
        }
    }
    return incomingJid;
}

// --- Handler Utama: delprem ---
const handler = async ({ sock, msg, args, isOwner }) => {
    
    if (!isOwner) {
        return msg.reply('🚫 *Command ini hanya untuk Owner.*');
    }

    const usage = `*Usage:*
${process.env.PREFIX || '.'}delprem <nomor/jid>
Atau balas pesan user:
${process.env.PREFIX || '.'}delprem
    
*Contoh:*
${process.env.PREFIX || '.'}delprem 6281234567890
(Balas pesan user) ${process.env.PREFIX || '.'}delprem
`;

    let targetJid = null;
    let tempArgs = [...args]; 

    // 1. Ambil JID target
    
    // A. PRIORITY 1: DARI REPLY PESAN
    if (msg.quoted) {
        targetJid = msg.quoted.sender;
    } 
    
    // B. PRIORITY 2: DARI ARGUMEN TEKS (JID LENGKAP ATAU NOMOR)
    else if (tempArgs[0]) {
        const possibleJidOrNumber = tempArgs[0];
        
        if (possibleJidOrNumber.includes(S_WHATSAPP_NET) || /^\d+$/.test(possibleJidOrNumber)) {
            if (!possibleJidOrNumber.includes(S_WHATSAPP_NET)) {
                targetJid = possibleJidOrNumber.replace(/[^0-9]/g, '') + S_WHATSAPP_NET;
            } else {
                targetJid = possibleJidOrNumber.split('@')[0].replace(/[^0-9]/g, '') + S_WHATSAPP_NET;
            }
        } 
    }
    
    if (!targetJid) {
        return msg.reply(usage);
    }
    
    targetJid = targetJid.split(':')[0]; // Bersihkan JID

    // 2. Mapping dan Update Database
    const db = await readDatabase();
    const finalTargetJid = mapTargetJid(targetJid, db);
    
    if (!db[finalTargetJid]) {
        return msg.reply(`⚠️ User dengan JID utama ${finalTargetJid} tidak ditemukan di database.`);
    }

    const userEntry = db[finalTargetJid];
    
    if (userEntry.premiumUntil === 0 || userEntry.status !== 'premium') {
         return msg.reply(`🔔 ${finalTargetJid} saat ini tidak memiliki status premium aktif.`);
    }

    // Reset status premium
    userEntry.premiumUntil = 0;
    userEntry.status = userEntry.registered ? 'user' : 'guest';
    
    await fs.writeFile(dbPath, JSON.stringify(db, null, 2));

    let replyText = `🗑️ *STATUS PREMIUM DIHAPUS*
        
👤 *User:* ${finalTargetJid}
✨ *Status Baru:* ${userEntry.status.toUpperCase()}
    
Status premium telah dihentikan secara instan.`;

    msg.reply(replyText.trim());
};

export default {
    command: ['delprem', 'hapuspremium'],
    category: 'owner',
    handler: handler,
    isOwner: true,
    isPremium: false,
    description: 'Menghapus status premium dari user tertentu.'
};