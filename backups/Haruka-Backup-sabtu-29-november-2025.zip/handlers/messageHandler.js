import fs from 'fs/promises'; 
import path from 'path';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { fileURLToPath } from 'url';
import { createRequire } from 'module'; 

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url);

import log from '../lib/logger.js';
import cfg from '../config/config.json' assert { type: 'json' };

const dbPath = path.join(__dirname, '../database/users.json');
let sockGlobal = null;

const groupAdminCache = {};
const CACHE_TTL = 30000; // 30 detik

async function readDatabase() {
  let db = {};
  try {
    const fileContent = await fs.readFile(dbPath, 'utf8');
    const trimmedContent = fileContent.trim();
    if (trimmedContent.length > 0) {
      db = JSON.parse(trimmedContent);
    }
  } catch (error) {
    if (error.code === 'ENOENT') {
      await fs.writeFile(dbPath, JSON.stringify({}, null, 2));
    }
    db = {};
  }
  return db;
}

const parseQuoted = (m, sock) => {
  const q = m.message?.extendedTextMessage?.contextInfo;
  if (!q?.quotedMessage) return;
  const quoted = q.quotedMessage;
  const mtype = Object.keys(quoted)[0];
  const msg = quoted[mtype];
  m.quoted = {
    type: mtype,
    mtype,
    id: q.stanzaId,
    sender: q.participant,
    fromMe: q.participant === sock.user.id,
    isBaileys: !!q.isForwarded,
    text: msg?.text || msg?.caption || '',
    message: quoted,
    download: async () => {
      const stream = await downloadContentFromMessage(quoted[mtype], mtype.replace('Message', ''));
      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }
      return buffer;
    }
  };
};

function mapJid(incomingJid, db, ownerJid, ownerAltJids) {
  if (incomingJid === ownerJid || (ownerAltJids && ownerAltJids.includes(incomingJid))) {
    return ownerJid;
  }
  for (const realJid in db) {
    if (db[realJid].altJids && db[realJid].altJids.includes(incomingJid)) {
      return realJid;
    }
  }
  return incomingJid;
}

async function Msg(sock, m) {
  try {
    sockGlobal = sock;
    
    if (!m || !m.message) return;
    if (m.key.fromMe) return; 

    const now = Date.now();
    const { key, message, pushName } = m;
    const remoteJid = key.remoteJid;
    
    const isGroup = remoteJid.endsWith('@g.us');
    let incomingJid = isGroup ? key.participant : remoteJid;
    m.isGroup = isGroup;

    // Handle LID / Mapping
    const originalIncomingJid = incomingJid;
    if (isGroup && key.participantPn && /@lid$/.test(key.participant)) {
        incomingJid = key.participantPn; 
    }

    // Deteksi Body Pesan
    const msgTypes = {
      conversation: () => message.conversation,
      imageMessage: () => message.imageMessage.caption || '',
      videoMessage: () => message.videoMessage.caption || '',
      extendedTextMessage: () => message.extendedTextMessage.text,
      buttonsResponseMessage: () => message.buttonsResponseMessage.selectedButtonId,
      listResponseMessage: () => message.listResponseMessage.singleSelectReply.selectedRowId,
      templateButtonReplyMessage: () => message.templateButtonReplyMessage.selectedId
    };
    const msgType = Object.keys(message || {})[0];
    const body = (msgTypes[msgType] ? msgTypes[msgType]() : '') || '';

    if (!body.startsWith(cfg.prefix)) return; // Jika bukan command, skip
    const args = body.slice(cfg.prefix.length).trim().split(/ +/);
    if (!args[0]) return;
    const cmd = args.shift().toLowerCase();

    // --- LOGIKA DATABASE & USER BARU (DIPERBAIKI) ---
    let db = await readDatabase();
    let isDbChanged = false; // Flag untuk menghemat write file

    const ownerConfigJid = cfg.owner + '@s.whatsapp.net';
    const senderJid = mapJid(incomingJid, db, ownerConfigJid, cfg.ownerAltJids);
    
    // Tentukan JID Utama
    const primaryJidToUse = (senderJid !== incomingJid && senderJid) ? senderJid : incomingJid;
    m.sender = primaryJidToUse;

    // FIX: Pastikan User Object Ada SEBELUM lanjut
    if (!db[primaryJidToUse]) {
        db[primaryJidToUse] = {
            nama: pushName || 'User',
            registered: false,
            lastReset: now,
            status: 'guest',
            premiumUntil: 0, 
            altJids: []
        };
        log.info(`➕ User baru dibuat: ${primaryJidToUse}`);
        isDbChanged = true;
    }

    // Ambil referensi user yang PASTI sudah ada sekarang
    let userDbEntry = db[primaryJidToUse];

    // Update Alt Jids jika perlu
    if (originalIncomingJid !== primaryJidToUse) {
        if (!userDbEntry.altJids) userDbEntry.altJids = [];
        if (!userDbEntry.altJids.includes(originalIncomingJid)) {
            userDbEntry.altJids.push(originalIncomingJid);
            isDbChanged = true;
        }
    }

    // Cek Expired Premium
    if (!userDbEntry.premiumUntil) userDbEntry.premiumUntil = 0;
    if (userDbEntry.premiumUntil > 0 && now > userDbEntry.premiumUntil) {
      userDbEntry.premiumUntil = 0;
      userDbEntry.status = userDbEntry.registered ? 'user' : 'guest';
      log.info(`⬇️ Premium ${primaryJidToUse} habis.`);
      isDbChanged = true;
    }

    // Cek Status Premium (Sync)
    const isOwner = m.sender === ownerConfigJid;
    const isPremium = isOwner || (userDbEntry.premiumUntil > 0 && now < userDbEntry.premiumUntil);
    
    if (isPremium && userDbEntry.status !== 'premium') {
        userDbEntry.status = 'premium';
        isDbChanged = true;
    }

    // Simpan Database HANYA jika ada perubahan (Biar gak berat/lag)
    if (isDbChanged) {
        await fs.writeFile(dbPath, JSON.stringify(db, null, 2));
    }

    // --- PENGECEKAN ADMIN GRUP ---
    const participantJidForGroupCheck = key.participant || remoteJid;
    let isAdmin = isOwner; 
    
    if (isGroup && !isOwner) {
        const cacheKey = remoteJid;
        if (groupAdminCache[cacheKey] && now < groupAdminCache[cacheKey].expiry) {
            const participant = groupAdminCache[cacheKey].participants.find(p => p.id === participantJidForGroupCheck);
            isAdmin = !!(participant?.admin === 'admin' || participant?.admin === 'superadmin');
        } else {
            try {
                const groupMetadata = await sock.groupMetadata(remoteJid);
                groupAdminCache[cacheKey] = {
                    participants: groupMetadata.participants,
                    expiry: now + CACHE_TTL
                };
                const participant = groupMetadata.participants.find(p => p.id === participantJidForGroupCheck);
                isAdmin = !!(participant?.admin === 'admin' || participant?.admin === 'superadmin');
            } catch (e) { isAdmin = false; }
        }
    }

    // Helper Reply
    parseQuoted(m, sock);
    m.reply = async (text, opt = {}) => {
      return sock.sendMessage(remoteJid, { text, ...opt }, { quoted: m });
    };

    // --- CARI PLUGIN ---
    const pluginDir = path.join(__dirname, '../plugins');
    let pluginFiles;
    try {
        pluginFiles = (await fs.readdir(pluginDir)).filter(f => f.endsWith('.js'));
    } catch (e) {
        log.err("Gagal membaca folder plugins");
        return;
    }

    let found = false;
    const isUserRegistered = !!userDbEntry.registered; // Ambil dari userDbEntry yg sudah aman

    for (const file of pluginFiles) {
      try {
        // Import plugin
        const plugin = await import(`../plugins/${file}?v=${Date.now()}`); // Timestamp agar hot reload jalan
        
        if (!plugin.default) continue;

        // Filter permission
        if (plugin.default.isOwner && !isOwner) continue;
        if (plugin.default.isPremium && !isPremium) {
            // Cek command dulu baru reply reject
            const cmds = Array.isArray(plugin.default.command) ? plugin.default.command : [plugin.default.command];
            if (cmds.includes(cmd)) {
                 m.reply('🚫 *Fitur ini khusus Premium.*');
                 return; 
            }
            continue;
        }

        const commands = Array.isArray(plugin.default.command) ? plugin.default.command : [plugin.default.command];
        
        if (commands.includes(cmd)) {
          found = true;
          log.evt(`Cmd '${cmd}' dari ${pushName || m.sender}`);
          
          await plugin.default.handler({ 
            sock,
            msg: m,
            args,
            command: cmd,
            from: remoteJid,
            pushName,
            isOwner,
            isPremium,
            isUserRegistered,
            db,
            sender: m.sender,
            isGroup,
            isAdmin
          });
          break; // Stop loop jika command sudah ketemu
        }
        
      } catch (e) {
        log.err(`❌ Plugin '${file}' error: ${e.message}`);
      }
    }

    if (!found) {
      // log.warn(`Command '${cmd}' tidak ditemukan.`); // Optional: Uncomment kalau mau nyepam log
    }

  } catch (e) {
    log.err(`❌ Msg() fatal error: ${e.stack || e.message}`);
  }
}

export default Msg;
