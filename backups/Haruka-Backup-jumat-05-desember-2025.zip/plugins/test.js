import axios from 'axios';
import fileType from 'file-type'; 
import { downloadContentFromMessage } from '@whiskeysockets/baileys'; 
import log from '../lib/logger.js';

// Model yang tepat untuk pengeditan gambar (Nano Banana resmi)
const MODEL_NAME = "gemini-2.5-flash-image-preview"; 

async function geminiImageEdit(prompt, imageBuffer) {
    // API Key diatur ke string kosong agar diisi otomatis oleh lingkungan Canvas
    const apiKey = "AIzaSyBF41CE3BOHmI4DOOMziRGG_sqUnH5ukzw"; 
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL_NAME}:generateContent?key=${apiKey}`;

    const type = await fileType.fromBuffer(imageBuffer);
    const mimeType = type?.mime || 'image/jpeg';
    const base64ImageData = imageBuffer.toString('base64');

    const payload = {
        contents: [
            {
                role: "user",
                parts: [
                    { text: prompt },
                    {
                        inlineData: {
                            mimeType: mimeType,
                            data: base64ImageData
                        }
                    }
                ]
            }
        ],
        generationConfig: {
            responseModalities: ['TEXT', 'IMAGE']
        },
    };

    const config = {
        headers: { 'Content-Type': 'application/json' }
    };

    const MAX_RETRIES = 5; 
    let response;
    
    // Mekanisme Exponential Backoff untuk menangani error 429/5xx
    for (let i = 0; i < MAX_RETRIES; i++) {
        try {
            response = await axios.post(apiUrl, payload, config);
            break; 
        } catch (error) {
            const status = error.response?.status;
            
            if ((status === 429 || (status >= 500 && status < 600)) && i < MAX_RETRIES - 1) {
                const waitTime = 1500 * Math.pow(2, i);
                await new Promise(resolve => setTimeout(resolve, waitTime));
                continue;
            }
            
            if (error.response) {
                console.error("Gemini API Error Response:", error.response.data);
                throw new Error(`Gemini API Error: Status ${error.response.status} - ${JSON.stringify(error.response.data)}`);
            } else {
                throw new Error(error.message);
            }
        }
    }

    try {
        const result = response.data;
        const base64Data = result?.candidates?.[0]?.content?.parts?.find(p => p.inlineData)?.inlineData?.data;

        if (!base64Data) {
            const errorText = result?.candidates?.[0]?.content?.parts?.find(p => p.text)?.text || 'Model tidak menghasilkan gambar atau teks.';
            throw new Error(`Gagal menghasilkan gambar. Pesan model: ${errorText}`);
        }
        
        return Buffer.from(base64Data, 'base64');
    } catch (e) {
        throw e;
    }
}

async function sendReaction(sock, msgKey, reactionEmoji) {
    const remoteJid = msgKey.remoteJid;
    
    const reactionKey = {
        id: msgKey.id,
        remoteJid: remoteJid,
        fromMe: msgKey.fromMe || false,
    };

    if (msgKey.participant) {
        reactionKey.participant = msgKey.participant;
    }

    if (!reactionKey.id || !reactionKey.remoteJid) {
        log.err('Gagal mengirim reaksi: ID pesan atau JID tidak terdefinisi.');
        return;
    }

    return sock.sendMessage(remoteJid, {
        react: {
            text: reactionEmoji,
            key: reactionKey
        }
    });
}

export default {
    command: ['blackskin', 'skinhitam'], 
    category: 'edit',
    
    handler: async function ({ sock, msg, args, remoteJid, quoted }) {
        const targetMsgKey = msg.key; 
        let mediaBuffer = null;
        let isImage = false;
        
        const targetMessage = msg.message.imageMessage ? msg.message : quoted?.message;

        if (targetMessage?.imageMessage) {
            isImage = true;
            try {
                const stream = await downloadContentFromMessage(targetMessage.imageMessage, 'image');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }
                mediaBuffer = buffer;
            } catch (e) {
                log.err("Gagal mengunduh gambar:", e.message);
            }
        }
        
        if (!isImage || !mediaBuffer) {
            return msg.reply("❗ Mohon kirim atau balas gambar dengan caption `!blackskin` atau `!skinhitam`.");
        }

        const prompt = "change skin color to black. apply the new skin color realistically.";

        try {
            await sendReaction(sock, targetMsgKey, '⏳');

            log.info(`Mulai pengeditan gambar dengan prompt: ${prompt}`);
            
            const resultBuffer = await geminiImageEdit(prompt, mediaBuffer);

            await sendReaction(sock, targetMsgKey, '✅');
            
            await sock.sendMessage(remoteJid, {
                image: resultBuffer,
                caption: `✅ Selesai! Warna kulit diubah menjadi hitam menggunakan AI. Prompt: "${prompt}".`
            }, { quoted: msg });

        } catch (e) {
            log.err("Edit Gambar Error:", e.message);
            await sendReaction(sock, targetMsgKey, '❌');
            let errorMessage = "❌ Terjadi kesalahan saat memproses gambar.";
            
            if (e.message.includes('Status 429')) {
                errorMessage = "❌ Kuota layanan AI (Rate Limit) habis. Mohon tunggu 5-10 menit lalu coba lagi.";
            } else if (e.message.includes('Status 400')) {
                errorMessage = "❌ Permintaan tidak valid (Bad Request). Model mungkin tidak dapat memproses gambar ini.";
            } else if (e.message.includes('Status 403')) {
                errorMessage = "❌ Akses ditolak (Forbidden). Masalah izin API.";
            } else if (e.message.includes('Gemini API Error')) {
                errorMessage += ` Kesalahan API: ${e.message.split(' - ')[0]}`;
            } else if (e.message.includes('Gagal menghasilkan gambar')) {
                errorMessage += ` ${e.message.split(': ')[1]}`;
            } else {
                 errorMessage += ` Detail: ${e.message}`;
            }
            return msg.reply(errorMessage);
        }
    }
};