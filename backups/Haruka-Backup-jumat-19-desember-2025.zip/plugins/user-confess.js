import { parsePhoneNumber } from 'libphonenumber-js';
import cfg from '../config/config.json' assert { type: 'json' };
import { CONFESSION_MAP } from '../handlers/messageHandler.js';

const cooldowns = new Map();
const COOLDOWN_SECONDS = 60; // Cooldown 1 menit per user untuk menghindari spam Confes

export default {
    command: ['confes', 'menfess'],
    category: 'User', 
    isOwner: false, 
    isPremium: false,
    handler: async ({ sock, msg, args, sender }) => {
        
        const now = Date.now();
        
        if (cooldowns.has(sender)) {
            const expirationTime = cooldowns.get(sender) + COOLDOWN_SECONDS * 1000;
            if (now < expirationTime) {
                const timeLeft = Math.ceil((expirationTime - now) / 1000);
                return msg.reply(`🚫 Tunggu *${timeLeft} detik* sebelum mengirim konfesi lagi.`);
            }
        }

        if (args.length < 2) {
            return msg.reply(`
❌ Format salah.
*Gunakan:* ${cfg.prefix}confes [nomor target] [pesan]

Contoh: ${cfg.prefix}confes 62812345678 Aku suka kamu dari lama...
            `);
        }

        let targetNumber = args[0].replace(/[^0-9]/g, "");
        if (!targetNumber.startsWith('+')) targetNumber = '+' + targetNumber;
        
        let targetJid;
        try {
            const pn = parsePhoneNumber(targetNumber);
            if (!pn || !pn.isValid()) {
                return msg.reply("❌ Nomor target tidak valid atau tidak dikenali.");
            }
            targetJid = pn.number.replace('+', '') + '@s.whatsapp.net';
        } catch (e) {
            return msg.reply("❌ Nomor target tidak valid.");
        }
        
        if (targetJid === sender) {
            return msg.reply("❌ Anda tidak bisa mengirim konfesi ke diri sendiri.");
        }

        const confessionMessage = args.slice(1).join(' ').trim();
        
        if (confessionMessage.length < 15) {
            return msg.reply("❌ Pesan konfesi terlalu pendek. Minimal 15 karakter.");
        }

        const anonymousHeader = `
💌 *KONFESI ANONIM* 💌

Seseorang ingin menyampaikan ini kepada Anda:
----------------------------------------

*Pesan:*
${confessionMessage}

----------------------------------------
*Catatan:* Balas pesan ini untuk membalas konfesi secara anonim.
        `.trim();
        
        try {
            const sentMsg = await sock.sendMessage(
                targetJid,
                { text: anonymousHeader }
            );

            if (sentMsg?.key?.id) {
                // Simpan mapping: ID pesan yang terkirim ke target -> JID pengirim asli
                CONFESSION_MAP.set(sentMsg.key.id, sender);
                cooldowns.set(sender, now);
                
                await msg.reply(`✅ Konfesi Anda berhasil dikirimkan kepada @${targetJid.split('@')[0]}.`);
            } else {
                throw new Error("Pesan gagal terkirim atau tidak memiliki ID.");
            }
            
        } catch (e) {
            console.error("Gagal mengirim konfesi:", e);
            await msg.reply(`❌ Gagal mengirim konfesi. Pastikan bot dan target berada di grup yang sama jika Anda mengirim dari grup, atau target telah menyimpan nomor bot. Error: ${e.message}`);
        }
    }
};