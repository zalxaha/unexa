import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const S_WHATSAPP_NET = '@s.whatsapp.net';

function mapTargetJid(incomingJid, db) {
    if (db[incomingJid]) return incomingJid;
    
    // Cari JID utama berdasarkan altJids
    for (const realJid in db) {
        if (db[realJid].altJids && db[realJid].altJids.includes(incomingJid)) {
            return realJid;
        }
    }
    return incomingJid;
}

const handler = async ({ sock, msg, args, isOwner, db, saveDatabase }) => {
    
    if (!isOwner) {
        return msg.reply('🚫 *Command ini hanya untuk Owner.*');
    }

    const usage = `*Usage:*
${process.env.PREFIX || '.'}delprem <nomor/jid/@tag>
Atau balas pesan user:
${process.env.PREFIX || '.'}delprem
    
*Contoh:*
${process.env.PREFIX || '.'}delprem @taguser
(Balas pesan user) ${process.env.PREFIX || '.'}delprem
`;

    let targetJid = null;
    let tempArgs = [...args]; 
    let mentionedJids = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

    // --- LOGIKA PENGAMBILAN TARGET JID ---
    if (msg.quoted) {
        targetJid = msg.quoted.sender;
    } else if (mentionedJids.length > 0) {
        targetJid = mentionedJids[0]; 
    } else if (tempArgs[0]) {
        const possibleJidOrNumber = tempArgs[0];
        if (possibleJidOrNumber.includes(S_WHATSAPP_NET) || /^\d+$/.test(possibleJidOrNumber)) {
            if (!possibleJidOrNumber.includes(S_WHATSAPP_NET)) {
                targetJid = possibleJidOrNumber.replace(/[^0-9]/g, '') + S_WHATSAPP_NET;
            } else {
                targetJid = possibleJidOrNumber.split('@')[0].replace(/[^0-9]/g, '') + S_WHATSAPP_NET;
            }
        } 
    }
    
    if (!targetJid) {
        return msg.reply(usage);
    }
    
    // 1. Bersihkan JID dari suffix dan pastikan format
    targetJid = targetJid.split(':')[0];

    // 2. MAPPING JID PENTING UNTUK MENDAPATKAN JID UTAMA (DARI ALIAS/TEMPORER)
    const finalTargetJid = mapTargetJid(targetJid, db);
    
    if (!db[finalTargetJid]) {
        // Jika JID utama (finalTargetJid) tidak ada di DB, tampilkan pesan error generik
        return msg.reply(`⚠️ User dengan JID ${finalTargetJid} tidak ditemukan di database.`);
    }

    const userEntry = db[finalTargetJid];
    
    if (userEntry.premiumUntil === 0 || userEntry.status !== 'premium') {
         // Perbaikan: Gunakan JID target awal (yang dimasukkan user) untuk pesan error yang familiar
         const displayJid = targetJid; 
         return msg.reply(`🔔 ${displayJid} saat ini tidak memiliki status premium aktif.`);
    }

    userEntry.premiumUntil = 0;
    userEntry.status = userEntry.registered ? 'user' : 'guest';
    userEntry.lastPremiumNotif = 0;

    await saveDatabase();

    // --- LOGIKA NOTIFIKASI KE USER TARGET ---
    const notificationText = `
🔔 *PEMBERITAHUAN STATUS PREMIUM*
    
Status premium Anda telah *DIHAPUS* oleh Owner.
    
✨ *Status Baru:* ${userEntry.status.toUpperCase()}
`;
    try {
        await sock.sendMessage(finalTargetJid, { text: notificationText.trim() });
    } catch (e) {
        console.error(`Gagal mengirim notifikasi premium ke ${finalTargetJid}:`, e.message);
    }
    // ----------------------------------------

    let replyText = `🗑️ *STATUS PREMIUM DIHAPUS*
        
👤 *User Target:* ${finalTargetJid}
✨ *Status Baru:* ${userEntry.status.toUpperCase()}
    
Status premium telah dihentikan secara instan. Notifikasi telah dikirim.`;

    msg.reply(replyText.trim());
};

export default {
    command: ['delprem', 'hapuspremium'],
    category: 'owner',
    handler: handler,
    isOwner: true,
    isPremium: false,
    description: 'Menghapus status premium dari user tertentu.'
};