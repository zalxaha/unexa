import { promises as fs } from 'fs'; 
import path from 'path';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { fileURLToPath } from 'url';
import { createRequire } from 'module'; 
import fetch from 'node-fetch';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url);

import log from '../lib/logger.js';

// Load Config
const cfg = require('../config/config.json');

// --- PATH DATABASE ---
const dbPath = path.join(__dirname, '../database/users.json');
const featuresPath = path.join(__dirname, '../database/features.json');
const groupDbPath = path.join(__dirname, '../database/groups.json'); 
const settingsPath = path.join(__dirname, '../database/settings.json'); 
const pluginDir = path.join(__dirname, '../plugins');

let sockGlobal = null;
const groupAdminCache = {};
const CACHE_TTL = 30000;

let pluginsCache = {};
let disabledFeatures = {};
let usersDbCache = null;
let groupsDbCache = null;

// --- DEFAULT SETTINGS ---
let globalSettings = {
    publicMode: true,       // TRUE = Bisa PC & Group. FALSE = Hanya Group.
    limitMode: true,        // Jika ON, limit berjalan
    privateLimit: 10,       // Limit harian default
    groupLink: "https://chat.whatsapp.com/C6KcF2yIWk39eC6KArmWm5?mode=hqrt3"
};

const altJidCache = new Map();
const CONFESSION_MAP = new Map();

// --- DEBOUNCE SAVE ---
let saveTimeout = null;
const DEBOUNCE_MS = 2000; 

async function debouncedSaveDatabase() {
    if (saveTimeout) clearTimeout(saveTimeout);
    saveTimeout = setTimeout(async () => {
        try {
            if (usersDbCache) await fs.writeFile(dbPath, JSON.stringify(usersDbCache, null, 2));
            if (groupsDbCache) await fs.writeFile(groupDbPath, JSON.stringify(groupsDbCache, null, 2));
            await fs.writeFile(settingsPath, JSON.stringify(globalSettings, null, 2));
        } catch (e) {
            log.err(`Gagal menyimpan database: ${e.message}`);
        }
        saveTimeout = null;
    }, DEBOUNCE_MS);
}

// --- INIT DATABASE ---
async function initDatabase() {
    try {
        const userContent = await fs.readFile(dbPath, 'utf8').catch(() => '{}');
        usersDbCache = JSON.parse(userContent || '{}');

        const groupContent = await fs.readFile(groupDbPath, 'utf8').catch(() => '{}');
        groupsDbCache = JSON.parse(groupContent || '{}');

        const settingsContent = await fs.readFile(settingsPath, 'utf8').catch(() => '{}');
        const loadedSettings = JSON.parse(settingsContent || '{}');
        
        // Merge settings, pastikan publicMode default true jika belum ada
        globalSettings = { ...globalSettings, ...loadedSettings };
        if (typeof globalSettings.publicMode === 'undefined') globalSettings.publicMode = true;
        
        rebuildAltJidCache();
    } catch (error) {
        log.err('Database Init Error: ' + error.message);
        usersDbCache = usersDbCache || {};
        groupsDbCache = groupsDbCache || {};
        if (error.code === 'ENOENT') await debouncedSaveDatabase();
    }
}

function rebuildAltJidCache() {
    altJidCache.clear();
    if (!usersDbCache) return;
    for (const mainJid in usersDbCache) {
        const user = usersDbCache[mainJid];
        if (user.altJids && Array.isArray(user.altJids)) {
            user.altJids.forEach(alt => altJidCache.set(alt, mainJid));
        }
    }
}

async function loadDisabledFeatures() {
    try {
        const data = await fs.readFile(featuresPath, 'utf8');
        disabledFeatures = JSON.parse(data);
    } catch {
        disabledFeatures = {};
    }
    log.info(`✅ ${Object.keys(disabledFeatures).length} fitur dinonaktifkan dimuat.`);
}

async function loadPlugins() {
    if (!usersDbCache) await initDatabase();
    log.info('🔄 Memuat plugin...');
    const newPluginsCache = {};
    let pluginFiles = [];
    try {
        pluginFiles = (await fs.readdir(pluginDir)).filter(f => f.endsWith('.js'));
    } catch (e) {
        log.err("Gagal membaca plugins");
        return;
    }

    for (const file of pluginFiles) {
        const filePath = path.join(pluginDir, file);
        try {
            delete require.cache[filePath]; 
            const pluginModule = await import(`../plugins/${file}?v=${Date.now()}`); 
            const plugin = pluginModule.default || pluginModule;
            if (!plugin?.command) continue;

            const commands = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
            const category = plugin.isOwner ? 'Owner' : plugin.category || 'Uncategorized';

            for (const cmd of commands) {
                newPluginsCache[cmd.toLowerCase()] = {
                    file,
                    handler: plugin.handler,
                    isOwner: !!plugin.isOwner,
                    isPremium: !!plugin.isPremium,
                    isDisabled: disabledFeatures[cmd.toLowerCase()] || false,
                    category
                };
            }
        } catch (e) {
            log.err(`❌ Plugin error: ${file} -> ${e.message}`);
        }
    }
    pluginsCache = newPluginsCache;
    log.info(`✅ ${Object.keys(pluginsCache).length} commands dimuat.`);
}

const parseQuoted = (m, sock) => {
    const q = m.message?.extendedTextMessage?.contextInfo;
    if (!q?.quotedMessage) return;
    const mtype = Object.keys(q.quotedMessage)[0];
    const msg = q.quotedMessage[mtype];
    m.quoted = {
        type: mtype,
        id: q.stanzaId,
        sender: q.participant,
        fromMe: q.participant === sock.user.id,
        text: msg?.text || msg?.caption || '',
        message: q.quotedMessage,
        download: async () => {
            const stream = await downloadContentFromMessage(q.quotedMessage[mtype], mtype.replace('Message', ''));
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);
            return buffer;
        }
    };
};

function mapJid(incomingJid, ownerJid, ownerAltJids) {
    if (incomingJid === ownerJid || (ownerAltJids && ownerAltJids.includes(incomingJid))) return ownerJid;
    return altJidCache.get(incomingJid) || incomingJid;
}

async function sendDonationMessage(sock, jid, caption, url) {
    try {
        const imageResponse = await fetch(url);
        if (!imageResponse.ok) throw new Error(`Failed to fetch image`);
        const imageBuffer = await imageResponse.buffer();
        
        await sock.sendMessage(jid, { image: imageBuffer, caption: caption });
        return true;
    } catch (e) {
        log.err(`Gagal kirim gambar donasi: ${e.message}`);
        await sock.sendMessage(jid, { text: caption });
        return false;
    }
}

function clockString(ms) {
    let h = isNaN(ms) ? "--" : Math.floor(ms / 3600000);
    let m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
    let s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(":");
}

// --- RENTAL CHECKER ---
setInterval(async () => {
    if (!sockGlobal || !groupsDbCache) return;
    const now = Date.now();
    let isChanged = false;

    for (const groupId in groupsDbCache) {
        const group = groupsDbCache[groupId];
        if (!group.expired) continue; 
        const timeLeft = group.expired - now;
        
        // Warning H-1 Hari
        if (timeLeft > 0 && timeLeft <= 86400000 && !group.warningSent) {
            await sockGlobal.sendMessage(groupId, { text: `⚠️ *Sewa Bot Hampir Habis*\nTersisa: ${clockString(timeLeft)}. Hubungi owner untuk perpanjangan.` }).catch(() => {});
            group.warningSent = true;
            isChanged = true;
        }
        // Expired
        if (now >= group.expired) {
            await sockGlobal.sendMessage(groupId, { text: `🛑 *Masa Sewa Habis*\nBot akan keluar otomatis. Terima kasih!` }).catch(() => {});
            await new Promise(r => setTimeout(r, 3000));
            await sockGlobal.groupLeave(groupId).catch(() => {});
            delete groupsDbCache[groupId];
            isChanged = true;
        }
    }
    if (isChanged) debouncedSaveDatabase();
}, 60000); 


// --- MAIN HANDLER ---
async function Msg(sock, m) {
    try {
        sockGlobal = sock;
        if (!m || !m.message) return;
        if (m.key.fromMe) return;
        
        // [Init DB Check]
        if (!usersDbCache) await initDatabase();
        
        const start_time = Date.now();
        const now = Date.now();
        const { key, message, pushName } = m;
        const remoteJid = key.remoteJid;
        const isGroup = remoteJid.endsWith('@g.us');
        const ownerConfigJid = cfg.owner + '@s.whatsapp.net';

        m.reply = async (text, opt = {}) => sock.sendMessage(remoteJid, { text, ...opt }, { quoted: m });

        // Identifikasi Sender
        let incomingJid = isGroup ? key.participant : remoteJid;
        if (isGroup && key.participantPn && /@lid$/.test(key.participant)) incomingJid = key.participantPn;
        const finalSenderJid = mapJid(incomingJid, ownerConfigJid, cfg.ownerAltJids);
        m.sender = finalSenderJid;

        // Parsing Body (Fix NativeFlow error)
        const msgType = Object.keys(message)[0];
        let body = '';
        if (msgType === 'conversation') body = message.conversation;
        else if (msgType === 'imageMessage') body = message.imageMessage.caption;
        else if (msgType === 'videoMessage') body = message.videoMessage.caption;
        else if (msgType === 'extendedTextMessage') body = message.extendedTextMessage.text;
        else if (msgType === 'interactiveResponseMessage') {
            const interactive = message.interactiveResponseMessage;
            body = interactive.nativeFlowResponseMessage?.paramsJson 
                ? JSON.parse(interactive.nativeFlowResponseMessage.paramsJson).id 
                : (interactive.body?.text || "");
        } else if (msgType === 'templateButtonReplyMessage') body = message.templateButtonReplyMessage.selectedId;
        else if (msgType === 'buttonsResponseMessage') body = message.buttonsResponseMessage.selectedButtonId;
        
        body = body || '';
        parseQuoted(m, sock);

        // --- 1. FITUR PREFIX TRIGGER (Online Check) ---
        if (body === cfg.prefix) {
            const latensi = Date.now() - start_time;
            return m.reply(`🤖 Bot *Online*!\n⚡ Speed: ${latensi}ms`);
        }

        const isCommand = body.startsWith(cfg.prefix);
        
        // Load User Data & Init Logic
        let user = usersDbCache[finalSenderJid];
        let isDbChanged = false;
        
        if (!user) {
            user = usersDbCache[finalSenderJid] = {
                nama: pushName || 'User',
                registered: false,
                limit: globalSettings.privateLimit,
                lastLimitReset: now,
                promoSentToday: false, // Flag untuk notif harian
                premiumUntil: 0,
                status: 'guest',
                afk: -1,
                afkReason: "",
                lastDonationSent: 0
            };
            isDbChanged = true;
        } else {
            // Migrasi property baru
            if (typeof user.limit === 'undefined') { user.limit = globalSettings.privateLimit; isDbChanged = true; }
            if (typeof user.promoSentToday === 'undefined') { user.promoSentToday = false; isDbChanged = true; }
            if (typeof user.afk === 'undefined') { user.afk = -1; user.afkReason = ""; isDbChanged = true; }
        }

        // Alt Jid Check
        if (incomingJid !== finalSenderJid) {
            if (!user.altJids) user.altJids = [];
            if (!user.altJids.includes(incomingJid)) {
                user.altJids.push(incomingJid);
                altJidCache.set(incomingJid, finalSenderJid);
                isDbChanged = true;
            }
        }

        // Expired Prem Check
        if (user.premiumUntil > 0 && now > user.premiumUntil) {
            user.premiumUntil = 0;
            user.status = 'user';
            await sock.sendMessage(finalSenderJid, { text: "⚠️ Masa aktif Premium Anda telah habis." });
            isDbChanged = true;
        }

        const isOwner = finalSenderJid === ownerConfigJid;
        const isPremium = isOwner || (user.premiumUntil > 0);

        // --- 2. AFK SYSTEM (Sender & Mentions) ---
        if (user.afk > -1) {
            m.reply(`Kamu berhenti AFK${user.afkReason ? " setelah " + user.afkReason : ""} (${clockString(now - user.afk)})`);
            user.afk = -1;
            user.afkReason = "";
            isDbChanged = true;
        }
        
        let mentions = [...new Set([...(m.message?.extendedTextMessage?.contextInfo?.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])];
        for (let jid of mentions) {
            const targetJid = mapJid(jid, ownerConfigJid, cfg.ownerAltJids);
            const targetUser = usersDbCache[targetJid];
            if (targetUser && targetUser.afk > -1) {
                await m.reply(`Jangan tag dia! Sedang AFK: ${targetUser.afkReason || "Tanpa alasan"}\nSelama: ${clockString(now - targetUser.afk)}`);
            }
        }

        // --- 3. MENFESS/CONFESSION SYSTEM ---
        const quotedId = m.quoted?.id;
        if (quotedId && CONFESSION_MAP.has(quotedId)) {
            const originalSenderJid = CONFESSION_MAP.get(quotedId);
            try {
                await sock.sendMessage(originalSenderJid, { 
                    text: `💬 *Balasan Menfess*\nDari: @${remoteJid.split('@')[0]}`, 
                    mentions: [remoteJid] 
                });
                const currentMsgType = Object.keys(m.message || {})[0];
                if (currentMsgType) {
                    const payload = {};
                    payload[currentMsgType] = m.message[currentMsgType];
                    await sock.relayMessage(originalSenderJid, payload, { messageId: m.key.id });
                }
                return; 
            } catch (e) {
                log.err('Confession relay fail: ' + e.message);
            }
        }

        // --- 4. DONASI HARIAN (Gambar + Teks) ---
        if (!isGroup && !isCommand && !quotedId) {
            const ONE_DAY_MS = 24 * 60 * 60 * 1000;
            const timeSinceLastDonation = now - (user.lastDonationSent || 0);

            if (timeSinceLastDonation >= ONE_DAY_MS) {
                const DONATION_URL = 'https://cdn.jsdelivr.net/gh/rhamt24/zalxzhu.github.io/images/1764680372103.png';
                const DONATION_CAPTION = 
                    "Halo! 😊 Terima kasih telah menggunakan bot ini.\n\n" +
                    "Untuk membantu kelangsungan biaya server, kami menerima donasi seikhlasnya. " +
                    "Donasi Anda sangat berarti! 🙏\n\n" +
                    "(Pesan ini muncul 1x dalam 24 jam)";

                sendDonationMessage(sock, finalSenderJid, DONATION_CAPTION, DONATION_URL)
                    .then(sent => {
                        if (sent) {
                            user.lastDonationSent = now;
                            debouncedSaveDatabase();
                        }
                    });
            }
        }

        // --- 5. LOGIKA PUBLIC MODE, LIMIT & PROMO ---
        if (!isGroup && !isOwner && !isPremium) {
            
            // A. Cek PUBLIC Mode (Jika OFF, abaikan chat private)
            if (!globalSettings.publicMode) return; 

            // B. Reset Limit Harian & Promo Flag
            const lastDate = new Date(user.lastLimitReset).getDate();
            const currDate = new Date(now).getDate();
            if (lastDate !== currDate) {
                user.limit = globalSettings.privateLimit;
                user.lastLimitReset = now;
                user.promoSentToday = false; 
                isDbChanged = true;
            }

            // C. Logika Limit vs Promo (Hanya saat Command)
            if (isCommand) {
                if (globalSettings.limitMode) {
                    if (user.limit <= 0) {
                        if (!user.promoSentToday) {
                            await m.reply(`🛑 *Limit Harian Habis*\n\nLimit kamu hari ini sudah habis. Untuk akses tanpa batas:\n💎 *Beli Premium*\n👥 *Join Grup Bot*\n\n🔗 ${globalSettings.groupLink}`);
                            user.promoSentToday = true;
                            debouncedSaveDatabase();
                        }
                        return; // Blokir command
                    }
                    user.limit -= 1;
                    isDbChanged = true;
                } 
                else {
                    if (!user.promoSentToday) {
                        const welcomeMsg = `👋 Halo Kak ${pushName}!\n\nBot dapat digunakan GRATIS di sini. Namun agar lebih stabil, yuk:\n💎 *Upgrade Premium*\n👥 *Join Grup Official*\n\n🔗 ${globalSettings.groupLink}\n\n_(Pesan ini hanya muncul 1x hari ini)_`;
                        await sock.sendMessage(finalSenderJid, { text: welcomeMsg });
                        user.promoSentToday = true;
                        isDbChanged = true;
                    }
                }
            }
        }
        
        if (isDbChanged) debouncedSaveDatabase();
        if (!isCommand) return;
        
        const rawBody = body.slice(cfg.prefix.length).trim();
        const args = rawBody.split(/ +/);
        const cmd = args.shift()?.toLowerCase();
        if (!cmd) return;

        // --- OWNER COMMANDS (UPDATE) ---
        if (isOwner) {
            switch (cmd) {
                // ✅ FITUR JOIN ANTI-SUSPEND (HUMANIZED)
                case 'join': {
                    if (!args[0] || !args[1]) return m.reply(`❌ Format: ${cfg.prefix}join <link> <hari>`);
                    const days = parseInt(args[1]);
                    if (isNaN(days)) return m.reply('❌ Hari harus angka.');
                    
                    const codeMatch = args[0].match(/chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i);
                    const code = codeMatch ? codeMatch[1] : null;

                    if (!code) return m.reply('❌ Link grup tidak valid/tidak terbaca.');

                    try {
                        // 1. Join ke Grup
                        const res = await sock.groupAcceptInvite(code);
                        if (!res) throw new Error("Gagal join (Unknown)");
                        
                        groupsDbCache[res] = {
                            id: res,
                            expired: now + (days * 24 * 3600 * 1000),
                            joinedAt: now,
                            warningSent: false
                        };
                        
                        m.reply(`✅ Sukses join ke grup ID: ${res}\n⏳ Memproses pesan sambutan (Human Behavior)...`);
                        
                        // --- TEKNIK ANTI-SUSPEND ---
                        // 2. Jeda acak seolah sedang loading chat
                        const loadingDelay = Math.floor(Math.random() * 3000) + 3000;
                        await new Promise(r => setTimeout(r, loadingDelay));

                        // 3. Simulasi "Sedang Mengetik..."
                        await sock.sendPresenceUpdate('composing', res);
                        
                        const typingDelay = Math.floor(Math.random() * 2000) + 3000;
                        await new Promise(r => setTimeout(r, typingDelay));

                        // 4. Kirim Pesan Sambutan
                        await sock.sendMessage(res, { 
                            text: `✅ *Bot Berhasil Join!*\n\nSewa aktif selama: ${days} Hari.\nKetik *${cfg.prefix}menu* untuk memulai.` 
                        });
                        
                        // 5. Berhenti mengetik
                        await sock.sendPresenceUpdate('paused', res);

                        debouncedSaveDatabase();
                    } catch (e) {
                        m.reply(`❌ Gagal join: Pastikan link benar dan bot tidak diblokir.\nLog: ${e.message}`);
                    }
                    return;
                }

                // ✅ FITUR RESET LIMIT SEMUA USER
                case 'resetalllimit':
                case 'resetlimitall': {
                    if (!usersDbCache) return m.reply('Database belum siap.');
                    let totalUsers = 0;
                    for (const jid in usersDbCache) {
                        usersDbCache[jid].limit = globalSettings.privateLimit;
                        usersDbCache[jid].promoSentToday = false; 
                        totalUsers++;
                    }
                    debouncedSaveDatabase();
                    m.reply(`✅ Sukses mereset limit ${totalUsers} user ke default (${globalSettings.privateLimit}).`);
                    return;
                }

                // ✅ PENGATURAN PUBLIC MODE
                case 'public': {
                    if (!args[0]) return m.reply(`Mode Public: *${globalSettings.publicMode ? 'ON' : 'OFF'}*\n(ON = Respon PC & Group)\n(OFF = Hanya Respon Group)\nSet: ${cfg.prefix}public on/off`);
                    const isPublic = args[0].toLowerCase() === 'on';
                    globalSettings.publicMode = isPublic;
                    m.reply(`✅ Public Mode diubah ke: *${isPublic ? 'ON (Bisa PC)' : 'OFF (Hanya Group)'}*`);
                    debouncedSaveDatabase();
                    return;
                }

                case 'limitmode': {
                    if (!args[0]) return m.reply(`Mode Limit: *${globalSettings.limitMode ? 'ON' : 'OFF'}*\n(ON = Ada limit, OFF = Bebas + Promo)\nSet: ${cfg.prefix}limitmode on/off`);
                    globalSettings.limitMode = args[0] === 'on';
                    m.reply(`✅ Limit Mode: *${globalSettings.limitMode ? 'ON' : 'OFF'}*`);
                    debouncedSaveDatabase();
                    return;
                }

                case 'setlimit': {
                    const num = parseInt(args[0]);
                    if (isNaN(num)) return m.reply(`Limit PC saat ini: ${globalSettings.privateLimit}`);
                    globalSettings.privateLimit = num;
                    m.reply(`✅ Limit default user diubah ke: ${num}\nGunakan .resetalllimit untuk menerapkan ke semua user sekarang.`);
                    debouncedSaveDatabase();
                    return;
                }

                case 'reload': {
                    await loadPlugins();
                    m.reply('✅ Plugins reloaded');
                    return;
                }

                case 'disable': {
                    if (!args[0]) {
                        let text = `📜 *List Fitur*\n\n`;
                        text += Object.keys(pluginsCache).sort().join('\n- ');
                        return m.reply(text);
                    }
                    const targetCmd = args[0].toLowerCase();
                    disabledFeatures[targetCmd] = true;
                    await fs.writeFile(featuresPath, JSON.stringify(disabledFeatures, null, 2));
                    if (pluginsCache[targetCmd]) pluginsCache[targetCmd].isDisabled = true;
                    m.reply(`✅ ${targetCmd} dimatikan.`);
                    return;
                }

                case 'enable': {
                    const targetCmd = args[0].toLowerCase();
                    delete disabledFeatures[targetCmd];
                    await fs.writeFile(featuresPath, JSON.stringify(disabledFeatures, null, 2));
                    if (pluginsCache[targetCmd]) pluginsCache[targetCmd].isDisabled = false;
                    m.reply(`✅ ${targetCmd} dihidupkan.`);
                    return;
                }
            }
        }

        // --- PLUGIN EXECUTION ---
        const pluginEntry = pluginsCache[cmd];
        if (!pluginEntry) return;

        // Group Admin Check
        let isAdmin = isOwner;
        if (isGroup && !isOwner) {
            const cacheKey = remoteJid;
            if (groupAdminCache[cacheKey] && now < groupAdminCache[cacheKey].expiry) {
                const p = groupAdminCache[cacheKey].participants.find(x => x.id === m.sender);
                isAdmin = !!(p?.admin);
            } else {
                try {
                    const meta = await sock.groupMetadata(remoteJid);
                    groupAdminCache[cacheKey] = { participants: meta.participants, expiry: now + CACHE_TTL };
                    const p = meta.participants.find(x => x.id === m.sender);
                    isAdmin = !!(p?.admin);
                } catch { isAdmin = false; }
            }
        }

        if (pluginEntry.isDisabled) return m.reply('🚫 Fitur nonaktif.');
        if (pluginEntry.isOwner && !isOwner) return m.reply('🚫 Khusus Owner.');
        if (pluginEntry.isPremium && !isPremium) return m.reply('🚫 Khusus Premium.');

        await pluginEntry.handler({
            sock, msg: m, args, command: cmd, from: remoteJid, pushName,
            isOwner, isPremium, db: usersDbCache, saveDatabase: debouncedSaveDatabase,
            sender: m.sender, isGroup, isAdmin
        });

    } catch (e) {
        log.err(`Msg Error: ${e.message}`);
    }
}

export { loadPlugins, loadDisabledFeatures, pluginsCache, CONFESSION_MAP };
export default Msg;
