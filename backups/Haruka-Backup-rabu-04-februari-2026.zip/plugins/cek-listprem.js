const handler = async ({ msg, isOwner, sender, db }) => { 
    if (!isOwner) return msg.reply('🚫 *Command ini hanya untuk Owner.*');
    
    const now = Date.now();
    let premiumUsers = [];
    let mentions = []; // Array untuk menampung JID agar jadi Tag Hijau
    
    // Loop database memory
    for (const jid in db) {
        const user = db[jid];
        if (!user) continue;

        const isUserPremium = user.premiumUntil && user.premiumUntil > now;
        
        // Cek Owner
        if (jid === sender) {
            premiumUsers.push({
                jid: jid,
                name: user.nama || 'Owner',
                expiry: 'PERMANEN (Owner)',
                isOwner: true
            });
            mentions.push(jid);
            continue;
        }

        // Cek User Premium
        if (isUserPremium) {
            const expiryDate = new Date(user.premiumUntil);
            const formattedDate = expiryDate.toLocaleDateString('id-ID', {
                year: 'numeric', month: 'short', day: 'numeric',
                hour: '2-digit', minute: '2-digit',
                timeZone: 'Asia/Jakarta'
            });
            
            premiumUsers.push({
                jid: jid,
                name: user.nama || 'User',
                expiry: formattedDate,
                isOwner: false
            });
            mentions.push(jid);
        }
    }
    
    // Urutkan: Owner paling atas
    premiumUsers.sort((a, b) => (a.isOwner === b.isOwner) ? 0 : a.isOwner ? -1 : 1);

    let txt = 'H͟a͟r͟u͟k͟a͟ \n\n💎 *DAFTAR PENGGUNA PREMIUM AKTIF* 💎\n\n';
    
    if (premiumUsers.length === 0) {
        txt += 'Tidak ada pengguna premium yang tercatat.';
    } else {
        premiumUsers.forEach((u, i) => {
            // Format Tag Hijau: @Nomor (Nama)
            txt += `${i + 1}. @${u.jid.split('@')[0]} (${u.name})\n`;
            txt += `   📅 Exp: ${u.expiry}\n`;
        });
        txt += `\n*Total:* ${premiumUsers.length} pengguna.`;
    }

    // Kirim dengan parameter mentions agar tag berfungsi
    msg.reply(txt, { mentions: mentions });
};

export default {
    command: ['listprem', 'premlist'],
    handler: handler,
    isOwner: true, 
    description: 'Menampilkan daftar pengguna premium aktif dengan tag.'
};
