import skr from 'chikaa-js';

export default {
  command: ['tiktok', 'tt', 'ttnowm', 'ttslide', 'ttphoto', 'ttmp3'],
  description: 'Download video/foto/audio dari TikTok',
  category: 'Downloader',
  handler: async ({ sock, msg, args, from, command }) => {
    const text = args.join(' ');
    
    if (!text) {
      return sock.sendMessage(from, {
        text: `📌 Masukkan link TikTok!\n\nContoh Video:\n*.tiktok https://vt.tiktok.com/xxxxx*\n\nContoh Audio saja:\n*.ttmp3 https://vt.tiktok.com/xxxxx*`
      }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    try {
      const cls = new skr();
      const scraper = new cls.Scraper();
      const result = await scraper.Tiktok.download(text);

      if (!result) {
        return sock.sendMessage(from, {
          text: '❌ Gagal mengunduh. Pastikan link TikTok valid.'
        }, { quoted: msg });
      }

      // Metadata Info
      const captionPrefix = "H͟a͟r͟u͟k͟a͟ *tiktok downloader*\n\n";
      const title = result.title || 'TikTok Media';
      const author = result.author?.nickname || result.author?.username || 'Unknown';
      const duration = result.duration || 0;

      const fullCaption = `${captionPrefix}📝 *Title:* ${title}\n👤 *Author:* ${author}\n⏱️ *Durasi:* ${duration}s`;

      // --- LOGIKA UTAMA ---

      // 1. JIKA COMMAND KHUSUS AUDIO (.ttmp3)
      if (command === 'ttmp3') {
        if (!result.music) {
          return sock.sendMessage(from, { text: '❌ Audio tidak tersedia untuk postingan ini.' }, { quoted: msg });
        }
        
        await sock.sendMessage(from, { 
          audio: { url: result.music }, 
          mimetype: 'audio/mpeg',
          ptt: false, // Kirim sebagai audio file (bukan voice note)
          contextInfo: {
            externalAdReply: {
              title: title,
              body: author,
              thumbnailUrl: result.cover || result.musicInfo?.cover,
              sourceUrl: text,
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }, { quoted: msg });
        
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
        return; // Selesai, jangan lanjut ke bawah
      }

      // 2. JIKA COMMAND BIASA (.tiktok / .tt) -> KIRIM VIDEO/FOTO + MP3

      // A. Cek Slide Foto
      if (result.images && result.images.length > 0) {
        let count = 1;
        for (const url of result.images) {
          await sock.sendMessage(from, {
            image: { url },
            caption: `${fullCaption}\n📸 *Slide:* ${count}/${result.images.length}`
          }, { quoted: msg });
          count++;
          await new Promise(res => setTimeout(res, 1500));
        }
      } 
      // B. Cek Video Biasa
      else {
        await sock.sendMessage(from, {
          video: { url: result.video },
          caption: fullCaption
        }, { quoted: msg });
      }

      // C. KIRIM MP3 (Audio Tambahan)
      // Dikirim setelah video/foto selesai terkirim
      if (result.music) {
        await sock.sendMessage(from, { 
          audio: { url: result.music }, 
          mimetype: 'audio/mpeg',
          ptt: false,
          contextInfo: {
            externalAdReply: {
              title: "H͟a͟r͟u͟k͟a͟ tiktok audio",
              body: author,
              thumbnailUrl: result.cover,
              sourceUrl: text,
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }, { quoted: msg });
      }

      await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (e) {
      console.error('[TIKTOK ERROR]', e);
      await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
      return sock.sendMessage(from, {
        text: '❌ Gagal mengunduh media TikTok.\nCoba lagi nanti.'
      }, { quoted: msg });
    }
  }
};
