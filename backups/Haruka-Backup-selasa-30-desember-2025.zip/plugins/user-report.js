import cfg from '../config/config.json' with { type: 'json' };

const cooldowns = new Map();
const COOLDOWN_SECONDS = 300; 

export default {
    command: ['lapor', 'report'],
    category: 'User', 
    isOwner: false, 
    isPremium: false,
    handler: async ({ sock, msg, args, from, pushName, sender }) => {
        
        const ownerConfigJid = cfg.owner + '@s.whatsapp.net';
        const ownerName = cfg.ownerName || "Owner Bot";
        const now = Date.now();
        
        if (cooldowns.has(sender)) {
            const expirationTime = cooldowns.get(sender) + COOLDOWN_SECONDS * 1000;
            if (now < expirationTime) {
                const timeLeft = Math.ceil((expirationTime - now) / 1000);
                const minutes = Math.floor(timeLeft / 60);
                const seconds = timeLeft % 60;
                
                let timeString = minutes > 0 ? `${minutes} menit ` : '';
                timeString += `${seconds} detik`;

                return msg.reply(`🚫 Fitur lapor hanya bisa digunakan setiap *${COOLDOWN_SECONDS/60} menit*. Silakan coba lagi dalam *${timeString}*.`);
            }
        }
        
        const reportBody = args.join(' ').trim();
        
        if (reportBody.length < 10) {
            return msg.reply(`
❌ Format salah atau pesan terlalu pendek.
*Gunakan:* ${cfg.prefix}lapor <pesan laporan Anda>

Contoh: ${cfg.prefix}lapor Bot error saat mencoba command .stiker di grup ini.
*Minimal 10 karakter.*
            `);
        }

        const reportMessage = `
🚨 *LAPORAN PENGGUNA BARU* 🚨

*Pelapor:* ${pushName || 'Anonim'}
*JID:* @${sender.split('@')[0]}
*Waktu:* ${new Date().toLocaleString('id-ID')}
*Dari:* ${msg.isGroup ? 'Grup' : 'Pribadi'}

*Pesan Laporan:*
\`\`\`
${reportBody}
\`\`\`
        `.trim();
        
        try {
            await sock.sendMessage(
                ownerConfigJid,
                {
                    text: reportMessage,
                    mentions: [sender]
                }
            );
            
            cooldowns.set(sender, now);
            
            await msg.reply(`
✅ Laporan Anda telah berhasil terkirim kepada Owner *${ownerName}*.
Harap bersabar menunggu tanggapan. Terima kasih atas laporannya!
Anda dapat menggunakan fitur ini lagi dalam *${COOLDOWN_SECONDS/60} menit*.
            `);
            
        } catch (e) {
            console.error("Gagal mengirim laporan ke Owner:", e);
            await msg.reply(`❌ Gagal mengirim laporan. Mungkin ada masalah dengan JID Owner di konfigurasi. Silakan hubungi Owner secara manual.`);
        }
    }
};