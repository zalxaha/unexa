import cfg from '../config/config.json' with { type: 'json' };

export default {
    command: ['donasi', 'donate', 'qris'],
    category: 'Main', 
    isOwner: false, 
    isPremium: false,
    handler: async ({ sock, msg, args, from }) => {
        
        const qrisUrl = "https://cdn.jsdelivr.net/gh/rhamt24/zalxzhu.github.io/images/1764680372103.png";
        
        const ownerName = cfg.ownerName || "Owner Bot"; 
        const ownerJid = cfg.owner + '@s.whatsapp.net';
        
        const captionText = `
*--- 💰 DONASI UNTUK BOT AGAR DAPAT SELALU ONLINE ---*

Terima kasih atas dukungan Anda! 🙏
Donasi ini sangat membantu kami agar bot tetap *online* dan berkembang.

Silakan scan *QRIS* di atas untuk donasi.
Semua donasi akan digunakan untuk biaya server dan pengembangan fitur baru.

${ownerName} (@${cfg.owner})

Terima kasih!
        `.trim();

        try {
            await sock.sendMessage(
                from,
                {
                    image: { url: qrisUrl },
                    caption: captionText,
                    mentions: [ownerJid]
                },
                { quoted: msg }
            );

        } catch (e) {
            console.error("Gagal mengirim pesan donasi:", e);
            
            await msg.reply(`
*--- 💰 DONASI UNTUK BOT AGAR DAPAT SELALU ONLINE ---*

Gagal mengambil gambar QRIS. Silakan hubungi Owner *${ownerName}* (@${cfg.owner}) melalui chat pribadi.

${captionText}
            `, { mentions: [ownerJid] });
        }
    }
};