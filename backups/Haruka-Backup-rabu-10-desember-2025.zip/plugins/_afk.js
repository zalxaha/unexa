const handler = async ({ msg, args, sender, db }) => {
    const reason = args.join(' ').trim() || 'tanpa alasan';
    const now = Date.now();

    let userEntry = db[sender];
    if (!userEntry) return;

    userEntry.afk = now;
    userEntry.afkReason = reason;

    // KODE YANG DIPERBAIKI:
    // .trim() dipindahkan ke dalam argumen msg.reply()
    await msg.reply(`
Kamu sekarang AFK!
${reason !== 'tanpa alasan' ? 'Dengan alasan: *' + reason + '*' : 'Tanpa alasan.'}
`.trim()); // <-- PERBAIKAN DI SINI
};

export default {
    command: ['afk'],
    category: 'user',
    handler
};