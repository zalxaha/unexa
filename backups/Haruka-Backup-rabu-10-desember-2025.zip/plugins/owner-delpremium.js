import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const S_WHATSAPP_NET = '@s.whatsapp.net';

function mapTargetJid(incomingJid, db) {
    if (db[incomingJid]) return incomingJid;
    
    for (const realJid in db) {
        if (db[realJid].altJids && db[realJid].altJids.includes(incomingJid)) {
            return realJid;
        }
    }
    return incomingJid;
}

const handler = async ({ msg, args, isOwner, db, saveDatabase }) => {
    
    if (!isOwner) {
        return msg.reply('🚫 *Command ini hanya untuk Owner.*');
    }

    const usage = `*Usage:*
${process.env.PREFIX || '.'}delprem <nomor/jid/@tag>
Atau balas pesan user:
${process.env.PREFIX || '.'}delprem
    
*Contoh:*
${process.env.PREFIX || '.'}delprem 6281234567890
${process.env.PREFIX || '.'}delprem @taguser
(Balas pesan user) ${process.env.PREFIX || '.'}delprem
`;

    let targetJid = null;
    let tempArgs = [...args]; 
    let mentionedJids = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

    // --- LOGIKA PENGAMBILAN TARGET JID ---
    
    // 1. PRIORITY: REPLY PESAN
    if (msg.quoted) {
        targetJid = msg.quoted.sender;
    } 
    // 2. PRIORITY: TAG USER (@tag)
    else if (mentionedJids.length > 0) {
        // Hanya ambil target pertama yang ditag
        targetJid = mentionedJids[0]; 
    }
    // 3. PRIORITY: ARGUMEN TEKS (Nomor/JID)
    else if (tempArgs[0]) {
        const possibleJidOrNumber = tempArgs[0];
        
        if (possibleJidOrNumber.includes(S_WHATSAPP_NET) || /^\d+$/.test(possibleJidOrNumber)) {
            if (!possibleJidOrNumber.includes(S_WHATSAPP_NET)) {
                targetJid = possibleJidOrNumber.replace(/[^0-9]/g, '') + S_WHATSAPP_NET;
            } else {
                targetJid = possibleJidOrNumber.split('@')[0].replace(/[^0-9]/g, '') + S_WHATSAPP_NET;
            }
        } 
    }
    
    if (!targetJid) {
        return msg.reply(usage);
    }
    
    targetJid = targetJid.split(':')[0];

    const finalTargetJid = mapTargetJid(targetJid, db);
    
    if (!db[finalTargetJid]) {
        return msg.reply(`⚠️ User dengan JID utama ${finalTargetJid} tidak ditemukan di database.`);
    }

    const userEntry = db[finalTargetJid];
    
    if (userEntry.premiumUntil === 0 || userEntry.status !== 'premium') {
         return msg.reply(`🔔 ${finalTargetJid} saat ini tidak memiliki status premium aktif.`);
    }

    userEntry.premiumUntil = 0;
    userEntry.status = userEntry.registered ? 'user' : 'guest';
    userEntry.lastPremiumNotif = 0;

    await saveDatabase();

    let replyText = `🗑️ *STATUS PREMIUM DIHAPUS*
        
👤 *User:* ${finalTargetJid}
✨ *Status Baru:* ${userEntry.status.toUpperCase()}
    
Status premium telah dihentikan secara instan.`;

    msg.reply(replyText.trim());
};

export default {
    command: ['delprem', 'hapuspremium'],
    category: 'owner',
    handler: handler,
    isOwner: true,
    isPremium: false,
    description: 'Menghapus status premium dari user tertentu.'
};
