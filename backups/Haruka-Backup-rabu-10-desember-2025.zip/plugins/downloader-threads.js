import axios from 'axios';
import { Buffer } from 'buffer'; 

const CHOCOMILK_API = 'https://chocomilk.amira.us.kg/v1/download/threads';

async function chocomilkDownloader(url) {
    try {
        if (!url.includes('https://')) throw new Error('URL harus dimulai dengan "https://".');
        
        const { data } = await axios.get(`${CHOCOMILK_API}?url=${encodeURIComponent(url)}`);
        
        if (!data || data.code !== 200 || data.success !== true || !data.data || !data.data.media) {
             throw new Error(data.error || "Media tidak ditemukan atau API gagal memproses.");
        }
        
        const mediaData = data.data.media;
        
        if (!mediaData || mediaData.length === 0) {
             throw new Error("Media tidak ditemukan di dalam respons data.");
        }
        
        const filteredMedias = mediaData.filter(media => {
            const type = media.type?.toLowerCase();
            return (type === 'video' || type === 'image') && media.url;
        }).map(media => ({
            url: media.url,
            type: media.type.toLowerCase()
        }));

        if (filteredMedias.length === 0) {
             throw new Error("Tidak ada media video atau gambar yang valid ditemukan.");
        }
        
        return filteredMedias;
        
    } catch (error) {
        // CATAT error detail ke konsol (untuk owner)
        const errorMessage = error.response?.data ? JSON.stringify(error.response.data) : error.message;
        console.error(`[THREADS CHOCOMILK API ERROR] ${errorMessage}`);
        
        // LEMPAR error generik (untuk pengguna)
        throw new Error("Gagal mengambil data dari server download (Threads).");
    }
}


const handler = async ({ sock, msg, from, command, args }) => {
    
    const text = args.join(' ').trim();
    
    if (!text || (!text.includes('threads.net') && !text.includes('threads.com'))) {
        return sock.sendMessage(from, { text: `❌ URL tidak valid. Masukkan link Threads!\n\nContoh:\n*.${command} https://www.threads.net/@user/post/XXX*` }, { quoted: msg });
    }

    const MAX_OUTER_RETRIES = 2;
    let sentCount = 0;
    let finalError = null;
    
    for (let outerAttempt = 1; outerAttempt <= MAX_OUTER_RETRIES; outerAttempt++) {
        try {
            await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

            const medias = await chocomilkDownloader(text);
            
            if (medias.length === 0) {
                await sock.sendMessage(from, { text: "Tidak ada media yang ditemukan di postingan ini." }, { quoted: msg });
                sentCount = 1; 
                break; 
            }
                
            let currentSentCount = 0;
            const MAX_INNER_RETRIES = 3;
            
            for (const media of medias) {
                const url = media.url;
                if (!url) continue; 
                
                let mediaBuffer = null;
                const isVideo = media.type === 'video'; 
                let innerAttempt = 0;
                
                while (innerAttempt < MAX_INNER_RETRIES) {
                    innerAttempt++;
                    try {
                        const response = await axios.get(url, {
                            responseType: 'arraybuffer'
                        });
                        mediaBuffer = Buffer.from(response.data);
                        break; 
                    } catch (bufferError) {
                        // CATAT error detail download buffer ke konsol (untuk owner)
                        console.error(`[DOWNLOAD BUFFER ERROR] Percobaan ${innerAttempt}/${MAX_INNER_RETRIES} gagal untuk URL: ${url}. Error: ${bufferError.message}`);
                        
                        if (innerAttempt < MAX_INNER_RETRIES) {
                            await new Promise(resolve => setTimeout(resolve, 1000 * innerAttempt)); 
                        }
                    }
                }
                
                if (!mediaBuffer) continue; 
                
                const finalCaption = isVideo ? "Ini kak video nya" : "Ini kak gambar nya";

                if (isVideo) {
                    await sock.sendMessage(from, { video: mediaBuffer, caption: finalCaption }, { quoted: msg });
                } else {
                    await sock.sendMessage(from, { image: mediaBuffer, caption: finalCaption }, { quoted: msg });
                }
                currentSentCount++;
            }
            
            sentCount = currentSentCount;

            if (sentCount > 0) {
                break; 
            } else if (outerAttempt < MAX_OUTER_RETRIES) {
                 finalError = new Error(`Semua media gagal diunduh pada percobaan API ke-${outerAttempt}. Mencoba mengambil URL baru...`);
                 console.error(finalError.message);
                 await new Promise(resolve => setTimeout(resolve, 2000)); 
            }
            
        } catch (e) {
            finalError = e;
            // CATAT error detail ke konsol
            console.error(`[THREADS DL OUTER ERROR] Percobaan ${outerAttempt}/${MAX_OUTER_RETRIES} gagal. Pesan: ${e.message}`);
            
            if (outerAttempt < MAX_OUTER_RETRIES) {
                await new Promise(resolve => setTimeout(resolve, 2000)); 
            }
        }
    }

    if (sentCount > 0) {
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
    } else {
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        // KIRIM pesan error generik ke pengguna
        const errorMessage = finalError?.message?.includes("Gagal mengambil data dari server") 
            ? finalError.message 
            : `Gagal memproses link Anda setelah ${MAX_OUTER_RETRIES} kali percobaan. Mohon coba lagi atau pastikan link publik.`;
        
        await sock.sendMessage(from, { text: `❌ ${errorMessage}` }, { quoted: msg });
    }
};

export default {
    command: ["threads", "thrd", "th"],
    description: 'Download media (gambar/video) dari postingan Threads menggunakan Chocomilk API.',
    category: 'downloader', 
    handler,
};
