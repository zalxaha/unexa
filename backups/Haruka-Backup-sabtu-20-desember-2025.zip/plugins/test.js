import crypto from "node:crypto";
import * as baileys from "@whiskeysockets/baileys"; 

const cooldowns = new Map();

async function groupStatus(sock, jid, content) {
    const { backgroundColor } = content;
    delete content.backgroundColor;

    const inside = await baileys.generateWAMessageContent(content, {
        upload: sock.waUploadToServer, 
        backgroundColor
    });

    const messageSecret = crypto.randomBytes(32);

    const m = baileys.generateWAMessageFromContent(
        jid,
        {
            messageContextInfo: { messageSecret },
            groupStatusMessageV2: {
                message: {
                    ...inside,
                    messageContextInfo: { messageSecret }
                }
            }
        },
        {}
    );

    await sock.relayMessage(jid, m.message, { messageId: m.key.id });
    return m;
}

const handler = async ({ sock, msg, args, command, isGroup, isAdmin, isOwner, sender }) => {
    
    const remoteJid = msg.key.remoteJid;
    const q = msg.quoted ? msg.quoted : msg;
    const caption = args.join(' ').trim();

    if (!isGroup) {
        return msg.reply('❌ Perintah ini hanya bisa digunakan di dalam grup.');
    }

    if (!isAdmin) {
        return msg.reply('🛡️ Maaf, perintah ini hanya untuk Admin Grup.');
    }

    if (!isOwner) {
        const now = Date.now();
        const cooldownAmount = 5000; 
        
        if (cooldowns.has(sender)) {
            const expirationTime = cooldowns.get(sender) + cooldownAmount;
            if (now < expirationTime) {
                const timeLeft = (expirationTime - now) / 1000;
                return msg.reply(`⏳ Harap tunggu ${timeLeft.toFixed(1)} detik sebelum mengirim status lagi.`);
            }
        }
        cooldowns.set(sender, now);
        setTimeout(() => cooldowns.delete(sender), cooldownAmount);
    }

    let payload = {};
    
    try {
        const messageObject = q.message || q.msg;
        
        if (!messageObject) {
             if (caption) {
                 payload = { text: caption };
                 await groupStatus(sock, remoteJid, payload);
                 return await sock.sendMessage(remoteJid, { react: { text: "✅", key: msg.key } });
             } else {
                 return msg.reply(`Reply media (gambar/video) atau tambahkan teks.\n\nContoh:\n*Reply media:* ${command} Ini captionnya`);
             }
        }

        const messageType = Object.keys(messageObject)[0];
        
        if (/image|video/.test(messageType)) {
            const mediaType = messageType.replace('Message', '');
            const stream = await baileys.downloadContentFromMessage(messageObject[messageType], mediaType);
            
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            if (mediaType === 'image') {
                payload = { image: buffer, caption };
            } else if (mediaType === 'video') {
                payload = { video: buffer, caption };
            }

        } else if (/audio/.test(messageType)) {
            const stream = await baileys.downloadContentFromMessage(messageObject[messageType], 'audio');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            
            payload = { audio: buffer, mimetype: "audio/mp4" };

        } else {
            if (caption) {
                payload = { text: caption };
            } else {
                return msg.reply(`Tipe pesan tidak didukung atau tidak ada media.`);
            }
        }

        await groupStatus(sock, remoteJid, payload);

        await sock.sendMessage(remoteJid, {
            react: { text: "✅", key: msg.key }
        });

    } catch (e) {
        await sock.sendMessage(remoteJid, {
            react: { text: "❌", key: msg.key }
        });
        console.error(e);
        msg.reply("❌ Gagal mengirim status. Pastikan media valid.");
    }
};

export default {
    command: ['upswgc', 'swgc', 'swgrup'], 
    description: 'Mengirim Status (Story) ke dalam grup.',
    category: 'admin',
    handler,
};