import fs from 'fs';
import fetch from 'node-fetch';
import { writeExifImg } from '../lib/exif.js';
import cfg from '../config/config.json' with { type: "json" };

const handler = async ({ sock, msg, from, args }) => {
    const text = args.join(" ");
    if (!text) return sock.sendMessage(from,{ text:"Format:\n.brat teks"},{quoted:msg});

    await sock.sendMessage(from,{ react:{ text:"⏳", key:msg.key }});

    const url = `https://anabot.my.id/api/maker/brat?text=${encodeURIComponent(text)}&apikey=freeApikey`;
    const temp = `./temp/brat_${Date.now()}.png`;

    let result = "";

    try {
        const res = await fetch(url);
        const buffer = await res.buffer();
        fs.writeFileSync(temp, buffer);
    } catch {
        await sock.sendMessage(from,{ react:{ text:"❌", key:msg.key }});
        return sock.sendMessage(from,{ text:"API tidak merespon"},{quoted:msg});
    }

    const meta = { pack: cfg.botName || "Haruka", author: "https://zalxzhu.my.id" };

    try {
        result = await writeExifImg(fs.readFileSync(temp), meta);
        const sticker = fs.readFileSync(result);
        await sock.sendMessage(from,{ sticker },{quoted:msg});
        await sock.sendMessage(from,{ react:{ text:"✨", key:msg.key }});
    } catch {
        await sock.sendMessage(from,{ react:{ text:"❌", key:msg.key }});
        sock.sendMessage(from,{ text:"Gagal convert — cek lib/exif.js & ffmpeg"},{quoted:msg});
    } finally {
        if(fs.existsSync(temp)) fs.unlinkSync(temp);
        if(result && fs.existsSync(result)) fs.unlinkSync(result);
    }
};

export default {
    command:["brat"],
    category:"Sticker",
    description:"Buat stiker brat dari teks",
    handler
};