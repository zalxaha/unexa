import axios from 'axios';

export default {
  command: ['dl', 'dwn', 'download'],
  description: 'All-in-One Downloader (TikTok, IG, FB)',
  category: 'Downloader',
  handler: async ({ sock, msg, args, from }) => {
    const text = args.join(' ');
    
    if (!text) {
      return sock.sendMessage(from, {
        text: '📌 Masukkan link media!\nContoh: *.dl https://www.instagram.com/reel/xxxxx*'
      }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    try {
      const { data: res } = await axios.get(`https://api.nekolabs.web.id/downloader/aio/v1?url=${encodeURIComponent(text)}`);

      if (!res.success || !res.result || !res.result.medias) {
        throw new Error('Media tidak ditemukan atau link tidak didukung.');
      }

      const data = res.result;
      
      // Logic pemilihan media terbaik berdasarkan platform
      let selectedMedia = data.medias.find(m => m.quality === 'hd_no_watermark') || // TikTok HD
                          data.medias.find(m => m.quality === 'HD') ||              // FB HD
                          data.medias.find(m => m.quality === 'no_watermark') ||    // TikTok Biasa
                          data.medias.find(m => m.type === 'video') ||              // IG / Lainnya
                          data.medias[0];                                           // Fallback

      const caption = `✅ *Success Download*\n\n` +
                      `👤 *Author:* ${data.author || data.owner?.username || '-'}\n` +
                      `📌 *Title:* ${data.title || '-'}\n` +
                      `🌐 *Source:* ${data.source || '-'}`;

      if (selectedMedia.type === 'video' || selectedMedia.extension === 'mp4') {
        await sock.sendMessage(from, {
          video: { url: selectedMedia.url },
          caption: caption
        }, { quoted: msg });
      } else if (selectedMedia.type === 'image' || ['jpg', 'png', 'jpeg'].includes(selectedMedia.extension)) {
        await sock.sendMessage(from, {
          image: { url: selectedMedia.url },
          caption: caption
        }, { quoted: msg });
      } else {
        await sock.sendMessage(from, {
          document: { url: selectedMedia.url },
          mimetype: 'video/mp4',
          fileName: `${data.source || 'download'}.mp4`,
          caption: caption
        }, { quoted: msg });
      }

      await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (e) {
      console.error(e);
      await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
      return sock.sendMessage(from, {
        text: `❌ Gagal: ${e.message}`
      }, { quoted: msg });
    }
  }
};