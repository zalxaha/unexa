import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

// --- [ SETUP PATH & DATABASE ] ---

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const userDataFile = path.join(__dirname, '../data/userData.json');
let userData = {}; 

async function loadUserData() {
  try {
    const content = await fs.readFile(userDataFile, 'utf8');
    const trimmedContent = content.trim();
    if (trimmedContent.length > 0) {
        userData = JSON.parse(trimmedContent);
    } else {
        userData = {};
    }
  } catch (e) {
    if (e.code === 'ENOENT') {
        // Jika file tidak ada, tidak perlu melakukan apa-apa, akan menggunakan objek kosong
    }
    userData = {};
  }
}

async function saveUserData() {
    await fs.writeFile(userDataFile, JSON.stringify(userData, null, 2), 'utf8');
}

// --- [ KONSTANTA ] ---
const COOLDOWN_PLAY = 4 * 3600000; // 4 jam
const HAPPINESS_GAIN = 15;
const STRESS_DECREASE_WIFE = 10;

// --- [ HELPER FUNCTIONS ] ---

function formatRemainingTime(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    
    let parts = [];
    if (hours > 0) parts.push(`${hours} jam`);
    if (minutes > 0) parts.push(`${minutes} menit`);
    if (seconds > 0 && parts.length < 2) parts.push(`${seconds} detik`);
    
    return parts.length > 0 ? parts.join(' ') : 'sebentar';
}

/**
 * Mencari anak target berdasarkan nomor urut atau nama.
 * Menggunakan logika yang sama dengan yang sudah diperbaiki di marry.js.
 */
function getTargetChild(userId, args) {
    const children = userData[userId]?.children || [];
    if (children.length === 0) return null;

    const targetArg = args[0]?.trim();
    
    // Prioritas 1: Nomor Urut
    const targetNumber = parseInt(targetArg);
    if (!isNaN(targetNumber) && targetNumber >= 1 && targetNumber <= children.length) {
        const index = targetNumber - 1;
        return { child: children[index], childIndex: index };
    }

    // Prioritas 2: Nama
    const targetName = args.join(' ').trim().toLowerCase();
    
    if (targetName) {
        const index = children.findIndex(c => c.name.toLowerCase().includes(targetName));
        if (index !== -1) {
            return { child: children[index], childIndex: index };
        }
    }
    
    // Prioritas 3: Jika tidak ada argumen, ambil yang pertama
     if (args.length === 0) {
        return { child: children[0], childIndex: 0 };
    }

    return null; // Anak tidak ditemukan
}

/**
 * Mendapatkan waifu berdasarkan nama ibu.
 */
function getWaifuByMotherName(userId, motherName) {
    const waifus = userData[userId]?.waifus || [];
    return waifus.find(w => w.name === motherName);
}


// --- [ HANDLER UTAMA ] ---

const handler = async ({ msg, args, command, pushName, sender, isUserRegistered }) => {
    
    if (!sender) return; 
    const user = sender; 
    
    await loadUserData(); 
    
    if (!userData[user] || !userData[user].children || userData[user].children.length === 0) {
        return msg.reply('Anda belum memiliki anak! Gunakan *.waifu senggama* untuk mencoba.');
    }
    
    const children = userData[user].children;
    const subCommand = args[0]?.toLowerCase(); 

    // --- INISIALISASI PROPERTI ANAK (Guard untuk database lama) ---
    // Memastikan setiap anak memiliki properti happiness dan lastPlay
    let dbModified = false;
    children.forEach(child => {
        if (typeof child.happiness !== 'number') {
            child.happiness = 50; 
            dbModified = true;
        }
        if (typeof child.lastPlay !== 'number') {
            child.lastPlay = 0;
            dbModified = true;
        }
    });
    if (dbModified) {
        await saveUserData();
    }
    // -----------------------------------------------------------


    // ===================================
    // 1. COMMAND: LIST (Status Anak)
    // ===================================
    if (subCommand === 'list' || subCommand === 'status' || !subCommand) {
        let statusText = `👶 *DAFTAR ANAK (${children.length})*\n\n`;
        statusText += `Ayah: @${user.split('@')[0]}\n`;
        statusText += `--------------------------\n`;

        children.forEach((c, index) => {
            const happinessIcon = c.happiness >= 80 ? '😄' : c.happiness >= 50 ? '🙂' : '😔';
            const ageDisplay = `${c.age === 0 ? 'Bayi' : `${c.age} tahun`}`;

            statusText += `*${index + 1}. ${c.name}* (${c.gender})\n`;
            statusText += `   - Ibu: ${c.mother}\n`;
            statusText += `   - Happiness: ${c.happiness}/100 ${happinessIcon}\n`;
            statusText += `   - Status: ${ageDisplay} (Lahir ${c.birthDate})\n`;
            statusText += `--------------------------\n`;
        });
        
        statusText += `\nGunakan *.child play [No/Nama]* untuk berinteraksi.`;

        return msg.reply(statusText);
    }

    // ===================================
    // 2. COMMAND: PLAY (Bermain dengan Anak)
    // ===================================
    if (subCommand === 'play') {
        
        const targetArgs = args.slice(1);
        const target = getTargetChild(user, targetArgs);

        if (!target) {
            return msg.reply('❌ Anak tidak ditemukan. Gunakan *.child list* untuk melihat daftar anak.');
        }
        
        const { child, childIndex } = target;
        
        const cooldownTime = COOLDOWN_PLAY; 
        const lastPlay = child.lastPlay || 0; 
        
        if (Date.now() - lastPlay < cooldownTime) {
            const remaining = (lastPlay + cooldownTime) - Date.now();
            return msg.reply(`*${child.name}* sedang tidur siang/fokus belajar. Anda bisa bermain lagi dengannya dalam ${formatRemainingTime(remaining)}.`);
        }
        
        // Cari waifu (ibu) untuk efek pengurangan stress
        const motherWaifu = getWaifuByMotherName(user, child.mother);

        child.happiness = Math.min(100, child.happiness + HAPPINESS_GAIN);
        child.lastPlay = Date.now();
        
        let resultText = `Anda menghabiskan waktu berkualitas dengan bermain bersama *${child.name}*.\n\n`;
        resultText += `*${child.name}* sangat senang! Happiness ⬆️ +${HAPPINESS_GAIN}. (Saat ini: ${child.happiness}/100)\n`;

        if (motherWaifu) {
            const oldStress = motherWaifu.stress || 0;
            motherWaifu.stress = Math.max(0, oldStress - STRESS_DECREASE_WIFE);
            
            resultText += `*${child.mother}* (Ibu) merasa lega melihat kalian akur. Stressnya ⬇️ -${STRESS_DECREASE_WIFE}. (Saat ini: ${motherWaifu.stress}/100)\n`;
        } else {
            resultText += `*Waifu (Ibu) tidak ditemukan.* (Mungkin sudah dicerai/ditalak.)\n`;
        }

        // Simpan perubahan
        userData[user].children[childIndex] = child;
        await saveUserData();
        
        return msg.reply(resultText);
    }
    
    // ===================================
    // 3. COMMAND: HELP / USAGE
    // ===================================
     if (subCommand === 'help') {
        let help = `*CHILD CARE COMMANDS*\n\n`;
        help += `Perintah untuk berinteraksi dan mengurus anak.\n\n`;
        help += `*.child list*: Melihat status semua anak Anda (Happiness, Ibu).\n`;
        help += `*.child play [No/Nama]*: Bermain dengan anak (CD ${COOLDOWN_PLAY / 3600000} Jam). Meningkatkan Happiness anak dan mengurangi Stress waifu (ibu).\n`;
        help += `\n*NOTE*: Gunakan Nomor Urut atau Nama anak untuk memilih target.`;
        return msg.reply(help);
    }

    return msg.reply(`❌ Perintah tidak dikenal. Gunakan *.child list* atau *.child help*.`);
};

export default {
    command: ['child'],
    description: 'Mengelola interaksi dan status anak (child care).',
    category: 'fun',
    handler,
};