import axios from "axios";
import * as cheerio from "cheerio";
import { Buffer } from 'buffer';

/**
 * Object untuk scraping media dari Pinterest.
 */
const pindl = {
   /**
    * Mencoba mendapatkan data video dari URL Pin Pinterest menggunakan 2 metode.
    */
   video: async (url) => {
      try {
         const { data: a } = await axios.get(url);
         const $ = cheerio.load(a);

         // --- METODE 1: Schema Markup (Paling Bersih) ---
         const mediaDataScript = $('script[data-test-id="video-snippet"]');

         if (mediaDataScript.length) {
            try {
               const mediaData = JSON.parse(mediaDataScript.html());
               if (mediaData["@type"] === "VideoObject" && mediaData.contentUrl && mediaData.contentUrl.endsWith(".mp4")) {
                  return {
                     type: "video",
                     name: mediaData.name,
                     contentUrl: mediaData.contentUrl,
                     thumbnailUrl: mediaData.thumbnailUrl,
                     duration: mediaData.duration,
                     creator: mediaData.creator?.name,
                  };
               }
            } catch (e) {
               // Gagal parsing JSON, coba metode lain
            }
         }

         // --- METODE 2: Mencari Langsung di Script Tags (Fallback untuk Idea Pin) ---
         const appData = $('script[data-test-id="content-registry"]').html();
         if (appData) {
            // RegEx untuk mencari URL MP4 dengan resolusi tinggi di JSON/script data
            const vidMatch = appData.match(/"video_list":\s*\{.*?\"high\":\s*\{.*?\"url\":\s*\"(https:\/\/v\.pinimg\.com\/.*?.mp4)\"/i);

            if (vidMatch && vidMatch[1]) {
                // Mencari URL Thumbnail
                const thumbMatch = appData.match(/"image_medium_url":\s*\"(https:\/\/i\.pinimg\.com\/.*?)\"/i);
                
                return {
                    type: "video",
                    name: "Idea Pin Video",
                    contentUrl: vidMatch[1].replace(/\\/g, ''), // Hapus karakter escape
                    thumbnailUrl: thumbMatch ? thumbMatch[1].replace(/\\/g, '') : null,
                    duration: 'N/A',
                    creator: 'N/A',
                };
            }
         }

         return null;
      } catch (error) {
         return { error: `Error fetching video data: ${error.message}` }; 
      }
   },

   /**
    * Mencoba mendapatkan data gambar dari URL Pin Pinterest.
    */
   image: async (url) => {
      try {
         const { data: a } = await axios.get(url);
         const $ = cheerio.load(a);

         const mediaDataScript = $('script[data-test-id="leaf-snippet"]');

         if (mediaDataScript.length) {
            const mediaData = JSON.parse(mediaDataScript.html());

            if (mediaData["@type"] === "SocialMediaPosting" && mediaData.image && 
               (mediaData.image.endsWith(".png") || mediaData.image.endsWith(".jpg") || mediaData.image.endsWith(".jpeg") || mediaData.image.endsWith(".webp")) && 
               !mediaData.image.endsWith(".gif")) {
               
               return {
                  type: "image",
                  author: mediaData.author?.name,
                  headline: mediaData.headline,
                  image: mediaData.image,
               };
            }
         }

         return null;
      } catch (error) {
         return { error: "Error fetching image data" };
      }
   },

   /**
    * Mencoba mendapatkan data GIF dari URL Pin Pinterest.
    */
   gif: async (url) => {
      try {
         const { data: a } = await axios.get(url);
         const $ = cheerio.load(a);

         const mediaDataScript = $('script[data-test-id="leaf-snippet"]');

         if (mediaDataScript.length) {
            const mediaData = JSON.parse(mediaDataScript.html());

            if (mediaData["@type"] === "SocialMediaPosting" && mediaData.image && mediaData.image.endsWith(".gif")) {
               return {
                  type: "gif",
                  author: mediaData.author?.name,
                  headline: mediaData.headline,
                  gif: mediaData.image,
               };
            }
         }

         return null;
      } catch (error) {
         return { error: "Error fetching gif data" };
      }
   },

   /**
    * Fungsi utama untuk mencoba semua tipe download.
    */
   donlod: async (urlPin) => {
      let result = await pindl.video(urlPin);
      // Pastikan hasilnya ada DAN BUKAN objek error sebelum dikembalikan
      if (result && !result.error) return result; 

      result = await pindl.image(urlPin);
      if (result && !result.error) return result;

      result = await pindl.gif(urlPin);
      return (result && !result.error) ? result : { error: "No media found or recognized" };
   }
};

/**
 * Handler utama Pinterest Downloader.
 * Menggunakan scraper pindl.
 */
const handler = async ({ sock, msg, args, from, command }) => {
    let link = args[0];
    
    const PINTEREST_URL_REGEX = /(pinterest\.com\/pin\/\d+|pin\.it\/[a-zA-Z0-9]+)/i;

    if (!link || !link.match(PINTEREST_URL_REGEX) ) {
        return sock.sendMessage(from, {
            text: `❌ Masukkan link Pin Pinterest yang valid (contoh: \`pinterest.com/pin/... \` atau \`pin.it/...\`).\n\nContoh:\n*.${command} https://pin.it/XXX*`
        }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    try {
        // 1. Scraping Data Media Langsung dari Pinterest
        const mediaData = await pindl.donlod(link);

        if (mediaData.error) {
            throw new Error(mediaData.error);
        }

        let mediaUrl, mediaType, captionText;

        // 2. Tentukan URL dan Tipe berdasarkan data scraping
        if (mediaData.type === 'video') {
            mediaUrl = mediaData.contentUrl;
            mediaType = 'video';
            captionText = `*Pinterest Video Downloader*\n\nJudul: ${mediaData.name || 'N/A'}\n\n[Scraped by PinoScrape]`;
        } else if (mediaData.type === 'image') {
            mediaUrl = mediaData.image;
            mediaType = 'image';
            captionText = `*Pinterest Image Downloader*\n\nJudul: ${mediaData.headline || 'N/A'}\nAuthor: ${mediaData.author || 'N/A'}\n\n[Scraped by PinoScrape]`;
        } else if (mediaData.type === 'gif') {
            mediaUrl = mediaData.gif;
            mediaType = 'gif';
            captionText = `*Pinterest GIF Downloader*\n\nJudul: ${mediaData.headline || 'N/A'}\nAuthor: ${mediaData.author || 'N/A'}`;
        } else {
            throw new Error("Tidak dapat mengidentifikasi tipe media yang didukung (video/image/gif).");
        }

        if (!mediaUrl) {
            throw new Error("Gagal mendapatkan URL media setelah scraping.");
        }
        
        // 3. Mengunduh Buffer Media
        const response = await axios.get(mediaUrl, {
            responseType: 'arraybuffer'
        });
        const mediaBuffer = Buffer.from(response.data);

        // 4. Mengirim Media
        if (mediaType === 'video') {
            await sock.sendMessage(from, {
                video: mediaBuffer,
                mimetype: 'video/mp4',
                caption: captionText
            }, { quoted: msg });
        } else if (mediaType === 'image' || mediaType === 'gif') {
             await sock.sendMessage(from, {
                image: mediaBuffer,
                caption: captionText
            }, { quoted: msg });
        }

        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (err) {
        console.error('[PINDL HANDLER ERROR]', err.message);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        sock.sendMessage(from, {
            text: `❌ Gagal mengunduh media Pinterest.\n\nPesan: ${err.message}. Ini mungkin Idea Pin yang tidak bisa di-scrape.`
        }, { quoted: msg });
    }
};

export default {
    command: ['pindl', 'pinterestdl'],
    description: 'Download media (video/image/gif) dari link Pinterest dengan scraping langsung.',
    category: 'Downloader',
    handler,
};