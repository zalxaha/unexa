import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.join(__dirname, '../database/users.json');

// --- Helper Function: Membaca Database ---
async function readDatabase() {
  let db = {};
  try {
    const fileContent = await fs.readFile(dbPath, 'utf8');
    const trimmedContent = fileContent.trim();
    if (trimmedContent.length > 0) {
      db = JSON.parse(trimmedContent);
    } 
  } catch (error) {
    if (error.code === 'ENOENT') {
      // Jika file tidak ada, buat file kosong
      await fs.writeFile(dbPath, JSON.stringify({}));
    }
    db = {};
  }
  return db;
}

// --- Handler Utama: listprem ---
const handler = async ({ sock, msg, isOwner, sender }) => {
    
    if (!isOwner) {
        return msg.reply('🚫 *Command ini hanya untuk Owner.*');
    }
    
    const db = await readDatabase();
    const now = Date.now();
    const ownerJid = sender; // Owner JID sudah terjamin dari sender saat isOwner true
    
    let premiumUsers = [];
    
    // Iterasi melalui semua entri di database
    for (const jid in db) {
        const userEntry = db[jid];
        
        // Cek status premium
        const isUserPremium = userEntry.premiumUntil && userEntry.premiumUntil > now;
        
        // OWNER SELALU DIANGGAP PREMIUM PERMANEN
        if (jid === ownerJid) {
            premiumUsers.push({
                jid: jid,
                expiry: 'PERMANEN (Owner)'
            });
            continue;
        }

        // Jika user memiliki status premium aktif
        if (isUserPremium) {
            const expiryDate = new Date(userEntry.premiumUntil);
            const formattedDate = expiryDate.toLocaleDateString('id-ID', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            
            premiumUsers.push({
                jid: jid,
                expiry: formattedDate
            });
        }
    }
    
    let replyText = 'H͟a͟r͟u͟k͟a͟ \n\n💎 *DAFTAR PENGGUNA PREMIUM AKTIF* 💎\n\n';
    
    if (premiumUsers.length === 0) {
        replyText += 'Tidak ada pengguna premium yang tercatat selain Owner.';
    } else {
        premiumUsers.forEach((user, index) => {
            replyText += `${index + 1}. JID: ${user.jid.split('@')[0]}\n`;
            replyText += `   Berakhir: ${user.expiry}\n`;
        });
        
        replyText += `\n*Total:* ${premiumUsers.length} pengguna (termasuk Owner).`;
    }

    // Kirim balasan
    msg.reply(replyText);
};

export default {
    command: ['listprem', 'premlist'],
    handler: handler,
    isOwner: true,
    isPremium: false,
    description: 'Menampilkan daftar semua pengguna premium aktif.'
};