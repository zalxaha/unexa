import axios from 'axios';
import FormData from 'form-data'; // Diperlukan kembali untuk FormData
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import fs from 'fs';
import path from 'path';
import { tmpdir } from 'os';
import Crypto from 'crypto';
import { Buffer } from 'buffer';

// --- HELPER FUNCTIONS ---

// Diaktifkan kembali untuk menyimpan buffer ke file sementara
function generateFileName(ext = '.mp4') {
  return path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}${ext}`);
}

// --- KONSTANTA API ANABOT ---
const ANABOT_API = 'https://anabot.my.id/api/ai/videoEnhance';
const ANABOT_API_KEY = 'freeApikey'; 

/**
 * Mengirim video sebagai file stream (multipart/form-data) ke API Anabot.
 * CATATAN: Metode ini bergantung pada API Anabot yang sebenarnya mendukung pengiriman file
 * dan bukan hanya Base64. Jika API hanya menerima Base64, kode ini akan gagal
 * dengan error yang berbeda (misalnya 400 Bad Request).
 * * @param {string} filePath Path ke video lokal.
 * @returns {Promise<{message: string, url: string} | Error>} Hasil proses.
 */
async function hdvid(filePath) {
  if (!fs.existsSync(filePath)) {
    throw new Error('File sementara video tidak ditemukan.');
  }
  
  try {
    const data = new FormData();
    // Menggunakan fs.createReadStream untuk mengirim file/stream
    data.append('video', fs.createReadStream(filePath)); // Asumsi nama field adalah 'video' atau 'file'
    data.append('apikey', ANABOT_API_KEY);

    const config = {
      method: 'POST',
      url: ANABOT_API,
      headers: {
        ...data.getHeaders(),
      },
      data: data,
      // Penting: Pastikan axios tidak mengubah data menjadi JSON
    };
    
    const response = await axios.request(config);
    const json = response.data; // Response axios sudah otomatis JSON jika sukses

    if (json.status) {
        let downloadUrl;
        
        // Pengambilan URL hasil yang fleksibel dari JSON
        if (json.result && json.result.url) {
            downloadUrl = json.result.url;
        } else if (json.url) {
            downloadUrl = json.url;
        } else if (typeof json.result === 'string') {
            downloadUrl = json.result;
        }

        if (downloadUrl) {
            return {
                message: 'success',
                url: downloadUrl
            };
        } else {
            throw new Error(`Link download tidak ditemukan dalam struktur respon. Respon: ${JSON.stringify(json)}`);
        }
    } else {
        throw new Error(json.message || 'API Anabot gagal memproses video.');
    }
  } catch (error) {
    // Penanganan error khusus axios, termasuk 413, 400, dll.
    if (error.response) {
         // Error dari server Anabot (misal 413, 400, 500)
        throw new Error(`Permintaan API gagal. Status: ${error.response.status}. Respon: ${JSON.stringify(error.response.data || error.response.statusText)}`);
    } else if (error.request) {
        // Permintaan dikirim, tapi tidak ada respon (misal timeout)
        throw new Error('Tidak ada respon dari server Anabot.');
    }
    throw new Error(`Gagal memproses video: ${error.message}`);
  }
}

// --- HANDLER BOT (ESM) ---

export default {
  command: ['hdvid', 'vidhd', 'enhancevid'],
  description: 'Meningkatkan kualitas video (Enhance Video) menggunakan API Anabot.',
  category: 'tools',
  
  handler: async ({ sock, msg, from, command }) => {
    
    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
    const quoted = contextInfo?.quotedMessage;
    const mediaMessage = quoted || msg.message;
    const mimeType = Object.keys(mediaMessage || {}).find(k => k.endsWith('Message')) || '';

    let filePath = null; // Kembali menggunakan filePath

    try {
        if (!mimeType.includes('video')) {
            await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
            return msg.reply('❌ Harap kirim atau balas *video* untuk di-enhance.');
        }
        
        const mediaInfo = mediaMessage[mimeType];
        
        const stream = await downloadContentFromMessage(mediaInfo, 'video');
        let chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        const videoBuffer = Buffer.concat(chunks);
        
        // Simpan Buffer ke file sementara
        filePath = generateFileName('.mp4');
        fs.writeFileSync(filePath, videoBuffer);
        
    } catch (error) {
        console.error('[HDVID DOWNLOAD ERROR]', error);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        return msg.reply('❌ Gagal mengunduh video: ' + error.message);
    }
    
    let response;
    try {
        await sock.sendMessage(from, { react: { text: '🚀', key: msg.key } });
        // Mengirim path file lokal, bukan buffer
        response = await hdvid(filePath); 
    } catch (error) {
        response = { message: error.message }; 
    } finally {
        // Hapus file sementara setelah selesai upload
        if (filePath && fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }
    }

    if (!response || response.message !== 'success' || !response.url) {
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        return msg.reply(`❌ Gagal memproses Enhance Video: ${response.message || "Terjadi kesalahan yang tidak terduga."}`);
    }

    const resultUrl = response.url;
    
    try {
        await sock.sendMessage(from, { 
            text: `✨ *Video Enhance Selesai!* (API Anabot)\n\n🔗 Link Download: ${resultUrl}\n\n*Catatan:* Video hasil mungkin terlalu besar untuk dikirim langsung oleh bot.`
        }, { quoted: msg });
        
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (e) {
        console.error('[HDVID SEND ERROR]', e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        return msg.reply('❌ Gagal mengirim link hasil: ' + e.message);
    }
  }
};