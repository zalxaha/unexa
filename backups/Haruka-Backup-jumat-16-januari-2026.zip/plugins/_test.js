import speedTest from 'speedtest-net';

export default {
    command: ['speedtest', 'speed', 'testspeed', 'bandwidth'],
    category: 'Server',
    description: 'Cek kecepatan download & upload VPS',
    isOwner: false, 
    isAdmin: false,

    handler: async ({ sock, msg, reply }) => {
        // 1. Notifikasi Proses
        await sock.sendMessage(msg.key.remoteJid, { react: { text: '🚀', key: msg.key } });
        await reply('🚀 *Sedang melakukan Speedtest...*\nMohon tunggu sekitar 10-30 detik...');

        try {
            // 2. Jalankan Speedtest
            const options = { acceptLicense: true, acceptGdpr: true };
            const result = await speedTest(options);

            // 3. Konversi Data
            const toMbps = (bps) => (bps / 1000000).toFixed(2);

            const downloadSpeed = toMbps(result.download.bandwidth * 8); 
            const uploadSpeed = toMbps(result.upload.bandwidth * 8);
            const ping = result.ping.latency.toFixed(0);
            const jitter = result.ping.jitter.toFixed(0);
            
            const ispName = result.isp;
            const serverLocation = `${result.server.name}, ${result.server.country}`;
            const host = result.server.host;
            
            // --- BAGIAN INI DIUBAH (SENSOR IP) ---
            // const ip = result.interface.externalIp; // <-- Kode lama (menampilkan IP asli)
            const ip = "xxx.xxx.xxx.xxx (Hidden)"; // <-- Kode baru (disensor)

            // 4. Susun Pesan
            const txt = `
🚀 *SPEEDTEST RESULT*

⬇️ *Download:* ${downloadSpeed} Mbps
⬆️ *Upload:* ${uploadSpeed} Mbps
📶 *Ping:* ${ping} ms (Jitter: ${jitter} ms)

---------------------------
🏢 *ISP:* ${ispName}
📍 *Server:* ${serverLocation}
🌐 *IP:* ${ip}
🖥️ *Host:* ${host}
`.trim();

            // 5. Kirim Hasil
            await sock.sendMessage(msg.key.remoteJid, { react: { text: '✅', key: msg.key } });
            await reply(txt);

        } catch (e) {
            console.error(e);
            await sock.sendMessage(msg.key.remoteJid, { react: { text: '❌', key: msg.key } });
            reply(`❌ *Speedtest Gagal!*\n\nError: ${e.message}\n\n_Pastikan VPS mengizinkan eksekusi binary speedtest._`);
        }
    }
};