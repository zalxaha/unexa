import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import cfg from '../config/config.json' assert { type: 'json' };

const PLUGINS_DIR = path.join(__dirname);
const BOT_FILENAME = path.basename(__filename);

const sanitizePath = (filename) => {
    const fullPath = path.join(PLUGINS_DIR, filename);
    if (!fullPath.startsWith(PLUGINS_DIR)) {
        throw new Error("Akses ditolak: Path traversal terdeteksi.");
    }
    return fullPath;
};

const handler = async ({ sock, msg, args, from }) => {
    const sender = msg.key.participant || msg.key.remoteJid;
    
    const authorizedJids = [
        `${cfg.owner}@s.whatsapp.net`,
        ...(cfg.ownerAltJids || [])
    ];
    
    if (!authorizedJids.includes(sender)) {
        return sock.sendMessage(from, { text: "Akses ditolak. Perintah ini hanya untuk Owner." }, { quoted: msg });
    }

    const command = args[0]?.toLowerCase();
    const filename = args[1];

    if (command === 'list') {
        try {
            const files = (await fs.readdir(PLUGINS_DIR)).filter(f => f.endsWith('.js'));
            const listText = `📁 *Daftar File Plugin:*\n\n` + files.map((f, i) => `${i + 1}. ${f}`).join('\n');
            return sock.sendMessage(from, { text: listText }, { quoted: msg });
        } catch (e) {
            return sock.sendMessage(from, { text: `❌ Gagal membaca direktori: ${e.message}` }, { quoted: msg });
        }
    }

    if (command === 'delete' || command === 'del') {
        if (!filename || !filename.endsWith('.js')) {
            return sock.sendMessage(from, { text: `Format salah. Contoh: !plugin delete downloader-fb.js` }, { quoted: msg });
        }
        if (filename === BOT_FILENAME) {
            return sock.sendMessage(from, { text: "Tidak bisa menghapus file manajer ini sendiri." }, { quoted: msg });
        }

        try {
            const filePath = sanitizePath(filename);
            await fs.unlink(filePath);
            return sock.sendMessage(from, { text: `✅ File *${filename}* berhasil dihapus.` }, { quoted: msg });
        } catch (e) {
            return sock.sendMessage(from, { text: `❌ Gagal menghapus file *${filename}*.\nDetail: ${e.message}` }, { quoted: msg });
        }
    }

    if (command === 'save' || command === 'sv') {
        if (!filename || !filename.endsWith('.js')) {
            return sock.sendMessage(from, { text: `Format salah. Contoh: !plugin save nama-plugin.js (Reply ke kode)` }, { quoted: msg });
        }

        const repliedMsg = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;
        const code = repliedMsg?.conversation || repliedMsg?.extendedTextMessage?.text;

        if (!code) {
            return sock.sendMessage(from, { text: "Anda harus me-reply pesan yang berisi kode JavaScript untuk disimpan." }, { quoted: msg });
        }

        try {
            const filePath = sanitizePath(filename);
            await fs.writeFile(filePath, code, 'utf8');
            return sock.sendMessage(from, { text: `✅ File *${filename}* berhasil disimpan atau diperbarui.\n\n_Bot mungkin perlu di-restart agar plugin terdeteksi._` }, { quoted: msg });
        } catch (e) {
            return sock.sendMessage(from, { text: `❌ Gagal menyimpan file *${filename}*.\nDetail: ${e.message}` }, { quoted: msg });
        }
    }
    
    let helpText = `*⚙️ Plugin File Manager (Owner Only)*\n\n`;
    helpText += `Gunakan format berikut:\n\n`;
    helpText += `1. Simpan/Update File:\n*!plugin save <nama_file.js>*\n_(Reply pada pesan yang berisi kode)_ \n\n`;
    helpText += `2. Hapus File:\n*!plugin delete <nama_file.js>*\n\n`;
    helpText += `3. Daftar File:\n*!plugin list*`;

    return sock.sendMessage(from, { text: helpText }, { quoted: msg });
};

export default {
    command: ['plugin', 'p'],
    description: 'Mengelola file plugin (Owner Only)',
    category: 'owner',
    handler,
};
