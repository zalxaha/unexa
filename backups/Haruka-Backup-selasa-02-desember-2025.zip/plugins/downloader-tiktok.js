import skr from 'chikaa-js';
import axios from 'axios';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

// Konfigurasi path __dirname tidak lagi diperlukan untuk DB
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default {
  command: ['tiktok', 'tt', 'ttnowm', 'ttslide', 'ttphoto', 'tiktokphoto', 'tiktokslide', 'tiktoknowm'],
  description: 'Download video/foto dari TikTok',
  category: 'Downloader',
  handler: async ({ sock, msg, args, from }) => {
    const text = args.join(' ');
    
    if (!text) {
      return sock.sendMessage(from, {
        text: '📌 Masukkan link TikTok!\nContoh: *.tiktok https://vt.tiktok.com/xxxxx*'
      }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    try {
      const cls = new skr();
      const scraper = new cls.Scraper();
      const result = await scraper.Tiktok.download(text);

      if (!result) {
        return sock.sendMessage(from, {
          text: '❌ Gagal mengunduh. Pastikan link TikTok valid.'
        }, { quoted: msg });
      }

      if (result.images && result.images.length > 0) {
        let count = 1;
        for (const url of result.images) {
          await sock.sendMessage(from, {
            image: { url },
            caption: `${result.title || 'Slide TikTok'}\n(${count}/${result.images.length})`
          }, { quoted: msg });
          count++;
          await new Promise(res => setTimeout(res, 1000));
        }
      } else {
        await sock.sendMessage(from, {
          video: { url: result.video },
          caption: result.title || 'Video TikTok'
        }, { quoted: msg });
      }

      await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
    } catch (e) {
      console.error('[TIKTOK ERROR]', e);
      return sock.sendMessage(from, {
        text: '❌ Gagal mengunduh video TikTok.\nCoba lagi nanti atau gunakan link lain.'
      }, { quoted: msg });
    }
  }
};
