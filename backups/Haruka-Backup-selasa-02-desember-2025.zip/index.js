import 'dotenv/config';
import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore
} from '@whiskeysockets/baileys';

import qr from 'qrcode-terminal';
import pino from 'pino';
import path from 'path';
import fs from 'fs/promises';
import * as fsSync from 'fs';
import { fileURLToPath } from 'url';
import { parsePhoneNumber } from 'libphonenumber-js';
import chalk from 'chalk';
import NodeCache from 'node-cache';

import log from './lib/logger.js';
import config from './config/config.json' assert { type: 'json' };

let MsgHandler;
let loadPlugins;
let loadDisabledFeatures;

try {
  const MsgModule = await import('./handlers/messageHandler.js');
  MsgHandler = MsgModule.default;
  loadPlugins = MsgModule.loadPlugins;
  loadDisabledFeatures = MsgModule.loadDisabledFeatures;

  if (typeof loadPlugins !== 'function' || typeof loadDisabledFeatures !== 'function') {
      throw new Error("loadPlugins atau loadDisabledFeatures tidak terdefinisi di messageHandler.js");
  }

} catch (e) {
  console.error(chalk.red('⚠️ Warning: Gagal import messageHandler atau fungsi cache saat start awal.'), e.message);
}

import CallHandler from './lib/call.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const sessionFolder = path.join(__dirname, 'session');
const dbPath = path.join(__dirname, 'database/users.json');

const msgRetryCounterCache = new NodeCache();

async function validatePhoneNumber(input) {
  if (!input) return null;
  try {
    let phone = String(input).replace(/[^0-9]/g, "");
    if (!phone.startsWith('+')) phone = '+' + phone;
    const pn = parsePhoneNumber(phone);
    if (!pn || !pn.isValid()) {
      log.err(chalk.redBright("❌ Nomor tidak valid. Cek config.json"));
      return null;
    }
    return pn.number.replace('+', '');
  } catch (error) {
    return null;
  }
}

async function checkDatabase() {
  try {
    await fs.access(dbPath);
    const fileContent = (await fs.readFile(dbPath, 'utf8')).trim();
    if (fileContent.length === 0) {
      await fs.writeFile(dbPath, JSON.stringify({}));
    }
  } catch (error) {
    if (error.code === 'ENOENT') {
      await fs.mkdir(path.dirname(dbPath), { recursive: true });
      await fs.writeFile(dbPath, JSON.stringify({}));
    }
  }
}

let isReady = false;

async function Start() {
  await checkDatabase();

  try {
    await fs.access(sessionFolder);
  } catch (err) {
    if (err.code === "ENOENT") {
      await fs.mkdir(sessionFolder, { recursive: true });
    }
  }

  const { state, saveCreds } = await useMultiFileAuthState(sessionFolder);
  const { version, isLatest } = await fetchLatestBaileysVersion();

  log.info(`Baileys v${version.join('.')}, latest: ${isLatest}`);

  // Simpan versi di config agar bisa diakses messageHandler untuk respons online
  if (!config.version) config.version = version.join('.'); 

  const usePairing = config.system?.pairing === true;

  const getMessageFallback = async (key) => {
      return { conversation: 'Hello' };
  };

  const sock = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })),
    },
    logger: pino({ level: 'silent' }),
    printQRInTerminal: !usePairing,
    syncFullHistory: false,
    generateHighQualityLinkPreview: true,
    patch: ['status'],
    shouldSyncHistoryMessage: () => false,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    retryRequestDelayMs: 500,
    connectTimeoutMs: 60000,
    msgRetryCounterCache, 
    getMessage: getMessageFallback
  });

  if (usePairing && !sock.authState.creds.registered) {
    setTimeout(async () => {
        const phoneNumber = await validatePhoneNumber(config.system.number);
        if (phoneNumber) {
            try {
              let code = await sock.requestPairingCode(phoneNumber);
              code = code?.match(/.{1,4}/g)?.join('-') || code;

              console.log(chalk.bgGreen.black(`\n📞 KODE PAIRING BARU:`));
              console.log(chalk.white.bold(code));
              console.log(chalk.yellow(`\n⚠️ Segera ketik kode ini di HP (Perangkat Tertaut > Tautkan dengan Nomor)\n`));

            } catch (e) {
              log.err("❌ Gagal request kode: " + e.message);
            }
        } else {
            log.err("❌ Nomor di config.json salah format/kosong!");
        }
    }, 3000);
  }

  sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr: code }) => {
    if (code && !usePairing && !sock.authState.creds.registered) {
      log.info("🔐 Scan QR Mode:");
      qr.generate(code, { small: true });
    }

    if (connection === "open") {
      isReady = true;
      log.ok("✅ Bot Terhubung!");

      if (loadDisabledFeatures) await loadDisabledFeatures();
      if (loadPlugins) await loadPlugins();

      const ownerJid = config.owner + "@s.whatsapp.net";
      try {
        await sock.sendMessage(ownerJid, { text: "✅ Bot berhasil login dan online!" });
      } catch {}
    }

    if (connection === "close") {
      isReady = false;
      const reason = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.message || "Unknown";

      log.warn(`❌ Terputus: ${reason}`);

      if (reason === DisconnectReason.loggedOut) {
        log.err("🚪 Sesi logout (Device Unlinked). Menghapus folder session...");
        try {
          await fs.rm(sessionFolder, { recursive: true, force: true });
          console.log("✅ Session terhapus. Silakan restart bot untuk scan ulang.");
          process.exit(1);
        } catch {}

      } else {
        log.info("🔁 Menghubungkan ulang...");
        Start();
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("messages.upsert", async ({ messages }) => {
    if (!isReady || !messages) return;
    const m = messages[0];
    if (!m || !m.message) return;

    try {
      if (MsgHandler) await MsgHandler(sock, m);
    } catch (err) {
      log.err(`Handler Error: ${err.message}`);
    }
  });

  sock.ev.on("call", async (calls) => {
    if (!isReady) return;
    try {
      await CallHandler.code(sock, calls);
    } catch (err) {}
  });

  fsSync.watch(path.join(__dirname, "plugins"), async (evt, filename) => {
    if (filename && filename.endsWith(".js")) {
      const timestamp = Date.now();
      try {
        const reloadedModule = await import(`./handlers/messageHandler.js?v=${timestamp}`);
        MsgHandler = reloadedModule.default;
        loadPlugins = reloadedModule.loadPlugins;
        loadDisabledFeatures = reloadedModule.loadDisabledFeatures;

        if (loadDisabledFeatures) await loadDisabledFeatures();
        if (loadPlugins) await loadPlugins();
        
        log.ok(`[RELOAD BERHASIL] ${filename} dan Plugin Cache dimuat ulang.`);
        
      } catch (e) {
        log.err("❌ Reload gagal: " + e.message);
      }
    }
  });
}

process.on("unhandledRejection", (e) => {
    if (e?.message?.includes('Bad MAC')) return;
    console.error("Unhandled Rejection:", e);
});

process.on("uncaughtException", (e) => {
    if (e?.message?.includes('Bad MAC')) return;
    console.error("Uncaught Exception:", e);
});

Start();
