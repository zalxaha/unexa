import fs from 'fs/promises';
import path from 'path';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url); // Tetap ada untuk menghapus cache yang tersisa

import log from '../lib/logger.js';
import cfg from '../config/config.json' assert { type: 'json' };

const dbPath = path.join(__dirname, '../database/users.json');
const featuresPath = path.join(__dirname, '../database/features.json');
const pluginDir = path.join(__dirname, '../plugins');

let sockGlobal = null;
const groupAdminCache = {};
const CACHE_TTL = 30000;
let pluginsCache = {};
let disabledFeatures = {};

async function readDatabase(dbPath) {
  let db = {};
  try {
    const fileContent = await fs.readFile(dbPath, 'utf8');
    const trimmedContent = fileContent.trim();
    if (trimmedContent.length > 0) {
      db = JSON.parse(trimmedContent);
    }
  } catch (error) {
    if (error.code === 'ENOENT') {
      await fs.writeFile(dbPath, JSON.stringify({}, null, 2));
    }
    db = {};
  }
  return db;
}

async function writeDatabase(dbPath, data) {
    try {
        await fs.writeFile(dbPath, JSON.stringify(data, null, 2));
    } catch (e) {
        log.err(`Gagal menulis ke database ${dbPath}: ${e.message}`);
    }
}

async function loadDisabledFeatures() {
    disabledFeatures = await readDatabase(featuresPath);
    log.info(`✅ ${Object.keys(disabledFeatures).length} fitur dinonaktifkan dimuat.`);
}

async function loadPlugins() {
    log.info('🔄 Memuat ulang/memuat plugin...');
    const newPluginsCache = {};
    let pluginFiles;
    try {
        pluginFiles = (await fs.readdir(pluginDir)).filter(f => f.endsWith('.js'));
    } catch (e) {
        log.err("Gagal membaca folder plugins");
        return;
    }

    for (const file of pluginFiles) {
        const filePath = path.join(pluginDir, file);
        try {
            // Hapus cache yang mungkin dibuat oleh require() atau sistem lama
            delete require.cache[filePath]; 
            
            // Menggunakan Dynamic Import dengan timestamp untuk Hot Reload
            const pluginModule = await import(`../plugins/${file}?v=${Date.now()}`); 
            const plugin = pluginModule.default || pluginModule;

            if (!plugin || !plugin.command) {
                log.warn(`Plugin '${file}' dilewati.`);
                continue;
            }

            const commands = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
            for (const cmd of commands) {
                newPluginsCache[cmd.toLowerCase()] = {
                    file,
                    handler: plugin.handler,
                    isOwner: !!plugin.isOwner,
                    isPremium: !!plugin.isPremium,
                    isDisabled: disabledFeatures[cmd.toLowerCase()] || false
                };
            }
        } catch (e) {
            log.err(`❌ Plugin '${file}' error saat memuat: ${e.message}`);
        }
    }

    pluginsCache = newPluginsCache;
    log.info(`✅ ${Object.keys(pluginsCache).length} commands dimuat.`);
}

const parseQuoted = (m, sock) => {
  const q = m.message?.extendedTextMessage?.contextInfo;
  if (!q?.quotedMessage) return;
  const quoted = q.quotedMessage;
  const mtype = Object.keys(quoted)[0];
  const msg = quoted[mtype];
  m.quoted = {
    type: mtype,
    mtype,
    id: q.stanzaId,
    sender: q.participant,
    fromMe: q.participant === sock.user.id,
    isBaileys: !!q.isForwarded,
    text: msg?.text || msg?.caption || '',
    message: quoted,
    download: async () => {
      const stream = await downloadContentFromMessage(quoted[mtype], mtype.replace('Message', ''));
      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }
      return buffer;
    }
  };
};

function mapJid(incomingJid, db, ownerJid, ownerAltJids) {
  if (incomingJid === ownerJid || (ownerAltJids && ownerAltJids.includes(incomingJid))) {
    return ownerJid;
  }
  for (const realJid in db) {
    if (db[realJid].altJids && db[realJid].altJids.includes(incomingJid)) {
      return realJid;
    }
  }
  return incomingJid;
}

async function Msg(sock, m) {
    try {
        sockGlobal = sock;

        if (!m || !m.message) return;
        if (m.key.fromMe) return;

        const now = Date.now();
        const { key, message, pushName } = m;
        const remoteJid = key.remoteJid;

        const isGroup = remoteJid.endsWith('@g.us');
        let incomingJid = isGroup ? key.participant : remoteJid;
        m.isGroup = isGroup;

        const originalIncomingJid = incomingJid;
        if (isGroup && key.participantPn && /@lid$/.test(key.participant)) {
            incomingJid = key.participantPn;
        }

        const msgType = Object.keys(message || {})[0];
        let body = '';

        if (msgType === 'conversation') body = message.conversation;
        else if (msgType === 'imageMessage') body = message.imageMessage.caption || '';
        else if (msgType === 'videoMessage') body = message.videoMessage.caption || '';
        else if (msgType === 'extendedTextMessage') body = message.extendedTextMessage.text || '';
        else if (msgType === 'buttonsResponseMessage') body = message.buttonsResponseMessage.selectedButtonId || '';
        else if (msgType === 'listResponseMessage') body = message.listResponseMessage.singleSelectReply?.selectedRowId || '';
        else if (msgType === 'templateButtonReplyMessage') body = message.templateButtonReplyMessage.selectedId || '';

        if (!body.startsWith(cfg.prefix)) return;
        const args = body.slice(cfg.prefix.length).trim().split(/ +/);
        if (!args[0]) return;
        const cmd = args.shift().toLowerCase();

        const ownerConfigJid = cfg.owner + '@s.whatsapp.net';
        const senderJid = mapJid(incomingJid, {}, ownerConfigJid, cfg.ownerAltJids);
        const isOwner = senderJid === ownerConfigJid;

        if (isOwner) {
            if (cmd === 'reload') {
                await loadDisabledFeatures();
                await loadPlugins();
                m.reply('✅ Semua plugin dan konfigurasi fitur dinonaktifkan berhasil dimuat ulang!');
                return;
            } else if (cmd === 'disable' || cmd === 'enable') {
                const targetCmd = args[0]?.toLowerCase();
                if (!targetCmd) return m.reply(`${cfg.prefix}${cmd} <command>`);

                const status = cmd === 'disable';
                
                if (status) {
                    disabledFeatures[targetCmd] = true;
                } else {
                    delete disabledFeatures[targetCmd];
                }
                
                await writeDatabase(featuresPath, disabledFeatures);

                if (pluginsCache[targetCmd]) {
                    pluginsCache[targetCmd].isDisabled = status;
                }
                
                m.reply(`✅ Command *${targetCmd}* berhasil di${status ? 'nonaktifkan' : 'aktifkan'}.`);
                return;
            }
        }
        
        const pluginEntry = pluginsCache[cmd];
        if (!pluginEntry) return;

        let db = await readDatabase(dbPath);
        let isDbChanged = false;

        const primaryJidToUse = (senderJid !== incomingJid && senderJid) ? senderJid : incomingJid;
        m.sender = primaryJidToUse;

        let userDbEntry = db[primaryJidToUse];
        if (!userDbEntry) {
            userDbEntry = db[primaryJidToUse] = {
                nama: pushName || 'User',
                registered: false,
                lastReset: now,
                status: 'guest',
                premiumUntil: 0,
                altJids: []
            };
            log.info(`➕ User baru dibuat: ${primaryJidToUse}`);
            isDbChanged = true;
        }

        if (originalIncomingJid !== primaryJidToUse) {
            if (!userDbEntry.altJids) userDbEntry.altJids = [];
            if (!userDbEntry.altJids.includes(originalIncomingJid)) {
                userDbEntry.altJids.push(originalIncomingJid);
                isDbChanged = true;
            }
        }

        if (!userDbEntry.premiumUntil) userDbEntry.premiumUntil = 0;
        if (userDbEntry.premiumUntil > 0 && now > userDbEntry.premiumUntil) {
            userDbEntry.premiumUntil = 0;
            userDbEntry.status = userDbEntry.registered ? 'user' : 'guest';
            log.info(`⬇️ Premium ${primaryJidToUse} habis.`);
            isDbChanged = true;
        }

        const isPremium = isOwner || (userDbEntry.premiumUntil > 0 && now < userDbEntry.premiumUntil);

        if (isPremium && userDbEntry.status !== 'premium') {
            userDbEntry.status = 'premium';
            isDbChanged = true;
        }
        
        if (isDbChanged) {
            await writeDatabase(dbPath, db);
        }
        
        const isUserRegistered = !!userDbEntry.registered;

        const participantJidForGroupCheck = key.participant || remoteJid;
        let isAdmin = isOwner;

        if (isGroup && !isOwner) {
            const cacheKey = remoteJid;
            if (groupAdminCache[cacheKey] && now < groupAdminCache[cacheKey].expiry) {
                const participant = groupAdminCache[cacheKey].participants.find(p => p.id === participantJidForGroupCheck);
                isAdmin = !!(participant?.admin === 'admin' || participant?.admin === 'superadmin');
            } else {
                try {
                    const groupMetadata = await sock.groupMetadata(remoteJid);
                    groupAdminCache[cacheKey] = {
                        participants: groupMetadata.participants,
                        expiry: now + CACHE_TTL
                    };
                    const participant = groupMetadata.participants.find(p => p.id === participantJidForGroupCheck);
                    isAdmin = !!(participant?.admin === 'admin' || participant?.admin === 'superadmin');
                } catch (e) { isAdmin = false; }
            }
        }

        parseQuoted(m, sock);
        m.reply = async (text, opt = {}) => {
            return sock.sendMessage(remoteJid, { text, ...opt }, { quoted: m });
        };

        if (pluginEntry.isDisabled) {
            return m.reply('🚫 Fitur ini sedang dinonaktifkan oleh Owner.');
        }

        if (pluginEntry.isOwner && !isOwner) {
            return m.reply('🚫 Fitur ini khusus Owner.');
        }

        if (pluginEntry.isPremium && !isPremium) {
            return m.reply('🚫 Fitur ini khusus Premium.');
        }

        try {
            log.evt(`Cmd '${cmd}' dari ${pushName || m.sender}`);
            await pluginEntry.handler({
                sock,
                msg: m,
                args,
                command: cmd,
                from: remoteJid,
                pushName,
                isOwner,
                isPremium,
                isUserRegistered,
                db,
                sender: m.sender,
                isGroup,
                isAdmin
            });
        } catch (e) {
            log.err(`❌ Plugin '${pluginEntry.file}' error: ${e.stack || e.message}`);

            const ownerJid = ownerConfigJid;
            const errorMsg = `
🚨 *SYSTEM ERROR REPORT* 🚨
User: @${m.sender.split('@')[0]} (ID: ${m.sender})
Command: *${cfg.prefix}${cmd}*
Plugin: ${pluginEntry.file}
Error:
\`\`\`
${e.stack || e.message}
\`\`\`
            `.trim();

            if (sockGlobal && ownerJid) {
                await sockGlobal.sendMessage(ownerJid, { text: errorMsg, mentions: [m.sender] });
                m.reply('❌ Terjadi *Error* saat menjalankan fitur ini. Laporan sudah dikirim ke Owner.');
            } else {
                m.reply('❌ Terjadi *Error* saat menjalankan fitur ini.');
            }
        }

    } catch (e) {
        log.err(`❌ Msg() fatal error: ${e.stack || e.message}`);
    }
}

export { loadPlugins, loadDisabledFeatures };
export default Msg;
