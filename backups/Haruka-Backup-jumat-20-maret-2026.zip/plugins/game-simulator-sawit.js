export default {
    command: ['sawit', 'sawitsimulator'],
    category: 'Game',
    description: 'Simulasi Juragan Sawit dengan sistem Mitra, Mandiri, Cuaca & Perawatan',

    handler: async ({ sock, msg, args, db, sender, saveDatabase, reply, pushName }) => {
        const user = db[sender];
        
        const COOLDOWN_CMD = 10000; 

        if (user.lastSawitCmd && (Date.now() - user.lastSawitCmd) < COOLDOWN_CMD) {
            const sisaWaktu = Math.ceil((user.lastSawitCmd + COOLDOWN_CMD - Date.now()) / 1000);
            return reply(`⏳ Tunggu ${sisaWaktu} detik sebelum menggunakan perintah ini lagi.`);
        }
        user.lastSawitCmd = Date.now();

        const subCmd = args[0]?.toLowerCase();
        const arg2 = args[1]?.toLowerCase();
        const arg3 = parseInt(args[2]);

        // Helper Random Cuaca
        const generateCuaca = () => {
            const r = Math.random();
            if (r < 0.40) return 'Cerah';
            if (r < 0.65) return 'Hujan';
            if (r < 0.90) return 'Kemarau';
            return 'Ekstrem';
        };

        // ==========================================
        // --- AUTO-FIX DATABASE (ANTI ERROR NaN) ---
        // ==========================================
        const defaultValues = {
            sawit_lahan: 0, sawit_bibit: 0, sawit_pohon: 0, sawit_pekerja: 0, 
            sawit_mess: 0, sawit_truk: 0, sawit_drainase: 0, sawit_pompa: 0, 
            sawit_pupuk: 0, sawit_pestisida: 0, sawit_keamanan: 0, sawit_riset: 0, 
            xp: 0, money: 0, sawit_panen_count: 0, sawit_last_panen: 0,
            sawit_pupuk_aktif: false, sawit_pestisida_aktif: false
        };

        for (const key in defaultValues) {
            if (typeof user[key] === 'undefined' || (typeof defaultValues[key] === 'number' && isNaN(user[key]))) {
                user[key] = defaultValues[key];
            }
        }
        if (typeof user.sawit_has_claimed_loan === 'undefined') user.sawit_has_claimed_loan = false;
        if (typeof user.sawit_is_loan === 'undefined') user.sawit_is_loan = false;
        if (!user.sawit_cuaca_next) user.sawit_cuaca_next = generateCuaca();

        // ==========================================
        // --- KONFIGURASI GAMBAR & HARGA ---
        // ==========================================
        const baseUrl = "https://cdn.jsdelivr.net/gh/rhamt24/zalxzhu.github.io/images/";
        const img = {
            default: baseUrl + "sawit.png",
            modal: baseUrl + "sawit-beri-uang.png",     
            nomodal: baseUrl + "sawit-gaboleh.png",     
            beli: baseUrl + "sawit-beli-bibit.png",     
            pajak: baseUrl + "sawit-setor-pajak.png",   
            mandiri: baseUrl + "sawit-mandiri.png"
        };

        const sendSawitCard = async (text, headerTitle, imageUrl) => {
            await sock.sendMessage(msg.key.remoteJid, {
                text: text,
                contextInfo: {
                    externalAdReply: {
                        title: headerTitle || "SAWIT SIMULATOR",
                        body: "Juragan Sawit Mobile - RPG Tycoon",
                        thumbnailUrl: imageUrl || img.default,
                        sourceUrl: 'https://whatsapp.com/channel/0029VaoNbbHAInPfk5U20C12',
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: msg });
        };

        const COOLDOWN_PANEN = 20 * 60 * 1000; 
        const MAX_POHON_PER_HA = 256;          
        const PAJAK_MITRA = 0.40;              
        const BIAYA_LUNAS = 250000000;         
        const BASE_PEKERJA = 20;
        const PEKERJA_PER_MESS = 50;
        const GAJI_POKOK = 40000; 
        const BONUS_PANEN_PERSEN = 0.05; 
        const KAPASITAS_TRUK = 1000; 
        const BIAYA_TRUK_PRIBADI = 1000; 
        const BIAYA_SEWA_TRUK = 5000; 

        const HARGA = {
            lahan: 50000000, bibit: 30000, pekerja: 2000000, mess: 50000000, truk: 150000000, 
            drainase: 10000000, pompa: 15000000, pupuk: 25000, pestisida: 30000
        };

        const BIAYA_UPGRADE = {
            keamanan: [0, 50000000, 150000000, 300000000],
            riset: [0, 100000000, 250000000, 500000000, 1000000000, 2500000000]
        };

        const formatMoney = (angka) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(angka);
        const addXp = (amount) => { user.xp += amount; return amount; };

        // 1. MENU UTAMA
        if (!subCmd) {
            const menuText = `
🌴 *SAWIT SIMULATOR RPG* 🌴

👤 Owner: ${pushName}
🏷️ Status: *${user.sawit_lahan > 0 ? (user.sawit_is_loan ? "🤝 Mitra" : "👑 Mandiri") : "Belum Main"}*
⭐ XP: ${user.xp}

🎮 *PANDUAN JURAGAN:*
👉 \`.sawit daftar\` (Mulai)
👉 \`.sawit status\` (Cek Kebun)
👉 \`.sawit cuaca\` (Cek BMKG)
👉 \`.sawit beli\` (Toko Aset)
👉 \`.sawit upgrade\` (Riset & Aman)
👉 \`.sawit tanam [jml]\` 
👉 \`.sawit rawat [pupuk/pestisida]\`
👉 \`.sawit panen\` (Kirim CPO)
👉 \`.sawit lunasi\` (Bebas Mitra)
`.trim();
            return sendSawitCard(menuText, "MANUAL BOOK JURAGAN", img.default);
        }

        // 2. DAFTAR
        if (subCmd === 'daftar') {
            if (user.sawit_lahan > 0) return reply('❌ Kebun kamu sudah jalan.');
            let message = "", header = "", currentImage = img.default, xpGain = 0;

            if (!user.sawit_has_claimed_loan) {
                user.money += 10000000;
                user.sawit_lahan = 1; user.sawit_bibit = 200; user.sawit_pekerja = 2; user.sawit_truk = 1;
                user.sawit_has_claimed_loan = true; 
                xpGain = addXp(1000); 
                message = `🤝 *SELAMAT DATANG JURAGAN!*\n\n💰 Modal: Rp 10.000.000\n📦 Aset: 1 Ha, 200 Bibit, 2 Buruh, 1 Truk.\n⭐ XP: +${xpGain}`;
                header = "KONTRAK MITRA BARU"; currentImage = img.modal;
            } else {
                user.money += 500000;
                user.sawit_lahan = 1; user.sawit_bibit = 100; user.sawit_pekerja = 1; 
                xpGain = addXp(100); 
                message = `📉 *PAKET BANGKIT*\n\n📦 Aset: 1 Ha Lahan, 100 Bibit, 1 Buruh.\n💰 Uang Saku: Rp 500.000`;
                header = "KONTRAK PEMULIHAN"; currentImage = img.nomodal;
            }
            user.sawit_is_loan = true;
            await saveDatabase();
            return sendSawitCard(message, header, currentImage);
        }

        if (user.sawit_lahan === 0 && subCmd !== 'reset') return reply('❌ Ketik *.sawit daftar* untuk mulai.');

        // 3. STATUS
        if (subCmd === 'status') {
            const now = Date.now();
            const timeLeft = COOLDOWN_PANEN - (now - user.sawit_last_panen);
            
            const maxPekerja = BASE_PEKERJA + (user.sawit_mess * PEKERJA_PER_MESS);
            let iconCuaca = user.sawit_cuaca_next === 'Cerah' ? '☀️' : (user.sawit_cuaca_next === 'Hujan' ? '🌧️' : (user.sawit_cuaca_next === 'Kemarau' ? '🏜️' : '🌪️'));

            const statusText = `
📊 *LAPORAN HARIAN JURAGAN*

🌳 Pohon: ${user.sawit_pohon} / ${user.sawit_lahan * MAX_POHON_PER_HA} (${user.sawit_lahan} Ha)
👷 Buruh: ${user.sawit_pekerja} / ${maxPekerja} | 🚛 Truk: ${user.sawit_truk}

🌦️ *Prediksi Cuaca Panen:* ${iconCuaca} ${user.sawit_cuaca_next}
🧪 *Status Perawatan Lahan:*
- Pupuk (+20%): ${user.sawit_pupuk_aktif ? "✅ Sudah Ditebar" : "❌ Belum (.sawit rawat pupuk)"}
- Pestisida (Anti Hama): ${user.sawit_pestisida_aktif ? "✅ Sudah Disemprot" : "❌ Belum (.sawit rawat pestisida)"}

🎒 *Gudang:* Pupuk ${user.sawit_pupuk} Sak | Pestisida ${user.sawit_pestisida} Liter
🛡️ *Fasilitas:* Drainase ${user.sawit_drainase} | Pompa ${user.sawit_pompa}

🕒 Panen: ${timeLeft > 0 ? Math.ceil(timeLeft/60000) + " Menit" : "✅ SIAP!"}
💰 Saldo: ${formatMoney(user.money)}
`.trim();
            return sendSawitCard(statusText, "STATUS KEBUN", img.default);
        }

        // 4. BMKG / CUACA
        if (['cuaca', 'ramalan', 'bmkg'].includes(subCmd)) {
            let infoCuaca = '';
            if (user.sawit_cuaca_next === 'Cerah') infoCuaca = '☀️ *Cerah* - Cuaca bersahabat, panen dijamin aman dari bencana alam.';
            if (user.sawit_cuaca_next === 'Hujan') infoCuaca = '🌧️ *Hujan Lebat* - Waspada BANJIR! Pastikan level fasilitas Drainase mencukupi.';
            if (user.sawit_cuaca_next === 'Kemarau') infoCuaca = '🏜️ *Kemarau Panjang* - Waspada KEKERINGAN! Buah menyusut jika tidak ada Pompa Air.';
            if (user.sawit_cuaca_next === 'Ekstrem') infoCuaca = '🌪️ *Cuaca Ekstrem* - Waspada BADAI ANGIN! Bisa menumbangkan pohon-pohon di kebun.';

            return sendSawitCard(`📡 *LAPORAN BMKG JURAGAN*\n\nPrediksi cuaca untuk masa panen berikutnya:\n\n${infoCuaca}\n\n💡 *Tips:* Cek menu toko di *.sawit beli* untuk membeli infrastruktur pelindung cuaca.`, "PREDIKSI CUACA", img.default);
        }

        // 5. BELI & UPGRADE (Dipadatkan)
        if (subCmd === 'beli') {
            if (!arg2) {
                return sendSawitCard(`🛒 *TOKO PERALATAN & KONSUMSI*
1. *bibit*: ${formatMoney(HARGA.bibit)}
2. *pekerja*: ${formatMoney(HARGA.pekerja)}
3. *mess*: ${formatMoney(HARGA.mess)} (+50 Kapasitas Buruh)
4. *lahan*: ${formatMoney(HARGA.lahan)} / Ha
5. *truk*: ${formatMoney(HARGA.truk)} (Kapasitas 1000)
6. *drainase*: ${formatMoney(HARGA.drainase)} (Anti Banjir)
7. *pompa*: ${formatMoney(HARGA.pompa)} (Anti Kering)
8. *pupuk*: ${formatMoney(HARGA.pupuk)} (Boost 20%)
9. *pestisida*: ${formatMoney(HARGA.pestisida)} (Anti Hama)`, "TOKO JURAGAN", img.beli);
            }
            let jumlah = arg3 || 1; let harga = HARGA[arg2]; let itemStr = `sawit_${arg2}`;
            if (!harga) return reply('❌ Item tidak valid.');
            if (arg2 === 'pekerja' && user.sawit_pekerja + jumlah > BASE_PEKERJA + (user.sawit_mess * PEKERJA_PER_MESS)) return reply(`❌ Mess buruh penuh! Beli Mess dulu.`);
            if (user.money < (harga * jumlah)) return reply('❌ Saldo kurang!');
            user.money -= (harga * jumlah); user[itemStr] += jumlah; await saveDatabase();
            return sendSawitCard(`🛒 *STRUK BELI*\nItem: ${arg2} (x${jumlah})\nSisa Saldo: ${formatMoney(user.money)}`, "TRANSAKSI BERHASIL", img.beli);
        }

        if (subCmd === 'upgrade') {
            if (!arg2) return sendSawitCard(`⬆️ *PUSAT UPGRADE*\n\n🛡️ *1. keamanan* (Cegah Pencurian)\n🔬 *2. riset* (+Rp2.500/Pohon)\n\nKetik: *.sawit upgrade [keamanan/riset]*`, "UPGRADE SYSTEM", img.beli);
            let lvlKey = `sawit_${arg2}`; let max = arg2 === 'keamanan' ? 3 : 5;
            let nextLvl = user[lvlKey] + 1;
            if (nextLvl > max) return reply(`✅ ${arg2} sudah Max Level!`);
            let cost = BIAYA_UPGRADE[arg2][nextLvl];
            if (arg2 === 'riset' && (!args[2] || args[2] !== 'yakin')) return reply(`🔬 *Riset Lvl ${nextLvl}*\nBiaya: ${formatMoney(cost)}\nKetik: *.sawit upgrade riset yakin* untuk membeli.`);
            if (user.money < cost) return reply(`❌ Saldo kurang! Butuh ${formatMoney(cost)}`);
            user.money -= cost; user[lvlKey] = nextLvl; await saveDatabase();
            return reply(`✅ ${arg2} berhasil di-upgrade ke Level ${nextLvl}!`);
        }

        // 6. TANAM
        if (subCmd === 'tanam') {
            let jumlah = (arg2 && !isNaN(parseInt(arg2))) ? parseInt(arg2) : user.sawit_bibit; 
            if (jumlah < 1) return reply(`❌ Kamu tidak punya bibit.`);
            if (user.sawit_bibit < jumlah) return reply(`❌ Stok bibit kurang.`);
            if ((user.sawit_pohon + jumlah) > (user.sawit_lahan * MAX_POHON_PER_HA)) return reply(`❌ Lahan penuh!`);
            const butuhPekerja = Math.ceil((user.sawit_pohon + jumlah) / 100);
            if (user.sawit_pekerja < butuhPekerja) return reply(`❌ Kurang orang! Kamu butuh minimal ${butuhPekerja} buruh untuk merawat kebun seluas ini.`);

            user.sawit_bibit -= jumlah; user.sawit_pohon += jumlah; await saveDatabase();
            return reply(`🌱 Menanam ${jumlah} pohon berhasil.\nTotal pohon: ${user.sawit_pohon}`);
        }

        // 7. RAWAT MANUAL (PUPUK & PESTISIDA)
        if (['rawat', 'pupuk', 'semprot'].includes(subCmd)) {
            if (user.sawit_pohon === 0) return reply('❌ Kamu belum menanam pohon sama sekali!');
            
            let tipe = arg2;
            if (subCmd === 'pupuk') tipe = 'pupuk';
            if (subCmd === 'semprot') tipe = 'pestisida';

            if (tipe === 'pupuk') {
                if (user.sawit_pupuk_aktif) return reply('✅ Kebun sudah dipupuk! Tunggu panen berikutnya.');
                let butuhPupuk = Math.ceil(user.sawit_pohon / 100);
                if (user.sawit_pupuk < butuhPupuk) return reply(`❌ Pupuk kurang! Butuh ${butuhPupuk} sak untuk ${user.sawit_pohon} pohon.`);
                user.sawit_pupuk -= butuhPupuk; user.sawit_pupuk_aktif = true; await saveDatabase();
                return reply(`✨ Berhasil menebar ${butuhPupuk} sak pupuk! Omzet panen selanjutnya dipastikan +20%.`);
            }
            if (tipe === 'pestisida') {
                if (user.sawit_pestisida_aktif) return reply('✅ Kebun sudah disemprot pestisida!');
                let butuhPestisida = Math.ceil(user.sawit_pohon / 100);
                if (user.sawit_pestisida < butuhPestisida) return reply(`❌ Pestisida kurang! Butuh ${butuhPestisida} liter untuk ${user.sawit_pohon} pohon.`);
                user.sawit_pestisida -= butuhPestisida; user.sawit_pestisida_aktif = true; await saveDatabase();
                return reply(`🛡️ Berhasil menyemprot ${butuhPestisida} liter pestisida! Kebun aman dari hama untuk panen selanjutnya.`);
            }
            return reply(`❓ Cara penggunaan:\n👉 *.sawit rawat pupuk*\n👉 *.sawit rawat pestisida*`);
        }

        // 8. PANEN & LOGISTIK
        if (subCmd === 'panen') {
            if (user.sawit_pohon === 0) return reply('❌ Belum ada pohon.');
            const now = Date.now();
            if (now - user.sawit_last_panen < COOLDOWN_PANEN) return reply('⏳ Belum matang.');

            let eventText = "", pinalti = 0;
            let randHama = Math.random() * 100;
            let randMaling = Math.random() * 100;

            // SISTEM BENCANA ALAM (Berdasarkan BMKG)
            if (user.sawit_cuaca_next === 'Hujan') {
                if (Math.random() * 100 > (user.sawit_drainase * 10)) {
                    pinalti += Math.floor(user.sawit_pohon * 5000); eventText += `🌊 Banjir merendam kebun! Rugi: -${formatMoney(pinalti)}\n`;
                } else { eventText += `🌧️ Hujan Lebat. Beruntung Drainase bekerja optimal.\n`; }
            } else if (user.sawit_cuaca_next === 'Kemarau') {
                if (Math.random() * 100 > (user.sawit_pompa * 15)) {
                    pinalti += Math.floor(user.sawit_pohon * 4000); eventText += `☀️ Kekeringan parah! Buah menyusut. Rugi: -${formatMoney(pinalti)}\n`;
                } else { eventText += `☀️ Panas Terik. Beruntung Pompa Air mendinginkan lahan.\n`; }
            } else if (user.sawit_cuaca_next === 'Ekstrem') {
                if (Math.random() < 0.5) { // 50% chance kena badai beneran kalau cuaca ekstrem
                    let tumbang = Math.floor(Math.random() * 10) + 1;
                    if (user.sawit_pohon >= tumbang) { user.sawit_pohon -= tumbang; eventText += `🌪️ BADAI! ${tumbang} Pohon tumbang tercabut angin!\n`; }
                } else { eventText += `🌪️ Angin Kencang, tapi kebun selamat.\n`; }
            }

            // SISTEM HAMA (Dihandle oleh Pestisida Manual)
            if (!user.sawit_pestisida_aktif && randHama < 30) {
                let rugiHama = Math.floor(user.sawit_pohon * 3500);
                pinalti += rugiHama; eventText += `🐀 HAMA MENYERANG! Kamu lupa menyemprot Pestisida! Rugi: -${formatMoney(rugiHama)}\n`;
            } else if (user.sawit_pestisida_aktif) {
                eventText += `🛡️ Kebun aman dari hama karena Pestisida.\n`;
            }

            // SISTEM MALING (15% Chance)
            if (randMaling < 15) {
                let baseHilang = Math.floor(user.sawit_pohon * 8000);
                let mitigasi = user.sawit_keamanan * 0.3; 
                if (user.sawit_keamanan === 3) { eventText += `🥷 Maling tertangkap oleh CCTV & Guard!\n`; } 
                else { pinalti += Math.floor(baseHilang - (baseHilang * mitigasi)); eventText += `🥷 Kebun Kebobolan! Ninja sawit beraksi. Rugi: -${formatMoney(pinalti)}\n`; }
            }

            // PERHITUNGAN OMZET
            let baseHarga = Math.floor(Math.random() * (22000 - 12000 + 1)) + 12000;
            baseHarga += (user.sawit_riset * 2500); 
            
            let gross = user.sawit_pohon * baseHarga;
            
            // CEK PUPUK MANUAL
            if (user.sawit_pupuk_aktif) {
                gross = Math.floor(gross * 1.2); eventText += `✨ Efek Pupuk bekerja! Harga Jual & Omzet +20%\n`;
            }

            // PENGELUARAN GAJI
            let gajiPokok = user.sawit_pekerja * GAJI_POKOK;
            let premiPanen = Math.floor(gross * BONUS_PANEN_PERSEN);
            let totalGaji = gajiPokok + premiPanen;

            // PENGELUARAN LOGISTIK
            let pohonTercoverTruk = Math.min(user.sawit_pohon, user.sawit_truk * KAPASITAS_TRUK);
            let pohonSisaSewa = user.sawit_pohon - pohonTercoverTruk;
            let biayaLogistikPribadi = pohonTercoverTruk * BIAYA_TRUK_PRIBADI;
            let biayaLogistikSewa = pohonSisaSewa > 0 ? (pohonSisaSewa * BIAYA_SEWA_TRUK) : 0;
            let totalLogistik = biayaLogistikPribadi + biayaLogistikSewa;

            // PAJAK MITRA & NET PROFIT
            let pajak = user.sawit_is_loan ? Math.floor(gross * PAJAK_MITRA) : 0;
            let net = gross - (totalGaji + totalLogistik + pajak + pinalti);
            let totalXp = 200 + Math.floor(net / 1000000);

            user.money += net;
            user.sawit_last_panen = now;
            user.sawit_panen_count += 1;
            
            // RESET BUFF & GENERATE CUACA BARU UNTUK PANEN DEPAN
            user.sawit_pupuk_aktif = false;
            user.sawit_pestisida_aktif = false;
            user.sawit_cuaca_next = generateCuaca();

            addXp(totalXp);
            await saveDatabase();

            const panenText = `
🚛 *PENGIRIMAN CPO #${user.sawit_panen_count}*
${eventText ? `\n🔔 *LOG HARIAN:*\n${eventText}` : ""}
📈 Omzet Kotor: ${formatMoney(gross)}

🛑 *OPERASIONAL:*
- Gaji Buruh & Premi: -${formatMoney(totalGaji)}
- Transportasi Logistik: -${formatMoney(totalLogistik)}
${pinalti > 0 ? `- Kerugian Bencana/Maling: -${formatMoney(pinalti)}` : ""}
${pajak > 0 ? `- Pajak Mitra (40%): -${formatMoney(pajak)}` : ""}
-------------------------------
💰 *NET PROFIT: ${formatMoney(net)}*
⭐ *XP EARNED: +${totalXp}*

☁️ *BMKG UPDATE:* Cuaca panen berikutnya diperkirakan *${user.sawit_cuaca_next}*.
`.trim();
            return sendSawitCard(panenText, "PANEN RAYA", user.sawit_is_loan ? img.pajak : img.mandiri);
        }

        // 9. LUNASI & RESET
        if (subCmd === 'lunasi') {
            if (!user.sawit_is_loan) return reply('✅ Sudah mandiri.');
            if (user.money < BIAYA_LUNAS) return reply(`❌ Kurang ${formatMoney(BIAYA_LUNAS - user.money)}.`);
            user.money -= BIAYA_LUNAS; user.sawit_is_loan = false; await saveDatabase();
            return sendSawitCard(`🎉 *KEBEBASAN FINANSIAL!*\nStatus Mitra dicabut. Potongan 40% dihapus selamanya!`, "PELUNASAN SUKSES", img.mandiri);
        }

        if (subCmd === 'reset') {
            if (arg2 !== 'confirm') return reply(`⚠️ *PERINGATAN!* Reset akan menghapus SEMUA aset.\nKetik: *.sawit reset confirm* jika yakin.`);
            for (const key in defaultValues) if (key !== 'money' && key !== 'xp') user[key] = defaultValues[key];
            user.sawit_is_loan = false; await saveDatabase();
            return reply('✅ Game Sawit di-reset! Ketik *.sawit daftar* untuk main lagi.');
        }
    }
};