import axios from "axios";
import crypto from "crypto";

class Savetube {
  constructor() {
    // Key AES-128-CBC untuk decrypt
    this.ky = 'C5D58EF67A7584E4A29F6C35BBC4EB12';
    this.m = /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(?:embed\/)?(?:v\/)?(?:shorts\/)?([a-zA-Z0-9_-]{11})/;
    this.is = axios.create({
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/plain, */*',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36',
        'Referer': 'https://save-tube.com/',
        'Origin': 'https://save-tube.com'
      },
      timeout: 30000
    });
  }
  
  async decrypt(enc) {
    try {
      const sr = Buffer.from(enc, 'base64');
      const ky = Buffer.from(this.ky, 'hex');
      
      if (sr.length < 16) {
        throw new Error(`Encrypted data too short: ${sr.length} bytes`);
      }
      
      const iv = sr.slice(0, 16);
      const dt = sr.slice(16);
      
      const dc = crypto.createDecipheriv('aes-128-cbc', ky, iv);
      let decrypted = Buffer.concat([dc.update(dt), dc.final()]);
      
      // Parse JSON hasil decrypt
      const result = JSON.parse(decrypted.toString());
      return result;
    } catch (err) {
      throw new Error(`Decryption failed: ${err.message}`);
    }
  }
  
  async getCdn() {
    try {
      const response = await this.is.get("https://media.savetube.vip/api/random-cdn");
      if (!response.data?.cdn) {
        console.log("   [CDN] No CDN in response, using fallback cdn402");
        return "cdn402.savetube.vip";
      }
      return response.data.cdn;
    } catch (err) {
      console.error("   [CDN] Error:", err.message);
      return "cdn402.savetube.vip"; // Fallback ke cdn402
    }
  }
  
  async download(url, format = 'video', quality = '480') {
    console.log("\n=== SAVETUBE DOWNLOAD START ===");
    console.log("Input URL:", url);
    
    const id = url.match(this.m)?.[3];
    if (!id) throw new Error("ID video tidak ditemukan. Pastikan link YouTube valid.");
    console.log("Video ID:", id);

    // Step 1: Get CDN
    console.log("\n[Step 1] Getting CDN...");
    const cdn = await this.getCdn();
    console.log("   CDN:", cdn);

    // Step 2: Get Info (dengan decrypt)
    console.log("\n[Step 2] Getting video info...");
    let infoRes;
    try {
      const payload = { url: url }; // Langsung pakai URL asli, tidak perlu diubah
      console.log("   POST https://" + cdn + "/v2/info");
      console.log("   Payload:", JSON.stringify(payload));
      
      infoRes = await this.is.post(`https://${cdn}/v2/info`, payload);
      
      console.log("   Status:", infoRes.status);
      if (infoRes.status !== 200) {
        throw new Error(`HTTP ${infoRes.status}: ${JSON.stringify(infoRes.data)}`);
      }
    } catch (err) {
      console.error("   [ERROR] Failed to get info:", err.message);
      if (err.response) {
        console.error("   Response Status:", err.response.status);
        console.error("   Response Data:", err.response.data);
      }
      throw new Error(`Gagal ambil info: ${err.message}`);
    }

    // Cek apakah ada data yang perlu didecrypt
    if (!infoRes.data?.data) {
      console.error("   [ERROR] No 'data' field in response");
      console.error("   Response:", JSON.stringify(infoRes.data, null, 2));
      throw new Error("Response tidak memiliki field 'data' untuk didecrypt");
    }

    // Step 3: Decrypt metadata
    console.log("\n[Step 3] Decrypting metadata...");
    let metadata;
    try {
      console.log("   Encrypted data length:", infoRes.data.data.length);
      metadata = await this.decrypt(infoRes.data.data);
      console.log("   Decrypted successfully!");
      console.log("   Title:", metadata.title);
      console.log("   Duration:", metadata.durationLabel);
      console.log("   Thumbnail:", metadata.thumbnail ? "Yes" : "No");
    } catch (err) {
      console.error("   [ERROR] Decrypt failed:", err.message);
      throw new Error(`Gagal decrypt metadata: ${err.message}`);
    }

    if (!metadata.key) {
      console.error("   [ERROR] No 'key' in decrypted metadata");
      console.error("   Metadata keys:", Object.keys(metadata));
      throw new Error("Key download tidak ditemukan dalam metadata");
    }

    // Step 4: Get Download URL
    console.log("\n[Step 4] Getting download URL...");
    let dlRes;
    try {
      const dlPayload = {
        id: id,
        downloadType: format,
        quality: quality,
        key: metadata.key
      };
      console.log("   POST https://" + cdn + "/download");
      console.log("   Payload:", JSON.stringify(dlPayload));
      
      dlRes = await this.is.post(`https://${cdn}/download`, dlPayload);
      
      console.log("   Status:", dlRes.status);
      console.log("   Response:", JSON.stringify(dlRes.data, null, 2));
      
      if (dlRes.status !== 200) {
        throw new Error(`HTTP ${dlRes.status}: ${JSON.stringify(dlRes.data)}`);
      }
    } catch (err) {
      console.error("   [ERROR] Download request failed:", err.message);
      if (err.response) {
        console.error("   Response Status:", err.response.status);
        console.error("   Response Data:", err.response.data);
      }
      throw new Error(`Gagal proses download: ${err.message}`);
    }

    // Parse response - bisa berupa string URL langsung atau object
    let downloadUrl;
    if (typeof dlRes.data === 'string') {
      downloadUrl = dlRes.data.trim();
      console.log("   Response is direct URL (string)");
    } else if (dlRes.data?.data?.downloadUrl) {
      downloadUrl = dlRes.data.data.downloadUrl;
      console.log("   Response is object with data.downloadUrl");
    } else if (dlRes.data?.downloadUrl) {
      downloadUrl = dlRes.data.downloadUrl;
      console.log("   Response is object with downloadUrl");
    } else {
      console.error("   [ERROR] Unknown response structure");
      console.error("   Response:", JSON.stringify(dlRes.data, null, 2));
      throw new Error("Struktur response download tidak dikenali");
    }

    // Validasi URL
    if (!downloadUrl.startsWith('http')) {
      throw new Error(`URL download tidak valid: ${downloadUrl.substring(0, 100)}`);
    }

    console.log("   Download URL:", downloadUrl.substring(0, 80) + "...");
    console.log("\n=== SAVETUBE DOWNLOAD SUCCESS ===");

    return {
      title: metadata.title || "Unknown",
      duration: metadata.durationLabel || "Unknown",
      thumbnail: metadata.thumbnail || null,
      downloadUrl: downloadUrl,
      quality: quality,
      videoId: id
    };
  }
}

// --- HELPER: Download Video ke Buffer dengan Validasi ---
const downloadVideoBuffer = async (url, maxRetries = 3) => {
  console.log("\n[Video Download] Starting...");
  console.log("URL:", url.substring(0, 80) + "...");

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`   Attempt ${attempt}/${maxRetries}...`);
      
      const response = await axios({
        method: 'get',
        url: url,
        responseType: 'arraybuffer',
        timeout: 120000, // 2 menit untuk video besar
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'video/webm,video/mp4,video/*,*/*;q=0.9',
          'Referer': 'https://save-tube.com/',
          'Origin': 'https://save-tube.com'
        },
        onDownloadProgress: (progressEvent) => {
          if (progressEvent.total) {
            const percent = Math.round((progressEvent.loaded * 100) / progressEvent.total);
            if (percent % 20 === 0) console.log(`   Progress: ${percent}%`);
          }
        }
      });

      const buffer = Buffer.from(response.data);
      const sizeMB = (buffer.length / 1024 / 1024).toFixed(2);
      console.log(`   Downloaded: ${sizeMB} MB`);

      // Validasi magic bytes
      const magic = buffer.slice(0, 16).toString('hex');
      const isMP4 = magic.includes('66747970') || magic.startsWith('00000018'); // ftyp atau mvhd
      const isWebM = magic.startsWith('1a45dfa3'); // EBML
      const isFLV = magic.startsWith('464c56'); // FLV
      
      console.log(`   Format: ${isMP4 ? 'MP4' : isWebM ? 'WebM' : isFLV ? 'FLV' : 'Unknown'}`);
      console.log(`   Magic: ${magic.substring(0, 32)}...`);

      // Validasi ukuran minimum (100KB)
      if (buffer.length < 100000) {
        throw new Error(`File too small (${buffer.length} bytes), possible error page`);
      }

      return {
        buffer,
        size: buffer.length,
        contentType: isWebM ? 'video/webm' : 'video/mp4',
        format: isMP4 ? 'mp4' : isWebM ? 'webm' : 'unknown'
      };

    } catch (err) {
      console.error(`   Attempt ${attempt} failed:`, err.message);
      if (attempt === maxRetries) throw err;
      await new Promise(r => setTimeout(r, 2000 * attempt));
    }
  }
};

const handler = async ({ sock, msg, args, from, sendReact }) => {
  const text = args.join(' ');
  const parts = text.trim().split(' ');
  const url = parts[0];
  const reso = parts[1] || '480';

  if (!url) {
    return sock.sendMessage(from, { 
      text: '❌ Masukkan link YouTube.\n\nContoh: `.ytv https://youtu.be/xyz 720`\n\nKualitas: 360, 480, 720, 1080' 
    }, { quoted: msg });
  }

  // Validasi URL YouTube
  const ytRegex = /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)/;
  if (!ytRegex.test(url)) {
    return sock.sendMessage(from, { 
      text: '❌ Link tidak valid. Pastikan menggunakan link YouTube.' 
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🔍', key: msg.key } });

  try {
    const st = new Savetube();
    
    // Step 1: Dapatkan info dan URL download
    const result = await st.download(url, 'video', reso);
    
    await sock.sendMessage(from, { react: { text: '⬇️', key: msg.key } });
    
    // Step 2: Download video ke buffer (ANTI-CORRUPT)
    const videoData = await downloadVideoBuffer(result.downloadUrl);
    
    await sock.sendMessage(from, { react: { text: '📤', key: msg.key } });
    
    // Step 3: Kirim ke WhatsApp
    const safeTitle = (result.title || 'video').replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);
    const fileSizeMB = (videoData.size / 1024 / 1024).toFixed(2);
    
    // Strategi: File besar kirim sebagai document, kecil sebagai video
    const isLargeFile = videoData.size > 60 * 1024 * 1024; // > 60MB
    
    if (isLargeFile) {
      await sock.sendMessage(from, {
        document: videoData.buffer,
        mimetype: 'video/mp4',
        fileName: `${safeTitle}_${reso}p.mp4`,
        caption: `✅ *YouTube Video*\n\n📌 *Judul:* ${result.title}\n⏱️ *Durasi:* ${result.duration}\n🎥 *Kualitas:* ${reso}p\n📦 *Ukuran:* ${fileSizeMB} MB\n\n💡 _File besar dikirim sebagai document agar tidak corrupt._`
      }, { quoted: msg });
    } else {
      await sock.sendMessage(from, {
        video: videoData.buffer,
        mimetype: 'video/mp4',
        fileName: `${safeTitle}_${reso}p.mp4`,
        caption: `✅ *YouTube Video*\n\n📌 *Judul:* ${result.title}\n⏱️ *Durasi:* ${result.duration}\n🎥 *Kualitas:* ${reso}p\n📦 *Ukuran:* ${fileSizeMB} MB`
      }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (err) {
    console.error("Handler Error:", err);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    
    let errorMsg = err.message;
    if (err.code === 'ECONNABORTED') errorMsg = 'Timeout: Server terlalu lama merespons';
    if (err.code === 'ENOTFOUND') errorMsg = 'DNS Error: Tidak dapat terhubung ke server';
    if (err.response?.status === 403) errorMsg = 'Forbidden: Video mungkin private atau key expired';
    if (err.response?.status === 404) errorMsg = 'Not Found: Video tidak ditemukan';
    if (err.response?.status === 500) errorMsg = 'Server Error: Savetube sedang bermasalah';
    if (err.message.includes('decrypt')) errorMsg = 'Decrypt Error: Key mungkin sudah tidak valid';
    
    await sock.sendMessage(from, { 
      text: `❌ *Error:* ${errorMsg}\n\n💡 Tips:\n• Coba kualitas lebih rendah (360/480p)\n• Pastikan video tidak private/region-locked\n• Coba lagi dalam 1-2 menit` 
    }, { quoted: msg });
  }
};

export default {
  command: ['ytv', 'ytmp4', 'ytvideo'],
  description: 'Download video YouTube via Savetube CDN402 (Anti-Corrupt)',
  category: 'Downloader',
  handler,
};