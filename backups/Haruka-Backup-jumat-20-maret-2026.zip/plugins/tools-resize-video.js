import { spawn } from 'child_process'; // Ganti exec dengan spawn
import fs from 'fs';
import path from 'path';
import { downloadMediaMessage } from '@whiskeysockets/baileys';

export default {
    command: ['resize', 'vresize'],
    category: 'tools',
    isOwner: false,
    isAdmin: false,
    isBotAdmin: false,
    isPremium: false,

    handler: async ({ 
        sock, 
        msg, 
        args, 
        reply, 
        sendVideo, 
        sendReact 
    }) => {
        const isQuoted = !!msg.quoted;
        const targetMsg = isQuoted ? msg.quoted : msg;
        const mime = (targetMsg.msg || targetMsg).mimetype || targetMsg.message?.videoMessage?.mimetype || targetMsg.mimetype || '';

        if (!/video/.test(mime)) return reply('❌ Balas video atau kirim video dengan caption command ini!');
        
        const percent = parseInt(args[0]);
        if (isNaN(percent) || percent < 10 || percent > 90) {
            return reply('❌ Masukkan angka rasio antara 10 - 90! Contoh: .resize 50');
        }

        await sendReact('⏳');

        const ratio = percent / 100;
        const tmpDir = path.join(process.cwd(), 'tmp');
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

        const inputPath = path.join(tmpDir, `input_${Date.now()}.mp4`);
        const outputPath = path.join(tmpDir, `output_${Date.now()}.mp4`);

        try {
            const buffer = await downloadMediaMessage(
                targetMsg,
                'buffer',
                {},
                { reuploadRequest: sock.updateMediaMessage }
            );

            fs.writeFileSync(inputPath, buffer);

            // Get video info pakai ffprobe
            const getVideoInfo = () => {
                return new Promise((resolve, reject) => {
                    const probe = spawn('ffprobe', [
                        '-v', 'error',
                        '-select_streams', 'v:0',
                        '-show_entries', 'stream=width,height,r_frame_rate',
                        '-of', 'csv=s=x:p=0',
                        inputPath
                    ]);
                    
                    let output = '';
                    probe.stdout.on('data', (data) => output += data);
                    probe.on('close', (code) => {
                        if (code !== 0) return reject(new Error('ffprobe failed'));
                        const [width, height, fps] = output.trim().split('x');
                        resolve({
                            width: parseInt(width),
                            height: parseInt(height),
                            fps: eval(fps) || 30
                        });
                    });
                });
            };

            const videoInfo = await getVideoInfo();
            const newWidth = Math.round(videoInfo.width * ratio / 2) * 2; // pastikan genap
            const newHeight = Math.round(videoInfo.height * ratio / 2) * 2;
            const crf = Math.max(18, Math.min(28, Math.round(23 + (1 - ratio) * 10)));
            const audioBitrate = ratio > 0.7 ? '128k' : ratio > 0.4 ? '96k' : '64k';

            // Progress handler
            await reply(`🎬 Memproses video...\n📐 ${newWidth}x${newHeight}\n⏳ Mohon tunggu ~${Math.ceil((videoInfo.width * videoInfo.height * ratio)/1000000)} detik`);

            // SPAWN untuk video besar
            const ffmpeg = spawn('ffmpeg', [
                '-i', inputPath,
                '-vf', `scale=${newWidth}:${newHeight}:flags=lanczos,format=yuv420p`,
                '-c:v', 'libx264',
                '-crf', crf.toString(),
                '-preset', 'medium',
                '-c:a', 'aac',
                '-b:a', audioBitrate,
                '-ar', '44100',
                '-ac', '2',
                '-movflags', '+faststart',
                '-pix_fmt', 'yuv420p',
                '-y',
                outputPath
            ]);

            let errorOutput = '';
            ffmpeg.stderr.on('data', (data) => {
                errorOutput += data.toString();
            });

            ffmpeg.on('close', async (code) => {
                if (code !== 0) {
                    console.error('FFmpeg error:', errorOutput);
                    cleanup(inputPath, outputPath);
                    return reply('❌ Gagal memproses video. Mungkin video terlalu besar atau corrupt.');
                }

                try {
                    if (!fs.existsSync(outputPath) || fs.statSync(outputPath).size === 0) {
                        throw new Error('Output file kosong');
                    }

                    const videoBuffer = fs.readFileSync(outputPath);
                    const originalSize = (fs.statSync(inputPath).size / 1024 / 1024).toFixed(2);
                    const newSize = (fs.statSync(outputPath).size / 1024 / 1024).toFixed(2);
                    
                    // FIX CAPTION - sesuaikan dengan format sendVideo kamu
                    const caption = `✅ *Video Resized ${percent}%*\n` +
                                   `📐 Resolusi: ${newWidth}x${newHeight}\n` +
                                   `📉 Ukuran: ${originalSize}MB → ${newSize}MB\n` +
                                   `🎯 Kualitas: CRF ${crf}`;

                    // Coba cara 1 (string)
                    await sendVideo(videoBuffer, caption);
                    
                    // Jika tidak work, coba cara 2 (object):
                    // await sendVideo({ video: videoBuffer, caption: caption });

                } catch (e) {
                    console.error('Send error:', e);
                    reply('❌ Gagal mengirim video hasil.');
                } finally {
                    cleanup(inputPath, outputPath);
                }
            });

        } catch (err) {
            console.error('Handler error:', err);
            cleanup(inputPath, outputPath);
            reply(`❌ Error: ${err.message}`);
        }

        function cleanup(inPath, outPath) {
            try {
                if (fs.existsSync(inPath)) fs.unlinkSync(inPath);
                if (fs.existsSync(outPath)) fs.unlinkSync(outPath);
            } catch (e) {}
        }
    }
};
