import axios from "axios";
import * as fsp from 'fs/promises';
import fs from 'fs';
import * as path from 'path';
import NodeID3 from 'node-id3';
import yts from 'yt-search';
import fetch from 'node-fetch';

/**
 * Scraper YTMP3.AI
 */
const H = {
  html: {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36"
  },
  api: {
    "accept": "*/*",
    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    "origin": "https://v1.ytmp3.ai",
    "referer": "https://v1.ytmp3.ai/",
    "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36"
  }
};

async function ytmp3(youtubeURL, format = "mp3") {
  const ts = () => Math.floor(Date.now() / 1000);

  const vid = (() => {
    if (youtubeURL.includes("youtu.be/")) return /\/([a-zA-Z0-9_-]{11})/.exec(youtubeURL)?.[1];
    if (youtubeURL.includes("youtube.com")) {
      if (youtubeURL.includes("/live/") || youtubeURL.includes("/shorts/"))
        return /\/([a-zA-Z0-9_-]{11})/.exec(youtubeURL)?.[1];
      return /v=([a-zA-Z0-9_-]{11})/.exec(youtubeURL)?.[1];
    }
  })();
  if (!vid) throw new Error("ID video tidak ditemukan dari URL");

  const html = await (await fetch("https://v1.ytmp3.ai/", { headers: H.html })).text();
  const jsonMatch = /var json = JSON\.parse\('(.+?)'\)/.exec(html);
  if (!jsonMatch) throw new Error("Gagal mengambil token scraping");
  const json = JSON.parse(jsonMatch[1]);

  let token = "";
  for (let i = 0; i < json[0].length; i++)
    token += String.fromCharCode(json[0][i] - json[2][json[2].length - (i + 1)]);
  if (json[1]) token = token.split("").reverse().join("");
  if (token.length > 32) token = token.substring(0, 32);

  const initRes = await (await fetch(
    `https://epsilon.epsiloncloud.org/api/v1/init?${String.fromCharCode(json[6])}=${encodeURIComponent(token)}&t=${ts()}`,
    { headers: H.api }
  )).json();
  if (initRes.error > 0) throw new Error(`Init failed: ${initRes.error}`);

  let cvtURL = initRes.convertURL;
  if (cvtURL.includes("&v=")) cvtURL = cvtURL.split("&v=")[0];
  const cvtRes = await (await fetch(
    `${cvtURL}&v=${vid}&f=${format}&t=${ts()}`,
    { headers: H.api }
  )).json();
  if (cvtRes.error > 0) throw new Error(`Convert failed: ${cvtRes.error}`);

  let resData = cvtRes.redirect === 1
    ? await (await fetch(`${cvtRes.redirectURL.split("&v=")[0]}&v=${vid}&f=${format}&t=${ts()}`, { headers: H.api })).json()
    : cvtRes;

  while (true) {
    const prog = await (await fetch(`${resData.progressURL}&t=${ts()}`, { headers: H.api })).json();
    if (prog.error > 0) throw new Error(`Progress failed: ${prog.error}`);
    if (prog.progress >= 3) break;
    await new Promise(r => setTimeout(r, 3000));
  }

  return { 
    title: resData.title, 
    format, 
    downloadURL: resData.downloadURL,
    thumbnail: `https://i.ytimg.com/vi/${vid}/hqdefault.jpg`,
    id: vid
  };
}

/**
 * Utility Functions
 */
async function downloadAndSave(url, filePath) {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Gagal mengunduh file: ${response.statusText}`);
    const buffer = await response.buffer();
    await fsp.writeFile(filePath, buffer); 
}

async function embedMetadata(audioPath, imagePath, tags) {
    const imageBuffer = await fsp.readFile(imagePath);
    const defaultTags = {
        title: tags.title,
        artist: tags.artist || 'YouTube Downloader',
        image: {
            mime: 'image/jpeg',
            type: { id: 3, name: 'front cover' },
            description: 'Cover Art',
            imageBuffer: imageBuffer
        }
    };
    return NodeID3.write(defaultTags, audioPath);
}

/**
 * Main Handler
 */
const handler = async ({ sock, msg, args, from, command }) => {
  const text = args.join(' ');
  
  const tempId = Date.now();
  const audioTempPath = path.join('/tmp', `${tempId}-audio.mp3`); 
  const imageTempPath = path.join('/tmp', `${tempId}-thumb.jpg`);

  if (!text) {
    return sock.sendMessage(from, {
      text: 'Masukkan teks pencarian atau link YouTube.\nContoh: .play mockingbird'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🔎', key: msg.key } });

  let url;
  const isURL = text.trim().match(/youtube\.com|youtu\.be/);
  
  try {
    // 1. Pencarian jika input bukan URL
    if (!isURL) {
      const results = await yts(text);
      if (!results.videos || results.videos.length === 0) throw new Error('Video tidak ditemukan.');
      url = results.videos[0].url;
    } else {
      url = text.trim().split(' ')[0];
    }

    // 2. Ambil data menggunakan scraper YTMP3.AI
    const result = await ytmp3(url, 'mp3');

    // 3. Kirim Informasi Video
    const captionThumbnail = `*YOUTUBE PLAY - HARUKA DOWNLOADER*\n\n` +
                             `• *Judul:* ${result.title}\n` +
                             `• *ID:* ${result.id}\n\n` +
                             `*Sedang memproses audio, mohon tunggu...*`;

    await sock.sendMessage(from, {
      image: { url: result.thumbnail },
      caption: captionThumbnail
    }, { quoted: msg });

    // 4. Kirim Audio Langsung (untuk diputar di WA)
    await sock.sendMessage(from, {
        audio: { url: result.downloadURL },
        mimetype: 'audio/mp4', 
        ptt: false 
    }, { quoted: msg });
    
    // 5. Proses Metadata (ID3 Tag)
    await downloadAndSave(result.downloadURL, audioTempPath);
    await downloadAndSave(result.thumbnail, imageTempPath);
    
    await embedMetadata(audioTempPath, imageTempPath, {
        title: result.title,
        artist: 'YTMP3 Downloader'
    });
    
    // 6. Kirim sebagai Dokumen MP3
    await sock.sendMessage(from, {
        document: { stream: fs.createReadStream(audioTempPath) }, 
        mimetype: 'audio/mpeg', 
        fileName: `${result.title}.mp3`,
        caption: `✅ *File Audio Berhasil Diproses*`
    }, { quoted: msg });

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (err) {
    console.error(err);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    sock.sendMessage(from, {
      text: `❌ *Kesalahan:* ${err.message}`
    }, { quoted: msg });
  } finally {
    // Cleanup temporary files
    try {
        if (fs.existsSync(audioTempPath)) await fsp.unlink(audioTempPath); 
        if (fs.existsSync(imageTempPath)) await fsp.unlink(imageTempPath); 
    } catch (e) {}
  }
};

export default {
  command: ['play'],
  description: 'Mencari dan mengunduh audio YouTube via YTMP3.AI',
  category: 'Downloader',
  handler,
};