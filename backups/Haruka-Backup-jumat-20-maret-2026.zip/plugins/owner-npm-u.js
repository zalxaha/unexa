import { exec } from 'child_process';
import util from 'util';
import path from 'path';
import { fileURLToPath } from 'url';

const execPromise = util.promisify(exec);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import cfg from '../config/config.json' with { type: 'json' };

const PROJECT_ROOT = path.join(__dirname, '..');

const handler = async ({ sock, msg, args, from }) => {
    const sender = msg.key.participant || msg.key.remoteJid;
    
    const authorizedJids = [
        `${cfg.owner}@s.whatsapp.net`,
        ...(cfg.ownerAltJids || [])
    ];
    
    if (!authorizedJids.includes(sender)) {
        return sock.sendMessage(from, { text: "Akses ditolak. Perintah ini hanya untuk Owner." }, { quoted: msg });
    }

    const packageName = args.join(' ');

    if (!packageName) {
        return sock.sendMessage(from, { text: "Masukkan nama paket npm yang ingin di-uninstall.\nContoh: *.npmuninstall axios*" }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    // --- PERUBAHAN UTAMA: MENGGUNAKAN 'npm uninstall' ---
    // '--save' adalah default untuk npm uninstall dan akan menghapus dari package.json
    const command = `npm uninstall ${packageName} --prefix ${PROJECT_ROOT}`;
    
    try {
        await sock.sendMessage(from, { text: `[NPM] Mulai meng-uninstall: *${packageName}*...` }, { quoted: msg });

        // Jalankan perintah
        const { stdout, stderr } = await execPromise(command, { cwd: PROJECT_ROOT, maxBuffer: 1024 * 500 });
        
        if (stderr && !stderr.includes('npm WARN')) {
            // Jika ada stderr yang bukan hanya warning
            throw new Error(stderr);
        }

        let output = stdout || 'Uninstall berhasil, namun output kosong.';
        
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
        
        await sock.sendMessage(from, { 
            text: `✅ *Uninstall NPM Berhasil!*\n\n*Paket:* ${packageName}\n\n*Output:* \n\`\`\`bash\n${output.slice(0, 1500)}...\n\`\`\``
        }, { quoted: msg });

    } catch (e) {
        console.error(`[NPM ERROR] Gagal meng-uninstall ${packageName}:`, e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        
        let errorMessage = e.message ? e.message.slice(0, 1500) : 'Terjadi kesalahan saat menjalankan perintah npm.';

        return sock.sendMessage(from, {
            text: `❌ *Gagal Meng-uninstall NPM*\n\n*Paket:* ${packageName}\n\n*Detail Error:* \n\`\`\`bash\n${errorMessage}\n\`\`\``
        }, { quoted: msg });
    }
};

export default {
    command: ['npmuninstall', 'npmu'],
    description: 'Meng-uninstall paket NPM (Owner Only)',
    category: 'owner',
    handler,
};