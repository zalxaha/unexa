import axios from "axios";
import crypto from "crypto";

class Savetube {
  constructor() {
    this.ky = 'C5D58EF67A7584E4A29F6C35BBC4EB12';
    this.m = /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(?:embed\/)?(?:v\/)?(?:shorts\/)?([a-zA-Z0-9_-]{11})/;
    this.is = axios.create({
      headers: {
        'content-type': 'application/json',
        'origin': 'https://yt.savetube.me',
        'user-agent': 'Mozilla/5.0 (Android 15; Mobile; SM-F958; rv:130.0) Gecko/130.0 Firefox/130.0',
        'accept': 'application/json',
        'accept-language': 'en-US,en;q=0.9'
      },
      timeout: 15000 // Tambahin timeout
    });
  }
  
  async decrypt(enc) {
    try {
      const sr = Buffer.from(enc, 'base64');
      const ky = Buffer.from(this.ky, 'hex');
      
      if (sr.length < 16) throw new Error("Invalid encrypted data length");
      
      const iv = sr.slice(0, 16);
      const dt = sr.slice(16);
      const dc = crypto.createDecipheriv('aes-128-cbc', ky, iv);
      const result = Buffer.concat([dc.update(dt), dc.final()]);
      return JSON.parse(result.toString());
    } catch (err) {
      throw new Error(`Decryption failed: ${err.message}`);
    }
  }
  
  async getCdn() {
    try {
      const response = await this.is.get("https://media.savetube.vip/api/random-cdn");
      if (!response.data?.cdn) throw new Error("CDN not found in response");
      return response.data.cdn;
    } catch (err) {
      console.log("CDN fetch error:", err.message);
      // Fallback CDN jika API random-cdn gagal
      return "cdn400.savetube.vip";
    }
  }
  
  async download(url, format = 'video', quality = '480') {
    const id = url.match(this.m)?.[3];
    if (!id) throw new Error("ID video tidak ditemukan. Pastikan link YouTube valid.");
    
    let cdn;
    try {
      cdn = await this.getCdn();
      console.log("Using CDN:", cdn); // Debug log
    } catch (err) {
      throw new Error("Gagal mendapatkan CDN server");
    }
    
    // Step 1: Get Info dengan better error handling
    let res;
    try {
      res = await this.is.post(`https://${cdn}/v2/info`, { 
        url: `https://www.youtube.com/watch?v=${id}` 
      });
      console.log("Info response:", res.data); // Debug log
    } catch (err) {
      throw new Error(`Gagal mengambil info video: ${err.message}`);
    }
    
    if (!res.data?.data) {
      throw new Error("Response info tidak valid (mungkin API berubah)");
    }
    
    // Step 2: Decrypt
    let dec;
    try {
      dec = await this.decrypt(res.data.data);
      console.log("Decrypted data:", dec); // Debug log
    } catch (err) {
      throw new Error(`Gagal decrypt data: ${err.message}`);
    }
    
    if (!dec.key) {
      throw new Error("Key download tidak ditemukan dalam response");
    }
    
    // Step 3: Download
    let dl;
    try {
      dl = await this.is.post(`https://${cdn}/download`, {
        id: id,
        downloadType: format,
        quality: quality,
        key: dec.key
      });
      console.log("Download response:", dl.data); // Debug log
    } catch (err) {
      throw new Error(`Gagal proses download: ${err.message}`);
    }
    
    if (!dl.data?.data?.downloadUrl) {
      throw new Error("URL download tidak ditemukan");
    }

    return {
      title: dec.title || "Unknown",
      duration: dec.durationLabel || "Unknown",
      dl: dl.data.data.downloadUrl,
      quality: quality
    };
  }
}

const handler = async ({ sock, msg, args, from }) => {
  const text = args.join(' ');
  const parts = text.trim().split(' ');
  const url = parts[0];
  const reso = parts[1] || '480';

  if (!url) return sock.sendMessage(from, { text: 'Masukkan link YouTube.\nContoh: .ytv https://youtu.be/xyz 720' }, { quoted: msg });

  // Validasi URL YouTube
  const ytRegex = /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)/;
  if (!ytRegex.test(url)) {
    return sock.sendMessage(from, { text: '❌ Link tidak valid. Pastikan menggunakan link YouTube.' }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🎬', key: msg.key } });

  try {
    const st = new Savetube();
    const result = await st.download(url, 'video', reso);

    const caption = `*YOUTUBE VIDEO*\n\n• *Judul:* ${result.title}\n• *Durasi:* ${result.duration}\n• *Kualitas:* ${result.quality}p`;

    await sock.sendMessage(from, {
      video: { url: result.dl },
      mimetype: 'video/mp4',
      fileName: `${result.title}.mp4`,
      caption
    }, { quoted: msg });

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
  } catch (err) {
    console.error("Full error:", err); // Log error lengkap ke console
    await sock.sendMessage(from, { text: `❌ Error: ${err.message}` }, { quoted: msg });
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
  }
};

export default {
  command: ['ytmp4', 'ytv'],
  description: 'Download video YouTube via Savetube',
  category: 'Downloader',
  handler,
};