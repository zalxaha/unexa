import axios from 'axios';

const handler = async ({ sock, msg, args, from }) => {
  const url = args[0];
  const sender = msg.key.participant || msg.key.remoteJid;
  const senderNumber = sender.split('@')[0];

  // Validasi Input URL
  if (!url) {
    return sock.sendMessage(from, {
      text: '📌 Masukkan URL video Facebook!\nContoh: *.fb https://www.facebook.com/xxx*'
    }, { quoted: msg });
  }

  // Cek apakah URL valid Facebook
  if (!url.match(/facebook\.com|fb\.watch|fb\.gg/i)) {
    return sock.sendMessage(from, { text: '❌ URL tidak valid. Gunakan link Facebook yang benar.' }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

  try {
    // 1. Mengambil data dari API NexRay
    const { data } = await axios.get(`https://api.nexray.web.id/downloader/facebook?url=${encodeURIComponent(url)}`);

    // Validasi data dari API
    if (!data || !data.status || !data.result) {
      throw new Error('Gagal mendapatkan data video dari server NexRay.');
    }

    const res = data.result;
    
    // Prioritaskan HD, jika tidak ada gunakan SD
    const videoUrl = res.video_hd || res.video_sd;
    const quality = res.video_hd ? 'High Definition (HD)' : 'Standard (SD)';
    const title = res.title || 'Facebook Video';

    if (!videoUrl) {
      throw new Error('Link download tidak ditemukan dalam respon API.');
    }
    
    const caption = `*FACEBOOK DOWNLOADER*\n\n` +
                    `📝 *Judul:* ${title}\n` +
                    `⚙️ *Kualitas:* ${quality}\n` +
                    `🔗 *Source:* Facebook\n\n` +
                    `Ini kak videonya @${senderNumber}`;

    // 2. Fetch video menjadi buffer menggunakan axios dengan header User-Agent
    const videoResponse = await axios.get(videoUrl, {
      responseType: 'arraybuffer',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
        'Referer': 'https://www.facebook.com/'
      }
    });

    const videoBuffer = Buffer.from(videoResponse.data);

    // 3. Kirim buffer video ke WhatsApp
    await sock.sendMessage(
      from, {
        video: videoBuffer,
        mimetype: "video/mp4",
        fileName: `${title.replace(/[/\\?%*:|"<>-]/g, '_')}.mp4`, 
        caption: caption,
        mentions: [sender]
      }, {
        quoted: msg
      }
    );

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (e) {
    console.error('[FB NEXRAY ERROR]', e);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    
    // Tampilkan pesan error yang lebih jelas jika axios gagal
    const errorMessage = e.response ? `HTTP ${e.response.status}` : e.message;
    return sock.sendMessage(from, {
      text: `❌ Gagal mengunduh video.\nDetail: ${errorMessage}`
    }, { quoted: msg });
  }
};

export default {
  command: ['facebook', 'fb', 'fbdownload', 'fbdl'],
  description: 'Download video dari Facebook via NexRay API',
  category: 'Downloader',
  handler,
};