import axios from 'axios'
import fs from 'fs'
import path from 'path'
import crypto from 'crypto'

const handler = async ({ sock, msg, from, args }) => {
    const urlArgs = args.join(' ').trim()
    
    // 1. Validasi URL
    if (!/instagram\.com/i.test(urlArgs)) {
        return sock.sendMessage(from, { text: '❌ URL tidak valid' }, { quoted: msg })
    }

    // Buat folder tmp jika belum ada
    const tmpDir = path.resolve('./tmp')
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })

    try {
        await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } })

        // Fetch data dari API NexRay
        const apiUrl = `https://api.nexray.web.id/downloader/instagram?url=${encodeURIComponent(urlArgs)}`
        const { data } = await axios.get(apiUrl)

        if (!data.status || !data.result || data.result.length === 0) {
            throw new Error('Media tidak ditemukan atau API error')
        }

        // ==========================================
        // 2. FILTER DUPLIKAT & AMBIL TIPE MEDIA
        // ==========================================
        const uniqueUrls = new Set()
        const mediaItems = []

        for (const item of data.result) {
            const mediaUrl = item.url

            // Cek apakah URL valid dan belum pernah diproses
            if (mediaUrl && !uniqueUrls.has(mediaUrl)) {
                uniqueUrls.add(mediaUrl)
                mediaItems.push({
                    url: mediaUrl,
                    type: item.type // 'image' atau 'video' dari response API
                })
            }
        }
        // ==========================================

        if (mediaItems.length === 0) throw new Error('Tidak ada URL media yang valid.')

        // 3. PROSES DOWNLOAD
        for (const item of mediaItems) {
            const tempFileName = `${crypto.randomBytes(6).toString('hex')}.dat`
            const filePath = path.join(tmpDir, tempFileName)

            try {
                // A. Download Stream ke TMP
                const writer = fs.createWriteStream(filePath)
                const response = await axios.get(item.url, { responseType: 'stream' })
                
                response.data.pipe(writer)

                await new Promise((resolve, reject) => {
                    writer.on('finish', resolve)
                    writer.on('error', reject)
                })

                // B. Kirim Sesuai Tipe Asli dari API (Tanpa perlu cek Magic Number lagi)
                if (item.type === 'image') {
                    await sock.sendMessage(from, {
                        image: { url: filePath },
                        caption: 'H͟a͟r͟u͟k͟a͟ *Instagram downloader*'
                    }, { quoted: msg })
                } else if (item.type === 'video') {
                    await sock.sendMessage(from, {
                        video: { url: filePath },
                        mimetype: 'video/mp4',
                        caption: 'H͟a͟r͟u͟k͟a͟ *Instagram downloader*'
                    }, { quoted: msg })
                }

            } catch (err) {
                console.error('Error processing media:', err)
            } finally {
                // C. Hapus File Sampah
                if (fs.existsSync(filePath)) fs.unlinkSync(filePath)
            }
        }

        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } })

    } catch (e) {
        console.error(e)
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } })
        await sock.sendMessage(from, { text: `❌ Gagal: ${e.message || e}` }, { quoted: msg })
    }
}

export default {
    command: ['ig', 'igdl', 'instagram'],
    category: 'downloader',
    handler
}