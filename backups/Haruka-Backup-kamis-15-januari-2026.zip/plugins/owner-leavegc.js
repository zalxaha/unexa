import { groupsDb, saveDatabase } from '../lib/database.js';

export default {
    command: ['leavegc', 'leavegroup', 'out', 'keluar'],
    category: 'Owner',
    description: 'Paksa bot keluar dari grup menggunakan ID',
    isOwner: true, // Wajib Owner agar aman

    handler: async ({ sock, args, reply }) => {
        // Ambil ID dari parameter pertama
        const targetId = args[0];

        if (!targetId) {
            return reply('❌ Masukkan ID Grup!\n\nContoh: *.leavegc 1203630482@g.us*\n_(Cek ID menggunakan command .listgroup)_');
        }

        try {
            // 1. Cek & Hapus data sewa di database jika ada (Clean up)
            if (groupsDb[targetId]) {
                delete groupsDb[targetId];
                await saveDatabase();
            }

            // 2. Eksekusi keluar grup
            await sock.groupLeave(targetId);
            
            reply(`✅ Sukses!\nBot telah keluar dari grup dengan ID:\n${targetId}`);
            
        } catch (e) {
            console.error(e);
            reply(`❌ Gagal keluar dari grup.\n\nKemungkinan penyebab:\n1. ID Grup salah.\n2. Bot sudah tidak ada di grup tersebut.\n\nError: ${e.message}`);
        }
    }
};