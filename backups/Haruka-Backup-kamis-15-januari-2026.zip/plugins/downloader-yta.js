import fetch from 'node-fetch';
import * as crypto from 'crypto';
import * as fsp from 'fs/promises'; // fsp digunakan untuk fungsi Promise (writeFile, unlink, readFile)
import fs from 'fs';              // fs digunakan untuk fungsi Stream (createReadStream)
import * as path from 'path';
import NodeID3 from 'node-id3';

// --- [ BAGIAN UTILITY ] ---

async function downloadAndSave(url, filePath) {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Gagal mengunduh: ${response.statusText}`);
    
    const buffer = await response.buffer();
    await fsp.writeFile(filePath, buffer); 
}

/**
 * Fungsi ASYNC untuk menyematkan metadata.
 * PERBAIKAN: Menggunakan await fsp.readFile untuk mendapatkan Buffer gambar.
 */
async function embedMetadata(audioPath, imagePath, tags) {
    const imageBuffer = await fsp.readFile(imagePath); // <-- PERBAIKAN: Await agar mendapat Buffer
    
    const defaultTags = {
        title: tags.title,
        artist: tags.artist || 'YouTube Downloader',
        image: {
            mime: 'image/jpeg',
            type: { id: 3, name: 'front cover' },
            description: 'Cover Art',
            imageBuffer: imageBuffer // <-- Menggunakan Buffer yang sudah diawait
        }
    };
    
    return NodeID3.write(defaultTags, audioPath);
}

// --- [ BAGIAN CLASS Youtubers (Tetap Sama) ] ---

class Youtubers {
  // ... (Semua metode di sini tetap sama dengan versi sebelumnya)
  
  constructor() {
    this.hex = "C5D58EF67A7584E4A29F6C35BBC4EB12";
  }

  async uint8(hex) {
    const pecahan = hex.match(/[\dA-F]{2}/gi);
    if (!pecahan) throw new Error("Format tidak valid");
    return new Uint8Array(pecahan.map(h => parseInt(h, 16)));
  }

  b64Byte(b64) {
    const bersih = b64.replace(/\s/g, "");
    const biner = Buffer.from(bersih, 'base64');
    return new Uint8Array(biner);
  }

  async key() {
    const raw = await this.uint8(this.hex);
    return crypto.webcrypto.subtle.importKey("raw", raw, { name: "AES-CBC" }, false, ["decrypt"]);
  }

  async Data(base64Terenkripsi) {
    const byteData = this.b64Byte(base64Terenkripsi);
    if (byteData.length < 16) throw new Error("Data terlalu pendek");

    const iv = byteData.slice(0, 16);
    const data = byteData.slice(16);
    const kunci = await this.key();
    const hasil = await crypto.webcrypto.subtle.decrypt({ name: "AES-CBC", iv }, kunci, data);
    const teks = new TextDecoder().decode(new Uint8Array(hasil));
    return JSON.parse(teks);
  }

  async getCDN() {
    const res = await fetch("https://media.savetube.me/api/random-cdn");
    const data = await res.json();
    return data.cdn;
  }

  async infoVideo(linkYoutube) {
    const cdn = await this.getCDN();
    const res = await fetch(`https://${cdn}/v2/info`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: linkYoutube }),
    });

    const hasil = await res.json();
    if (!hasil.status) throw new Error(hasil.message || "Gagal ambil data video");

    const isi = await this.Data(hasil.data);
    return {
      judul: isi.title,
      durasi: isi.durationLabel,
      thumbnail: isi.thumbnail,
      kode: isi.key,
      kualitas: isi.video_formats.map(f => ({
        label: f.label,
        kualitas: f.height,
        default: f.default_selected
      })),
      infoLengkap: isi 
    };
  }

  async getDownloadLink(kodeVideo, kualitas, type) {
    const cdn = await this.getCDN();
    const res = await fetch(`https://${cdn}/download`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        downloadType: kualitas === "128" ? "audio" : type,
        quality: kualitas,
        key: kodeVideo,
      }),
    });

    const json = await res.json();
    if (!json.status) throw new Error(json.message);
    return json.data.downloadUrl;
  }

  async downloadyt(linkYoutube, kualitas, type) {
    try {
      const data = await this.infoVideo(linkYoutube);
      const linkUnduh = await this.getDownloadLink(data.kode, kualitas, type);
      return {
        status: true,
        judul: data.judul,
        kualitasTersedia: data.kualitas,
        thumbnail: data.thumbnail,
        durasi: data.durasi,
        url: linkUnduh,
      };
    } catch (err) {
      return {
        status: false,
        pesan: err.message
      };
    }
  }
}

// --- [ BAGIAN HANDLER ] ---

const handler = async ({ sock, msg, args, from }) => {
  const text = args.join(' ');
  const parts = text.trim().split(' ');
  const url = parts[0];
  const selectedQuality = parts[1] || '128'; 
  
  const tempId = Date.now();
  const audioTempPath = path.join('/tmp', `${tempId}-audio.mp3`); 
  const imageTempPath = path.join('/tmp', `${tempId}-thumb.jpg`);

  if (!url) {
    return sock.sendMessage(from, {
      text: 'Masukkan link YouTube dan kualitas audio (opsional).\nContoh: /ytmp3 https://youtu.be/xyz123 128'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '🎧', key: msg.key } });

  try {
    const yt = new Youtubers();
    
    // 1. Ambil info & link download
    const data = await yt.infoVideo(url); 
    const result = await yt.downloadyt(url, selectedQuality, 'audio');

    if (!result.status) throw new Error(result.pesan);

    // Ambil daftar kualitas audio untuk caption
    const audioFormats = data.infoLengkap.audio_formats || [];
    const availableQualities = audioFormats.map(f => {
      return `• ${f.label} (Kode: ${f.quality || '128'})`; 
    }).join('\n');

    // 2. Kirim Thumbnail dengan Caption
    const captionThumbnail = `*YOUTUBE AUDIO DOWNLOADER*\n\n` +
                             `• *Judul:* ${data.judul}\n` +
                             `• *Durasi:* ${data.durasi}\n\n` +
                             `*Kualitas Audio Tersedia:*\n${availableQualities}\n\n` +
                             `*Mengunduh Kualitas:* ${selectedQuality} (Mengirim 2 Versi Audio)`;

    await sock.sendMessage(from, {
      image: { url: data.thumbnail },
      caption: captionThumbnail
    }, { quoted: msg });

    // --- [ VERSI A: AUDIO LANGSUNG PUTAR (CEPAT) ] ---
    
    await sock.sendMessage(from, {
        audio: { url: result.url },
        mimetype: 'audio/mp4', 
        caption: `[1/2] ✅ Audio Langsung Putar (M4A):\n*${data.judul}*`
    }, { quoted: msg });
    
    // --- [ LANGKAH PEMROSESAN METADATA ] ---
    
    // 3. Download Audio URL ke file sementara (.mp3)
    await downloadAndSave(result.url, audioTempPath);
    
    // 4. Download Thumbnail URL ke file sementara (.jpg)
    await downloadAndSave(data.thumbnail, imageTempPath);
    
    // 5. Sematkan Metadata ke file audio (PERBAIKAN ada di dalam fungsi ini)
    await embedMetadata(audioTempPath, imageTempPath, {
        title: data.judul,
        artist: data.infoLengkap.channelName || 'YouTube' 
    });
    
    // --- [ VERSI B: FILE MP3 DENGAN METADATA ] ---

    // 6. Kirim Audio yang sudah memiliki metadata sebagai Dokumen (MP3)
    await sock.sendMessage(from, {
        document: { stream: fs.createReadStream(audioTempPath) }, 
        mimetype: 'audio/mp3', 
        fileName: `${data.judul}.mp3`,
        caption: `[2/2] ✅ File MP3 dengan Sampul Metadata:\n*${data.judul}*`
    }, { quoted: msg });

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (err) {
    console.error(err);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    sock.sendMessage(from, {
      text: `❌ Gagal memproses atau mengunduh audio.\n\n${err.message}`
    }, { quoted: msg });
  } finally {
    // 7. Bersihkan file sementara
    try {
        await fsp.unlink(audioTempPath); 
        await fsp.unlink(imageTempPath); 
    } catch (e) {
        // Abaikan error
    }
  }
};

export default {
  command: ['ytmp3', 'yta'],
  description: 'Download audio MP3 dengan sampul metadata dari YouTube dalam 2 versi',
  category: 'Downloader',
  handler,
};