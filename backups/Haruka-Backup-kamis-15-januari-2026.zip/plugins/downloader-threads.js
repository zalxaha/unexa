import axios from 'axios';
import * as cheerio from 'cheerio';

// --- FUNGSI SCRAPER (Native/Tanpa API Pihak ke-3) ---
async function scrapeThreads(url) {
    try {
        const { data } = await axios.get(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.9',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'none',
                'Upgrade-Insecure-Requests': '1'
            }
        });

        const $ = cheerio.load(data);

        // Ambil Metadata lengkap (Title biasanya berisi Username)
        const description = $('meta[property="og:description"]').attr('content') || '-';
        const title = $('meta[property="og:title"]').attr('content') || 'Threads Post';
        const imageUrl = $('meta[property="og:image"]').attr('content');
        
        let videoUrl = null;

        // Logika pencarian JSON (Recursion)
        const findVideoVersions = (obj) => {
            if (!obj || typeof obj !== 'object') return null;
            
            if (Array.isArray(obj)) {
                for (let item of obj) {
                    const result = findVideoVersions(item);
                    if (result) return result;
                }
            } else {
                if (obj.video_versions) return obj.video_versions;
                for (let key in obj) {
                    const result = findVideoVersions(obj[key]);
                    if (result) return result;
                }
            }
            return null;
        };

        // Parsing Script JSON
        $('script[type="application/json"]').each((i, el) => {
            const content = $(el).html();
            if (content && content.includes('video_versions')) {
                try {
                    const json = JSON.parse(content);
                    const videoVersions = findVideoVersions(json);
                    
                    if (videoVersions && videoVersions.length > 0) {
                        videoUrl = videoVersions[0].url;
                        return false; 
                    }
                } catch (e) {
                    // Ignore error
                }
            }
        });

        // Return Data Lengkap
        const resultData = {
            title: title,
            desc: description,
            url: videoUrl || imageUrl,
            type: videoUrl ? 'video' : 'image'
        };

        if (!resultData.url) return null;
        return resultData;

    } catch (error) {
        throw new Error(`Gagal scraping: ${error.message}`);
    }
}

// --- HANDLER UTAMA ---
const handler = async ({ sock, msg, from, command, args }) => {
    
    const text = args.join(' ').trim();
    
    if (!text || (!text.includes('threads.net') && !text.includes('threads.com'))) {
        return sock.sendMessage(from, { 
            text: `❌ URL tidak valid. Masukkan link Threads!\n\nContoh:\n*.${command} https://www.threads.net/@user/post/XXX*` 
        }, { quoted: msg });
    }

    try {
        await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

        // 1. Jalankan Scraper
        const result = await scrapeThreads(text);

        if (!result) {
            throw new Error("Media tidak ditemukan (Mungkin akun privat).");
        }

        // 2. Buat Caption Lengkap
        // Format: Signature + Title/User + Deskripsi
        const finalCaption = `H͟a͟r͟u͟k͟a͟ *threads downloader*\n\n` +
                             `👤 *${result.title}*\n` +
                             `📝 ${result.desc}`;

        // 3. Download Media ke Buffer
        const response = await axios.get(result.url, { 
            responseType: 'arraybuffer',
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        
        const mediaBuffer = Buffer.from(response.data);
        const isVideo = result.type === 'video';

        // 4. Kirim ke WhatsApp
        if (isVideo) {
            await sock.sendMessage(from, { 
                video: mediaBuffer, 
                caption: finalCaption,
                mimetype: 'video/mp4'
            }, { quoted: msg });
        } else {
            await sock.sendMessage(from, { 
                image: mediaBuffer, 
                caption: finalCaption 
            }, { quoted: msg });
        }

        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (e) {
        console.error(`[THREADS ERROR] ${e.message}`);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        await sock.sendMessage(from, { text: `❌ Gagal: ${e.message}` }, { quoted: msg });
    }
};

export default {
    command: ["threads", "thrd", "th"],
    description: 'Download media Threads (Scrape Native).',
    category: 'downloader', 
    handler,
};
