import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { existsSync } from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import cfg from '../config/config.json' with { type: 'json' };

const PLUGINS_DIR = path.join(__dirname);
const BOT_FILENAME = path.basename(__filename);

const STATE_FILE = path.join(__dirname, '../database/plugin_state.json');
const LOG_FILE   = path.join(__dirname, '../database/plugin_update_log.json');

// ================= UTIL =================

const ensureExtension = n => n.endsWith('.js') ? n : `${n}.js`;

const sanitizePath = (file) => {
    const full = path.join(PLUGINS_DIR, file);
    if (!full.startsWith(PLUGINS_DIR)) throw new Error('Path traversal');
    return full;
};

const ensureDb = async () => {
    const dir = path.dirname(STATE_FILE);
    try { await fs.access(dir); }
    catch { await fs.mkdir(dir, { recursive: true }); }
};

const saveHistory = async ({ added=[], modified=[], deleted=[] }) => {
    if (![added, modified, deleted].some(a => a.length)) return;

    await ensureDb();

    let logs = [];
    if (existsSync(LOG_FILE)) {
        logs = JSON.parse(await fs.readFile(LOG_FILE, 'utf8'));
    }

    logs.push({
        time: Date.now(),
        added,
        modified,
        deleted
    });

    // simpan max 7 hari
    const MAX = 7 * 86400000;
    logs = logs.filter(l => Date.now() - l.time <= MAX);

    await fs.writeFile(LOG_FILE, JSON.stringify(logs, null, 2));
};

const updateState = async () => {
    const files = (await fs.readdir(PLUGINS_DIR)).filter(f => f.endsWith('.js'));
    const state = {};

    for (const f of files) {
        const s = await fs.stat(path.join(PLUGINS_DIR, f));
        state[f] = s.mtimeMs;
    }

    await fs.writeFile(STATE_FILE, JSON.stringify(state, null, 2));
};

// ================= HANDLER =================

const handler = async ({ sock, msg, args, from }) => {
    const sender = msg.key.participant || msg.key.remoteJid;
    const allowed = [`${cfg.owner}@s.whatsapp.net`, ...(cfg.ownerAltJids || [])];

    if (!allowed.includes(sender)) {
        return sock.sendMessage(from, { text: '🚫 Owner only' }, { quoted: msg });
    }

    const cmd = args[0]?.toLowerCase();
    let filename = args[1];

    // ================= LIST =================
    if (cmd === 'list') {
        const files = (await fs.readdir(PLUGINS_DIR)).filter(f => f.endsWith('.js'));
        return sock.sendMessage(from, {
            text: `📁 *Plugin (${files.length})*\n\n${files.join('\n')}`
        }, { quoted: msg });
    }

    // ================= UPDATE (VIEW ONLY) =================
    if (cmd === 'update' || cmd === 'up') {
        const q = args[1] || '24h';

        if (!existsSync(LOG_FILE)) {
            return sock.sendMessage(from, { text: '📭 Belum ada history.' }, { quoted: msg });
        }

        const logs = JSON.parse(await fs.readFile(LOG_FILE, 'utf8'));
        const now = Date.now();

        let filtered = logs;
        if (q === '24h') filtered = logs.filter(l => now - l.time <= 86400000);
        else if (q.endsWith('d')) {
            const d = parseInt(q);
            filtered = logs.filter(l => now - l.time <= d * 86400000);
        }

        if (!filtered.length) {
            return sock.sendMessage(from, { text: '📭 Tidak ada update.' }, { quoted: msg });
        }

        const text = filtered.slice(-20).reverse().map(l =>
`🕒 ${new Date(l.time).toLocaleString('id-ID')}
🆕 ${l.added.join(', ') || '-'}
✏️ ${l.modified.join(', ') || '-'}
🗑️ ${l.deleted.join(', ') || '-'}`).join('\n\n');

        return sock.sendMessage(from, {
            text: `📜 *History Update*\n\n${text}`
        }, { quoted: msg });
    }

    // ================= SAVE =================
    if (cmd === 'save' || cmd === 'sv') {
        if (!filename) return sock.sendMessage(from, { text: 'Contoh: .p save menu' }, { quoted: msg });

        filename = ensureExtension(filename);

        const quoted = msg.message.extendedTextMessage?.contextInfo?.quotedMessage;
        const code = quoted?.conversation || quoted?.extendedTextMessage?.text;
        if (!code) return sock.sendMessage(from, { text: 'Reply kodenya' }, { quoted: msg });

        const exists = existsSync(sanitizePath(filename));
        await fs.writeFile(sanitizePath(filename), code, 'utf8');

        await saveHistory({
            added: exists ? [] : [filename],
            modified: exists ? [filename] : []
        });

        await updateState();

        return sock.sendMessage(from, { text: `✅ ${filename} disimpan.` }, { quoted: msg });
    }

    // ================= DELETE =================
    if (cmd === 'delete' || cmd === 'del') {
        if (!filename) return sock.sendMessage(from, { text: 'Contoh: .p del menu' }, { quoted: msg });

        filename = ensureExtension(filename);
        if (filename === BOT_FILENAME) {
            return sock.sendMessage(from, { text: '❌ Tidak bisa hapus file ini.' }, { quoted: msg });
        }

        await fs.unlink(sanitizePath(filename));

        await saveHistory({ deleted: [filename] });
        await updateState();

        return sock.sendMessage(from, { text: `🗑️ ${filename} dihapus.` }, { quoted: msg });
    }

    // ================= HELP =================
    return sock.sendMessage(from, {
        text:
`⚙️ *Plugin Manager*

.p save <nama> (auto log)
.p del <nama> (auto log)
.p list
.p update
.p update 24h
.p update 3d
.p update all`
    }, { quoted: msg });
};

export default {
    command: ['plugin', 'p'],
    description: 'Plugin Manager Auto History',
    category: 'owner',
    handler
};