import { igdl } from 'btch-downloader';

const handler = async ({ sock, msg, from, command, args }) => {
    
    const text = args.join(' ').trim();
    
    // Regex validasi URL Instagram
    const IG_URL_REGEX = /(instagram\.com|instagr\.am|threads\.net|threads\.com)/i;
    
    if (!text || !text.match(IG_URL_REGEX)) {
        return sock.sendMessage(from, { 
            text: `❌ URL tidak valid. Masukkan link Instagram atau Threads!\n\nContoh:\n*.${command} https://www.instagram.com/reel/xxx/*` 
        }, { quoted: msg });
    }

    try {
        await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

        // 1. Ambil data dari btch-downloader
        const data = await igdl(text);
        
        // ==========================================
        // 🛠️ DEBUGGING ZONE (Hapus nanti jika sudah fix)
        // ==========================================
        
        // Tampilkan di Terminal (Server)
        console.log('--- [DEBUG IG JSON] ---');
        console.log(JSON.stringify(data, null, 2));
        console.log('-----------------------');

        // Kirim JSON mentah ke Chat WhatsApp
        await sock.sendMessage(from, { 
            text: `🔍 *DEBUG OUTPUT BTCH:*\n\n\`\`\`${JSON.stringify(data, null, 2)}\`\`\`` 
        }, { quoted: msg });

        // ==========================================
        // END DEBUGGING ZONE
        // ==========================================

        // Validasi hasil standar
        if (!data || !data.result || data.result.length === 0) {
            await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
            return sock.sendMessage(from, { text: "⚠️ Data kosong/null. Cek JSON di atas." }, { quoted: msg });
        }

        // Lanjut mencoba mengirim media (meskipun mungkin error jika struktur beda)
        for (const item of data.result) {
            const mediaUrl = item.url;
            
            try {
                // Prioritas Video
                await sock.sendMessage(from, { 
                    video: { url: mediaUrl }, 
                    caption: `H͟a͟r͟u͟k͟a͟ *Instagram Debug*` 
                }, { quoted: msg });
            } catch (videoErr) {
                try {
                    // Fallback Gambar
                    await sock.sendMessage(from, { 
                        image: { url: mediaUrl }, 
                        caption: `H͟a͟r͟u͟k͟a͟ *Instagram Debug*` 
                    }, { quoted: msg });
                } catch (imgErr) {
                    console.error(`Gagal kirim media: ${mediaUrl}`);
                }
            }
        }

        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (e) {
        console.error(`[IG DL ERROR] ${e.message}`);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        await sock.sendMessage(from, { text: `❌ Error: ${e.message}` }, { quoted: msg });
    }
};

export default {
    command: ["ig", "igdl", "instagram"], 
    description: 'Mode Debug Instagram Downloader', 
    category: 'downloader', 
    handler,
};