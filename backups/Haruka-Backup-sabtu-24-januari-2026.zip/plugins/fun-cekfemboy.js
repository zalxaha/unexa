import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';

const execPromise = promisify(exec);

// --- CORE LOGIC ---
function cekFemboyLogic(nama) {
    const percent = Math.floor(Math.random() * 101);
    let desc = '';
    let imgUrl = '';
    
    if (percent < 20) {
        desc = 'Cowok banget! 😎';
        imgUrl = 'https://cek-seberapa-femboy.vercel.app/img/normal.gif';
    } else if (percent < 40) {
        desc = 'Ada aura lembutnya dikit~ 🌸';
        imgUrl = 'https://cek-seberapa-femboy.vercel.app/img/dibwh40.gif';
    } else if (percent < 60) {
        desc = 'Lumayan femboy 😘';
        imgUrl = 'https://cek-seberapa-femboy.vercel.app/img/dibwh60.gif';
    } else if (percent < 80) {
        desc = 'Femboy sejati 💅✨';
        imgUrl = 'https://cek-seberapa-femboy.vercel.app/img/dibwh80.gif';
    } else {
        desc = 'FEMBOY DEWA 🔥💖';
        imgUrl = 'https://cek-seberapa-femboy.vercel.app/img/femboyyyy.gif';
    }
    
    return {
        text: `🔍 *Analisis Femboy*\n\nTarget: ${nama}\nPersentase: *${percent}%*\nStatus: ${desc}`,
        gif: imgUrl
    };
}

// --- HELPER: CONVERT GIF TO MP4 ---
async function gifToMp4(gifBuffer) {
    const filename = Date.now();
    const gifPath = path.join(process.cwd(), `${filename}.gif`);
    const mp4Path = path.join(process.cwd(), `${filename}.mp4`);

    try {
        await fs.promises.writeFile(gifPath, gifBuffer);
        // Convert GIF to MP4 (Resolusi genap & Faststart)
        await execPromise(`ffmpeg -i "${gifPath}" -movflags faststart -pix_fmt yuv420p -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2" "${mp4Path}"`);
        const mp4Buffer = await fs.promises.readFile(mp4Path);
        
        // Cleanup
        await fs.promises.unlink(gifPath);
        await fs.promises.unlink(mp4Path);
        return mp4Buffer;
    } catch (e) {
        if (fs.existsSync(gifPath)) await fs.promises.unlink(gifPath).catch(() => {});
        if (fs.existsSync(mp4Path)) await fs.promises.unlink(mp4Path).catch(() => {});
        throw e;
    }
}

// --- HANDLER ---
export default {
    command: ['cekfemboy', 'femboy', 'femboycheck'],
    description: 'Mengecek seberapa femboy seseorang (Video Loop).',
    category: 'fun',
    
    handler: async ({ sock, msg, args, from, pushName }) => {
        try {
            // 1. Cek Mentions (Orang yang ditag)
            const mentions = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
            
            let targetName = args.join(' ');
            let targetMentions = [...mentions];

            // 2. Logika Penentuan Target
            if (!targetName) {
                // Jika tidak ada input, pakai pushName (Pengirim)
                targetName = pushName || 'Kamu';
            } 
            // Jika user ngetag orang, targetName otomatis berisi "@628xx..." dari args
            // dan targetMentions berisi JID mereka agar tag-nya aktif/biru.

            await sock.sendMessage(from, { react: { text: '🏳️‍⚧️', key: msg.key } });

            const result = cekFemboyLogic(targetName);
            const caption = `H͟a͟r͟u͟k͟a͟\n\n${result.text}`;

            // 3. Download GIF
            const response = await axios.get(result.gif, { responseType: 'arraybuffer' });
            
            try {
                // 4. Konversi ke MP4
                const videoBuffer = await gifToMp4(response.data);

                // Kirim Video Loop
                await sock.sendMessage(from, {
                    video: videoBuffer,
                    caption: caption,
                    gifPlayback: true,
                    mentions: targetMentions // Sertakan mentions agar tag orang lain berfungsi
                }, { quoted: msg });

            } catch (ffmpegErr) {
                console.error('[FFMPEG ERROR]', ffmpegErr.message);
                
                // Fallback jika FFmpeg error
                await sock.sendMessage(from, {
                    document: response.data,
                    mimetype: 'image/gif',
                    fileName: 'result.gif',
                    caption: caption, // Caption mungkin tidak muncul di dokumen, tergantung versi WA
                    mentions: targetMentions
                }, { quoted: msg });
                
                // Kirim teks terpisah jika pakai mode dokumen agar caption terbaca
                await sock.sendMessage(from, { text: caption, mentions: targetMentions }, { quoted: msg });
            }

        } catch (e) {
            console.error('[CEKFEMBOY ERROR]', e);
            msg.reply('❌ Terjadi kesalahan sistem.');
        }
    }
};