import { getContentType } from '@whiskeysockets/baileys';

export default {
    command: ['getm', 'quoted', 'metadata', 'inspect'],
    category: 'Tools',
    description: 'Mengambil metadata/JSON mentah dari pesan yang di-reply',

    handler: async ({ sock, msg, reply }) => {
        // 1. Cek apakah user me-reply pesan
        if (!msg.quoted) {
            return reply('❌ Reply pesan (teks/media) yang ingin dicek metadatanya!');
        }

        try {
            // 2. Ambil objek pesan yang di-quoted
            // msg.quoted di sistem handler kamu biasanya sudah diparsing, 
            // tapi kita perlu akses raw object dari Baileys jika ingin lihat detail aslinya.
            // Namun, karena handler kamu sudah mempermudah, kita ambil dari msg.quoted yang sudah tersedia.
            
            const quotedMsg = msg.quoted;
            
            // 3. Tentukan Tipe Pesan
            const type = getContentType(quotedMsg.message) || Object.keys(quotedMsg.message)[0];

            // 4. Filter data yang mau ditampilkan (Biar gak terlalu berantakan)
            // Kita kloning objek biar aman
            const metadata = JSON.parse(JSON.stringify(quotedMsg));
            
            // Hapus buffer data yang panjang (seperti thumbnail gambar) biar chat gak nge-lag
            if (metadata.message?.[type]?.jpegThumbnail) {
                metadata.message[type].jpegThumbnail = "(Binary Data - Hidden)";
            }
            if (metadata.message?.[type]?.thumbnailDirectPath) {
                 // Tetap tampilkan jika string
            }

            // 5. Susun Laporan
            const textResult = `
🔍 *METADATA INSPECTOR*

🆔 *ID Pesan:* ${quotedMsg.id}
👤 *Pengirim:* ${quotedMsg.sender}
📄 *Tipe:* ${type}

📂 *Raw JSON:*
\`\`\`json
${JSON.stringify(metadata.message, null, 2)}
\`\`\`
`.trim();

            // 6. Kirim Balasan
            await reply(textResult);

        } catch (e) {
            console.error(e);
            return reply('❌ Gagal mengambil metadata pesan.');
        }
    }
};