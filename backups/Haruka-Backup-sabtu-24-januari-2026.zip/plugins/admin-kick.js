import { jidNormalizedUser } from '@whiskeysockets/baileys';

export default {
    command: ['kick', 'keluarkan', 'ban', 'tendang'],
    description: 'Mengeluarkan anggota dari grup.',
    category: 'Group',

    // KONFIGURASI HANDLER
    isGroup: true,
    isAdmin: true,
    isBotAdmin: true,

    handler: async ({ sock, msg, args, participants, from, quoted }) => {
        try {
            // 1. Tentukan target (Prioritas: Quoted -> Mention -> Input Nomor)
            let targetJid = null;

            if (msg.quoted) {
                targetJid = msg.quoted.sender;
            } else if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                targetJid = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
            } else if (args.length > 0) {
                // Bersihkan input angka
                const cleanNum = args[0].replace(/[^0-9]/g, '');
                if (cleanNum) targetJid = cleanNum + '@s.whatsapp.net';
            }

            // Validasi Target
            if (!targetJid) {
                return msg.reply('❗ Mohon tag, reply pesan, atau ketik nomor target yang ingin dikeluarkan.');
            }

            // 2. Cek apakah target ada di grup (LOGIKA PENCARIAN DIPERBAIKI)
            // Kita ambil Nomor HP-nya saja untuk membandingkan, agar LID vs Phone JID tetap cocok
            const targetNum = jidNormalizedUser(targetJid).split('@')[0];

            const targetMember = participants.find(p => {
                const pNum = jidNormalizedUser(p.id).split('@')[0];
                return pNum === targetNum;
            });

            if (!targetMember) {
                return msg.reply(`❌ Target @${targetNum} tidak ditemukan dalam grup ini.`, { mentions: [targetJid] });
            }

            // Pastikan kita menggunakan JID ASLI dari metadata peserta untuk kick
            // (Kadang WA menolak jika kita kick pakai JID hasil convert manual)
            const finalJidToKick = targetMember.id; 

            // Validasi Safety
            const botJid = jidNormalizedUser(sock.user.id);
            if (targetNum === botJid.split('@')[0]) return msg.reply('❌ Jangan keluarkan bot.');
            if (targetNum === msg.sender.split('@')[0]) return msg.reply('❌ Kamu tidak bisa mengeluarkan dirimu sendiri.');

            // Beri reaksi proses
            await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

            // 3. Eksekusi Kick
            const response = await sock.groupParticipantsUpdate(from, [finalJidToKick], 'remove');

            // Cek status respon
            // Respons sukses biasanya [{ status: '200', jid: ... }]
            const status = response[0]?.status;

            if (status === '200') {
                await sock.sendMessage(from, { react: { text: '👋', key: msg.key } });
                await sock.sendMessage(from, { 
                    text: `✅ Berhasil mengeluarkan @${targetNum}`,
                    mentions: [finalJidToKick]
                }, { quoted: msg });
            } else if (status === '403') {
                await sock.sendMessage(from, { react: { text: '🚫', key: msg.key } });
                msg.reply('❌ Gagal: Bot tidak memiliki izin (Mungkin target adalah Super Admin).');
            } else {
                msg.reply(`❌ Gagal mengeluarkan target. Status code: ${status}`);
            }

        } catch (e) {
            console.error('[KICK ERROR]', e);
            msg.reply('❌ Terjadi kesalahan saat mencoba mengeluarkan anggota.');
        }
    }
};