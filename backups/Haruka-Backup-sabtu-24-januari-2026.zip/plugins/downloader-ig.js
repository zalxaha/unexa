import { igdl } from 'btch-downloader'
import axios from 'axios'
import fs from 'fs'
import path from 'path'
import crypto from 'crypto'

const handler = async ({ sock, msg, from, args }) => {
    const url = args.join(' ').trim()
    
    // 1. Validasi URL
    if (!/instagram\.com|threads\.net/i.test(url)) {
        return sock.sendMessage(from, { text: '❌ URL tidak valid' }, { quoted: msg })
    }

    // Buat folder tmp jika belum ada
    const tmpDir = path.resolve('./tmp')
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })

    try {
        await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } })

        const data = await igdl(url)
        if (!data || !data.result || data.result.length === 0) {
            throw 'Media tidak ditemukan'
        }

        // ==========================================
        // 2. FILTER DUPLIKAT & ABAIKAN THUMBNAIL
        // ==========================================
        const uniqueUrls = new Set()
        const cleanLinks = []

        for (const item of data.result) {
            // Kita HANYA ambil 'item.url'. Field 'thumbnail' kita cuekin total.
            const mediaUrl = item.url

            // Cek apakah URL ada isinya DAN belum pernah disimpan
            if (mediaUrl && !uniqueUrls.has(mediaUrl)) {
                uniqueUrls.add(mediaUrl)
                cleanLinks.push(mediaUrl)
            }
        }
        // ==========================================

        if (cleanLinks.length === 0) throw 'Tidak ada URL media yang valid.'

        // 3. PROSES DOWNLOAD
        for (const link of cleanLinks) {
            const tempFileName = `${crypto.randomBytes(6).toString('hex')}.dat`
            const filePath = path.join(tmpDir, tempFileName)

            try {
                // A. Download Stream ke TMP
                const writer = fs.createWriteStream(filePath)
                const response = await axios.get(link, { responseType: 'stream' })
                
                response.data.pipe(writer)

                await new Promise((resolve, reject) => {
                    writer.on('finish', resolve)
                    writer.on('error', reject)
                })

                // B. Cek Magic Number (DNA File) - PALING AKURAT
                // Baca 4 byte pertama untuk pastikan ini Gambar atau Video
                const fd = fs.openSync(filePath, 'r')
                const buffer = Buffer.alloc(4)
                fs.readSync(fd, buffer, 0, 4, 0)
                fs.closeSync(fd)

                const hex = buffer.toString('hex').toUpperCase()
                // Header Gambar: FFD8 (JPG), 8950 (PNG), 5249 (WEBP)
                const isImage = hex.startsWith('FFD8') || hex.startsWith('8950') || hex.startsWith('5249')

                // C. Kirim Sesuai Tipe Asli
                if (isImage) {
                    await sock.sendMessage(from, {
                        image: { url: filePath },
                        caption: 'H͟a͟r͟u͟k͟a͟ *Instagram downloader*'
                    }, { quoted: msg })
                } else {
                    await sock.sendMessage(from, {
                        video: { url: filePath },
                        mimetype: 'video/mp4',
                        caption: 'H͟a͟r͟u͟k͟a͟ *Instagram downloader*'
                    }, { quoted: msg })
                }

            } catch (err) {
                console.error('Error processing media:', err)
            } finally {
                // D. Hapus File Sampah
                if (fs.existsSync(filePath)) fs.unlinkSync(filePath)
            }
        }

        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } })

    } catch (e) {
        console.error(e)
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } })
        await sock.sendMessage(from, { text: `❌ Gagal: ${e.message || e}` }, { quoted: msg })
    }
}

export default {
    command: ['ig', 'igdl', 'instagram'],
    category: 'downloader',
    handler
}