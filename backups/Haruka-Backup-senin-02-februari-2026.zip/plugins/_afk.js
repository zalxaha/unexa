const handler = async ({ msg, args, sender, db }) => {
    const reason = args.join(' ').trim() || 'tanpa alasan';
    const now = Date.now();

    let userEntry = db[sender];
    if (!userEntry) return;

    userEntry.afk = now;
    userEntry.afkReason = reason;

    // Format yang benar agar .trim() bekerja pada string sebelum dikirim
    await msg.reply(`
Kamu sekarang AFK!
${reason !== 'tanpa alasan' ? 'Dengan alasan: *' + reason + '*' : 'Tanpa alasan.'}
`.trim());
};

export default {
    command: ['afk'],
    category: 'user',
    handler
};
