import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import cfg from '../config/config.json' with { type: 'json' };

const PLUGINS_DIR = path.join(__dirname);

// --- ALGORITMA SIMILARITY (Levenshtein Distance) ---
const levenshtein = (a, b) => {
    if (a.length === 0) return b.length;
    if (b.length === 0) return a.length;
    const matrix = [];
    for (let i = 0; i <= b.length; i++) matrix[i] = [i];
    for (let j = 0; j <= a.length; j++) matrix[0][j] = j;
    for (let i = 1; i <= b.length; i++) {
        for (let j = 1; j <= a.length; j++) {
            if (b.charAt(i - 1) === a.charAt(j - 1)) {
                matrix[i][j] = matrix[i - 1][j - 1];
            } else {
                matrix[i][j] = Math.min(
                    matrix[i - 1][j - 1] + 1,
                    matrix[i][j - 1] + 1,
                    matrix[i - 1][j] + 1
                );
            }
        }
    }
    return matrix[b.length][a.length];
};

// Helper: Mencari file paling mirip
const findClosestFile = async (inputName) => {
    try {
        const files = (await fs.readdir(PLUGINS_DIR)).filter(f => f.endsWith('.js'));
        let closest = null;
        let minDistance = Infinity;

        // Threshold toleransi (semakin kecil, semakin harus mirip)
        const threshold = 3; 

        for (const file of files) {
            // Bandingkan nama file tanpa .js dengan input
            const fileNameNoExt = file.replace('.js', '');
            const dist = levenshtein(inputName.toLowerCase(), fileNameNoExt.toLowerCase());

            if (dist < minDistance) {
                minDistance = dist;
                closest = file;
            }
        }

        // Jika jaraknya cukup dekat (<= threshold), kembalikan closest
        if (closest && minDistance <= threshold) {
            return { found: true, name: closest, distance: minDistance };
        }
        return { found: false };

    } catch (e) {
        return { found: false };
    }
};

const handler = async ({ sock, msg, args, from }) => {
    const sender = msg.key.participant || msg.key.remoteJid;
    let filename = args[0];
    
    // --- Pengecekan Owner ---
    const authorizedJids = [
        `${cfg.owner}@s.whatsapp.net`,
        ...(cfg.ownerAltJids || [])
    ];
    
    if (!authorizedJids.includes(sender)) {
        return sock.sendMessage(from, { text: "🚫 Akses ditolak. Perintah ini hanya untuk Owner." }, { quoted: msg });
    }

    if (!filename) {
        return sock.sendMessage(from, { text: `📄 Gunakan *.getp <nama_file>*\nContoh: *.getp menu* (Otomatis cari menu.js)` }, { quoted: msg });
    }

    // 1. Coba baca langsung (Auto add .js)
    let targetFile = filename.endsWith('.js') ? filename : `${filename}.js`;
    let filePath = path.join(PLUGINS_DIR, targetFile);
    let isCorrection = false;

    try {
        // Cek apakah file exact ada
        await fs.access(filePath);
    } catch (e) {
        // 2. Jika tidak ada, gunakan SIMILARITY
        const match = await findClosestFile(filename);
        if (match.found) {
            targetFile = match.name;
            filePath = path.join(PLUGINS_DIR, targetFile);
            isCorrection = true; // Tandai bahwa ini hasil koreksi
        } else {
            return sock.sendMessage(from, { text: `❌ File *${filename}* tidak ditemukan dan tidak ada yang mirip.` }, { quoted: msg });
        }
    }

    // Baca file yang ditemukan (Entah exact atau hasil similarity)
    try {
        const codeContent = await fs.readFile(filePath, 'utf8');

        await sock.sendMessage(from, { react: { text: '📄', key: msg.key } });
        
        let header = isCorrection 
            ? `⚠️ File *${filename}* tidak ada, menampilkan *${targetFile}*:\n\n`
            : `*Kode File: ${targetFile}*\n\n`;

        let responseText = header + '```javascript\n' + codeContent + '\n```';

        await sock.sendMessage(from, { text: responseText }, { quoted: msg });

    } catch (e) {
        console.error('[GETP ERROR]', e);
        return sock.sendMessage(from, { text: `❌ Error membaca file: ${e.message}` }, { quoted: msg });
    }
};

export default {
    command: ['getp', 'getcode', 'gp'],
    description: 'Mengambil kode plugin (Auto Similarity & .js)',
    category: 'owner',
    handler,
};
