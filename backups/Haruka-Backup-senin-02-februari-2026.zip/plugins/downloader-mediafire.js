import fetch from 'node-fetch';
import * as cheerio from 'cheerio';

async function mediafireDownloader(url) {
    const response = await fetch('https://r.jina.ai/' + url, {
        headers: { 'x-return-format': 'html' }
    });
    if (!response.ok) throw new Error("Gagal mengambil data dari MediaFire!");

    const textHtml = await response.text();
    const $ = cheerio.load(textHtml);
    
    const TimeMatch = $('div.DLExtraInfo-uploadLocation div.DLExtraInfo-sectionDetails')
        .text()
        .match(/This file was uploaded from (.*?) on (.*?) at (.*?)\n/);

    const downloadButtonText = $('a#downloadButton').text().trim();
    const fileSizeMatch = downloadButtonText.match(/\((.*?B)\)/i); 
    let fileSize = fileSizeMatch ? fileSizeMatch[1].trim() : "Tidak diketahui";

    if (fileSize === "Tidak diketahui") {
        const sizeLine = downloadButtonText.split('\n').map(t => t.trim()).filter(t => t.length > 0 && !t.toLowerCase().includes('download'))[0];
        if (sizeLine) {
            fileSize = sizeLine.replace(/[()]/g, '');
        }
    }

    return {
        filename: $('div.dl-btn-label').attr('title') || $('div.dl-btn-label').text().trim() || "file",
        url: $('a#downloadButton').attr('href'),
        size: fileSize,
        from: TimeMatch?.[1] || "Tidak diketahui",
        date: TimeMatch?.[2] || "Tidak diketahui",
        time: TimeMatch?.[3] || "Tidak diketahui"
    };
}

const handler = async ({ sock, msg, args, from }) => {
  const url = args[0];
  
  if (!url) {
    return sock.sendMessage(from, {
      text: 'Masukkan link MediaFire yang ingin diunduh.\nContoh: .mf https://www.mediafire.com/file/xyz123'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '⌛', key: msg.key } });

  try {
    
    const result = await mediafireDownloader(url); 

    if (!result.url) throw new Error("Gagal mendapatkan link unduhan langsung.");

    const caption = `✅ *Berhasil mengunduh file dari MediaFire!*\n\n`
        + `📂 *Nama File:* ${result.filename}\n`
        + `📦 *Ukuran:* ${result.size}\n`
        + `📅 *Tanggal Unggah:* ${result.date}\n`
        + `⏰ *Waktu Unggah:* ${result.time}\n`
        + `🌍 *Diupload dari:* ${result.from}`;

    await sock.sendMessage(from, {
        document: { url: result.url }, 
        mimetype: 'application/octet-stream', 
        fileName: result.filename,
        caption: caption
    }, { quoted: msg });

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (err) {
    console.error(err);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    sock.sendMessage(from, {
      text: `❌ Gagal memproses atau mengunduh file dari MediaFire.\n\n${err.message}`
    }, { quoted: msg });
  } 
};

export default {
  command: ['mediafire', 'mf'],
  description: 'Download file dari MediaFire.',
  category: 'Downloader',
  handler,
};