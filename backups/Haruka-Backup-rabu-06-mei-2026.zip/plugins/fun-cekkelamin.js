// --- HELPER: GACHA SYSTEM ---
// Fungsi buat milih kata-kata berdasarkan persentase chance (Rarity)
function getJokeByRarity(tiers) {
    const rand = Math.random() * 100;
    let cumulative = 0;
    for (const tier of tiers) {
        cumulative += tier.chance;
        if (rand < cumulative) {
            const jokes = tier.texts;
            const selectedJoke = jokes[Math.floor(Math.random() * jokes.length)];
            return `[${tier.name}] ${selectedJoke}`;
        }
    }
    return tiers[0].texts[0]; // Fallback
}

// --- CORE LOGIC ---
function cekKelaminLogic(nama) {
    // Penentuan Gender Utama (45% Cowok, 45% Cewek, 10% Alien/Gak Jelas)
    const genderRand = Math.random() * 100;
    let gender = '';
    
    if (genderRand < 45) gender = 'Cowok ♂️';
    else if (genderRand < 90) gender = 'Cewek ♀️';
    else gender = 'Gak Jelas 👽';
    
    let desc = '';
    
    if (gender === 'Cowok ♂️') {
        const cowokTiers = [
            {
                name: '⚪ NORMAL',
                chance: 50,
                texts: [
                    'Standar SNI bang, ukuran wajar pemakaian normal 📏',
                    'Kecil tapi lincah kek kancil 🦌',
                    'Aman terkendali, bersih rajin dicuci 🧼',
                    'Cukuplah buat menuhin celana dalem 🩲',
                    'Gak gede ga kecil, pas lah pokoknya 👍',
                    'Biasa aja bang, ga ada yang spesial 🥱',
                    'Lurus tegap kayak paskibraka 🇮🇩',
                    'Lumayan rapi, sering di-trimming ya? ✂️'
                ]
            },
            {
                name: '🔵 RARE',
                chance: 30,
                texts: [
                    'Ih uler gondrong, jembutnya lebat banget kek hutan amazon 🐍🌲',
                    'Bengkok ke kiri dikit bre, kebanyakan coli pake tangan kanan ya? 🗿',
                    'Busettt hitam dekil banyak dakinya 🌚',
                    'Belum disunat nih pasti, masih ada helm batoknya 🪖',
                    'Kecil banget kek tauge warteg, kasian 🌱',
                    'Bentuknya kek jamur enoki, kurus panjang pucet 🍄',
                    'Udah karatan bang, jarang dipakai ya? 🔧',
                    'Bau menyan njir, lu abis ritual pesugihan ya? 🧟',
                    'Jembutnya rimbun bisa buat sarang burung pipit 🐦',
                    'Sekali senggol langsung muncrat, cupu bat 💦'
                ]
            },
            {
                name: '🟣 EPIC',
                chance: 15,
                texts: [
                    'Wah, gede dan berurat nih bang, idaman tante-tante 🍌🔥',
                    'Mulus banget kek perosotan TK, rajin *waxing* bang? ✨',
                    'Bisa nyala dalam gelap (Glow in the Dark) 💡',
                    'Wanginya kayak parfum bapak-bapak sholat jumat 🕌',
                    'Awas meledak bang, udah tegang banget tuh uratnya 💣',
                    'Tindik di ujungnya, anak punk sejati lu bang 🎸',
                    'Bisa muter 360 derajat kek bor listrik 🌪️',
                    'Warna-warni njir, lu abis nyelupin ke catokan kanvas? 🎨'
                ]
            },
            {
                name: '🟡 MYTHIC',
                chance: 5,
                texts: [
                    'LEGENDARY EXCALIBUR! Sekali tebas nembus dimensi! ⚔️🌌',
                    'Udah di bore-up, pake knalpot racing mberrr 🏍️💨',
                    'Bisa nembak laser kek Cyclops Mobile Legends 👁️⚡',
                    'Punya Bluetooth dan WiFi, bisa connect ke Spotify 🎧',
                    'Berlapis emas 24 karat, sultan mah bebas 🥇💸'
                ]
            }
        ];
        desc = getJokeByRarity(cowokTiers);

    } else if (gender === 'Cewek ♀️') {
        const cewekTiers = [
            {
                name: '⚪ NORMAL',
                chance: 50,
                texts: [
                    'Masih segel pabrik nih boss, aman 📦',
                    'Standar aja sih, rapi dan bersih 🌸',
                    'Lecet dikit pemakaian wajar, *good condition* 🛠️',
                    'Mulus pink merona sewajarnya 🍑',
                    'Aman terkendali, ga ada bau aneh-aneh 🍃',
                    'Biasa aja kak, ga terlalu longgar ga terlalu rapet 👌',
                    'Rajin dirawat nih kayaknya, bersih ✨'
                ]
            },
            {
                name: '🔵 RARE',
                chance: 30,
                texts: [
                    'Ih udah ga perawan ya, pantesan mbleber 🤭',
                    'Wah longgar bat kek goa jepang 🕳️',
                    'Busettt tembem banget kek bakpao baru mateng 🥟',
                    'Gelap bet kek masa depan lu 🌑',
                    'Banyak sarang laba-labanya, udah lama ga ada yang jenguk ya? 🕸️',
                    'Asem banget kek ketek tukang becak abis narik 🍋',
                    'Bau amis kek pasar ikan, mandi woy! 🐟',
                    'Udah sering dilewatin banyak orang nih kek jalan tol 🛣️',
                    'Rapi banget kek alis mbak-mbak SCBD 💅',
                    'Datar banget kek landasan pacu bandara 🛬'
                ]
            },
            {
                name: '🟣 EPIC',
                chance: 15,
                texts: [
                    'Wangi stroberi mempesona, *aesthetic* banget 🍓✨',
                    'Udah kayak sumur bor, dalem banget ga ada ujungnya 🪣',
                    'Hati-hati banyak jebakan betmennya, gigit boss 🦇',
                    'Bisa nyedot sekuat *vacuum cleaner* industri 🌪️',
                    'Udah dipasangin AC di dalemnya, seger bener ❄️',
                    'Bentuknya lope-lope (❤️), kok bisa gitu anjir?',
                    'Dalemnya ada lampu diskon kelap-kelip 🪩'
                ]
            },
            {
                name: '🟡 MYTHIC',
                chance: 5,
                texts: [
                    'SUPER BLACKHOLE! Masuk kesitu ga bisa balik lagi 🕳️🌌',
                    'Punya gigi taring di dalem, Mengerikan! 🧛‍♀️',
                    'Ada gerbang tol otomatis pake e-money 💳🚧',
                    'Dalemnya seluas kebun sawit, bisa buat ternak sapi 🌴🐄',
                    'Bisa ngomong dan nyanyi dangdut koplo 🎤💃'
                ]
            }
        ];
        desc = getJokeByRarity(cewekTiers);

    } else {
        const alienTiers = [
            {
                name: '⚪ NORMAL',
                chance: 50,
                texts: [
                    'Lu spesies apa njir, ga ada bentuknya sama sekali 👾',
                    'Datar kek talenan emak, lu beneran manusia? 🪵',
                    'Gak deteksi kelamin apapun, lu robot kah? 🤖',
                    'Cuma ada scan barcode QRIS, bayar dulu sini 📱'
                ]
            },
            {
                name: '🟡 MYTHIC',
                chance: 50, // Alien chance lebih kecil dari awal, jadi dalamnya gedein aja
                texts: [
                    'Bisa bongkar pasang kek lego, canggih bener 🧱',
                    'Cuma ada port USB Type-C, ngecasnya gimana woy? 🔌',
                    'Bentuknya kotak, lu warga Minecraft nyasar ya? 🟩',
                    'Punya baling-baling bambu, mau terbang kemana lu? 🚁',
                    'Isinya mesin capit boneka, koinnya masukin mana? 🕹️'
                ]
            }
        ];
        desc = getJokeByRarity(alienTiers);
    }
    
    return `🔍 *Analisis Kelamin*\n\nTarget: ${nama}\nGender: *${gender}*\n\n${desc}`;
}

// --- HANDLER ---
export default {
    command: ['cekkelamin', 'kelamin', 'cekgender'],
    description: 'Mengecek kelamin seseorang beserta Rarity (Gacha jokes).',
    category: 'fun',
    
    handler: async ({ sock, msg, args, from, pushName }) => {
        try {
            const mentions = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
            
            let targetName = args.join(' ');
            let targetMentions = [...mentions];

            if (!targetName) {
                targetName = pushName || 'Kamu';
            } 

            // Kasih reaction nunggu
            await sock.sendMessage(from, { react: { text: '🎰', key: msg.key } });

            const resultText = cekKelaminLogic(targetName);
            const caption = `H͟a͟r͟u͟k͟a͟ B͟o͟t͟\n\n${resultText}`;

            // Kirim hasilnya
            await sock.sendMessage(from, { 
                text: caption, 
                mentions: targetMentions 
            }, { quoted: msg });

        } catch (e) {
            console.error('[CEKKELAMIN ERROR]', e);
            msg.reply('❌ Terjadi kesalahan sistem saat mengecek kelamin.');
        }
    }
};