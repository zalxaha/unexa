import https from 'https';
import { generateWAMessageContent, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';

const getInitialAuth = () => {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'id.pinterest.com',
      path: '/',
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'
      }
    };
    https.get(options, res => {
      const cookies = res.headers['set-cookie'];
      if (cookies) {
        const csrfCookie = cookies.find(c => c.startsWith('csrftoken='));
        const pinterestSessCookie = cookies.find(c => c.startsWith('_pinterest_sess='));
        if (csrfCookie && pinterestSessCookie) {
          const csrftoken = csrfCookie.split(';')[0].split('=')[1];
          const sess = pinterestSessCookie.split(';')[0];
          resolve({ csrftoken, cookieHeader: `csrftoken=${csrftoken}; ${sess}` });
          return;
        }
      }
      reject(new Error('Gagal mendapatkan CSRF token atau session cookie.'));
    }).on('error', e => reject(e));
  });
};

const searchPinterestAPI = async (query, limit) => {
  try {
    const { csrftoken, cookieHeader } = await getInitialAuth();
    let results = [];
    let bookmark = null;
    let keepFetching = true;
    
    while (keepFetching && results.length < limit) {
      const postData = {
        options: {
          query: query,
          scope: 'pins',
          bookmarks: bookmark ? [bookmark] : []
        },
        context: {}
      };
      const sourceUrl = `/search/pins/?q=${encodeURIComponent(query)}`;
      const dataString = `source_url=${encodeURIComponent(sourceUrl)}&data=${encodeURIComponent(JSON.stringify(postData))}`;
      
      const options = {
        hostname: 'id.pinterest.com',
        path: '/resource/BaseSearchResource/get/',
        method: 'POST',
        headers: {
          Accept: 'application/json, text/javascript, */*, q=0.01',
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
          'X-Requested-With': 'XMLHttpRequest',
          'X-CSRFToken': csrftoken,
          'X-Pinterest-Source-Url': sourceUrl,
          Cookie: cookieHeader
        }
      };
      
      const responseBody = await new Promise((resolve, reject) => {
        const req = https.request(options, res => {
          let body = '';
          res.on('data', chunk => body += chunk);
          res.on('end', () => resolve(body));
        });
        req.on('error', e => reject(e));
        req.write(dataString);
        req.end();
      });
      
      const jsonResponse = JSON.parse(responseBody);
      
      if (jsonResponse.resource_response && jsonResponse.resource_response.data && jsonResponse.resource_response.data.results) {
        const pins = jsonResponse.resource_response.data.results;
        pins.forEach(pin => {
          if (pin.images && pin.images['736x']) results.push(pin.images['736x'].url);
          else if (pin.images && pin.images['orig']) results.push(pin.images['orig'].url);
        });
        
        bookmark = jsonResponse.resource_response.bookmark;
        if (!bookmark || pins.length === 0) keepFetching = false;
      } else {
        keepFetching = false;
      }
    }
    
    return results.slice(0, limit);
    
  } catch (e) {
    throw new Error(`Pinterest API Error: ${e.message}`);
  }
};

// --- [ BAGIAN HANDLER ] ---

const handler = async ({ sock, msg, args, from }) => {
  try {
    const text = args.join(' ');
    
    if (!text) {
      return sock.sendMessage(from, { text: '❌ Masukkan kueri pencarian.\n\nContoh:\n`.pin anime girl, 5`\n`.pin city aesthetic`' }, { quoted: msg });
    }
    
    const parts = text.split(',');
    const query = parts[0].trim();
    const limit = parts[1] ? parseInt(parts[1].trim()) : 5; 
    
    const finalLimit = Math.min(limit, 10); // Batasi maksimal 10 slide agar tidak lag
    
    if (finalLimit <= 0 || isNaN(finalLimit)) {
        return sock.sendMessage(from, { text: '❌ Batas hasil harus berupa angka positif.' }, { quoted: msg });
    }
    
    await sock.sendMessage(from, { react: { text: '🔎', key: msg.key } });
    
    const res = await searchPinterestAPI(query, finalLimit);
    
    if (res.length === 0) {
      return sock.sendMessage(from, { text: `❌ Tidak ditemukan hasil Pin untuk kueri: *${query}*` }, { quoted: msg });
    }

    const cards = [];

    // Proses URL menjadi bentuk kartu/slide
    for (let i = 0; i < res.length; i++) {
        const url = res[i];
        
        // Buat konten gambar untuk masing-masing slide
        const imageMessage = await generateWAMessageContent(
            { image: { url: url } },
            { upload: sock.waUploadToServer }
        );

        cards.push({
            header: proto.Message.InteractiveMessage.Header.create({
                title: `Pin ${i + 1}`,
                subtitle: "Pinterest",
                hasMediaAttachment: true,
                imageMessage: imageMessage.imageMessage
            }),
            body: proto.Message.InteractiveMessage.Body.create({
                text: `Hasil pencarian untuk: *${query}*`
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
                text: `Gambar ${i + 1} dari ${res.length}`
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Lihat Resolusi Penuh",
                            url: url,
                            merchant_url: url
                        })
                    }
                ]
            })
        });
    }

    // Bungkus semua kartu dalam bentuk Carousel
    const msgPayload = generateWAMessageFromContent(from, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({ 
                        text: `✅ Ditemukan ${res.length} gambar untuk: *${query}*\n_(Geser ke kanan untuk melihat hasil)_` 
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({ 
                        text: "Pinterest Search By Haruka Bot" 
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({ 
                        hasMediaAttachment: false 
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.create({
                        cards: cards
                    })
                })
            }
        }
    }, { quoted: msg });

    await sock.relayMessage(from, msgPayload.message, { messageId: msgPayload.key.id });
    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
    
  } catch (e) {
    console.error('[PINTEREST HANDLER ERROR]', e);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    sock.sendMessage(from, { text: `❌ Terjadi kesalahan:\n${e.message}` }, { quoted: msg });
  }
};

export default {
  command: ['pin', 'pinterest'],
  description: 'Cari gambar dari Pinterest.',
  category: 'Search',
  handler,
};