import axios from 'axios';

class Mobinime {
    constructor() {
        this.inst = axios.create({
            baseURL: 'https://air.vunime.my.id/mobinime',
            headers: {
                'accept-encoding': 'gzip',
                'content-type': 'application/x-www-form-urlencoded; charset=utf-8',
                host: 'air.vunime.my.id',
                'user-agent': 'Dart/3.3 (dart:io)',
                'x-api-key': 'ThWmZq4t7w!z%C*F-JaNdRgUkXn2r5u8'
            }
        });
    }

    // Menambah parameter count agar hasil search bisa diatur
    async search(query, count = 20) {
        const { data } = await this.inst.post('/anime/search', { 
            perpage: count.toString(), 
            startpage: '0', 
            q: query 
        });
        return data;
    }

    async detail(id) {
        const { data } = await this.inst.post('/anime/detail', { id: id.toString() });
        return data;
    }

    async stream(id, epsid) {
        try {
            const { data: srv } = await this.inst.post('/anime/get-server-list', {
                id: epsid.toString(),
                animeId: id.toString(),
                jenisAnime: '1',
                userId: ''
            });
            if (!srv || !srv.serverurl) return null;

            const { data: video } = await this.inst.post('/anime/get-url-video', {
                url: srv.serverurl,
                quality: 'HD',
                position: '0'
            });
            return video?.url || null;
        } catch { return null; }
    }
}

const mobi = new Mobinime();

const handler = async ({ sock, msg, from, args, command }) => {
    const text = args.join(' ').trim();
    
    try {
        if (!isNaN(text) && text !== "") {
            // == LOGIC DETAIL & STREAMING ==
            await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });
            
            const res = await mobi.detail(text);
            const anime = res.data || (res.id ? res : null);
            
            if (!anime) return msg.reply("❌ Data anime tidak ditemukan atau API sedang error.");

            // 1. Perbaikan GENRE (Handle Array atau String)
            let genreText = '-';
            if (anime.genre) {
                if (Array.isArray(anime.genre)) {
                    // Jika array object [{title:'Action'},...], ambil titlenya. Jika array string, langsung join.
                    genreText = anime.genre.map(g => g.title || g.name || g).join(', ');
                } else {
                    genreText = anime.genre;
                }
            }

            // 2. Perbaikan STATUS
            const statusText = anime.status || anime.status_anime || '-';

            // 3. Ambil List Episode
            // API kadang mengembalikan key berbeda, kita cek satu per satu
            let episodes = anime.episode || anime.list_episode || anime.episodes || res.episode || [];
            
            // Jika episodes terbalik (terbaru paling atas), kita reverse agar urut dari eps 1
            // (Opsional, tergantung selera. Hapus .reverse() jika ingin yang terbaru di atas)
            if (Array.isArray(episodes)) episodes.reverse();

            let cap = `🎬 *${anime.title || 'No Title'}*\n`;
            cap += `⭐ Rating: ${anime.rating || '-'}\n`;
            cap += `🎭 Genre: ${genreText}\n`;
            cap += `🎥 Status: ${statusText}\n`;
            cap += `📝 Total Eps: ${episodes.length || '-'}\n\n`;
            cap += `📽️ *LINK NONTON (HD):*\nWait... mengambil semua link (${episodes.length} eps)\n\n`;

            if (Array.isArray(episodes) && episodes.length > 0) {
                // == PERBAIKAN UTAMA: MENGHAPUS SLICE (LIMIT 10) ==
                // Kita ambil semua episode.
                // NOTE: Jika episode > 50, ini akan memakan waktu lama.
                
                let foundLink = false;
                
                // Menggunakan Promise.all untuk mempercepat fetching (Concurrency)
                // Hati-hati: terlalu banyak request bersamaan bisa kena block IP.
                // Disini kita gunakan loop serial biasa agar aman, tapi tanpa limit 10.
                
                for (let ep of episodes) {
                    const epId = ep.id || ep.episode_id || ep.eps_id;
                    const epTitle = ep.title || ep.episode || '?';
                    
                    if (!epId) continue;

                    // Fetch link stream
                    const link = await mobi.stream(text, epId);
                    
                    if (link) {
                        cap += `📍 *Eps ${epTitle}:*\n${link}\n\n`;
                        foundLink = true;
                    }
                }
                
                if (!foundLink) cap += `_Link streaming belum di-upload oleh admin Mobinime._`;
            } else {
                cap += `_Maaf, daftar episode belum tersedia (Anime mungkin belum rilis/Coming Soon)._`;
            }

            const poster = anime.poster || anime.thumbnail || anime.image;
            
            // Kirim hasil
            if (poster) {
                await sock.sendMessage(from, { image: { url: poster }, caption: cap }, { quoted: msg });
            } else {
                await sock.sendMessage(from, { text: cap }, { quoted: msg });
            }
            await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

        } else {
            // == LOGIC SEARCH ==
            if (!text) return msg.reply(`🔍 Mau cari anime apa?\nContoh: *.${command} spy x family*`);
            
            await sock.sendMessage(from, { react: { text: '🔎', key: msg.key } });
            
            // Request 20 hasil pencarian
            const results = await mobi.search(text, 20);
            const list = Array.isArray(results) ? results : (results.data || []);

            if (list.length === 0) return msg.reply("❌ Anime tidak ditemukan.");

            let txt = `🔍 *Hasil Pencarian: ${text}*\n\n`;
            list.forEach((v, i) => {
                const t = v.title || v.name;
                // Pastikan ID ada
                const id = v.id;
                txt += `*${i + 1}. ${t}*\n🆔 ID: \`${id}\`\n👉 Ketik: \`.${command} ${id}\`\n\n`;
            });
            await sock.sendMessage(from, { text: txt }, { quoted: msg });
            await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
        }
    } catch (e) {
        console.error(e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        await sock.sendMessage(from, { text: `❌ Gagal mengambil data: ${e.message}` }, { quoted: msg });
    }
};

export default {
    command: ['anime', 'nonton'],
    description: 'Cari anime dan dapatkan link streaming HD.',
    category: 'nonton',
    handler,
};