
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const S_WHATSAPP_NET = '@s.whatsapp.net';

function mapTargetJid(incomingJid, db) {
  if (db[incomingJid]) {
      return incomingJid;
  }
  
  // Cari JID utama berdasarkan altJids
  for (const realJid in db) {
    if (db[realJid].altJids && db[realJid].altJids.includes(incomingJid)) {
      return realJid;
    }
  }
  
  return incomingJid;
}

const handler = async ({ sock, msg, args, isOwner, db, saveDatabase }) => { // Tambahkan 'sock'
    
    if (!isOwner) {
        return msg.reply('🚫 *Command ini hanya untuk Owner.*');
    }

    const usage = `*Usage:*
${process.env.PREFIX || '.'}addprem <nomor/jid/@tag> <durasi>
Atau balas pesan user:
${process.env.PREFIX || '.'}addprem <durasi>
    
*Contoh:*
${process.env.PREFIX || '.'}addprem @taguser 7d
(Balas pesan user) ${process.env.PREFIX || '.'}addprem 7d
    
*Format Durasi yang Valid:* 1d, 7d, 1m, 1y.
`;

    let targetJid = null;
    let durationString = null;
    let tempArgs = [...args]; 
    let mentionedJids = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

    // --- LOGIKA PENGAMBILAN TARGET JID DAN DURASI ---
    let isExtension = false;

    // 1. PRIORITY: REPLY PESAN
    if (msg.quoted) {
        targetJid = msg.quoted.sender;
        durationString = tempArgs[0]; 
    } 
    // 2. PRIORITY: TAG USER (@tag)
    else if (mentionedJids.length > 0) {
        targetJid = mentionedJids[0]; 
        durationString = tempArgs[1]; // Jika ada tag, durasi di argumen ke-2
    }
    // 3. PRIORITY: ARGUMEN TEKS (Nomor/JID)
    else if (tempArgs[0]) {
        const possibleJidOrNumber = tempArgs[0];
        
        if (possibleJidOrNumber.includes(S_WHATSAPP_NET) || /^\d+$/.test(possibleJidOrNumber)) {
            
            if (!possibleJidOrNumber.includes(S_WHATSAPP_NET)) {
                targetJid = possibleJidOrNumber.replace(/[^0-9]/g, '') + S_WHATSAPP_NET;
            } else {
                targetJid = possibleJidOrNumber.split('@')[0].replace(/[^0-9]/g, '') + S_WHATSAPP_NET;
            }
            
            durationString = tempArgs[1]; // Jika JID di argumen ke-1, durasi di argumen ke-2

        } 
    }
    
    if (!targetJid || !durationString) {
        return msg.reply(usage);
    }
    
    targetJid = targetJid.split(':')[0];

    // --- MAPPING JID PENTING UNTUK MENDAPATKAN JID UTAMA ---
    const finalTargetJid = mapTargetJid(targetJid, db);
    
    const match = durationString.match(/^(\d{1,3})([dmy])$/i);
    if (!match) {
        return msg.reply('⚠️ Format durasi tidak valid. Gunakan: `1d`, `7d`, `1m`, `1y`.');
    }
    
    const [_, numStr, unit] = match;
    const num = parseInt(numStr, 10);
    const now = Date.now();
    let durationMs = 0;
    
    const MS_IN_DAY = 24 * 60 * 60 * 1000;
    switch (unit.toLowerCase()) {
        case 'd': durationMs = num * MS_IN_DAY; break;
        case 'm': durationMs = num * 30 * MS_IN_DAY; break; // Asumsi 30 hari
        case 'y': durationMs = num * 365 * MS_IN_DAY; break;
        default: return msg.reply('⚠️ Satuan durasi tidak valid. Hanya `d`, `m`, atau `y`.');
    }

    if (durationMs < MS_IN_DAY) {
        return msg.reply('⚠️ Durasi premium minimal harus 1 hari (1d).');
    }

    // Jika JID utama belum ada di DB
    if (!db[finalTargetJid]) {
         db[finalTargetJid] = {
            nama: null,
            registered: false,
            lastReset: now,
            status: 'guest',
            premiumUntil: 0,
            altJids: [],
            lastPremiumNotif: 0
        };
    }
    
    const userEntry = db[finalTargetJid];
    
    const currentPremiumUntil = userEntry.premiumUntil || 0;
    isExtension = currentPremiumUntil > now;
    
    const startTimestamp = isExtension ? currentPremiumUntil : now;
    const newPremiumUntil = startTimestamp + durationMs;
    
    userEntry.premiumUntil = newPremiumUntil;
    userEntry.status = 'premium';
    userEntry.lastPremiumNotif = 0;
    
    // Logika untuk menambahkan JID cadangan ke JID utama
    if (targetJid !== finalTargetJid) {
        if (!userEntry.altJids) userEntry.altJids = [];
        if (!userEntry.altJids.includes(targetJid)) {
            userEntry.altJids.push(targetJid);
        }
    }
    
    await saveDatabase();

    const expiryDate = new Date(newPremiumUntil);
    const formattedDate = expiryDate.toLocaleDateString('id-ID', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });

    // --- LOGIKA NOTIFIKASI KE USER TARGET ---
    const actionText = isExtension ? 'DIPERPANJANG' : 'DITAMBAHKAN';
    const notificationText = `
✅ *PEMBERITAHUAN STATUS PREMIUM*
    
Status premium Anda telah *${actionText}* oleh Owner.
    
⏳ *Durasi:* ${num} ${unit.toUpperCase()}
🗓️ *Berakhir pada:* ${formattedDate}
`;
    try {
        await sock.sendMessage(finalTargetJid, { text: notificationText.trim() });
    } catch (e) {
        console.error(`Gagal mengirim notifikasi premium ke ${finalTargetJid}:`, e.message);
    }
    // ----------------------------------------


    let replyText = `✅ *STATUS PREMIUM DIPERBARUI*
        
👤 *User Target:* ${finalTargetJid}
⏳ *Durasi:* ${num} ${unit.toUpperCase()}
🗓️ *Berakhir pada:* ${formattedDate}
        
${isExtension ? 'Premium yang ada *diperpanjang*.' : 'Premium *baru* ditambahkan.'} Notifikasi telah dikirim.`;

    msg.reply(replyText.trim());
};

export default {
    command: ['addprem', 'tambahpremium'],
    category: 'owner',
    handler: handler,
    isOwner: true,
    isPremium: false,
    description: 'Menambahkan status premium kepada user tertentu.'
};
