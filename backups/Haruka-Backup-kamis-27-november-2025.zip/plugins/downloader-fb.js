import axios from 'axios';

const handler = async ({ sock, msg, args, from }) => {
  const url = args[0];
  const sender = msg.key.participant || msg.key.remoteJid;
  const senderJid = sender;
  const senderNumber = senderJid.split('@')[0];

  if (!url) {
    return sock.sendMessage(from, {
      text: '📌 Masukkan URL video Facebook!\nContoh: *.fb https://www.facebook.com/xxx*'
    }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

  try {
    const apiUrl = `https://tiktod.eu.org/facebook?url=${encodeURIComponent(url)}`;
    const res = await axios.get(apiUrl);
    const { status, result } = res.data;

    if (status !== 200 || !result || !result.video || result.video.length === 0) {
      throw new Error('❌ Gagal mendapatkan data video dari API.');
    }

    const videoDownloadLink = result.video[0];

    if (!videoDownloadLink) {
      throw new Error('❌ Link download video tidak ditemukan di hasil API.');
    }
    
    const resolutionMatch = videoDownloadLink.match(/(\d+p)/i);
    const resolution = resolutionMatch ? resolutionMatch[1].toUpperCase() : 'HD/SD';

    const videoBuffer = await axios.get(videoDownloadLink, { responseType: 'arraybuffer' }).then(res => res.data);
    
    const caption = `Ini kak videonya @${senderNumber}`;

    await sock.sendMessage(
      from, {
        video: videoBuffer,
        mimetype: "video/mp4",
        fileName: `facebook_video_${resolution}.mp4`, 
        caption: caption,
        mentions: [senderJid],
      }, {
        quoted: msg
      }
    );

    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  } catch (e) {
    console.error('[FB DOWNLOAD ERROR]', e);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    const errorMessage = e.response?.data?.message || e.message || 'Terjadi kesalahan tidak terduga.';
    return sock.sendMessage(from, {
      text: `❌ Gagal mengunduh video.\nDetail: ${errorMessage}`
    }, { quoted: msg });
  }
};

export default {
  command: ['facebook', 'fb', 'fbdownload', 'fbdl'],
  description: 'Download video dari Facebook',
  category: 'Downloader',
  handler,
};
