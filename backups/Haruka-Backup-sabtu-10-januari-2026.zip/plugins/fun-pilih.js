const handler = async ({ msg, args }) => {
    
    if (args.length === 0) {
        const prefix = process.env.PREFIX || '.';
        return msg.reply(`⚠️ *Usage:*
${prefix}pilih <opsi1> atau <opsi2> atau <opsi3>...

*Contoh:*
${prefix}pilih hari ini masak tahu atau tempe
${prefix}pilih merah atau biru atau hijau`);
    }

    const fullText = args.join(' ');

    let options = fullText.split(/\s+atau\s+/i)
                          .map(option => option.trim())
                          .filter(option => option.length > 0); 

    if (options.length < 2) {
        return msg.reply('🥺 Berikan minimal *dua* pilihan yang dipisahkan oleh kata **"atau"**.');
    }

    const randomIndex = Math.floor(Math.random() * options.length);
    
    const selectedOption = options[randomIndex];

    let replyText = `🤔 Anda bimbang antara ${options.length} pilihan...\n`;
    replyText += '✨ Setelah mempertimbangkan dengan seksama, keputusannya adalah:\n\n';
    replyText += `**➡️ ${selectedOption.toUpperCase()} ⬅️**\n\n`;
    replyText += 'Semoga ini membantu! 😉';

    msg.reply(replyText);
};

export default {
    command: ['pilih', 'choose'],
    category: 'fun',
    handler: handler,
    isOwner: false,
    isPremium: false,
    description: 'Memilih satu opsi secara acak dari pilihan yang Anda berikan (dipisahkan oleh "atau").'
};