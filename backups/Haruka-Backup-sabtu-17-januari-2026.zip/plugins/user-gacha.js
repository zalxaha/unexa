import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Path ke DB Gacha yang baru
const gachaDbPath = path.join(__dirname, '../database/gacha_log.json');
// Path ke DB User yang sudah ada
const userDbPath = path.join(__dirname, '../database/users.json');

const MS_IN_DAY = 24 * 60 * 60 * 1000;
// Offset WIB (UTC+7) dalam milidetik
const WIB_OFFSET_MS = 7 * 60 * 60 * 1000; 

// --- Helper Function: Mendapatkan Timestamp Tengah Malam WIB Hari Ini ---
function getWibMidnight(now) {
    // 1. Terapkan offset WIB ke waktu saat ini
    const wibTime = now + WIB_OFFSET_MS;
    
    // 2. Buat objek Date (ini akan memperlakukan wibTime sebagai UTC, tapi karena kita sudah menyesuaikan offset, 
    // hasilnya akan merefleksikan tanggal di WIB)
    const date = new Date(wibTime);
    
    // 3. Set jam, menit, detik, milidetik ke 00:00:00.000 (WIB)
    date.setUTCHours(0, 0, 0, 0); 
    
    // 4. Ubah kembali ke timestamp UTC (yang merupakan format penyimpanan 'lastClaim')
    // Ini adalah timestamp UTC yang setara dengan 00:00 WIB hari itu.
    return date.getTime() - WIB_OFFSET_MS;
}

// --- Helper Function: Membaca Database Gacha ---
async function readGachaDatabase() {
  let db = { gachaCodes: {}, userLog: {} };
  try {
    const fileContent = await fs.readFile(gachaDbPath, 'utf8');
    const trimmedContent = fileContent.trim();
    if (trimmedContent.length > 0) {
      db = JSON.parse(trimmedContent);
    } 
  } catch (error) {
    if (error.code === 'ENOENT') {
      // Inisialisasi DB Gacha default jika tidak ada
      db.gachaCodes = {
        "CODE_RARE_7D": { "days": 7, "probability": 0.005, "message": "🎉 Selamat! Anda memenangkan Premium 7 Hari! Jangan sampai terlewatkan!" },
        "CODE_UNCOMMON_3D": { "days": 3, "probability": 0.02, "message": "✨ Beruntung! Anda mendapatkan Premium 3 Hari!" },
        "CODE_COMMON_1D": { "days": 1, "probability": 0.05, "message": "🌟 Hore! Anda berhasil meraih Premium 1 Hari!" },
        "CODE_CONSOLATION": { "days": 0, "probability": 0.925, "message": "😔 Maaf, Anda belum beruntung. Coba lagi besok!" }
      };
      await fs.writeFile(gachaDbPath, JSON.stringify(db, null, 2));
    }
  }
  return db;
}

// --- Helper Function: Menulis Database Gacha ---
async function writeGachaDatabase(db) {
    await fs.writeFile(gachaDbPath, JSON.stringify(db, null, 2));
}

// --- Helper Function: Membaca Database User ---
async function readUserDatabase() {
  let db = {};
  try {
    const fileContent = await fs.readFile(userDbPath, 'utf8');
    const trimmedContent = fileContent.trim();
    if (trimmedContent.length > 0) {
      db = JSON.parse(trimmedContent);
    } 
  } catch (error) {
    if (error.code === 'ENOENT') {
      await fs.writeFile(userDbPath, JSON.stringify({}));
    }
    db = {};
  }
  return db;
}

// --- Helper Function: Menulis Database User ---
async function writeUserDatabase(db) {
    await fs.writeFile(userDbPath, JSON.stringify(db, null, 2));
}

// --- CORE LOGIC: Gacha Berbasis Probabilitas ---
function spinGacha(gachaCodes) {
    const codes = Object.values(gachaCodes);
    const rand = Math.random(); 
    let cumulativeProbability = 0;

    for (const code of codes) {
        cumulativeProbability += code.probability;
        if (rand < cumulativeProbability) {
            return code; 
        }
    }

    return codes[codes.length - 1]; 
}


// --- Handler Utama: gacha ---
const handler = async ({ sock, msg, args, sender, db: dbFromMsg }) => {
    
    const now = Date.now();
    const gachaDb = await readGachaDatabase();
    const userDb = await readUserDatabase();
    const userId = sender.split(':')[0]; 

    // 1. --- Pengecekan Cooldown Tengah Malam WIB ---
    const lastClaim = gachaDb.userLog[userId] ? gachaDb.userLog[userId].lastClaim : 0;
    
    // Dapatkan waktu tengah malam WIB terakhir
    const midnightWIB = getWibMidnight(now); 
    
    // Jika lastClaim lebih kecil dari timestamp tengah malam, berarti user belum klaim hari ini (WIB)
    if (lastClaim >= midnightWIB) {
        
        // Perhitungan waktu tersisa hingga tengah malam (UTC)
        const nextMidnightUTC = midnightWIB + MS_IN_DAY; // Tengah malam WIB berikutnya
        const timeLeftMs = nextMidnightUTC - now;
        
        const hours = Math.floor(timeLeftMs / (60 * 60 * 1000));
        const minutes = Math.floor((timeLeftMs % (60 * 60 * 1000)) / (60 * 1000));
        
        return msg.reply(`⏳ Anda sudah menggunakan Gacha hari ini.
        
Gacha akan *di-reset* pada jam 00:00 WIB.
Coba lagi dalam *${hours} jam ${minutes} menit*!`);
    }

    // 2. --- Proses Gacha ---
    const result = spinGacha(gachaDb.gachaCodes);
    
    // 3. --- Update Log Penggunaan ---
    if (!gachaDb.userLog) gachaDb.userLog = {};
    gachaDb.userLog[userId] = { lastClaim: now };
    await writeGachaDatabase(gachaDb);

    // 4. --- Memberikan Premium jika Menang ---
    if (result.days > 0) {
        
        if (!userDb[userId]) {
            userDb[userId] = {
                nama: null,
                registered: false,
                lastReset: now,
                status: 'guest',
                premiumUntil: 0,
                altJids: []
            };
        }
        
        const userEntry = userDb[userId];
        
        const currentPremiumUntil = userEntry.premiumUntil || 0;
        const startTimestamp = currentPremiumUntil > now ? currentPremiumUntil : now;
        const newPremiumUntil = startTimestamp + (result.days * MS_IN_DAY);
        
        userEntry.premiumUntil = newPremiumUntil;
        userEntry.status = 'premium';
        
        await writeUserDatabase(userDb);
        
        const expiryDate = new Date(newPremiumUntil);
        const formattedDate = expiryDate.toLocaleDateString('id-ID', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        
        let replyText = `🌟 *HASIL GACHA PREMIUM* 🌟
        
${result.message}
        
🎁 *Hadiah:* ${result.days} Hari Premium
🗓️ *Berakhir pada:* ${formattedDate}
        
Selamat menikmati fitur premium!`;

        msg.reply(replyText.trim());
        
    } else {
        // Kirim Balasan Kekalahan/Hiburan
        msg.reply(`❌ *HASIL GACHA PREMIUM* ❌
        
${result.message}
        
Silakan coba lagi besok untuk kesempatan menang!`);
    }

};

export default {
    command: ['gacha', 'claimpremium'],
    category: 'user',
    handler: handler,
    isOwner: false,
    isPremium: false,
    description: 'Coba keberuntungan Anda untuk mendapatkan premium gratis (terbatas 1x sehari, reset 00:00 WIB).',
};