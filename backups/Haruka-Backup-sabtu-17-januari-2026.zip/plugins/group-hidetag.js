export default {
    command: ['hidetag', 'tagallhide', 'taghide', 'h'], 
    description: 'Tag seluruh anggota grup tanpa menampilkan nama.',
    category: 'Group',
    
    // KONFIGURASI PENTING UNTUK HANDLER BARU
    isAdmin: true,    // Handler otomatis cek admin & fetch metadata
    isGroup: true,    // Handler otomatis tolak jika di private chat

    handler: async ({ sock, msg, args, participants, from }) => {
        try {
            // Kita langsung pakai 'participants' dari parameter handler
            // Tidak perlu sock.groupMetadata(from) lagi (Hemat resource)
            const memberJids = participants.map(member => member.id);

            // Ambil teks dari argumen atau pesan yang di-quote
            const q = msg.quoted ? msg.quoted.text : null;
            const textToTag = args.join(' ') || q || '📢 Pesan penting dari Admin Grup.';

            // Kirim pesan dengan mentions (Hidetag)
            await sock.sendMessage(from, { 
                text: textToTag, 
                mentions: memberJids 
            }, { quoted: msg });
            
        } catch (e) {
            console.error('[HIDETAG ERROR]', e);
            msg.reply('❌ Gagal mengirim hidetag.');
        }
    }
};