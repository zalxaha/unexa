import axios from 'axios';
import fileType from 'file-type'; 
import { downloadContentFromMessage } from '@whiskeysockets/baileys'; 
import path from 'path';
import { fileURLToPath } from 'url';

import cfg from '../config/config.json' with { type: 'json' };
import log from '../lib/logger.js';

class VertexAI {
    constructor() {
        this.api_url = 'https://generativelanguage.googleapis.com/v1beta/models';
        this.model_url = 'projects/gemmy-ai-bdc03/locations/us-central1/publishers/google/models';
        this.headers = {
            'content-type': 'application/json',
            'x-goog-api-key': 'AIzaSyD6QwvrvnjU7j-R6fkOghfIVKwtvc7SmLk' 
        };
        this.ratio = ['1:1', '3:4', '4:3', '9:16', '16:9'];
        this.model = {
            search: ['gemini-2.0-flash', 'gemini-2.5-flash', 'gemini-2.5-pro'], 
            chat: ['gemini-1.5-flash', 'gemini-2.5-flash', 'gemini-2.5-pro'],
            image: ['imagen-3.0-generate-002', 'imagen-4.0-generate-preview-06-06']
        };
    }
    
    chat = async function (question, { model = 'gemini-2.5-flash', system_instruction = null, file_buffer = null, search = true } = {}) {
        if (!question) throw new Error('Question is required');
        if (!this.model.chat.includes(model)) throw new Error(`Available models: ${this.model.chat.join(', ')}`);
        
        if (search && !this.model.search.includes(model)) {
            if (model.includes('1.5')) search = false; 
        }

        const parts = [{ text: question }];
        
        if (file_buffer) {
            let mimeType;
            try {
                const type = await fileType.fromBuffer(file_buffer); 
                if (!type) throw new Error("Could not determine file type.");
                mimeType = type.mime;
            } catch (e) {
                log.err('Gagal mendeteksi MIME type:', e.message);
                throw new Error('Gagal memproses file buffer.');
            }
            
            parts.unshift({
                inlineData: {
                    mimeType: mimeType,
                    data: file_buffer.toString('base64')
                }
            });
        }
        
        const payload = {
            contents: [
                ...(system_instruction ? [{
                    role: 'model',
                    parts: [{ text: system_instruction }]
                }] : []),
                {
                    role: 'user',
                    parts: parts
                }
            ],
            ...(search ? {
                tools: [{
                    googleSearch: {}
                }]
            } : {})
        };

        const r = await axios.post(`${this.api_url}/${this.model_url}/${model}:generateContent`, payload, {
            headers: this.headers
        });
        
        if (r.status !== 200) throw new Error(`API Response Error: Status ${r.status}`);
        
        const result = r.data.candidates;
        if (!result || result.length === 0) throw new Error('No candidate response found.');
        
        return result;
    }
}

const ai = new VertexAI();

async function sendReaction(sock, msgKey, reactionEmoji) {
    const remoteJid = msgKey.remoteJid;
    
    const reactionKey = {
        id: msgKey.id,
        remoteJid: remoteJid,
        fromMe: msgKey.fromMe || false,
        ...(msgKey.participant ? { participant: msgKey.participant } : {}) 
    };

    if (!reactionKey.id || !reactionKey.remoteJid) {
        log.err('Gagal mengirim reaksi: ID pesan atau JID tidak terdefinisi.');
        return;
    }

    return sock.sendMessage(remoteJid, {
        react: {
            text: reactionEmoji,
            key: reactionKey
        }
    });
}

export default {
    command: ['ai', 'ask', 'gemini', 'tanya'], 
    category: 'ai',
    
    handler: async function ({ sock, msg, args, remoteJid }) {
        let question = args.join(' ');
        let mediaBuffer = null;
        const targetMsgKey = msg.key; 

        if (msg.message.imageMessage || msg.message.videoMessage) {
            try {
                const type = Object.keys(msg.message)[0];
                const stream = await downloadContentFromMessage(msg.message[type], type.replace('Message', ''));
                let buffer = Buffer.from([]);
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }
                mediaBuffer = buffer;
            } catch (e) {
                log.err("Gagal mengunduh media pesan baru:", e.message);
                await sendReaction(sock, targetMsgKey, '❌'); 
                return msg.reply("❌ Gagal mengunduh media dari pesan Anda.");
            }
        } 
        else if (msg.quoted?.message && (msg.quoted.type.includes('Image') || msg.quoted.type.includes('Video'))) {
            mediaBuffer = await msg.quoted.download(); 
            question = msg.text.trim();
        }
        
        if (!question && !mediaBuffer) {
            const prefix = cfg.prefix || '.';
            return msg.reply(`*AI Multimodal Chat* 🤖
Tanyakan sesuatu:
1. ${prefix}ai kota terdingin di dunia
2. Kirim/balas gambar dengan caption: ${prefix}ai apa isi gambar ini?`);
        }

        if (mediaBuffer && !question) {
            question = "Deskripsikan atau analisis gambar/video ini.";
        }

        try {
            await sendReaction(sock, targetMsgKey, '⏳');
            
            const instruction = "Jawablah dengan format teks biasa (plain text) yang mudah dibaca di chat. Hindari penggunaan kode LaTeX ($...). Untuk pecahan, gunakan format (a b/c) atau (a/b).";
            const finalQuestion = instruction + " Pertanyaan: " + question;

            const candidates = await ai.chat(finalQuestion, { 
                model: 'gemini-2.5-flash', 
                file_buffer: mediaBuffer,
                search: true 
            });

            const result = candidates[0]?.content?.parts[0]?.text || 'Gagal mendapatkan jawaban dari AI.';

            await sendReaction(sock, targetMsgKey, '✅');
            
            await msg.reply(result);

        } catch (e) {
            log.err("AI Error:", e.message);
            
            await sendReaction(sock, targetMsgKey, '❌'); 
            
            if (e.message.includes('MIME') || e.message.includes('buffer')) {
                 return msg.reply('❌ Gagal memproses file. Pastikan itu adalah format gambar/video yang valid.');
            }
            return msg.reply('❌ Terjadi kesalahan saat menghubungi layanan AI. Coba lagi nanti.');
        }
    }
};
