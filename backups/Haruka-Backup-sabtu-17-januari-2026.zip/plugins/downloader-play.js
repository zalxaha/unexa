import axios from 'axios';
import yts from 'yt-search';
import { exec } from 'child_process';
import fs from 'fs';
import path from 'path';
import os from 'os';
import { promisify } from 'util';

const execPromise = promisify(exec);

// --- Scraper Downr ---
async function downr(url) {
    const headers = {
        'referer': 'https://downr.org/',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    };
    try {
        const check = await axios.get('https://downr.org/.netlify/functions/analytics', { headers });
        const { data } = await axios.post('https://downr.org/.netlify/functions/download', { url }, {
            headers: {
                ...headers,
                'content-type': 'application/json',
                'cookie': check.headers['set-cookie']?.join('; ') || ''
            }
        });
        return data;
    } catch (error) {
        throw new Error("Server Downr sibuk, coba lagi nanti.");
    }
}

const handler = async ({ sock, msg, args, from }) => {
    const text = args.join(' ');
    const tempDir = os.tmpdir();
    const tempId = Date.now();
    
    // Path file untuk proses konversi
    const inputPath = path.join(tempDir, `${tempId}_in.m4a`);
    const outputPath = path.join(tempDir, `${tempId}_out.mp3`);

    if (!text) return sock.sendMessage(from, { text: '❌ Judul lagunya apa, Jul?' }, { quoted: msg });

    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    try {
        const isURL = text.startsWith('http');
        let query = text;
        let videoMeta = {};

        // 1. Cari Video
        if (!isURL) {
            const search = await yts(text);
            const v = search.videos[0];
            if (!v) throw new Error('Lagunya nggak ketemu.');
            query = v.url;
            videoMeta = { title: v.title, author: v.author.name, thumb: v.thumbnail, duration: v.timestamp };
        }

        // 2. Ambil Link dari Scraper
        const result = await downr(query);
        if (result.error || !result.medias) throw new Error("Gagal ambil link.");
        
        if (isURL) {
            videoMeta = { 
                title: result.title, 
                author: result.author || 'YouTube', 
                thumb: result.thumbnail,
                duration: result.duration + 's'
            };
        }

        // Cari audio ITAG 140
        const audio = result.medias.find(m => String(m.itag) === '140');
        if (!audio) throw new Error("Link audio tidak ditemukan.");

        // --- 3. KIRIM THUMBNAIL & INFO (Kembali Ditampilkan) ---
        await sock.sendMessage(from, {
            image: { url: videoMeta.thumb },
            caption: `*YOUTUBE PLAY*\n\n` +
                     `• *Judul:* ${videoMeta.title}\n` +
                     `• *Channel:* ${videoMeta.author}\n` +
                     `• *Durasi:* ${videoMeta.duration}\n\n` +
                     `_Sedang mengkonversi ke MP3..._`
        }, { quoted: msg });

        // 4. Download file asli (M4A)
        const response = await axios.get(audio.url, { responseType: 'arraybuffer' });
        await fs.promises.writeFile(inputPath, Buffer.from(response.data));

        // --- 5. KONVERSI DENGAN FFMPEG ---
        // Mengubah bitrate ke 128k agar ukuran pas dan tidak corrupt
        await execPromise(`ffmpeg -i "${inputPath}" -vn -ar 44100 -ac 2 -b:a 128k "${outputPath}"`);

        const audioBuffer = fs.readFileSync(outputPath);

        // 6. Kirim Audio Player
        await sock.sendMessage(from, {
            audio: audioBuffer,
            mimetype: 'audio/mpeg',
            ptt: false 
        }, { quoted: msg });

        // 7. Kirim Dokumen MP3
        await sock.sendMessage(from, {
            document: audioBuffer,
            mimetype: 'audio/mpeg',
            fileName: `${videoMeta.title}.mp3`,
            caption: `✅ *${videoMeta.title}*\n\ncreate by ijul`
        }, { quoted: msg });

        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (err) {
        console.error(err);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        sock.sendMessage(from, { text: `❌ *Error:* ${err.message}` }, { quoted: msg });
    } finally {
        // Hapus file temp
        if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
        if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
    }
};

export default {
    command: ['play', 'song'],
    description: 'Download audio YouTube dengan Konversi FFmpeg',
    category: 'Downloader',
    handler,
};