import axios from 'axios';

/**
 * Scraper Downr.org
 * Mengambil metadata dan link download dari berbagai platform
 */
async function downr(url) {
    try {
        if (!url.includes('https://')) throw new Error('URL tidak valid.');
        
        // Step 1: Ambil cookie session melalui endpoint analytics
        const { headers } = await axios.get('https://downr.org/.netlify/functions/analytics', {
            headers: {
                referer: 'https://downr.org/',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
            }
        });
        
        // Step 2: Request data download
        const { data } = await axios.post('https://downr.org/.netlify/functions/download', {
            url: url
        }, {
            headers: {
                'accept': '*/*',
                'content-type': 'application/json',
                'cookie': headers['set-cookie']?.join('; ') || '',
                'origin': 'https://downr.org',
                'referer': 'https://downr.org/',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
            }
        });
        
        return data;
    } catch (error) {
        throw new Error(error.message);
    }
}

/**
 * Handler Bot (Baileys)
 */
const handler = async ({ sock, msg, args, from }) => {
    const text = args.join(' ');
    const url = text.trim().split(' ')[0];

    if (!url) {
        return sock.sendMessage(from, {
            text: '❌ Masukkan link YouTube yang valid.\nContoh: *.ytv https://youtu.be/xxxx*'
        }, { quoted: msg });
    }

    // React loading
    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    try {
        const result = await downr(url);

        if (result.error || !result.medias) {
            throw new Error("Gagal mendapatkan link download. Pastikan link video benar.");
        }

        /**
         * LOGIKA PENCEGAHAN CORRUPT:
         * YouTube memisahkan Video & Audio untuk resolusi tinggi (DASH).
         * Kita wajib mengambil media yang memiliki 'is_audio: true' DAN 'type: video'
         * agar file yang dikirim ke WhatsApp bisa langsung diputar dengan suara.
         */
        let validVideos = result.medias.filter(m => 
            m.type === 'video' && 
            m.extension === 'mp4' && 
            m.is_audio === true // Pastikan ini true agar ada suaranya
        );

        // Jika tidak ditemukan video yang sudah include audio, ambil video pertama sebagai fallback
        if (validVideos.length === 0) {
            validVideos = result.medias.filter(m => m.type === 'video' && m.extension === 'mp4');
        }

        // Urutkan berdasarkan kualitas terbaik (bitrate tertinggi)
        validVideos.sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0));

        const selected = validVideos[0];

        if (!selected || !selected.url) {
            throw new Error("Format video yang kompatibel tidak ditemukan.");
        }

        // Format info ukuran file
        const size = selected.contentLength 
            ? (parseInt(selected.contentLength) / (1024 * 1024)).toFixed(2) + ' MB' 
            : 'Unknown';

        const caption = `*H͟a͟r͟u͟k͟a͟ YOUTUBE VIDEO DOWNLOADER*\n\n` +
                        `✨ *Judul:* ${result.title}\n` +
                        `👤 *Channel:* ${result.author}\n` +
                        `🎞️ *Kualitas:* ${selected.qualityLabel || selected.label}\n` +
                        `📦 *Ukuran:* ${size}\n` +
                        `⏱️ *Durasi:* ${result.duration}s\n\n` +
                        `_Ini videonya_`;

        // Kirim Video
        await sock.sendMessage(from, {
            video: { url: selected.url },
            mimetype: 'video/mp4',
            fileName: `${result.title}.mp4`,
            caption: caption
        }, { quoted: msg });

        // React sukses
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (err) {
        console.error("YT-V ERROR:", err);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        sock.sendMessage(from, {
            text: `❌ *Error:* ${err.message}`
        }, { quoted: msg });
    }
};

export default {
    command: ['ytv', 'ytmp4'],
    description: 'Download video YouTube (MP4)',
    category: 'Downloader',
    handler,
};