import cfg from '../config/config.json' with { type: 'json' };

export default {
    command: ['profile', 'ceklevel', 'level', 'me', 'myprofile'],
    category: 'User',
    isOwner: false,
    isAdmin: false,
    isBotAdmin: false,
    isPremium: false,

    // Tambahkan 'pushName' di parameter handler untuk mengambil nama WA
    handler: async ({ sock, msg, sender, db, reply, sendImage, pushName }) => {
        // Ambil data user dari database
        const user = db[sender];

        if (!user) return reply('❌ Data user tidak ditemukan. Coba chat bot dulu.');

        // --- LOGIKA NAMA ---
        // Prioritas: 1. Nama Custom di DB -> 2. Username WA (pushName) -> 3. Default 'User'
        const displayName = user.nama || pushName || 'User';

        const isPremium = user.premiumUntil > Date.now();
        const premiumStatus = isPremium 
            ? `✅ Aktif (Exp: ${new Date(user.premiumUntil).toLocaleDateString('id-ID')})`
            : '❌ Tidak Aktif';

        // Hitung XP progress
        const currentLevel = user.level || 0;
        const nextLevel = currentLevel + 1;
        const xpForNextLevel = Math.pow(nextLevel / 0.1, 2);
        const xpNeeded = Math.ceil(xpForNextLevel - user.xp);
        const progressPercent = Math.floor((user.xp / xpForNextLevel) * 100);

        // Progress Bar
        const barLength = 10;
        const filledLength = Math.min(Math.floor((progressPercent / 100) * barLength), barLength);
        const progressBar = '█'.repeat(filledLength) + '░'.repeat(barLength - filledLength);

        const profileText = `
👤 *USER PROFILE*

🔖 *Nama:* ${displayName}
🏷️ *Title:* ${user.role || 'Kroco Parah'}
🆙 *Level:* ${user.level || 0}
✨ *XP:* ${user.xp || 0}
📉 *Progress:* [${progressBar}] ${progressPercent}%
_Butuh ${xpNeeded} XP lagi untuk naik level_

---------------------------

💳 *Limit Harian:* ${user.limit} / ${user.premiumUntil > 0 ? '∞' : 20}
💎 *Status Premium:* ${premiumStatus}

_Ingin ganti nama? Ketik .setname NamaKamu_
`.trim();

        try {
            const ppUrl = await sock.profilePictureUrl(sender, 'image');
            await sendImage(ppUrl, profileText);
        } catch {
            await reply(profileText);
        }
    }
};