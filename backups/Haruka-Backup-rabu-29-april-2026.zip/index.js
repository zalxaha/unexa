import 'dotenv/config';
import makeWASocket, {
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    getContentType,
    jidNormalizedUser
} from '@whiskeysockets/baileys';

import qr from 'qrcode-terminal';
import pino from 'pino';
import path from 'path';
import fs from 'fs/promises';
import * as fsSync from 'fs';
import { fileURLToPath } from 'url';
import { parsePhoneNumber } from 'libphonenumber-js';
import chalk from 'chalk';
import NodeCache from 'node-cache';

// Import Logger & Heartbeat
import log from './lib/logger.js';
import { startHeartbeat } from './lib/heartbeat.js';
// --- IMPORT GROUPS DATABASE ---
import { groupsDb } from './lib/database.js'; 

// --- GLOBAL VARIABLES ---
let MsgHandler;
let loadPlugins;
let config = {};

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Cache Metadata Grup & Retry
const groupMetadataCache = new NodeCache({ stdTTL: 60 * 60, checkperiod: 60 });
const msgRetryCounterCache = new NodeCache();

// [OPTIMISASI 1] Cache LID - Agar tidak request ke WA terus menerus saat spam
const lidCache = new NodeCache({ stdTTL: 86400, checkperiod: 3600 });

// =================================================================
// SIMPLE MESSAGE STORE (RAM SAVER & ANTI LAG)
// =================================================================
const simpleMessageStore = new Map();

setInterval(() => {
    const now = Date.now();
    for (const [key, value] of simpleMessageStore.entries()) {
        if (now - value.timestamp > 120000) {
            simpleMessageStore.delete(key);
        }
    }
    if (simpleMessageStore.size > 1000) {
        const keysToDelete = Array.from(simpleMessageStore.keys()).slice(0, 300);
        keysToDelete.forEach(k => simpleMessageStore.delete(k));
    }
}, 30 * 1000); 

// --- INITIALIZATION ---
async function initHandler() {
    try {
        const configPath = path.join(__dirname, 'config/config.json');
        const configFileContent = await fs.readFile(configPath, 'utf8');
        config = JSON.parse(configFileContent);
        
        const MsgModule = await import(`./handler.js?v=${Date.now()}`); 
        
        if (MsgModule.loadPlugins) {
             const ownerJid = jidNormalizedUser(config.owner + '@s.whatsapp.net');
             await MsgModule.loadPlugins(null, ownerJid);
        }

        MsgHandler = MsgModule.default;
        loadPlugins = MsgModule.loadPlugins;

        console.log(chalk.green('✅ Handler & Plugins loaded.'));
    } catch (e) {
        console.error(chalk.red('⚠️ Fatal Error Loading Handler:'), e);
    }
}

await initHandler();

let CallHandler;
try {
    const CallModule = await import('./lib/call.js');
    CallHandler = CallModule.default;
} catch { 
    log.warn('⚠️ lib/call.js tidak ditemukan, fitur tolak telepon dimatikan.'); 
}

const sessionFolder = path.join(__dirname, 'session');

async function validatePhoneNumber(input) {
    if (!input) return null;
    try {
        let phone = String(input).replace(/[^0-9]/g, "");
        if (!phone.startsWith('+')) phone = '+' + phone;
        const pn = parsePhoneNumber(phone);
        return pn?.isValid() ? pn.number.replace('+', '') : null;
    } catch { return null; }
}

async function Start() {
    try { await fs.access(sessionFolder); } catch { await fs.mkdir(sessionFolder, { recursive: true }); }

    const { state, saveCreds } = await useMultiFileAuthState(sessionFolder);
    const { version } = await fetchLatestBaileysVersion();

    log.info(`Baileys v${version.join('.')}`);
    config.version = version.join('.');
    const usePairing = config.system?.pairing === true;

    const sock = makeWASocket({
        version,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" })),
        },
        logger: pino({ level: "silent" }),
        printQRInTerminal: !usePairing,
        syncFullHistory: false, 
        generateHighQualityLinkPreview: true,
        markOnlineOnConnect: true,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        connectTimeoutMs: 60000,
        retryRequestDelayMs: 2000,
        msgRetryCounterCache,
        getMessage: async (key) => {
            const msgId = key.id;
            const cached = simpleMessageStore.get(msgId);
            if (cached) return cached.message;
            return undefined;
        }
    });

    startHeartbeat();

    sock.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            const decode = jidNormalizedUser(jid);
            return decode;
        }
        return jid;
    };

    sock.decodeLid = async (lid) => {
        if (!lid || !lid.endsWith('@lid')) return sock.decodeJid(lid);
        if (lidCache.has(lid)) return lidCache.get(lid);
        try {
            const key = sock.signalRepository?.lidMapping;
            if (key) {
                const mapping = await key.getPNForLID(lid);
                if (mapping) {
                    const result = sock.decodeJid(mapping);
                    lidCache.set(lid, result);
                    return result;
                }
            }
            return sock.decodeJid(lid);
        } catch (e) {
            return sock.decodeJid(lid);
        }
    };

    if (usePairing && !sock.authState.creds.registered) {
        setTimeout(async () => {
            const number = await validatePhoneNumber(config.system.number);
            if (!number) return log.err("Nomor pairing invalid di config.json");
            try {
                let code = await sock.requestPairingCode(number);
                code = code?.match(/.{1,4}/g)?.join('-') || code;
                console.log(chalk.bgGreen.black(`\n📞 KODE PAIRING: `) + " " + chalk.white.bold(code));
            } catch (err) { log.err("Gagal request pairing: " + err.message); }
        }, 3000);
    }

    sock.ev.on("connection.update", async ({ connection, lastDisconnect, qr: code }) => {
        if (code && !usePairing && !sock.authState.creds.registered) qr.generate(code, { small: true });
        
        if (connection === "open") {
            log.ok("Bot Connected & Ready!");
            try {
                const ownerJid = await sock.decodeLid(config.owner + "@s.whatsapp.net");
                await sock.sendMessage(ownerJid, { text: `✅ *Bot Online!*\nVersion: ${config.version}` });
            } catch {}

            // 🔥 AUTO-RECONNECT JADIBOT DIINISIASI DARI SINI 🔥
            setTimeout(async () => {
                const JADIBOT_DIR = path.join(__dirname, 'jadibots_sessions');
                try {
                    await fs.access(JADIBOT_DIR);
                    const dirs = await fs.readdir(JADIBOT_DIR);
                    if (dirs.length > 0) {
                        console.log(chalk.yellow(`\n🔄 Menginisiasi ${dirs.length} sesi Jadibot dari server utama...`));
                        const jbPlugin = await import(`./plugins/jadibot.js?v=${Date.now()}`);
                        if (jbPlugin.startJadibot) {
                            for (const dir of dirs) {
                                const credsPath = path.join(JADIBOT_DIR, dir, 'creds.json');
                                try {
                                    await fs.access(credsPath);
                                    jbPlugin.startJadibot(dir, sock);
                                    await new Promise(res => setTimeout(res, 3000)); 
                                } catch (e) {}
                            }
                        }
                    }
                } catch (e) {}
            }, 5000);
        }
        
        if (connection === "close") {
            const code = lastDisconnect?.error?.output?.statusCode;
            if (code === DisconnectReason.loggedOut) {
                log.err("Session Logout.");
                await fs.rm(sessionFolder, { recursive: true, force: true });
                process.exit(1);
            } else {
                log.warn("Reconnecting...");
                Start();
            }
        }
    });

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on('groups.update', async (updates) => {
        for (const update of updates) {
            if (update.subject) groupMetadataCache.set(update.id, { subject: update.subject });
        }
    });

    // =================================================================
    // --- EVENT LISTENER WELCOME, GOODBYE, PROMOTE (FIXED JID ERROR) ---
    // =================================================================
    sock.ev.on('group-participants.update', async (update) => {
        const { id, participants, action } = update;
        
        // LOG DI TERMINAL BIAR KETAHUAN BOT BACA EVENT ATAU NGGAK
        console.log(chalk.bgBlue.white(' [GROUP EVENT] '), `Aksi: ${action} di grup: ${id}`);
        
        try {
            // Cek apakah fitur welcome diaktifkan oleh admin grup di database
            const isWelcomeOn = groupsDb[id]?.welcome;
            if (!isWelcomeOn) {
                console.log(chalk.yellow(`[Welcome] Dilewati: Fitur welcome OFF di grup ini.`));
                return; 
            }

            // Ambil data grup dengan aman
            let groupMetadata = groupMetadataCache.get(id);
            if (!groupMetadata || !groupMetadata.participants) {
                groupMetadata = await sock.groupMetadata(id);
                groupMetadataCache.set(id, groupMetadata);
            }
            
            const groupName = groupMetadata.subject || "Grup";
            const groupDesc = groupMetadata.desc ? groupMetadata.desc.toString() : "Tidak ada deskripsi.";
            const memberCount = groupMetadata.participants?.length || 0;

            for (let rawJid of participants) {
                // [FIX] Pastikan JID beneran format String, bukan Object
                let jid = (typeof rawJid === 'object' && rawJid !== null) ? (rawJid.id || rawJid.jid) : rawJid;
                if (!jid) continue; // Skip kalau kosong
                jid = String(jid); // Paksa convert jadi String

                let ppUrl;
                try {
                    ppUrl = await sock.profilePictureUrl(jid, 'image');
                } catch {
                    ppUrl = 'https://cdn.gimita.id/download/pp%20kosong%20wa%20default%20(1)_1769506608569_52b57f5b.jpg'; 
                }

                // Sekarang split pasti aman karena jid sudah pasti String
                const username = jid.split('@')[0];
                const dateNow = new Date().toLocaleDateString('id-ID', { timeZone: 'Asia/Jakarta' });

                if (action === 'add') {
                    const text = 
`🎐 Halo semua member grup tercinta!
Hari ini kita kedatangan member baru 🌱

✨ Selamat datang, *@${username}* 💫

╭─〔 📌 *ɪɴꜰᴏ ɢʀᴏᴜᴘ* 〕─✧
│ 🏠 *Nama* : ${groupName}
│ 👥 *Member* : ${memberCount}
│ 📅 *Tanggal* : ${dateNow}
╰──────────────────────✦

📝 *Deskripsi*
❝ ${groupDesc.slice(0, 100)}${groupDesc.length > 100 ? '...' : ''} ❞

🌟 _Semoga betah di grup ini, dan bisa saling berteman dengan member lain_ 🤍`;

                    await sock.sendMessage(id, { 
                        image: { url: ppUrl }, 
                        caption: text, 
                        mentions: [jid] 
                    });

                } else if (action === 'remove') {
                    const leaveMsg = 
`Sayonara *@${username}* 👋

Telah keluar dari grup *${groupName}*.
Semoga sukses di luar sana dan jangan lupakan kita ya! ✨`;

                    await sock.sendMessage(id, { 
                        image: { url: ppUrl }, 
                        caption: leaveMsg, 
                        mentions: [jid] 
                    });

                } else if (action === 'promote') {
                    const promoteMsg = `🎊*PENGUMUMAN ADMIN BARU*🎊\n\nSelamat *@${username}*!\nKamu sekarang telah diangkat menjadi *Admin* di grup ini. Tolong jaga grup ini dengan baik ya! ✨`;
                    await sock.sendMessage(id, { text: promoteMsg, mentions: [jid] });

                } else if (action === 'demote') {
                    const demoteMsg = `📉 *PENURUNAN JABATAN* 📉\n\nYahh *@${username}*, jabatan *Admin* kamu telah dicabut. Kamu sekarang menjadi member biasa.`;
                    await sock.sendMessage(id, { text: demoteMsg, mentions: [jid] });
                }
            }
        } catch (err) {
            console.log(chalk.red('[Welcome Error]'), err);
        }
    });

    // =================================================================
    // --- MAIN MESSAGE HANDLER ---
    // =================================================================
    sock.ev.on("messages.upsert", async ({ messages, type }) => {
        if (type !== 'notify') return;

        for (const msg of messages) {
            try {
                if (!msg.message || !msg.key) continue;
                
                if (msg.key.id) {
                    simpleMessageStore.set(msg.key.id, {
                        message: msg.message,
                        timestamp: Date.now()
                    });
                }

                if (msg.key.fromMe) continue;
                if (msg.key.remoteJid === "status@broadcast") continue;

                let mContent = msg.message;
                if (mContent.ephemeralMessage) mContent = mContent.ephemeralMessage.message;
                if (mContent.viewOnceMessageV2) mContent = mContent.viewOnceMessageV2.message;
                else if (mContent.viewOnceMessage) mContent = mContent.viewOnceMessage.message;
                msg.message = mContent;

                const msgType = getContentType(mContent);
                const ignoreTypes = ['protocolMessage', 'senderKeyDistributionMessage', 'messageContextInfo', 'reactionMessage', 'pollUpdateMessage', 'keepInChatMessage'];
                if (!msgType || ignoreTypes.includes(msgType)) continue;

                const from = msg.key.remoteJid;
                const isGroup = from.endsWith('@g.us');
                
                let senderRaw = isGroup ? (msg.key.participant || from) : from;
                if (isGroup && msg.key.participantPn) senderRaw = msg.key.participantPn;

                let sender = senderRaw;
                if (senderRaw.endsWith('@lid')) {
                    sender = await sock.decodeLid(senderRaw);
                }
                msg.sender = jidNormalizedUser(sender);

                const pushName = msg.pushName || "Unknown";
                let body = '';
                if (msgType === 'conversation') body = mContent.conversation;
                else if (msgType === 'imageMessage') body = mContent.imageMessage.caption;
                else if (msgType === 'videoMessage') body = mContent.videoMessage.caption;
                else if (msgType === 'extendedTextMessage') body = mContent.extendedTextMessage.text;
                
                if (typeof body === 'string' && body.length > 0) {
                    const timeStr = chalk.bgBlack.white(`⏰ ${new Date().toLocaleTimeString()}`);
                    const ctxStr = isGroup ? chalk.magenta(`[Group]`) : chalk.blue(`[Private]`);
                    console.log(`${timeStr} ${chalk.cyan(`[${msgType}]`)} ${ctxStr} ${chalk.green(pushName)} : ${chalk.white(body.substring(0, 50).replace(/\n/g, ' ') || '<Media>')}`);
                }

                if (msg.messageTimestamp && (Date.now() - (msg.messageTimestamp * 1000)) > 120000) continue; 

                if (MsgHandler) {
                    MsgHandler(sock, msg).catch(e => {
                        console.error(chalk.red(`❌ Handler Error:`), e);
                    });
                }

            } catch (e) {
                console.error("Error processing msg:", e);
            }
        }
    });

    sock.ev.on("call", async (calls) => {
        if (CallHandler) {
            try { await CallHandler.code(sock, calls); } catch {}
        }
    });

    if (!global.isWatching) {
        global.isWatching = true;
        let pluginWatchTimeout = null;
        fsSync.watch(path.join(__dirname, "plugins"), (evt, filename) => {
            if (filename && filename.endsWith(".js")) {
                if (pluginWatchTimeout) clearTimeout(pluginWatchTimeout);
                pluginWatchTimeout = setTimeout(async () => {
                    try {
                        console.log(chalk.yellow(`🔄 Reloading Plugins due to change in: ${filename}`));
                        const ts = Date.now();
                        const reload = await import(`./handler.js?v=${ts}`); 
                        
                        if (reload.loadPlugins) {
                            const ownerJid = jidNormalizedUser(config.owner + '@s.whatsapp.net');
                            await reload.loadPlugins(sock, ownerJid);
                        }

                        MsgHandler = reload.default;
                        log.ok(`✅ Plugin & Handler Reloaded.`);
                    } catch (e) {
                        log.err(`Gagal Reload: ${e.message}`);
                    }
                }, 1000); 
            }
        });
    }
}

process.on("unhandledRejection", (err) => {});
process.on("uncaughtException", (err) => {});

Start();
