import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const { hydratedTemplate } = require('baileys_helpers');

export default {
    command: ['sawit', 'sawitsimulator'],
    category: 'Game',
    description: 'Simulasi Juragan Sawit dengan sistem Mitra, Mandiri, Cuaca & Perawatan proporsional',

    handler: async ({ sock, msg, args, db, sender, saveDatabase, reply, pushName }) => {
        const user = db[sender];
        
        // --- DETEKSI PREFIX ---
        const bodyText = msg.message?.conversation || msg.message?.extendedTextMessage?.text || msg.message?.imageMessage?.caption || "";
        const match = bodyText.match(/^([^\w\s])/);
        const prefix = match ? match[1] : '.';
        
        const COOLDOWN_CMD = 8000; 

        if (user.lastSawitCmd && (Date.now() - user.lastSawitCmd) < COOLDOWN_CMD) {
            const sisaWaktu = Math.ceil((user.lastSawitCmd + COOLDOWN_CMD - Date.now()) / 1000);
            return reply(`⏳ Santai Juragan, tunggu ${sisaWaktu} detik lagi.`);
        }
        user.lastSawitCmd = Date.now();

        const subCmd = args[0]?.toLowerCase();
        const arg2 = args[1]?.toLowerCase();
        const arg3 = parseInt(args[2]);

        const generateCuaca = () => {
            const r = Math.random();
            if (r < 0.40) return 'Cerah';
            if (r < 0.65) return 'Hujan';
            if (r < 0.90) return 'Kemarau';
            return 'Ekstrem';
        };

        const defaultValues = {
            sawit_lahan: 0, sawit_bibit: 0, sawit_pohon: 0, sawit_pekerja: 0, 
            sawit_mess: 0, sawit_truk: 0, sawit_drainase: 0, sawit_pompa: 0, 
            sawit_pupuk: 0, sawit_pestisida: 0, sawit_keamanan: 0, sawit_riset: 0, 
            xp: 0, money: 0, sawit_panen_count: 0, sawit_last_panen: 0,
            sawit_pupuk_aktif: false, sawit_pestisida_aktif: false, sawit_hutang: 0
        };

        for (const key in defaultValues) {
            if (typeof user[key] === 'undefined' || (typeof defaultValues[key] === 'number' && isNaN(user[key]))) {
                user[key] = defaultValues[key];
            }
        }
        if (typeof user.sawit_has_claimed_loan === 'undefined') user.sawit_has_claimed_loan = false;
        if (typeof user.sawit_is_loan === 'undefined') user.sawit_is_loan = false;
        if (!user.sawit_cuaca_next) user.sawit_cuaca_next = generateCuaca();

        const baseUrl = "https://cdn.jsdelivr.net/gh/rhamt24/zalxzhu.github.io/images/";
        const img = {
            default: baseUrl + "sawit.png",
            modal: baseUrl + "sawit-beri-uang.png",     
            nomodal: baseUrl + "sawit-gaboleh.png",     
            beli: baseUrl + "sawit-beli-bibit.png",     
            pajak: baseUrl + "sawit-setor-pajak.png",   
            mandiri: baseUrl + "sawit-mandiri.png"
        };

        // --- DEFINISI MENU UTAMA ---
        const defaultMenuSections = [
            {
                title: "🌴 Aktivitas Utama",
                rows: [
                    { id: `${prefix}sawit status`, title: "📊 Laporan Kebun", description: "Cek kondisi & waktu panen" },
                    { id: `${prefix}sawit panen`, title: "🚛 Panen Raya", description: "Jual sawit & dapatkan profit" },
                    { id: `${prefix}sawit cuaca`, title: "🌦️ Cek BMKG", description: "Prediksi cuaca panen" }
                ]
            },
            {
                title: "🛠️ Manajemen Lahan",
                rows: [
                    { id: `${prefix}sawit tanam`, title: "🌱 Tanam Bibit", description: "Tanam bibit ke lahan" },
                    { id: `${prefix}sawit rawat pupuk`, title: "✨ Sembar Pupuk", description: "+20% Harga Jual saat panen" },
                    { id: `${prefix}sawit rawat pestisida`, title: "🛡️ Semprot Pestisida", description: "Cegah kerugian akibat hama" }
                ]
            },
            {
                title: "🛒 Ekonomi & Bisnis",
                rows: [
                    { id: `${prefix}sawit beli`, title: "🏪 Buka Toko Aset", description: "Beli Lahan, Bibit, Pekerja, dll" },
                    { id: `${prefix}sawit upgrade`, title: "⬆️ Pusat Upgrade", description: "Tingkatkan Keamanan & Riset" },
                    { id: `${prefix}sawit lunasi`, title: "💸 Lunasi Utang", description: "Bebas dari potongan mitra" }
                ]
            }
        ];

        // ==========================================
        // SISTEM KARTU SPLIT (GAMBAR DULUAN, TOMBOL NYUSUL)
        // ==========================================
        const sendSawitCard = async (text, headerTitle, imageUrl, customSections = null) => {
            await sock.sendMessage(msg.key.remoteJid, {
                text: text,
                contextInfo: {
                    isForwarded: true,
                    forwardingScore: 9999,
                    externalAdReply: {
                        title: headerTitle || "SAWIT SIMULATOR",
                        body: "Juragan Sawit Mobile - RPG Tycoon",
                        thumbnailUrl: imageUrl || img.default,
                        sourceUrl: 'https://whatsapp.com/channel/0029VaoNbbHAInPfk5U20C12',
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: msg });

            const activeSections = customSections || defaultMenuSections;
            const buttonPayload = {
                text: customSections ? "Pilih aksi di bawah ini 👇" : "Aksi cepat Juragan 👇",
                footer: `Owner: ${pushName}`,
                interactiveButtons: [
                    {
                        name: 'single_select',
                        buttonParamsJson: JSON.stringify({
                            title: customSections ? "Pilih Item 🔽" : "🎮 Menu Juragan 🔽",
                            sections: activeSections
                        })
                    }
                ]
            };
            
            await new Promise(r => setTimeout(r, 200)); 
            return hydratedTemplate(sock, msg.key.remoteJid, buttonPayload);
        };

        // --- SISTEM EKONOMI MERAKYAT (MAX LEVEL 10) ---
        const MAX_LEVEL = 10;
        const COOLDOWN_PANEN = 20 * 60 * 1000; 
        const MAX_POHON_PER_HA = 256;          
        const BASE_PEKERJA = 20;
        const PEKERJA_PER_MESS = 50;
        const GAJI_POKOK = 25000; // Gaji diturunkan biar gak tekor
        const BONUS_PANEN_PERSEN = 0.05; 
        const KAPASITAS_TRUK = 1000; 
        const BIAYA_TRUK_PRIBADI = 500; 
        const BIAYA_SEWA_TRUK = 3000; 

        // HARGA STATIS CONSUMABLES (Jauh Lebih Murah)
        const HARGA = {
            bibit: 15000, pekerja: 500000, pupuk: 25000, pestisida: 30000
        };

        // HARGA DINAMIS ASET (Leveling 1-10 Kenaikan Santai)
        const ASET_DINAMIS = {
            lahan: { base: 10000000, mult: 1.30 },     // Mulai 10Jt
            mess: { base: 5000000, mult: 1.25 },       // Mulai 5Jt
            truk: { base: 15000000, mult: 1.25 },      // Mulai 15Jt
            drainase: { base: 5000000, mult: 1.30 },   // Mulai 5Jt
            pompa: { base: 5000000, mult: 1.30 }       // Mulai 5Jt
        };

        const UPGRADE_DINAMIS = {
            keamanan: { base: 8000000, mult: 1.40 },   // Mulai 8Jt
            riset: { base: 12000000, mult: 1.50 }      // Mulai 12Jt
        };

        const getHargaDinamis = (item, currentLevel) => {
            if (ASET_DINAMIS[item]) {
                let lvl = Math.max(0, currentLevel);
                return Math.floor(ASET_DINAMIS[item].base * Math.pow(ASET_DINAMIS[item].mult, lvl));
            }
            return HARGA[item] || 0;
        };

        const formatMoney = (angka) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(angka);
        const formatStatusLvl = (val) => val >= MAX_LEVEL ? "MAX" : `Lvl ${val}`;
        const addXp = (amount) => { user.xp += amount; return amount; };

        // 1. MENU UTAMA
        if (!subCmd) {
            const menuText = `
🌴 *SAWIT SIMULATOR RPG* 🌴

👤 Owner: ${pushName}
🏷️ Status: *${user.sawit_lahan > 0 ? (user.sawit_is_loan ? "🤝 Mitra" : "👑 Mandiri") : "Belum Main"}*
⭐ XP: ${user.xp}
💰 Saldo: ${formatMoney(user.money)}
`.trim();
            return sendSawitCard(menuText, "MANUAL BOOK JURAGAN", img.default);
        }

        // 2. DAFTAR
        if (subCmd === 'daftar') {
            if (user.sawit_lahan > 0) return sendSawitCard('❌ Kebun kamu sudah jalan. Tidak perlu daftar ulang.', "INFO KEBUN", img.default);
            let message = "", header = "", currentImage = img.default, xpGain = 0;

            if (!user.sawit_has_claimed_loan) {
                user.money += 5000000; // Modal awal lebih rasional
                user.sawit_lahan = 1; user.sawit_bibit = 250; user.sawit_pekerja = 2; user.sawit_truk = 1;
                user.sawit_hutang = 50000000; // Hutang diturunkan jauh ke 50 Juta
                user.sawit_has_claimed_loan = true; 
                xpGain = addXp(1000); 
                message = `🤝 *KONTRAK MITRA DISETUJUI!*\n\nBank memberikan pinjaman kebun dan aset senilai Rp 50.000.000.\nSetiap panen akan dipotong 40% (15% Bunga Pabrik + 25% Cicilan Utang otomatis).\n\n💰 Modal Cash: Rp 5.000.000\n📦 Aset: 1 Ha, 250 Bibit, 2 Buruh, 1 Truk.\n⭐ XP: +${xpGain}`;
                header = "KONTRAK MITRA BARU"; currentImage = img.modal;
            } else {
                user.money += 500000;
                user.sawit_lahan = 1; user.sawit_bibit = 100; user.sawit_pekerja = 1; 
                xpGain = addXp(100); 
                message = `📉 *PAKET BANGKIT*\n\n📦 Aset: 1 Ha Lahan, 100 Bibit, 1 Buruh.\n💰 Uang Saku: Rp 500.000`;
                header = "KONTRAK PEMULIHAN"; currentImage = img.nomodal;
            }
            user.sawit_is_loan = true;
            await saveDatabase();
            return sendSawitCard(message, header, currentImage);
        }

        if (user.sawit_lahan === 0 && subCmd !== 'reset') return sendSawitCard(`❌ Kamu belum terdaftar.\nSilakan pilih *Mulai Kontrak Baru* di tombol menu atau ketik *${prefix}sawit daftar*.`, "AKSES DITOLAK", img.default);

        // 3. STATUS
        if (subCmd === 'status') {
            const now = Date.now();
            const timeLeft = COOLDOWN_PANEN - (now - user.sawit_last_panen);
            const maxPekerja = BASE_PEKERJA + (user.sawit_mess * PEKERJA_PER_MESS);
            let iconCuaca = user.sawit_cuaca_next === 'Cerah' ? '☀️' : (user.sawit_cuaca_next === 'Hujan' ? '🌧️' : (user.sawit_cuaca_next === 'Kemarau' ? '🏜️' : '🌪️'));
            let rasioDrainase = Math.min(100, Math.floor((user.sawit_drainase / user.sawit_lahan) * 100));
            let rasioPompa = Math.min(100, Math.floor((user.sawit_pompa / user.sawit_lahan) * 100));

            const statusText = `
📊 *LAPORAN HARIAN JURAGAN*

🌳 Pohon: ${user.sawit_pohon} / ${user.sawit_lahan * MAX_POHON_PER_HA} (${formatStatusLvl(user.sawit_lahan)} Ha)
👷 Buruh: ${user.sawit_pekerja} / ${maxPekerja} | 🚛 Truk: ${formatStatusLvl(user.sawit_truk)}

🌦️ *Prediksi Cuaca Panen:* ${iconCuaca} ${user.sawit_cuaca_next}
🧪 *Status Perawatan Lahan:*
- Pupuk (+20%): ${user.sawit_pupuk_aktif ? "✅ Sudah" : "❌ Belum"}
- Pestisida (Anti Hama): ${user.sawit_pestisida_aktif ? "✅ Sudah" : "❌ Belum"}

🎒 *Gudang:* Pupuk ${user.sawit_pupuk} Sak | Pestisida ${user.sawit_pestisida} L
🛡️ *Infrastruktur:*
- Keamanan: ${formatStatusLvl(user.sawit_keamanan)} | Riset: ${formatStatusLvl(user.sawit_riset)}
- Drainase: ${formatStatusLvl(user.sawit_drainase)} (${rasioDrainase}% Aman Banjir)
- Pompa Air: ${formatStatusLvl(user.sawit_pompa)} (${rasioPompa}% Aman Kering)

🕒 Panen: ${timeLeft > 0 ? Math.ceil(timeLeft/60000) + " Menit" : "✅ SIAP!"}
💰 Saldo: ${formatMoney(user.money)}
${user.sawit_is_loan ? `🏦 Sisa Utang: ${formatMoney(user.sawit_hutang)}` : ""}
`.trim();
            return sendSawitCard(statusText, "STATUS KEBUN", img.default);
        }

        // 4. BMKG / CUACA
        if (['cuaca', 'ramalan', 'bmkg'].includes(subCmd)) {
            let infoCuaca = '';
            if (user.sawit_cuaca_next === 'Cerah') infoCuaca = '☀️ *Cerah* - Cuaca bersahabat, panen aman dari penyusutan alam.';
            if (user.sawit_cuaca_next === 'Hujan') infoCuaca = '🌧️ *Hujan Lebat* - Waspada BANJIR! Pastikan jumlah Unit Drainase sebanding dengan jumlah Hektar lahanmu.';
            if (user.sawit_cuaca_next === 'Kemarau') infoCuaca = '🏜️ *Kemarau Panjang* - Waspada KEKERINGAN! Buah menyusut jika Unit Pompa Air lebih sedikit dari Hektar lahan.';
            if (user.sawit_cuaca_next === 'Ekstrem') infoCuaca = '🌪️ *Cuaca Ekstrem* - BADAI ANGIN! Sebagian pohon bisa tumbang tanpa pandang bulu.';

            return sendSawitCard(`📡 *LAPORAN BMKG JURAGAN*\n\nPrediksi cuaca panen berikutnya:\n\n${infoCuaca}`, "PREDIKSI CUACA", img.default);
        }

        // 5. BELI ASET
        if (subCmd === 'beli') {
            if (!arg2) {
                const getLabel = (item, lvl) => lvl >= MAX_LEVEL ? "MAX LEVEL" : formatMoney(getHargaDinamis(item, lvl));
                
                const menuToko = [
                    {
                        title: "🌱 Konsumsi & Tenaga Kerja",
                        rows: [
                            { id: `${prefix}sawit beli bibit 100`, title: "Beli 100 Bibit DxP", description: `${formatMoney(HARGA.bibit * 100)}` },
                            { id: `${prefix}sawit beli pupuk 5`, title: "Beli 5 Sak NPK", description: `${formatMoney(HARGA.pupuk * 5)}` },
                            { id: `${prefix}sawit beli pestisida 5`, title: "Beli 5L Pestisida", description: `${formatMoney(HARGA.pestisida * 5)}` },
                            { id: `${prefix}sawit beli pekerja 1`, title: "Rekrut 1 Pekerja", description: `${formatMoney(HARGA.pekerja)}` }
                        ]
                    },
                    {
                        title: "🚜 Aset Infrastruktur (Max Lvl 10)",
                        rows: [
                            { id: `${prefix}sawit beli lahan 1`, title: `Beli Lahan (${formatStatusLvl(user.sawit_lahan)})`, description: getLabel('lahan', user.sawit_lahan) },
                            { id: `${prefix}sawit beli truk 1`, title: `Beli Truk (${formatStatusLvl(user.sawit_truk)})`, description: getLabel('truk', user.sawit_truk) },
                            { id: `${prefix}sawit beli mess 1`, title: `Beli Mess (${formatStatusLvl(user.sawit_mess)})`, description: getLabel('mess', user.sawit_mess) },
                            { id: `${prefix}sawit beli drainase 1`, title: `Beli Drainase (${formatStatusLvl(user.sawit_drainase)})`, description: getLabel('drainase', user.sawit_drainase) },
                            { id: `${prefix}sawit beli pompa 1`, title: `Beli Pompa Air (${formatStatusLvl(user.sawit_pompa)})`, description: getLabel('pompa', user.sawit_pompa) }
                        ]
                    },
                    {
                        title: "↩️ Navigasi",
                        rows: [
                            { id: `${prefix}sawit`, title: "🔙 Kembali ke Menu Utama", description: "Batal belanja" }
                        ]
                    }
                ];

                const textToko = `🛒 *PASAR ASET SAWIT*\n\nSaldo kamu: *${formatMoney(user.money)}*\n(Harga aset bangunan akan naik perlahan setiap level)\n\nPilih barang yang ingin kamu beli 👇`;
                return sendSawitCard(textToko, "MARKETPLACE ASET", img.beli, menuToko);
            }
            
            let jumlah = arg3 && arg3 > 0 ? arg3 : 1; 
            let itemStr = `sawit_${arg2}`;
            
            if (['lahan', 'mess', 'truk', 'drainase', 'pompa'].includes(arg2)) {
                if (user[itemStr] + jumlah > MAX_LEVEL) {
                    return sendSawitCard(`❌ Maksimal kepemilikan aset ${arg2.toUpperCase()} adalah ${MAX_LEVEL} Unit/Level!`, "INFO JURAGAN", img.default);
                }
            } else if (!HARGA[arg2]) {
                return sendSawitCard('❌ Item tidak valid. Cek daftar barang di toko.', "INFO JURAGAN", img.default);
            }

            if (arg2 === 'pekerja' && user.sawit_pekerja + jumlah > BASE_PEKERJA + (user.sawit_mess * PEKERJA_PER_MESS)) return sendSawitCard(`❌ Mess buruh penuh! Beli Mess dulu di toko.`, "INFO JURAGAN", img.default);
            
            let totalBiaya = 0;
            if (ASET_DINAMIS[arg2]) {
                for (let i = 0; i < jumlah; i++) {
                    totalBiaya += getHargaDinamis(arg2, user[itemStr] + i);
                }
            } else {
                totalBiaya = HARGA[arg2] * jumlah;
            }

            if (user.money < totalBiaya) return sendSawitCard(`❌ Saldo kurang! Butuh ${formatMoney(totalBiaya)} untuk ${jumlah} ${arg2}.`, "INFO JURAGAN", img.default);
            
            user.money -= totalBiaya; 
            user[itemStr] += jumlah; 
            await saveDatabase();
            return sendSawitCard(`🛒 *STRUK BELI*\n\nItem: ${arg2.toUpperCase()} (x${jumlah})\nTotal Biaya: ${formatMoney(totalBiaya)}\nSisa Saldo: ${formatMoney(user.money)}\n\nPilih *Kembali ke Menu Utama* atau lanjut belanja!`, "TRANSAKSI BERHASIL", img.beli);
        }

        // 6. UPGRADE SYSTEM
        if (subCmd === 'upgrade') {
            if (!arg2) {
                let costKeamanan = user.sawit_keamanan >= MAX_LEVEL ? "MAX LEVEL" : formatMoney(Math.floor(UPGRADE_DINAMIS.keamanan.base * Math.pow(UPGRADE_DINAMIS.keamanan.mult, user.sawit_keamanan)));
                let costRiset = user.sawit_riset >= MAX_LEVEL ? "MAX LEVEL" : formatMoney(Math.floor(UPGRADE_DINAMIS.riset.base * Math.pow(UPGRADE_DINAMIS.riset.mult, user.sawit_riset)));

                const menuUpgrade = [
                    {
                        title: "⬆️ Pilihan Upgrade (Max Lvl 10)",
                        rows: [
                            { id: `${prefix}sawit upgrade keamanan yakin`, title: `🛡️ Keamanan (${formatStatusLvl(user.sawit_keamanan)})`, description: costKeamanan },
                            { id: `${prefix}sawit upgrade riset yakin`, title: `🔬 Riset (${formatStatusLvl(user.sawit_riset)})`, description: costRiset }
                        ]
                    },
                    {
                        title: "↩️ Navigasi",
                        rows: [
                            { id: `${prefix}sawit`, title: "🔙 Kembali ke Menu Utama", description: "Batal upgrade" }
                        ]
                    }
                ];
                return sendSawitCard(`⬆️ *PUSAT UPGRADE*\n\nSaldo: *${formatMoney(user.money)}*\nPilih fasilitas yang ingin kamu naikkan levelnya.`, "UPGRADE SYSTEM", img.beli, menuUpgrade);
            }
            
            let lvlKey = `sawit_${arg2}`; 
            if (!UPGRADE_DINAMIS[arg2]) return;

            if (user[lvlKey] >= MAX_LEVEL) return sendSawitCard(`✅ Fasilitas ${arg2.toUpperCase()} sudah mencapai batas maksimal (Level ${MAX_LEVEL})!`, "INFO JURAGAN", img.default);
            
            let cost = Math.floor(UPGRADE_DINAMIS[arg2].base * Math.pow(UPGRADE_DINAMIS[arg2].mult, user[lvlKey]));
            
            if (!args[2] || args[2] !== 'yakin') {
                return sendSawitCard(`🔬 *Konfirmasi Upgrade ${arg2.toUpperCase()} Level ${user[lvlKey] + 1}*\nBiaya: ${formatMoney(cost)}\nKetik: *${prefix}sawit upgrade ${arg2} yakin* untuk konfirmasi.`, "INFO JURAGAN", img.default);
            }
            
            if (user.money < cost) return sendSawitCard(`❌ Saldo kurang! Butuh ${formatMoney(cost)} untuk upgrade.`, "INFO JURAGAN", img.default);
            
            user.money -= cost; 
            user[lvlKey] += 1; 
            await saveDatabase();
            return sendSawitCard(`✅ Upgrade Selesai! Fasilitas ${arg2.toUpperCase()} berhasil dinaikkan ke Level ${user[lvlKey]}!`, "INFO JURAGAN", img.default);
        }

        // 6. TANAM
        if (subCmd === 'tanam') {
            let jumlah = (arg2 && !isNaN(parseInt(arg2))) ? parseInt(arg2) : user.sawit_bibit; 
            if (jumlah < 1) return sendSawitCard(`❌ Kamu tidak punya bibit di gudang. Buka Toko untuk membeli.`, "INFO JURAGAN", img.default);
            if (user.sawit_bibit < jumlah) return sendSawitCard(`❌ Stok bibit di gudang kurang dari ${jumlah}.`, "INFO JURAGAN", img.default);
            if ((user.sawit_pohon + jumlah) > (user.sawit_lahan * MAX_POHON_PER_HA)) return sendSawitCard(`❌ Kapasitas Hektar penuh! Maksimal ${MAX_POHON_PER_HA} pohon per Hektar. Silakan beli/upgrade lahan.`, "INFO JURAGAN", img.default);
            
            const butuhPekerja = Math.ceil((user.sawit_pohon + jumlah) / 100);
            if (user.sawit_pekerja < butuhPekerja) return sendSawitCard(`❌ Kurang tenaga buruh! Tiap kelipatan 100 pohon butuh 1 buruh. Kamu butuh minimal ${butuhPekerja} buruh.`, "INFO JURAGAN", img.default);

            user.sawit_bibit -= jumlah; user.sawit_pohon += jumlah; await saveDatabase();
            return sendSawitCard(`🌱 *PENANAMAN SUKSES*\n\nMenanam ${jumlah} pohon baru ke lahan.\nTotal pohon sekarang: ${user.sawit_pohon} Pohon.`, "INFO JURAGAN", img.default);
        }

        // 7. RAWAT MANUAL
        if (['rawat', 'pupuk', 'semprot'].includes(subCmd)) {
            if (user.sawit_pohon === 0) return sendSawitCard('❌ Belum ada pohon yang ditanam di lahanmu!', "INFO JURAGAN", img.default);
            
            let tipe = arg2;
            if (subCmd === 'pupuk') tipe = 'pupuk';
            if (subCmd === 'semprot') tipe = 'pestisida';

            if (tipe === 'pupuk') {
                if (user.sawit_pupuk_aktif) return sendSawitCard('✅ Kebun sudah dipupuk penuh! Tunggu masa panen untuk memupuk lagi.', "INFO JURAGAN", img.default);
                let butuhPupuk = Math.ceil(user.sawit_pohon / 100);
                if (user.sawit_pupuk < butuhPupuk) return sendSawitCard(`❌ Pupuk di gudang kurang! Butuh ${butuhPupuk} sak untuk mengcover ${user.sawit_pohon} pohon.`, "INFO JURAGAN", img.default);
                user.sawit_pupuk -= butuhPupuk; user.sawit_pupuk_aktif = true; await saveDatabase();
                return sendSawitCard(`✨ *PERAWATAN SELESAI*\n\nBerhasil menebar ${butuhPupuk} sak pupuk ke lahan! Omzet panen dipastikan meningkat +20%.`, "INFO JURAGAN", img.default);
            }
            if (tipe === 'pestisida') {
                if (user.sawit_pestisida_aktif) return sendSawitCard('✅ Kebun sudah disemprot pestisida dan aman dari hama!', "INFO JURAGAN", img.default);
                let butuhPestisida = Math.ceil(user.sawit_pohon / 100);
                if (user.sawit_pestisida < butuhPestisida) return sendSawitCard(`❌ Pestisida di gudang kurang! Butuh ${butuhPestisida} liter untuk ${user.sawit_pohon} pohon.`, "INFO JURAGAN", img.default);
                user.sawit_pestisida -= butuhPestisida; user.sawit_pestisida_aktif = true; await saveDatabase();
                return sendSawitCard(`🛡️ *PERAWATAN SELESAI*\n\nBerhasil menyemprot ${butuhPestisida} liter pestisida! Kebun sekarang kebal dari hama tikus dan jamur.`, "INFO JURAGAN", img.default);
            }
            return sendSawitCard(`❓ Gunakan menu Manajemen Lahan untuk merawat.`, "INFO JURAGAN", img.default);
        }

        // 8. PANEN & LOGISTIK
        if (subCmd === 'panen') {
            if (user.sawit_pohon === 0) return sendSawitCard('❌ Lahan masih kosong, belum ada pohon berbuah.', "INFO JURAGAN", img.default);
            const now = Date.now();
            if (now - user.sawit_last_panen < COOLDOWN_PANEN) return sendSawitCard('⏳ *BUAH BELUM MATANG*\n\nTunggu jadwal panen berikutnya sesuai waktu di Laporan Kebun.', "INFO JURAGAN", img.default);

            let eventText = "", kerugianCuaca = 0, kerugianMaling = 0, pohonMati = 0;
            let randHama = Math.random() * 100;
            let randMaling = Math.random() * 100;

            let rasioBanjirMaut = Math.max(0, 1 - (user.sawit_drainase / user.sawit_lahan)); 
            let rasioKeringMaut = Math.max(0, 1 - (user.sawit_pompa / user.sawit_lahan));

            if (user.sawit_cuaca_next === 'Hujan') {
                if (rasioBanjirMaut > 0) {
                    let persentaseRusak = (Math.random() * 0.2 + 0.1) * rasioBanjirMaut; 
                    kerugianCuaca += persentaseRusak; 
                    eventText += `🌊 Banjir merendam ${Math.floor(rasioBanjirMaut * 100)}% lahan rentan! Kualitas buah turun.\n`;
                } else { eventText += `🌧️ Hujan Lebat. Drainase 100% menahan banjir.\n`; }
            } else if (user.sawit_cuaca_next === 'Kemarau') {
                if (rasioKeringMaut > 0) {
                    let persentaseKering = (Math.random() * 0.25 + 0.15) * rasioKeringMaut; 
                    kerugianCuaca += persentaseKering; 
                    eventText += `☀️ Kekeringan di ${Math.floor(rasioKeringMaut * 100)}% area tanpa pompa! Bobot buah menyusut.\n`;
                } else { eventText += `☀️ Panas Terik. Pompa air mendinginkan seluruh lahan.\n`; }
            } else if (user.sawit_cuaca_next === 'Ekstrem') {
                if (Math.random() < 0.6) { 
                    pohonMati = Math.floor(Math.random() * (user.sawit_pohon * 0.05)) + 1; 
                    user.sawit_pohon -= pohonMati; 
                    eventText += `🌪️ BADAI MENGAMUK! ${pohonMati} Pohon tumbang tercabut angin!\n`; 
                } else { eventText += `🌪️ Angin Kencang berlalu, kebun selamat.\n`; }
            }

            if (!user.sawit_pestisida_aktif && randHama < 35) {
                let pohonDimakan = Math.floor(user.sawit_pohon * (Math.random() * 0.1 + 0.05)); 
                kerugianCuaca += (pohonDimakan / user.sawit_pohon); 
                eventText += `🐀 HAMA MENYERANG! Kamu lupa semprot Pestisida, buah dimakan hama.\n`;
            } else if (user.sawit_pestisida_aktif) {
                eventText += `🛡️ Kebun bersih dari hama.\n`;
            }

            // Mitigasi Maling berdasarkan level Keamanan (Maks level 10 = mitigasi 25%)
            if (randMaling < 20) {
                let bobolDasar = 0.20; 
                let mitigasi = user.sawit_keamanan * 0.025; 
                if (mitigasi >= bobolDasar || Math.random() < (user.sawit_keamanan * 0.1)) { 
                    eventText += `🥷 Maling tertangkap basah oleh Guard Level ${user.sawit_keamanan}!\n`; 
                } else { 
                    kerugianMaling = bobolDasar - mitigasi; 
                    eventText += `🥷 Kebun Kebobolan Ninja Sawit!\n`; 
                }
            }

            // Base harga panen diturunkan agar balance dengan modal baru
            let baseHarga = Math.floor(Math.random() * (12000 - 5000 + 1)) + 5000;
            // Bonus riset (Lvl 10 = +10.000 / pohon)
            baseHarga += (user.sawit_riset * 1000); 
            
            let pohonPanen = user.sawit_pohon;
            let grossAwal = pohonPanen * baseHarga;
            
            let nilaiRugiCuaca = Math.floor(grossAwal * kerugianCuaca);
            let nilaiRugiMaling = Math.floor(grossAwal * kerugianMaling);
            let totalPenalti = nilaiRugiCuaca + nilaiRugiMaling;
            
            let gross = grossAwal - totalPenalti;

            if (user.sawit_pupuk_aktif) {
                gross = Math.floor(gross * 1.2); eventText += `✨ Hasil optimal berkat Pupuk (+20% Harga Jual)\n`;
            }

            let totalGaji = (user.sawit_pekerja * GAJI_POKOK) + Math.floor(gross * BONUS_PANEN_PERSEN);

            let pohonTercoverTruk = Math.min(pohonPanen, user.sawit_truk * KAPASITAS_TRUK);
            let pohonSisaSewa = pohonPanen - pohonTercoverTruk;
            let totalLogistik = (pohonTercoverTruk * BIAYA_TRUK_PRIBADI) + (pohonSisaSewa > 0 ? (pohonSisaSewa * BIAYA_SEWA_TRUK) : 0);

            let totalPajakAtauCicilan = 0;
            let labelPotongan = "";

            if (user.sawit_is_loan) {
                let bungaPabrik = Math.floor(gross * 0.15); 
                let cicilan = Math.floor(gross * 0.25);     
                
                if (cicilan > user.sawit_hutang) {
                    cicilan = user.sawit_hutang;
                }
                
                totalPajakAtauCicilan = bungaPabrik + cicilan;
                user.sawit_hutang -= cicilan;
                labelPotongan = `Potongan Mitra (-${formatMoney(bungaPabrik)} Bunga, -${formatMoney(cicilan)} Cicilan)`;

                if (user.sawit_hutang <= 0) {
                    user.sawit_is_loan = false;
                    user.sawit_hutang = 0;
                    eventText += `\n🎉 *SELAMAT!* Utang kebunmu LUNAS sepenuhnya dari cicilan panen! Kamu sekarang Juragan Mandiri!\n`;
                }
            } else {
                if (user.sawit_lahan <= 4) {
                    totalPajakAtauCicilan = Math.floor(gross * 0.021);
                    labelPotongan = "Pajak UMKM (2.1%)";
                } else {
                    totalPajakAtauCicilan = Math.floor(gross * 0.1135);
                    labelPotongan = "Pajak Ekspor (11.35%)";
                }
            }

            let net = gross - (totalGaji + totalLogistik + totalPajakAtauCicilan);
            let totalXp = 200 + Math.floor(net / 1000000);

            user.money += net;
            user.sawit_last_panen = now;
            user.sawit_panen_count += 1;
            
            user.sawit_pupuk_aktif = false;
            user.sawit_pestisida_aktif = false;
            user.sawit_cuaca_next = generateCuaca();

            addXp(totalXp);
            await saveDatabase();

            const panenText = `
🚛 *PENGIRIMAN CPO #${user.sawit_panen_count}*
${eventText ? `\n🔔 *LOG HARIAN:*\n${eventText}` : ""}
📈 Omzet Kotor: ${formatMoney(grossAwal)}
${totalPenalti > 0 ? `📉 Penalti Bencana/Maling: -${formatMoney(totalPenalti)}` : ""}

🛑 *OPERASIONAL & PAJAK:*
- Gaji & Premi Buruh: -${formatMoney(totalGaji)}
- Transport Logistik: -${formatMoney(totalLogistik)}
- ${labelPotongan}
-------------------------------
💰 *NET PROFIT: ${formatMoney(net)}*
⭐ *XP EARNED: +${totalXp}*

☁️ *BMKG UPDATE:* Cuaca panen berikutnya diperkirakan *${user.sawit_cuaca_next}*.
`.trim();
            return sendSawitCard(panenText, "PANEN RAYA", user.sawit_is_loan ? img.pajak : img.mandiri);
        }

        // 9. LUNASI & RESET
        if (subCmd === 'lunasi') {
            if (!user.sawit_is_loan) return sendSawitCard('✅ Kamu sudah berstatus Mandiri, tidak ada utang pabrik.', "INFO JURAGAN", img.default);
            if (user.sawit_hutang <= 0) return sendSawitCard('✅ Utangmu sudah Rp 0. Tunggu panen berikutnya untuk update status!', "INFO JURAGAN", img.default);
            
            if (user.money < user.sawit_hutang) {
                return sendSawitCard(`❌ Saldo tidak cukup untuk pelunasan instan.\nSisa utangmu: ${formatMoney(user.sawit_hutang)}\nSaldo saat ini: ${formatMoney(user.money)}`, "INFO JURAGAN", img.default);
            }
            
            user.money -= user.sawit_hutang; 
            user.sawit_hutang = 0;
            user.sawit_is_loan = false; 
            await saveDatabase();
            
            return sendSawitCard(`🎉 *KEBEBASAN FINANSIAL!*\n\nSisa utang berhasil dilunasi secara tunai. Status Mitra dicabut, kamu sekarang 100% Juragan Mandiri!`, "PELUNASAN SUKSES", img.mandiri);
        }

        if (subCmd === 'reset') {
            if (arg2 !== 'confirm') return sendSawitCard(`⚠️ *PERINGATAN RESIKO TINGGI!*\n\nReset akan menghapus SEMUA aset lahan, uang, dan karyawan.\n\nKetik manual: *${prefix}sawit reset confirm* jika yakin.`, "SISTEM RESET", img.default);
            for (const key in defaultValues) if (key !== 'money' && key !== 'xp') user[key] = defaultValues[key];
            user.sawit_is_loan = false; await saveDatabase();
            return sendSawitCard('✅ Game Sawit berhasil di-reset ke nol! Silakan pilih *Mulai Kontrak Baru* untuk main lagi.', "SISTEM RESET", img.default);
        }
    }
};