import fs from 'fs/promises';
import path from 'path';
import axios from 'axios';
import { fileURLToPath } from 'url';
import * as fsSync from 'fs'; 
import { createRequire } from 'module'; // <-- Tambahan untuk tombol

const require = createRequire(import.meta.url);
const { hydratedTemplate } = require('baileys_helpers'); // <-- Import helper tombol

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Import config
let cfg = {};
try {
  const configPath = path.join(__dirname, '../config/config.json');
  const configData = fsSync.readFileSync(configPath, 'utf8');
  cfg = JSON.parse(configData);
} catch (e) {
  console.error('[ERROR] Gagal memuat atau mengurai config/config.json!');
  process.exit(1);
}

// Cache DATA STRUKTUR (Bukan Teks Final)
let cachedCommands = []; 
let cachedThumb = null;
let availableCategories = new Set();
let commandsByFile = new Map();

function formatUptime(seconds) {
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    
    const parts = [];
    if (d > 0) parts.push(`${d} hari`);
    if (h > 0) parts.push(`${h} jam`);
    if (m > 0) parts.push(`${m} menit`);
    if (s > 0 || parts.length === 0) parts.push(`${s} detik`);
    
    return parts.join(', ');
}

const userDataFile = path.join(__dirname, '../data/userData.json');
let userData = {};

async function loadUserData() {
  try {
    await fs.access(userDataFile);
    const content = await fs.readFile(userDataFile, 'utf8');
    userData = JSON.parse(content);
  } catch (e) {
    if (e.code === 'ENOENT') {
      await fs.mkdir(path.dirname(userDataFile), { recursive: true });
      await fs.writeFile(userDataFile, JSON.stringify({}, null, 2), 'utf8');
      userData = {};
    } else if (e instanceof SyntaxError) {
      userData = {};
    }
  }
}
async function saveUserData() {
    await fs.writeFile(userDataFile, JSON.stringify(userData, null, 2), 'utf8');
}
await loadUserData();

// PRELOAD: Hanya memuat data plugin ke memori, TIDAK menyusun teks
async function preloadMenuData() {
    const pluginDir = path.join(__dirname);
    const files = (await fs.readdir(pluginDir)).filter(f => f.endsWith('.js') && f !== 'menu.js');
    const tempCommands = [];
    const tempCategories = new Set();
    const tempCommandsByFile = new Map();
    
    for (const file of files) {
        try {
            const absolutePath = path.join(pluginDir, file);
            const modulePath = new URL(`file://${absolutePath}`).href;
            
            const plModule = await import(modulePath);
            const pl = plModule.default; 
            
            const categoryRaw = (pl.category || 'Umum').toLowerCase();
            tempCategories.add(categoryRaw);

            const allCmds = Array.isArray(pl.command) ? pl.command : [pl.command];
            
            if (allCmds.length > 0 && allCmds[0]) {
                tempCommandsByFile.set(file, {
                    command: allCmds[0],
                    category: categoryRaw
                });
            }
            
            for (const cmd of allCmds) {
                if (!cmd) continue;
                tempCommands.push({
                    command: cmd, 
                    category: categoryRaw,
                    file: file
                });
            }
        } catch (e) {
             console.error(`Gagal memuat plugin ${file} saat preload: ${e.message}`);
        }
    }

    cachedCommands = tempCommands;
    availableCategories = tempCategories;
    commandsByFile = tempCommandsByFile;
    
    try {
      const res = await axios.get(cfg.menuThumbnail, { responseType: 'arraybuffer' });
      cachedThumb = Buffer.from(res.data, 'binary');
    } catch (e) {
        cachedThumb = null;
    }
}

await preloadMenuData();

function createMenuMessage(teks, ownerId) {
    const newsletterJid = cfg.channel.jid; 
    const newsletterName = cfg.channel.name; 
    const newsletterServerMessageId = cfg.channel.serverMessageId;
    
    return {
        text: teks,
        mentions: [ownerId],
        contextInfo: {
            mentionedJid: [ownerId],
            isForwarded: true, 
            forwardingScore: 9999,
            forwardedNewsletterMessageInfo: { 
                newsletterJid: newsletterJid,
                newsletterName: newsletterName, 
                serverMessageId: newsletterServerMessageId,
            },
            externalAdReply: { 
                title: '📜 MENU BOT',
                body: cfg.botName,
                mediaType: 1,
                thumbnail: cachedThumb,
                renderLargerThumbnail: true,
                sourceUrl: cfg.menuLink
            }
        }
    };
}


export default {
  command: ['menu', 'help'],
  description: 'Menampilkan daftar command',
  category: 'info',
  handler: async ({ sock, msg, args, from, pushName }) => {
    
    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    // --- DETEKSI PREFIX YANG DIGUNAKAN USER ---
    const body = msg.message?.conversation || msg.message?.extendedTextMessage?.text || msg.message?.imageMessage?.caption || "";
    const configPrefixes = Array.isArray(cfg.prefix) ? cfg.prefix : [cfg.prefix];
    const usedPrefix = configPrefixes.find(p => body.startsWith(p)) || configPrefixes[0];

    const filterCategoryRaw = args[0]?.toLowerCase();
    const showAllCommands = filterCategoryRaw === 'all'; 

    userData[from] = { lastSeen: new Date().toISOString() };
    await saveUserData();

    const ownerId = `${cfg.owner}@s.whatsapp.net`;
    const uptimeSeconds = process.uptime();
    const uptimeFormatted = formatUptime(uptimeSeconds);
    
    // --- FILTER COMMAND ---
    let filteredCommands = [];
    if (showAllCommands || filterCategoryRaw) {
        filteredCommands = cachedCommands.filter(cmd => 
            showAllCommands || cmd.category === filterCategoryRaw
        );
    } else {
        filteredCommands = Array.from(commandsByFile.values());
    }
    
    // --- HEADER MENU ---
    let teks = `*${cfg.botName}*\n\n`;
    teks += `Creator: @${cfg.owner}\n`;
    teks += `Powered by: ${cfg.menuLink}\n`;
    teks += `Runtime: *${uptimeFormatted}*\n`; 
    teks += `Version: *${cfg.version || '1.0.0'}*\n`; 
    teks += `Fitur: *${commandsByFile.size}*\n`;
    teks += `Prefix: *${usedPrefix}*\n\n`; 

    if (filterCategoryRaw && !showAllCommands) {
        const categoryDisplay = filterCategoryRaw.charAt(0).toUpperCase() + filterCategoryRaw.slice(1);
        if (filteredCommands.length === 0) {
            teks += `❌ Command untuk kategori *${categoryDisplay}* tidak ditemukan.\n\n`;
            teks += `Kategori yang tersedia:\n${[...availableCategories].map(c => `• ${usedPrefix}menu ${c}`).join('\n')}`;
        } else {
            teks += `🔍 *Menu Kategori: ${categoryDisplay}*\n\n`;
        }
    } else {
        teks += `Halo *${pushName}*, berikut daftar command:\n\n`;
    }

    // --- GROUPING & LISTING COMMAND ---
    const grouped = {};
    const commandSet = new Set(); 
    
    for (const cmd of filteredCommands) {
      const categoryRaw = cmd.category; 
      const categoryDisplay = categoryRaw.charAt(0).toUpperCase() + categoryRaw.slice(1);
      
      if (!grouped[categoryRaw]) grouped[categoryRaw] = [];

      const mainCommand = cmd.command; 
      let formattedCommand = null;
      
      if (typeof mainCommand === 'string') {
          if (mainCommand && mainCommand.length > 0) {
              formattedCommand = `• ${usedPrefix}${mainCommand}`;
          }
      } else if (mainCommand instanceof RegExp) {
          const regexStr = mainCommand.toString();
          if (regexStr === '/^(vera|bot)$/i') {
            formattedCommand = '• vera | bot';
          }
      }
      
      if (formattedCommand && !commandSet.has(formattedCommand)) {
          grouped[categoryRaw].push({
              commandText: formattedCommand, 
              categoryDisplay: categoryDisplay
          });
          commandSet.add(formattedCommand);
      }
    }
    
    const sortedCategories = Object.keys(grouped).sort();

    for (const categoryRaw of sortedCategories) {
        const list = grouped[categoryRaw];
        const categoryDisplay = list.length > 0 ? list[0].categoryDisplay : categoryRaw.charAt(0).toUpperCase() + categoryRaw.slice(1);
        
        teks += `📁 *${categoryDisplay}*\n`;
        teks += list.map(item => item.commandText).join('\n') + '\n\n';
    }

    if (!showAllCommands && !filterCategoryRaw) {
        teks += `*Note*: Gunakan *${usedPrefix}menu all* untuk melihat semua command.\n`;
    }
    
    // ==========================================
    // 1. KIRIM PESAN PERTAMA (TEKS + THUMBNAIL)
    // ==========================================
    const message = createMenuMessage(teks, ownerId);
    await sock.sendMessage(from, message, { quoted: msg });


    // ==========================================
    // 2. KIRIM PESAN KEDUA (HANYA TOMBOL)
    // ==========================================
    // Kita buat logic untuk memecah daftar kategori agar tidak lebih dari 10 baris (mencegah error WA)
    const allCategories = [...availableCategories];
    const categorySections = [];
    
    let currentRows = [{
        id: `${usedPrefix}menu all`,
        title: `📜 Semua Command`,
        description: `Tampilkan seluruh daftar perintah bot`
    }];

    for (const cat of allCategories) {
        if (currentRows.length >= 10) { 
            categorySections.push({
                title: categorySections.length === 0 ? "Kategori Utama" : `Kategori Lainnya (${categorySections.length + 1})`,
                rows: currentRows
            });
            currentRows = [];
        }
        currentRows.push({
            id: `${usedPrefix}menu ${cat}`,
            title: `📁 ${cat.charAt(0).toUpperCase() + cat.slice(1)}`,
            description: `Menampilkan daftar fitur ${cat}`
        });
    }
    
    if (currentRows.length > 0) {
        categorySections.push({
            title: categorySections.length === 0 ? "Kategori Utama" : `Kategori Lainnya (${categorySections.length + 1})`,
            rows: currentRows
        });
    }

    // Payload untuk pesan kedua
    const buttonPayload = {
        text: "👇 *Males ngetik?* Langsung pilih kategori menu lewat tombol di bawah ini ya!",
        footer: "Interactive Menu",
        interactiveButtons: [
            {
                name: 'single_select',
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Kategori 🔽",
                    sections: categorySections
                })
            }
        ]
    };

    // Kirim tombolnya nyusul di bawah teks
    await hydratedTemplate(sock, from, buttonPayload);
    await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

  }
};