import fetch from 'node-fetch';
import { generateWAMessageContent, generateWAMessageFromContent, proto } from '@whiskeysockets/baileys';

// --- KONFIGURASI ---
const IMAGE_MENU_URL = 'https://cdn.jsdelivr.net/gh/rhamt24/zalxzhu.github.io/images/haruka.png';
const IMAGE_QRIS_URL = 'https://cdn.jsdelivr.net/gh/rhamt24/zalxzhu.github.io/images/1764680372103.png';
const OWNER_NUMBER = '6283846016963'; // GANTI DENGAN NOMOR WA KAMU

const handler = async (context) => {
    const { sock, msg, command, pushName, from } = context;

    await sock.sendMessage(from, { react: { text: '💳', key: msg.key } });

    try {
        const [menuRes, qrisRes] = await Promise.all([
            fetch(IMAGE_MENU_URL),
            fetch(IMAGE_QRIS_URL)
        ]);

        if (!menuRes.ok || !qrisRes.ok) throw new Error('Gagal mengambil gambar.');

        const menuBuffer = Buffer.from(await menuRes.arrayBuffer());
        const qrisBuffer = Buffer.from(await qrisRes.arrayBuffer());

        const menuImage = await generateWAMessageContent(
            { image: menuBuffer },
            { upload: sock.waUploadToServer }
        );

        const qrisImage = await generateWAMessageContent(
            { image: qrisBuffer },
            { upload: sock.waUploadToServer }
        );

        // --- LOGIK SISTEM PROMO OTOMATIS ---
        // Promo diset berakhir pada 6 Maret 2026 pukul 23:59:59 (WIB)
        const PROMO_END_DATE = new Date('2026-03-06T23:59:59+07:00').getTime();
        const now = Date.now();
        const isPromo = now <= PROMO_END_DATE;
        
        // Hitung sisa hari untuk ditampilkan ke user
        const remainingDays = Math.ceil((PROMO_END_DATE - now) / (1000 * 60 * 60 * 24));

        // Setup Harga & Header Promo (UPDATE TEKS RAMADHAN)
        const promoHeader = isPromo ? `🌙 *PROMO RAMADHAN (${remainingDays} HARI LAGI!)* 🌙\n\n` : '';
        const prem15Price = 'Rp 8.000';
        const prem30Price = isPromo ? '~Rp 15.000~  *Rp 10.000*' : 'Rp 15.000';
        const sewa30Price = isPromo ? '~Rp 25.000~  *Rp 20.000*' : 'Rp 25.000';

        // --- KARTU 1: LIST HARGA ---
        const card1_Menu = {
            header: proto.Message.InteractiveMessage.Header.create({
                title: "💎 HARGA LAYANAN",
                subtitle: "Premium & Sewa Bot",
                hasMediaAttachment: true,
                imageMessage: menuImage.imageMessage
            }),
            body: proto.Message.InteractiveMessage.Body.create({
                text: `Halo Kak ${pushName || 'User'} 👋\n\n` +
                      promoHeader +
                      `*💎 PREMIUM USER*\n` +
                      `• 15 Hari : ${prem15Price}\n` +
                      `• 30 Hari : ${prem30Price}\n` +
                      `> Unlimited Limit Harian\n` +
                      `> Akses Semua Fitur Premium\n` +
                      `> Prioritas Respon Bot\n\n` +
                      
                      `*🤖 SEWA BOT (MASUK GRUP)*\n` +
                      `• 30 Hari : ${sewa30Price}\n` +
                      `> Bot Join ke Grup Kamu\n` +
                      `> Fitur Admin, Welcome, Hidetag\n` +
                      `> Game, RPG & AI Chat\n\n` +

                      `*👾 JADI BOT (NUMPANG)*\n` +
                      `• Status : *COMING SOON* ⏳\n\n` +
                      
                      `_Geser ke kanan untuk QRIS_ ➡️`
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
                text: "Silahkan pilih paket tersedia"
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Hubungi Owner",
                            url: `https://wa.me/${OWNER_NUMBER}?text=Halo+kak+saya+mau+order+layanan+bot`,
                            merchant_url: `https://wa.me/${OWNER_NUMBER}`
                        })
                    }
                ]
            })
        };

        // --- KARTU 2: QRIS & ATURAN ---
        const card2_Qris = {
            header: proto.Message.InteractiveMessage.Header.create({
                title: "SCAN QRIS",
                subtitle: "Pembayaran Otomatis",
                hasMediaAttachment: true,
                imageMessage: qrisImage.imageMessage
            }),
            body: proto.Message.InteractiveMessage.Body.create({
                text: `*METODE PEMBAYARAN*\n` +
                      `Scan QRIS di atas (Dana/Gopay/Bank/dll).\n\n` +
                      `*⚠️ PERATURAN TRANSAKSI:*\n` +
                      `1. *Wajib Kirim Bukti*: Kirim screenshot setelah transfer berhasil.\n` +
                      `2. *Sabar Menunggu*: Jika owner tidak membalas, berarti sedang sibuk/istirahat.\n` +
                      `3. *Dilarang Spam*: Spam chat/telepon akan kami blokir.\n` +
                      `4. *Garansi*: Transaksi 100% Amanah & Bertanggung jawab.\n\n` +
                      `_Klik tombol di bawah untuk kirim bukti._ 👇`
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
                text: "Amanah & Terpercaya"
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Kirim Bukti Bayar",
                            url: `https://wa.me/${OWNER_NUMBER}?text=Halo+kak+ini+bukti+transfer+pembayaran+bot`,
                            merchant_url: `https://wa.me/${OWNER_NUMBER}`
                        })
                    }
                ]
            })
        };

        const msgPayload = generateWAMessageFromContent(from, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ 
                            text: "List Harga & Pembayaran\n(Geser kartu untuk melihat QRIS)" 
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ 
                            text: "Tap gambar untuk memperbesar" 
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({ 
                            hasMediaAttachment: false 
                        }),
                        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.create({
                            cards: [card1_Menu, card2_Qris]
                        })
                    })
                }
            }
        }, { quoted: msg });

        await sock.relayMessage(from, msgPayload.message, { messageId: msgPayload.key.id });
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (e) {
        console.error("Error menu premium:", e);
        msg.reply("❌ Gagal memuat menu.");
    }
};

export default {
    command: ['premium', 'sewabot', 'sewa', 'qris'],
    category: 'main',
    handler: handler,
};