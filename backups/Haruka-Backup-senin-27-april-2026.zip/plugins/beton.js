import cfg from '../config/config.json' with { type: 'json' };
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const { hydratedTemplate } = require('baileys_helpers');

export default {
    command: ['testbutton', 'baten'],
    category: 'Testing',
    isOwner: true,
    isAdmin: false,
    isBotAdmin: false,
    isPremium: false,

    handler: async ({ 
        sock,           
        msg,            
        sendReact,
        reply
    }) => {
        try {
            await sendReact('⏳');
            const chatId = msg.key.remoteJid;

            await hydratedTemplate(
                sock,
                chatId,
                {
                    title: "🤖 *HARUKA BOT SHOWCASE*",
                    text: "Ini adalah demonstrasi seluruh fitur tombol yang akan tersedia:",
                    footer: `Powered by zal`,
                    
                    interactiveButtons: [
                        // 1. SINGLE SELECT (Ini yang "Pilih Gambar" / List Menu)
                        {
                            name: 'single_select',
                            buttonParamsJson: JSON.stringify({
                                title: "Pilih Gambar",
                                sections: [
                                    {
                                        title: "Daftar Pilihan 1",
                                        rows: [
                                            { id: "img_1", title: "Gambar 1", description: "Resolusi 1080p" },
                                            { id: "img_2", title: "Gambar 2", description: "Resolusi 720p" }
                                        ]
                                    },
                                    {
                                        title: "Daftar Pilihan 2",
                                        rows: [
                                            { id: "img_all", title: "Unduh Semua", description: "Download dalam bentuk ZIP" }
                                        ]
                                    }
                                ]
                            })
                        },

                        // 2. QUICK REPLY (Tombol klik biasa)
                        { 
                            name: 'quick_reply', 
                            buttonParamsJson: JSON.stringify({ 
                                display_text: '➡️ Kirim Terpilih', 
                                id: 'action_kirim' 
                            }) 
                        },

                        // 3. COPY TEXT BUTTON (Salin teks)
                        {
                            name: 'cta_copy',
                            buttonParamsJson: JSON.stringify({
                                display_text: '📋 Salin ID',
                                copy_code: 'HARUKA-12345'
                            })
                        },

                        // 4. URL BUTTON (Buka link)
                        {
                            name: 'cta_url',
                            buttonParamsJson: JSON.stringify({
                                display_text: '🌐 Buka Web',
                                url: 'https://example.com' // Link dummy
                            })
                        },

                        // 5. CALL BUTTON (Telepon)
                        {
                            name: 'cta_call',
                            buttonParamsJson: JSON.stringify({
                                display_text: '📞 Telepon Owner',
                                phone_number: '6285700158613'
                            })
                        },

                        // 6. CATALOG BUTTON (Katalog Bisnis WA)
                        {
                            name: 'cta_catalog',
                            buttonParamsJson: JSON.stringify({
                                business_phone_number: '6285700158613'
                            })
                        },

                        // 7. OPEN WEBVIEW (Buka link di dalam WhatsApp)
                        {
                            name: 'open_webview',
                            buttonParamsJson: JSON.stringify({
                                title: 'Lihat Profil',
                                link: {
                                    in_app_webview: true,
                                    url: 'https://example.com' // Link dummy
                                }
                            })
                        },

                        // 8. SEND LOCATION (Kirim Lokasi)
                        {
                            name: 'send_location',
                            buttonParamsJson: JSON.stringify({
                                display_text: '📍 Minta Lokasi'
                            })
                        },

                        // 9. ADDRESS MESSAGE (Minta Alamat)
                        {
                            name: 'address_message',
                            buttonParamsJson: JSON.stringify({
                                display_text: '🏠 Isi Alamat Pengiriman'
                            })
                        },

                        // 10. REMINDER BUTTON (Pengingat)
                        {
                            name: 'cta_reminder',
                            buttonParamsJson: JSON.stringify({
                                display_text: '⏰ Buat Pengingat'
                            })
                        }
                    ]
                }, 
                { quoted: msg }
            );

            await sendReact('✅');

        } catch (error) {
            console.error(error);
            await reply(`❌ *Error saat mengirim pesan:* ${error.message}`);
        }
    }
};