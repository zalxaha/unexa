import 'dotenv/config';
import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore
} from '@whiskeysockets/baileys';

import qr from 'qrcode-terminal';
import pino from 'pino';
import path from 'path';
import fs from 'fs/promises';
import * as fsSync from 'fs';
import { fileURLToPath } from 'url';
import { parsePhoneNumber } from 'libphonenumber-js';
import chalk from 'chalk';
import NodeCache from 'node-cache';

import log from './lib/logger.js';
import config from './config/config.json' assert { type: 'json' };

// Variable Global
let MsgHandler;
let loadPlugins;
let loadDisabledFeatures;

// Fungsi untuk load handler awal
async function initHandler() {
  try {
    const MsgModule = await import('./handlers/messageHandler.js');
    // Load plugin DULU sebelum dipasang ke variabel global
    await MsgModule.loadDisabledFeatures();
    await MsgModule.loadPlugins(); 
    
    MsgHandler = MsgModule.default;
    loadPlugins = MsgModule.loadPlugins;
    loadDisabledFeatures = MsgModule.loadDisabledFeatures;

    console.log(chalk.green('✅ Handler & Plugins loaded successfully.'));
  } catch (e) {
    console.error(chalk.red('⚠️ Warning: Gagal import messageHandler.'), e);
  }
}

// Jalankan init di awal
await initHandler();

import CallHandler from './lib/call.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const sessionFolder = path.join(__dirname, 'session');
const dbPath = path.join(__dirname, 'database/users.json');

const msgRetryCounterCache = new NodeCache();

async function validatePhoneNumber(input) {
  if (!input) return null;
  try {
    let phone = String(input).replace(/[^0-9]/g, "");
    if (!phone.startsWith('+')) phone = '+' + phone;
    const pn = parsePhoneNumber(phone);
    if (!pn || !pn.isValid()) return null;
    return pn.number.replace('+', '');
  } catch {
    return null;
  }
}

async function checkDatabase() {
  try {
    await fs.access(dbPath);
    if ((await fs.readFile(dbPath, 'utf8')).trim().length === 0) {
      await fs.writeFile(dbPath, JSON.stringify({}));
    }
  } catch (err) {
    if (err.code === "ENOENT") {
      await fs.mkdir(path.dirname(dbPath), { recursive: true });
      await fs.writeFile(dbPath, JSON.stringify({}));
    }
  }
}

// PERBAIKAN 1: Hapus isReady global atau set true default, 
// kita akan handle kesiapan via keberadaan socket/user.
// Namun, untuk keamanan flow, kita pakai pengecekan sederhana saja.

async function Start() {
  await checkDatabase();

  try {
    await fs.access(sessionFolder);
  } catch {
    await fs.mkdir(sessionFolder, { recursive: true });
  }

  const { state, saveCreds } = await useMultiFileAuthState(sessionFolder);
  const { version, isLatest } = await fetchLatestBaileysVersion();

  log.info(`Baileys v${version.join('.')}, latest: ${isLatest}`);
  config.version = version.join('.');

  const usePairing = config.system?.pairing === true;

  const getMessageFallback = async () => undefined;

  const sock = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" })),
    },
    logger: pino({ level: "silent" }),
    printQRInTerminal: !usePairing,
    syncFullHistory: false, // Penting agar tidak spam history
    shouldSyncHistoryMessage: () => false,
    generateHighQualityLinkPreview: true,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    connectTimeoutMs: 60000,
    retryRequestDelayMs: 0,
    msgRetryCounterCache,
    getMessage: getMessageFallback
  });

  if (usePairing && !sock.authState.creds.registered) {
    setTimeout(async () => {
      const number = await validatePhoneNumber(config.system.number);
      if (!number) return log.err("Nomor pairing invalid!");

      try {
        let code = await sock.requestPairingCode(number);
        code = code?.match(/.{1,4}/g)?.join('-') || code;
        console.log(chalk.bgGreen.black(`\n📞 KODE PAIRING:`));
        console.log(chalk.white.bold(code));
      } catch (err) {
        log.err("Gagal request pairing: " + err.message);
      }
    }, 3000);
  }

  sock.ev.on("connection.update", async ({ connection, lastDisconnect, qr: code }) => {
    if (code && !usePairing && !sock.authState.creds.registered) {
      qr.generate(code, { small: true });
    }

    if (connection === "open") {
      log.ok("Bot Online!");
      
      // Kirim pesan ke owner saat connect
      try {
        await sock.sendMessage(config.owner + "@s.whatsapp.net", {
          text: `✅ Bot Online\nVersi Baileys: ${config.version}`
        });
      } catch {}
    }

    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode || 0;

      if (code === DisconnectReason.loggedOut) {
        log.err("Session logout → hapus folder session...");
        await fs.rm(sessionFolder, { recursive: true, force: true });
        process.exit(1);
      }

      log.warn("Reconnecting...");
      Start();
    }
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("messages.upsert", async (m) => {
    // PERBAIKAN 1: Hapus check if (!isReady) return;
    // Cukup cek apakah message dan Handler valid
    if (!m.messages) return;
    
    const msg = m.messages[0];
    if (!msg.message) return;
    if (msg.messageStubType) return;
    if (m.type === "append") return; // Tetap ignore history lama
    if (msg.key.remoteJid === "status@broadcast") return;

    // Pastikan Handler sudah terload
    if (!MsgHandler) return;

    try {
      // Langsung proses. Jika plugin belum 100% siap di detik pertama,
      // biasanya handler akan throw error atau fallback, 
      // tapi setidaknya pesan tidak di-skip.
      await MsgHandler(sock, msg);
    } catch (err) {
      log.err("Handler Error: " + err.message);
    }
  });

  sock.ev.on("call", async (calls) => {
    try {
      await CallHandler.code(sock, calls);
    } catch {}
  });

  // PERBAIKAN 2: Logic Reload yang Aman
  fsSync.watch(path.join(__dirname, "plugins"), async (evt, filename) => {
    if (filename && filename.endsWith(".js")) {
      const ts = Date.now();
      try {
        log.info(`[RELOAD START] Mendeteksi perubahan: ${filename}`);
        
        // 1. Import module baru ke variabel temporary
        const reload = await import(`./handlers/messageHandler.js?v=${ts}`);
        
        // 2. Load plugins pada module BARU tersebut (di memori)
        // Ini memastikan 'reload' sudah punya database command yang lengkap
        if (reload.loadDisabledFeatures) await reload.loadDisabledFeatures();
        if (reload.loadPlugins) await reload.loadPlugins();

        // 3. BARU kita ganti variabel global 'MsgHandler' dengan yang baru
        // Dengan cara ini, tidak ada jeda waktu dimana MsgHandler kosong
        MsgHandler = reload.default;
        loadPlugins = reload.loadPlugins;
        loadDisabledFeatures = reload.loadDisabledFeatures;

        log.ok(`[RELOAD SUCCESS] Plugin berhasil diperbarui.`);
      } catch (e) {
        log.err("Reload gagal: " + e.message);
      }
    }
  });
}

process.on("unhandledRejection", e => {
  if (String(e).includes("Bad MAC")) return;
  console.error(e);
});
process.on("uncaughtException", e => {
  if (String(e).includes("Bad MAC")) return;
  console.error(e);
});

Start();
