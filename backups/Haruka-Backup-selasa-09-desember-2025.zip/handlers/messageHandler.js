import fs from 'fs/promises';
import path from 'path';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url);

import log from '../lib/logger.js';
import cfg from '../config/config.json' assert { type: 'json' };

const dbPath = path.join(__dirname, '../database/users.json');
const featuresPath = path.join(__dirname, '../database/features.json');
const pluginDir = path.join(__dirname, '../plugins');

let sockGlobal = null;
const groupAdminCache = {};
const CACHE_TTL = 30000;

// GLOBAL MEMORY CACHE
// Agar tidak baca file berulang-ulang bikin lemot
let pluginsCache = {};
let disabledFeatures = {};
let usersDbCache = null; // Cache database user di RAM

const CONFESSION_MAP = new Map();

// --- DATABASE FUNCTIONS (OPTIMIZED) ---

// Fungsi baca DB hanya dipanggil saat start atau reload
async function initDatabase() {
  try {
    const fileContent = await fs.readFile(dbPath, 'utf8');
    usersDbCache = JSON.parse(fileContent);
  } catch (error) {
    usersDbCache = {}; // Default kosong jika error/file tidak ada
    if (error.code === 'ENOENT') {
      await fs.writeFile(dbPath, JSON.stringify({}, null, 2));
    }
  }
}

// Fungsi tulis DB (Menyimpan perubahan dari RAM ke File)
async function saveDatabase() {
    try {
        if (!usersDbCache) return;
        await fs.writeFile(dbPath, JSON.stringify(usersDbCache, null, 2));
    } catch (e) {
        log.err(`Gagal menyimpan database: ${e.message}`);
    }
}

async function loadDisabledFeatures() {
    try {
        const data = await fs.readFile(featuresPath, 'utf8');
        disabledFeatures = JSON.parse(data);
    } catch {
        disabledFeatures = {};
        await fs.writeFile(featuresPath, JSON.stringify({}, null, 2));
    }
    log.info(`✅ ${Object.keys(disabledFeatures).length} fitur dinonaktifkan dimuat.`);
}

async function loadPlugins() {
    // Pastikan DB user termuat sebelum plugin diload (untuk safety)
    if (!usersDbCache) await initDatabase();

    log.info('🔄 Memuat ulang/memuat plugin...');
    const newPluginsCache = {};
    let pluginFiles;
    try {
        pluginFiles = (await fs.readdir(pluginDir)).filter(f => f.endsWith('.js'));
    } catch (e) {
        log.err("Gagal membaca folder plugins");
        return;
    }

    for (const file of pluginFiles) {
        const filePath = path.join(pluginDir, file);
        try {
            // Hapus cache require agar reload command efektif
            delete require.cache[filePath]; 
            
            // Gunakan timestamp untuk bypassing cache import module
            const pluginModule = await import(`../plugins/${file}?v=${Date.now()}`); 
            const plugin = pluginModule.default || pluginModule;

            if (!plugin || !plugin.command) continue;

            const commands = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
            const category = plugin.isOwner ? 'Owner' : plugin.category || 'Uncategorized';

            for (const cmd of commands) {
                newPluginsCache[cmd.toLowerCase()] = {
                    file,
                    handler: plugin.handler,
                    isOwner: !!plugin.isOwner,
                    isPremium: !!plugin.isPremium,
                    isDisabled: disabledFeatures[cmd.toLowerCase()] || false,
                    category: category
                };
            }
        } catch (e) {
            log.err(`❌ Plugin '${file}' error saat memuat: ${e.message}`);
        }
    }

    pluginsCache = newPluginsCache;
    log.info(`✅ ${Object.keys(pluginsCache).length} commands dimuat.`);
}

// --- UTILS ---

const parseQuoted = (m, sock) => {
  const q = m.message?.extendedTextMessage?.contextInfo;
  if (!q?.quotedMessage) return;
  const quoted = q.quotedMessage;
  const mtype = Object.keys(quoted)[0];
  const msg = quoted[mtype];
  m.quoted = {
    type: mtype,
    mtype,
    id: q.stanzaId,
    sender: q.participant,
    fromMe: q.participant === sock.user.id,
    isBaileys: !!q.isForwarded,
    text: msg?.text || msg?.caption || '',
    message: quoted,
    download: async () => {
      const stream = await downloadContentFromMessage(quoted[mtype], mtype.replace('Message', ''));
      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }
      return buffer;
    }
  };
};

function mapJid(incomingJid, db, ownerJid, ownerAltJids) {
  if (incomingJid === ownerJid || (ownerAltJids && ownerAltJids.includes(incomingJid))) {
    return ownerJid;
  }
  return incomingJid; 
}

// --- MAIN HANDLER ---

async function Msg(sock, m) {
    try {
        sockGlobal = sock;

        if (!m || !m.message) return;
        if (m.key.fromMe) return;
        
        // 1. Definisikan start_time sepagi mungkin
        const start_time = Date.now(); 
        const now = Date.now();
        const { key, message, pushName } = m;
        const remoteJid = key.remoteJid;
        const ownerConfigJid = cfg.owner + '@s.whatsapp.net';

        // 2. Jika DB belum siap (misal baru banget nyala), init dulu
        if (!usersDbCache) await initDatabase();

        const isGroup = remoteJid.endsWith('@g.us');
        let incomingJid = isGroup ? key.participant : remoteJid;
        m.isGroup = isGroup;

        // Fix JID untuk LID (Linked Device)
        if (isGroup && key.participantPn && /@lid$/.test(key.participant)) {
            incomingJid = key.participantPn;
        }

        // Ekstrak Body Pesan
        const msgType = Object.keys(message || {})[0];
        let body = '';
        if (msgType === 'conversation') body = message.conversation || '';
        else if (msgType === 'imageMessage') body = message.imageMessage?.caption || '';
        else if (msgType === 'videoMessage') body = message.videoMessage?.caption || '';
        else if (msgType === 'extendedTextMessage') body = message.extendedTextMessage?.text || '';
        else if (msgType === 'buttonsResponseMessage') body = message.buttonsResponseMessage?.selectedButtonId || '';
        else if (msgType === 'listResponseMessage') body = message.listResponseMessage?.singleSelectReply?.selectedRowId || '';
        else if (msgType === 'templateButtonReplyMessage') body = message.templateButtonReplyMessage?.selectedId || '';
        
        parseQuoted(m, sock);
        const quotedId = m.quoted?.id;
        
        // --- FITUR CONFESSION (MENFS) ---
        if (quotedId && CONFESSION_MAP.has(quotedId)) {
            // (Kode Confession tetap sama, dipersingkat untuk fokus)
            const originalSenderJid = CONFESSION_MAP.get(quotedId);
            try {
                await sock.sendMessage(originalSenderJid, { text: `💬 *Balasan Menfess*\nDari: @${remoteJid.split('@')[0]}`, mentions: [remoteJid] });
                // Relay pesan asli
                const currentMsgType = Object.keys(m.message || {})[0];
                if (currentMsgType) {
                    const payload = {};
                    payload[currentMsgType] = m.message[currentMsgType];
                    await sock.relayMessage(originalSenderJid, payload, { messageId: m.key.id });
                }
                return;
            } catch (e) { log.err('Confession fail'); }
        }
        
        const isCommand = body.startsWith(cfg.prefix);

        // --- MANAJEMEN USER DATABASE (OPTIMIZED) ---
        // Menggunakan variable RAM (usersDbCache), tidak baca file lagi.
        let isDbChanged = false;
        const finalSenderJid = mapJid(incomingJid, usersDbCache, ownerConfigJid, cfg.ownerAltJids); 
        m.sender = finalSenderJid;
        
        // Cek/Buat User
        let userDbEntry = usersDbCache[finalSenderJid];
        if (!userDbEntry) {
            userDbEntry = usersDbCache[finalSenderJid] = {
                nama: pushName || 'User',
                registered: false,
                lastReset: now,
                status: 'guest',
                premiumUntil: 0,
                altJids: [],
                lastDonationSent: 0 
            };
            log.info(`➕ User baru dibuat di RAM: ${finalSenderJid}`);
            isDbChanged = true;
        }

        // Update Alt Jids
        const originalIncomingJid = incomingJid;
        if (originalIncomingJid !== finalSenderJid) {
            if (!userDbEntry.altJids) userDbEntry.altJids = [];
            if (!userDbEntry.altJids.includes(originalIncomingJid)) {
                userDbEntry.altJids.push(originalIncomingJid);
                isDbChanged = true;
            }
        }

        // Cek Expired Premium
        if (!userDbEntry.premiumUntil) userDbEntry.premiumUntil = 0;
        if (userDbEntry.premiumUntil > 0 && now > userDbEntry.premiumUntil) {
            userDbEntry.premiumUntil = 0;
            userDbEntry.status = userDbEntry.registered ? 'user' : 'guest';
            log.info(`⬇️ Premium ${finalSenderJid} habis.`);
            isDbChanged = true;
        }

        const isOwner = finalSenderJid === ownerConfigJid;
        const isPremium = isOwner || (userDbEntry.premiumUntil > 0 && now < userDbEntry.premiumUntil);

        // Auto set status premium di DB
        if (isPremium && userDbEntry.status !== 'premium') {
            userDbEntry.status = 'premium';
            isDbChanged = true;
        }
        
        // Simpan ke file HANYA jika ada perubahan data
        if (isDbChanged) {
            await saveDatabase(); // Async save (non-blocking)
        }

        // --- DONASI HARIAN ---
        if (!isGroup && !quotedId) { 
            const ONE_DAY_MS = 24 * 60 * 60 * 1000;
            const timeSinceLastDonation = now - (userDbEntry.lastDonationSent || 0);

            if (timeSinceLastDonation >= ONE_DAY_MS) {
                 // Kirim pesan donasi... (Code disingkat)
                 userDbEntry.lastDonationSent = now;
                 await saveDatabase();
            }
        }

        const isUserRegistered = !!userDbEntry.registered;
        
        // --- EKSEKUSI COMMAND ---
        if (!isCommand) return;
        const rawBody = body.slice(cfg.prefix.length).trim();
        
        m.reply = async (text, opt = {}) => {
            return sock.sendMessage(remoteJid, { text, ...opt }, { quoted: m });
        };
        
        // PING RESPONSE (Sekarang jauh lebih akurat karena DB Load di awal tidak dihitung)
        if (body === cfg.prefix) {
            const end_time = Date.now();
            const response_time = end_time - start_time;
            return m.reply(`✅ Bot sedang *online*! Respon dalam *${response_time}* ms`);
        }
        
        const args = rawBody.split(/ +/);
        const cmd = args.shift()?.toLowerCase();
        if (!cmd) return; 

        // HANDLE OWNER COMMANDS (RELOAD)
        if (isOwner) {
            if (cmd === 'reload') {
                m.reply('🔄 Reloading system...');
                await loadDisabledFeatures();
                await loadPlugins(); // Reload plugins ke variabel lokal baru
                // Karena kita pakai export, perubahan pluginsCache akan otomatis terbaca 
                // jika struktur import di index.js benar.
                m.reply('✅ System reloaded successfully!');
                return;
            } else if (cmd === 'disable' || cmd === 'enable') {
                const targetCmd = args[0]?.toLowerCase();
                if (!targetCmd) return m.reply(`❌ Gunakan: ${cfg.prefix}${cmd} <command>`);
                
                const status = cmd === 'disable';
                disabledFeatures[targetCmd] = status;
                
                // Simpan features.json
                await fs.writeFile(featuresPath, JSON.stringify(disabledFeatures, null, 2));

                // Update cache memory
                if (pluginsCache[targetCmd]) {
                    pluginsCache[targetCmd].isDisabled = status;
                }
                
                m.reply(`✅ Command *${targetCmd}* berhasil di${status ? 'nonaktifkan' : 'aktifkan'}.`);
                return;
            }
        }
        
        const pluginEntry = pluginsCache[cmd];
        if (!pluginEntry) return;

        // Cek Admin Group (Cache based)
        const participantJidForGroupCheck = key.participant || remoteJid;
        let isAdmin = isOwner;

        if (isGroup && !isOwner) {
            const cacheKey = remoteJid;
            if (groupAdminCache[cacheKey] && now < groupAdminCache[cacheKey].expiry) {
                const participant = groupAdminCache[cacheKey].participants.find(p => p.id === participantJidForGroupCheck);
                isAdmin = !!(participant?.admin === 'admin' || participant?.admin === 'superadmin');
            } else {
                try {
                    const groupMetadata = await sock.groupMetadata(remoteJid);
                    groupAdminCache[cacheKey] = {
                        participants: groupMetadata.participants,
                        expiry: now + CACHE_TTL
                    };
                    const participant = groupMetadata.participants.find(p => p.id === participantJidForGroupCheck);
                    isAdmin = !!(participant?.admin === 'admin' || participant?.admin === 'superadmin');
                } catch (e) { isAdmin = false; }
            }
        }

        // Cek Permission
        if (pluginEntry.isDisabled) return m.reply('🚫 Fitur ini sedang dinonaktifkan.');
        if (pluginEntry.isOwner && !isOwner) return m.reply('🚫 Fitur ini khusus Owner.');
        if (pluginEntry.isPremium && !isPremium) return m.reply('🚫 Fitur ini khusus Premium.');

        // JALANKAN PLUGIN
        try {
            log.evt(`Cmd '${cmd}' dari ${pushName || m.sender}`);
            await pluginEntry.handler({
                sock,
                msg: m,
                args,
                command: cmd,
                from: remoteJid,
                pushName,
                isOwner,
                isPremium,
                isUserRegistered,
                db: usersDbCache, // Oper cache memory, bukan fungsi baca file
                sender: m.sender,
                isGroup,
                isAdmin
            });
        } catch (e) {
            log.err(`❌ Plugin '${pluginEntry.file}' error: ${e.message}`);
            m.reply('❌ Terjadi *Error* saat menjalankan fitur ini.');
        }

    } catch (e) {
        log.err(`❌ Msg() fatal error: ${e.stack || e.message}`);
    }
}

export { loadPlugins, loadDisabledFeatures, pluginsCache, CONFESSION_MAP };
export default Msg;
