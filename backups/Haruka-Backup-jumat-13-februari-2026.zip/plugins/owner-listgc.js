import { groupsDb } from '../lib/database.js';

export default {
    command: ['listgroup', 'listgc', 'grouplist', 'gclist'],
    category: 'Owner',
    description: 'Melihat daftar grup & status sewa bot',
    isOwner: true,

    handler: async ({ sock, msg, reply }) => {
        await sock.sendMessage(msg.key.remoteJid, { react: { text: '⏳', key: msg.key } });

        try {
            const groupsRaw = await sock.groupFetchAllParticipating();
            const groups = Object.values(groupsRaw);

            if (groups.length === 0) return reply('❌ Bot belum bergabung ke grup manapun.');

            // Helper format hari
            const msToDays = (ms) => Math.ceil(ms / (1000 * 60 * 60 * 24));

            let txt = `📊 *DAFTAR GRUP BOT* (Total: ${groups.length})\n\n`;

            groups.forEach((g, i) => {
                const dbData = groupsDb[g.id];
                let infoSewa = "🆓 Permanent";

                if (dbData && dbData.expired) {
                    const now = Date.now();
                    const timeLeft = dbData.expired - now;

                    if (timeLeft > 0) {
                        const daysLeft = msToDays(timeLeft);
                        // Format tanggal pendek: 31/01/26
                        const dateExp = new Date(dbData.expired).toLocaleDateString('id-ID', {
                            day: 'numeric', month: 'numeric', year: '2-digit'
                        });
                        infoSewa = `⏳ ${daysLeft} Hari (${dateExp})`;
                    } else {
                        infoSewa = "⚠️ Expired";
                    }
                }

                // FORMAT BARU: Rapat, Tanpa Code Block (Backtick), Tanpa Spasi Depan
                txt += `${i + 1}. *${g.subject}*\n`;
                txt += `🆔 ${g.id}\n`; // ID Polos agar angka rapat
                txt += `👥 ${g.participants.length} Member • ${infoSewa}\n\n`;
            });

            await reply(txt.trim());

        } catch (e) {
            console.error(e);
            reply('❌ Gagal mengambil data grup.');
        }
    }
};