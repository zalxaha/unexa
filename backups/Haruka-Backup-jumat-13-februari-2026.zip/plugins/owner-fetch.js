import fetch from 'node-fetch';
import util from 'util';
import { URL } from 'url';
import path from 'path';

const handler = async ({ sock, msg, from, command, args }) => {
    
    const text = args.join(' ').trim();

    if (!text) {
        return sock.sendMessage(from, { text: `❌ Berikan URL yang ingin diambil, contoh: *.${command} https://example.com/api*` }, { quoted: msg });
    }

    if (!/^https?:\/\//i.test(text)) {
        return sock.sendMessage(from, { text: '❌ Awali *URL* dengan http:// atau https://' }, { quoted: msg });
    }

    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    let res;
    let finalContent = '';
    const url = text;

    try {
        const _url = new URL(url);
        
        res = await fetch(url);

        // --- BAGIAN PENGECEKAN UKURAN DIHAPUS SESUAI PERMINTAAN ---

        const contentType = res.headers.get('content-type') || '';
        const fileName = path.basename(_url.pathname) || 'file';

        // 1. Jika konten adalah TEXT, JSON, atau XML -> Kirim sebagai pesan teks
        if (/text|json|xml/i.test(contentType)) {
            let txt = await res.text();
            try {
                finalContent = util.format(JSON.parse(txt));
            } catch (e) {
                finalContent = txt;
            }

            await sock.sendMessage(from, { text: finalContent.slice(0, 65536) }, { quoted: msg });
        } 
        // 2. Jika bukan teks, download buffer dan cek tipe media
        else {
            const buffer = await res.buffer();
            const caption = `✅ Berhasil mengambil data dari:\n${url}\n\nType: ${contentType}`;

            if (/^image\//i.test(contentType)) {
                // KIRIM GAMBAR
                await sock.sendMessage(from, { 
                    image: buffer, 
                    caption: caption,
                    mimetype: contentType 
                }, { quoted: msg });
            } 
            else if (/^video\//i.test(contentType)) {
                // KIRIM VIDEO
                await sock.sendMessage(from, { 
                    video: buffer, 
                    caption: caption,
                    mimetype: contentType 
                }, { quoted: msg });
            } 
            else if (/^audio\//i.test(contentType)) {
                // KIRIM AUDIO
                await sock.sendMessage(from, { 
                    audio: buffer, 
                    mimetype: contentType 
                }, { quoted: msg });
            } 
            else {
                // KIRIM DOKUMEN (Default untuk file lain)
                await sock.sendMessage(from, { 
                    document: buffer,
                    fileName: fileName,
                    caption: caption,
                    mimetype: contentType
                }, { quoted: msg });
            }
        }

        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

    } catch (e) {
        console.error('[FETCHER ERROR]', e);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        await sock.sendMessage(from, { text: `❌ Gagal mengambil URL: ${e.message}` }, { quoted: msg });
    }
}

export default {
    command: ['fetch', 'get'],
    description: 'Mengambil konten dari URL (Auto detect Image/Video/Audio/Dokumen).',
    category: 'Owner',
    owner: true,
    handler,
};