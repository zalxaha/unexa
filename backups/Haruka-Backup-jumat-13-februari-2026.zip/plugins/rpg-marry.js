import fs from 'fs/promises'; 
import fsSync from 'fs'; 
import path from 'path';
import Crypto from 'crypto';
import { tmpdir } from 'os';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { fileURLToPath } from 'url';
import { createRequire } from 'module'; 

// Import modules kustom (asumsi path sudah benar)
import { uploadCatbox } from '../lib/uploader.js'; 
import { generateCertificate } from '../lib/sertifikat.js'; 

// --- [ SETUP PATH & DATABASE (OPTIMALISASI ATOMIC WRITE) ] ---

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url);

const userDataFile = path.join(__dirname, '../data/userData.json');
let userData = {}; 
let isSaving = false; // Flag untuk mencegah race condition (tumbukan penyimpanan)

// Variable untuk menyimpan waktu terakhir user menggunakan command (Cooldown Global)
const commandCooldown = new Map();

/**
 * Memuat data pengguna dari userData.json HANYA SEKALI saat startup.
 * Dilengkapi fitur auto-restore jika file rusak.
 */
async function loadUserData() {
  try {
    // Pastikan folder ada
    await fs.mkdir(path.dirname(userDataFile), { recursive: true });

    // Cek apakah file ada
    try {
        await fs.access(userDataFile);
    } catch {
        // Jika tidak ada, buat baru
        await fs.writeFile(userDataFile, JSON.stringify({}, null, 2), 'utf8');
        userData = {};
        console.log("[WAIFU DB] File userData.json baru dibuat.");
        return;
    }

    const content = await fs.readFile(userDataFile, 'utf8');
    const trimmedContent = content.trim();
    
    if (trimmedContent.length > 0) {
        try {
            userData = JSON.parse(trimmedContent);
            console.log(`[WAIFU DB] Berhasil memuat data untuk ${Object.keys(userData).length} user.`);
        } catch (parseError) {
            console.error("[WAIFU DB ERROR] File JSON korup/rusak. Backup dan reset memori.", parseError);
            // Backup file rusak agar data tidak hilang permanen
            await fs.copyFile(userDataFile, userDataFile + '.corrupt.' + Date.now());
            userData = {}; 
        }
    } else {
        userData = {};
    }
    
  } catch (e) {
    console.error("[WAIFU DB KRITIS] Gagal memuat database:", e);
    userData = {}; // Fallback ke objek kosong agar bot tidak crash
  }
}

/**
 * Menyimpan data ke file JSON dengan teknik ATOMIC WRITE.
 * Tulis ke file .tmp dulu -> jika sukses -> rename ke file asli.
 * Ini mencegah file menjadi kosong (0 bytes) jika bot mati mendadak saat proses penyimpanan.
 */
async function saveUserData() {
    if (isSaving) return; // Debounce sederhana
    isSaving = true;

    try {
        const tempFile = userDataFile + '.tmp';
        await fs.writeFile(tempFile, JSON.stringify(userData, null, 2), 'utf8');
        // Operasi Rename bersifat Atomic di level OS (sangat cepat & aman)
        await fs.rename(tempFile, userDataFile); 
    } catch (e) {
        console.error("[WAIFU DB] Gagal menyimpan database:", e);
    } finally {
        isSaving = false;
    }
}

// Muat database saat startup (INIT)
(async () => {
    try {
        await loadUserData(); 
    } catch (e) {
        console.error("[WAIFU] Gagal memuat database saat startup:", e.message);
    }
})();


// --- [ KONSTANTA DAN BATAS ] ---
const GLOBAL_COOLDOWN_TIME = 10000; // 10 Detik Cooldown Global untuk semua command Waifu
const COOLDOWN_LIGHT = 1 * 3600000; // 1 jam
const COOLDOWN_NAUGHTY = 1 * 3600000; // 1 jam
const COOLDOWN_HEAVY = 3 * 3600000; // 3 jam
const COOLDOWN_NEGLECT = 24 * 3600000; // 24 jam 
const COOLDOWN_DATE = 6 * 3600000; // 6 jam
const MAX_WAIFU_GUEST = 3; // Batas Waifu untuk Non-Premium


// --- [ HELPER FUNCTIONS (OPTIMIZED) ] ---

/**
 * FUNGSI FALLBACK PENTING:
 * Mengirim gambar jika URL valid. Jika URL mati/Catbox down, 
 * otomatis kirim teks saja agar bot tidak error.
 */
async function sendImageFallback(sock, jid, msg, url, caption, mentions = []) {
    try {
        if (!url) throw new Error("No URL provided");
        // Coba kirim gambar
        await sock.sendMessage(jid, { image: { url: url }, caption: caption, mentions: mentions }, { quoted: msg });
    } catch (e) {
        // Jika error (URL mati/Catbox down), kirim teks saja
        // console.warn(`[WAIFU IMAGE FAIL] Mengirim teks saja karena gambar gagal: ${e.message}`);
        await sock.sendMessage(jid, { text: caption, mentions: mentions }, { quoted: msg });
    }
}

/**
 * Upload ke Catbox yang aman. 
 * Jika gagal upload, return null (jangan throw error).
 */
async function safeUploadCatbox(filePath) {
    try {
        if (!fsSync.existsSync(filePath)) return null;
        return await uploadCatbox(filePath);
    } catch (e) {
        console.warn(`[WAIFU UPLOAD WARN] Catbox gagal: ${e.message}`);
        return null; // Return null agar kode tidak crash
    }
}

function generateFileName(ext = '') {
  return path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}${ext}`);
}

async function downloadMedia(mediaInfo, mimeType) {
    const mediaTypeForDownload = mimeType.includes('image') ? 'image' : 'document';
    let fileExt = '.jpg';

    const filePath = generateFileName(fileExt);
    const stream = await downloadContentFromMessage(mediaInfo, mediaTypeForDownload);
    const chunks = [];
    for await (const chunk of stream) {
        chunks.push(chunk);
    }
    const mediaBuffer = Buffer.concat(chunks);
    await fs.writeFile(filePath, mediaBuffer);
    return filePath;
}

function formatRemainingTime(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    
    let parts = [];
    if (hours > 0) parts.push(`${hours} jam`);
    if (minutes > 0) parts.push(`${minutes} menit`);
    if (seconds > 0 && parts.length < 2) parts.push(`${seconds} detik`);
    
    return parts.length > 0 ? parts.join(' ') : 'sebentar';
}

// --- [ UTILITY WAIFU ] ---

function getWaifuData(userId) {
    // Pastikan struktur data user ada
    if (!userData[userId]) userData[userId] = { waifus: [], children: [] };
    if (!userData[userId].waifus) userData[userId].waifus = [];
    
    return userData[userId].waifus; 
}

/**
 * Mencari Waifu berdasarkan input user (Nomor Urut atau Nama)
 */
function getTargetWaifu(userId, args) {
    const waifus = getWaifuData(userId);
    if (waifus.length === 0) return null;

    const targetArg = args[0]?.trim();
    
    // --- PRIORITAS 1: Cek berdasarkan Nomor Urut ---
    const targetNumber = parseInt(targetArg);
    if (!isNaN(targetNumber) && targetNumber >= 1 && targetNumber <= waifus.length) {
        const index = targetNumber - 1; 
        return { wife: waifus[index], wifeIndex: index };
    }

    // --- PRIORITAS 2: Cek berdasarkan Nama ---
    const targetName = args.join(' ').trim().toLowerCase();
    
    if (targetName) {
        const index = waifus.findIndex(w => w.name.toLowerCase().includes(targetName));
        if (index !== -1) {
            return { wife: waifus[index], wifeIndex: index };
        }
    }
    
    // --- PRIORITAS 3: Ambil yang pertama (index 0) ---
    if (args.length === 0) {
        return { wife: waifus[0], wifeIndex: 0 };
    }
    
    return null; 
}

function getTargetChild(userId, args) {
    const children = userData[userId]?.children || [];
    if (children.length === 0) return null;

    const targetArg = args[0]?.trim();
    
    // --- PRIORITAS 1: Cek berdasarkan Nomor Urut ---
    const targetNumber = parseInt(targetArg);
    if (!isNaN(targetNumber) && targetNumber >= 1 && targetNumber <= children.length) {
        const index = targetNumber - 1;
        return { child: children[index], childIndex: index };
    }

    // --- PRIORITAS 2: Cek berdasarkan Nama ---
    const targetName = args.join(' ').trim().toLowerCase();
    
    if (targetName) {
        const index = children.findIndex(c => c.name.toLowerCase().includes(targetName));
        if (index !== -1) {
            return { child: children[index], childIndex: index };
        }
    }
    
    return null; 
}


/**
 * Logika Penurunan Kasih Sayang (Neglect)
 * Jika user tidak berinteraksi > 24 jam, kasih sayang turun.
 */
async function checkAndDecreaseAffection(userId) {
    const waifus = userData[userId]?.waifus;
    if (!waifus || waifus.length === 0) return false;

    let changed = false;
    const now = Date.now();

    for (const wife of waifus) {
        wife.stress = wife.stress || 0; 
        
        const lastInteraction = Math.max(
            wife.lastKiss || 0,
            wife.lastHug || 0,
            wife.lastPatpat || 0,
            wife.lastHeavyInteraction || 0,
            wife.lastDate || 0 
        );

        // Pengurangan karena neglect (kurang interaksi 24 jam)
        if (lastInteraction && (now - lastInteraction) > COOLDOWN_NEGLECT) {
            const oldAffection = wife.affection;
            wife.affection = Math.max(0, wife.affection - 5); 
            wife.stress = Math.min(100, (wife.stress || 0) + 10); 
            
            if (oldAffection !== wife.affection) {
                changed = true;
            }
        }
        
        // Pengurangan stress secara pasif (jika affection tinggi)
        if (wife.stress > 0 && wife.affection >= 70) {
             wife.stress = Math.max(0, wife.stress - 1);
        }
        
        // Efek Stress Tinggi
        if (wife.stress >= 80 && wife.affection > 0) {
             const oldAffection = wife.affection;
             wife.affection = Math.max(0, wife.affection - 2); 
             if (oldAffection !== wife.affection) changed = true;
        }
    }

    if (changed) {
        await saveUserData();
    }
    return changed;
}


// --- [ FUNGSI KHUSUS SERTIFIKAT ] ---

async function generateAndStoreCertificate(sock, remoteJid, msg, newWaifu, pushName, user) {
    let tempImagePath = '';
    
    try {
        const husbandName = pushName; 
        const wifeName = newWaifu.name;
        const marriageDate = newWaifu.dateMarried;
        
        tempImagePath = await generateCertificate(husbandName, wifeName, marriageDate);
        // Gunakan upload aman
        const certificateUrl = await safeUploadCatbox(tempImagePath);

        if (certificateUrl) {
            newWaifu.marriageCertificateUrl = certificateUrl;
            
            // Gunakan sendImageFallback agar aman
            await sendImageFallback(sock, remoteJid, msg, certificateUrl, 
                `📜 Sertifikat Pernikahan untuk *${wifeName}* berhasil dibuat dan disimpan!`, 
                [user]
            );
        } else {
            await sock.sendMessage(remoteJid, { text: `⚠️ Sertifikat berhasil dibuat tapi gagal upload (Server Penuh). Data tetap aman.` }, { quoted: msg });
        }

    } catch (error) {
        console.error('[CERTIFICATE GENERATION ERROR]', error);
    } finally {
        if (tempImagePath && fsSync.existsSync(tempImagePath)) {
            await fs.unlink(tempImagePath).catch(() => {});
        }
    }
}


// --- [ HANDLER UTAMA ] ---

const handler = async ({ sock, msg, from, args, command, pushName, sender, isPremium, isOwner, db }) => {
    
    if (!sender) {
        return; 
    }
    const user = sender; 
    const remoteJid = from; 
    
    try {
        // --- [ CHECK GLOBAL COOLDOWN (10 Detik) ] ---
        // Owner kebal cooldown untuk testing
        if (!isOwner) {
            const lastTime = commandCooldown.get(user);
            if (lastTime && Date.now() - lastTime < GLOBAL_COOLDOWN_TIME) {
                const remaining = Math.ceil((GLOBAL_COOLDOWN_TIME - (Date.now() - lastTime)) / 1000);
                return msg.reply(`⏳ *Sabar dulu!* Tunggu ${remaining} detik lagi sebelum menggunakan command Waifu.`);
            }
            // Set waktu sekarang ke Map
            commandCooldown.set(user, Date.now());
        }
        // ----------------------------------------------------

        const mainCommand = command?.toLowerCase(); 
        const subCommand = args[0]?.toLowerCase(); 

        // --- INISIALISASI DATA PENGGUNA (Memory) ---
        if (!userData[user]) {
            userData[user] = { waifus: [], children: [] };
        }
        if (!userData[user].waifus) userData[user].waifus = [];
        if (!userData[user].children) userData[user].children = [];
        
        checkAndDecreaseAffection(user);
        
        const waifus = getWaifuData(user);
        const isUnlimited = isPremium || isOwner;

        // --- HELPER: ADD DOUBLE XP ---
        // Menambahkan XP ke database utama bot (bukan database waifu)
        const addDoubleXp = (amount) => {
            if (db && db[user]) {
                const bonus = amount * 2; // DOUBLE XP LOGIC
                db[user].xp = (db[user].xp || 0) + bonus;
                // db akan disimpan otomatis oleh handler utama di akhir proses
            }
        };

        // ===================================
        // 0. COMMAND: CERAI & TALAK 
        // ===================================
        if (mainCommand === 'cerai' || mainCommand === 'talak') {
             
             let targetArgs = args;
             const lastArg = args[args.length - 1]?.toLowerCase();
             
             // Pisahkan argumen 'ya' dari target pencarian
             if (lastArg === 'ya') {
                 targetArgs = args.slice(0, -1);
             } 
             
             if (targetArgs.length === 0 && args.length === 1 && lastArg === 'ya') {
                  targetArgs = ['1'];
             } else if (targetArgs.length === 0 && args.length === 0) {
                 targetArgs = ['1'];
             }


             const target = getTargetWaifu(user, targetArgs);

             if (!target) {
                return msg.reply(`❌ Waifu tidak ditemukan. Anda belum memiliki waifu!`);
             }
             
             const { wife, wifeIndex } = target; 
             
             if (lastArg !== 'ya') {
                 let confirmationText = `⚠️ Anda yakin ingin ${mainCommand} *${wife.name}*?`;
                 
                 const exampleTarget = targetArgs.length > 0 ? targetArgs.join(' ') : (wifeIndex + 1).toString();
                 
                 if (mainCommand === 'cerai') {
                     confirmationText += `\n\nPerceraian damai (*cerai*) butuh proses dan persetujuan (Affection minimal 60). Balas dengan *.cerai ${exampleTarget} ya* untuk melanjutkan.`;
                 } else if (mainCommand === 'talak') {
                     confirmationText += `\n\nIni adalah talak instan (*talak*). Waifu lain akan cemas, kasih sayang mereka akan turun, dan stress mereka akan meningkat! Balas dengan *.talak ${exampleTarget} ya* untuk melanjutkan.`;
                 }
                 return msg.reply(confirmationText);
             }

             // Cek jika waifu yang ditargetkan sedang hamil
             if (wife.isPregnant) {
                 return msg.reply(`💔 Anda tidak bisa ${mainCommand} *${wife.name}*. Dia sedang hamil! Tunggu sampai dia melahirkan.`);
             }

             // Hapus waifu dari array
             userData[user].waifus.splice(wifeIndex, 1);
             
             let responseText = '';
             let wifeReaction = '';

             if (mainCommand === 'cerai') {
                 // CERAI DAMAI (Membutuhkan Affection > 60)
                 if (wife.affection < 60) {
                     // Kembalikan waifu, batalkan cerai
                     userData[user].waifus.splice(wifeIndex, 0, wife); 
                     await saveUserData();
                     return msg.reply(`💔 Pengadilan menolak permohonan cerai Anda. *${wife.name}* terlalu sedih karena Affection-nya hanya ${wife.affection}. Anda harus menaikkan Affection-nya atau coba *talak* instan.`);
                 }
                 
                 wifeReaction = `*${wife.name}*: "Baiklah, saya akan mengurus dokumen pengadilan. Saya harap Anda bahagia. Selamat tinggal, Suami." 😢`;
                 responseText = `🕊️ *${wife.name}* telah dicerai secara damai dan resmi meninggalkan Anda. Semoga sukses dengan petualangan Anda!`;
             
             } else if (mainCommand === 'talak') {
                 // TALAK INSTAN 
                 wifeReaction = `*${wife.name}*: "Apa?! *Talak*?! Aku... aku tak percaya kau tega! Aku membencimu, @${user.split('@')[0]}!" 🤬`;
                 responseText = `💥 *${wife.name}* telah Anda talak secara instan. Ia sangat marah dan trauma.`;

                 // Efek samping talak pada waifu yang tersisa
                 for (const remainingWife of userData[user].waifus) {
                      remainingWife.affection = Math.max(0, remainingWife.affection - 15);
                      remainingWife.stress = Math.min(100, (remainingWife.stress || 0) + 20);
                 }
                 responseText += `\n\n*⚠️ Peringatan:* Sisa waifu Anda (x${userData[user].waifus.length}) menjadi sangat cemas. Kasih sayang mereka turun -15 dan Stress naik +20.`;
             }
             
             await saveUserData();
             await sock.sendMessage(remoteJid, { text: wifeReaction, mentions: [user] }, { quoted: msg });
             return msg.reply(responseText);
        }
        
        // ===================================
        // 1. COMMAND: MENIKAH / TAMBAH ISTRI
        // ===================================

        if (mainCommand === 'marry' || subCommand === 'marry') { 
            
            // --- BATAS WAIFU ---
            if (!isUnlimited && waifus.length >= MAX_WAIFU_GUEST) {
                 return msg.reply(`🚫 *Batas Poligami Tercapai!* Anda hanya diizinkan memiliki ${MAX_WAIFU_GUEST} waifu. Untuk lebih dari itu, Anda harus menjadi pengguna *Premium*.`);
            }
            // --------------------

            const nameArgs = (mainCommand === 'marry') ? args : args.slice(1);
            const newWaifuName = nameArgs.join(' ').trim();
            
            const contextInfo = msg.message?.extendedTextMessage?.contextInfo;
            const quoted = contextInfo?.quotedMessage;
            const mediaMessage = quoted || msg.message;
            
            const mimeType = Object.keys(mediaMessage || {}).find(k => k.endsWith('Message')) || '';

            if (!mimeType.includes('image')) {
                return msg.reply(`❌ Untuk menikah, kirim atau reply dengan *gambar* calon waifu Anda, disertai nama.\nContoh: *.marry Asuna Yuuki*`);
            }

            if (!newWaifuName || newWaifuName.toLowerCase() === 'marry') {
                return msg.reply(`❌ Berikan nama untuk waifu Anda.\nContoh: *.marry Asuna Yuuki*`);
            }
            
            // Cek Istri Pertama (untuk poligami)
            if (waifus.length >= 1) {
                const firstWife = waifus[0];
                if (firstWife.affection < 70) { 
                    return msg.reply(`💔 *${firstWife.name}* (Istri Pertama) tampak cemburu. Anda harus meningkatkan kasih sayangnya di atas 70 (Saat ini: ${firstWife.affection}) sebelum bisa menikah lagi.`);
                }
                await msg.reply(`💍 Istri pertama (*${firstWife.name}*) setuju! Memproses pernikahan kedua...`);
            }
            
            await sock.sendMessage(remoteJid, { react: { text: '⏳', key: msg.key } });

            let mediaPath = '';
            let waifuUrl = null;

            try {
                mediaPath = await downloadMedia(mediaMessage[mimeType], mimeType);
                // Gunakan Safe Upload
                waifuUrl = await safeUploadCatbox(mediaPath);

                const newWaifu = {
                    id: Crypto.randomBytes(4).toString('hex'),
                    name: newWaifuName,
                    url: waifuUrl, // Bisa null jika upload gagal
                    dateMarried: new Date().toISOString().split('T')[0],
                    affection: 50, 
                    status: 'Married',
                    childrenCount: 0,
                    stress: 0, 
                    lastKiss: 0, 
                    lastHug: 0,
                    lastPatpat: 0,
                    lastNaughtyInteraction: 0,
                    lastHeavyInteraction: 0, 
                    lastDate: 0, 
                    isPregnant: false,  
                    dueDate: null,
                    marriageCertificateUrl: null
                };

                // Push ke memori
                userData[user].waifus.push(newWaifu);
                // Simpan ke file
                await saveUserData();
                addDoubleXp(100); // XP untuk menikah

                const role = waifus.length === 1 ? 'Istri Pertama' : 'Istri Berikutnya'; 
                
                let caption = `🎉 Selamat, @${user.split('@')[0]}! Anda berhasil menikahi *${newWaifuName}*.\n\n` +
                                `Status: ${role}\n` +
                                `Kasih Sayang Awal: ${newWaifu.affection}\n` +
                                `Sekarang Anda memiliki ${userData[user].waifus.length} Waifu.\n` +
                                `💰 *Double XP Reward Obtained!*`;
                                
                if (!waifuUrl) caption += `\n\n⚠️ *Note:* Gambar gagal diupload (Server Error), tapi data waifu tetap tersimpan.`;

                // Kirim Respon (Aman jika gambar gagal)
                await sendImageFallback(sock, remoteJid, msg, waifuUrl, caption, [user]);
                
                // Sertifikat Process
                const currentWifeIndex = userData[user].waifus.length - 1;
                await generateAndStoreCertificate(sock, remoteJid, msg, userData[user].waifus[currentWifeIndex], pushName, user);
                
                await saveUserData(); 
                await sock.sendMessage(remoteJid, { react: { text: '✅', key: msg.key } });

            } catch (e) {
                console.error('[MARRY INTERNAL ERROR]', e);
                await sock.sendMessage(remoteJid, { react: { text: '❌', key: msg.key } });
                msg.reply(`❌ Gagal memproses pernikahan: ${e.message}`);
            } finally {
                if (mediaPath && fsSync.existsSync(mediaPath)) {
                    await fs.unlink(mediaPath).catch(() => {});
                }
            }
            return;
        }

        // ===================================
        // 2. COMMAND: DATE (Kencan/Jalan-jalan)
        // ===================================
        if (mainCommand === 'date' || (mainCommand === 'waifu' && subCommand === 'date')) {
            
            const targetArgs = (mainCommand !== 'waifu') ? args : args.slice(1);
            const target = getTargetWaifu(user, targetArgs);

            if (!target) {
                return msg.reply(`❌ Waifu tidak ditemukan. Anda belum memiliki waifu untuk diajak kencan!`);
            }
            const { wife, wifeIndex } = target; 
            
            const cooldownTime = COOLDOWN_DATE; 
            const lastDate = wife.lastDate || 0; 
            
            if (Date.now() - lastDate < cooldownTime) {
                const remaining = (lastDate + cooldownTime) - Date.now();
                return msg.reply(`*${wife.name}* (${wife.affection}/100) masih butuh istirahat setelah kencan terakhir. Anda harus menunggu ${formatRemainingTime(remaining)} lagi.`);
            }

            const dateSpots = [
                { spot: 'Cafe Bintang Lima', aff: 15, stress: 20, text: `Anda mengajak *${wife.name}* makan malam romantis di Cafe Bintang Lima. Ia sangat senang dan stressnya berkurang banyak.`, aff: 15, stress: 20 },
                { spot: 'Taman Kota', aff: 10, stress: 10, text: `Anda berjalan-jalan santai di Taman Kota. Suasana yang damai membuat *${wife.name}* rileks.`, aff: 10, stress: 10 },
                { spot: 'Nonton Film', aff: 8, stress: 5, text: `Anda menonton film terbaru di bioskop. *${wife.name}* tertawa lepas melihat adegan komedi.`, aff: 8, stress: 5 },
            ];
            
            const selectedDate = dateSpots[Math.floor(Math.random() * dateSpots.length)];
            
            wife.affection = Math.min(100, wife.affection + selectedDate.aff);
            wife.stress = Math.max(0, (wife.stress || 0) - selectedDate.stress); 
            wife.lastDate = Date.now();
            
            userData[user].waifus[wifeIndex] = wife;
            await saveUserData();
            addDoubleXp(50); // XP untuk Date

            await sock.sendMessage(remoteJid, { react: { text: '🥂', key: msg.key } });

            const resultText = `${selectedDate.text}\n\n*Kasih Sayang +${selectedDate.aff}. Stress -${selectedDate.stress}.*\n(Saat ini: Affection ${wife.affection}/100, Stress ${wife.stress}/100)\n💰 *Double XP Reward!*`;
            
            // Gunakan sendImageFallback
            await sendImageFallback(sock, remoteJid, msg, wife.url, resultText, [user]);
            return;
        }

        // ===================================
        // 3. COMMAND: INTERAKSI RINGAN (Kiss, Hug, Patpat)
        // ===================================
        
        const lightInteractionCommands = ['kiss', 'hug', 'patpat'];
        if (lightInteractionCommands.includes(mainCommand) || (mainCommand === 'waifu' && lightInteractionCommands.includes(subCommand))) {
            
            const action = (mainCommand !== 'waifu') ? mainCommand : subCommand;
            const targetArgs = (mainCommand !== 'waifu') ? args : args.slice(1);
            const target = getTargetWaifu(user, targetArgs);

            if (!target) {
                return msg.reply(`❌ Waifu tidak ditemukan. Anda belum memiliki waifu! Silahkan menikah dulu.`);
            }
            const { wife, wifeIndex } = target; 
            
            const cooldownTime = COOLDOWN_LIGHT; 
            let lastInteractKey;

            if (action === 'kiss') {
                lastInteractKey = 'lastKiss';
            } else if (action === 'hug') {
                lastInteractKey = 'lastHug';
            } else if (action === 'patpat') {
                lastInteractKey = 'lastPatpat';
            }
            
            const lastInteractTime = wife[lastInteractKey] || 0;
            const affectionGain = 5;
            const stressChange = (action === 'hug' || action === 'patpat') ? 5 : 0; 

            if (Date.now() - lastInteractTime < cooldownTime) {
                const remaining = (lastInteractTime + cooldownTime) - Date.now();
                return msg.reply(`*${wife.name}* (${wife.affection}/100) masih beristirahat. Anda harus menunggu ${formatRemainingTime(remaining)} lagi untuk interaksi ringan (${action}).`);
            }

            if (wife.isPregnant) {
                 return msg.reply(`*${wife.name}* sedang hamil. Interaksi ringan boleh, tapi jangan terlalu sering!`);
            }
            
            let reactionText;
            let reactionEmoji;
            let affectionChange = affectionGain;

            if (action === 'kiss') {
                reactionEmoji = '😘';
                if (wife.affection < 40) reactionText = `*${wife.name}*: "Ew, apa-apaan itu! Jangan mendadak cium aku, ${pushName}!"`;
                else if (wife.affection < 70) reactionText = `*${wife.name}*: "Ah... terima kasih, Suami. *chuu*."`;
                else reactionText = `*${wife.name}*: "Aku juga mencintaimu! Aku tak akan pernah bosan dicium olehmu. ❤️"`;
            } else if (action === 'hug') {
                 reactionEmoji = '🤗';
                if (wife.affection < 40) reactionText = `*${wife.name}*: "Lepaskan aku! Aku butuh ruang!"`;
                else if (wife.affection < 70) reactionText = `*${wife.name}*: "Pelukan yang hangat... ini cukup membuatku tenang."`;
                else reactionText = `*${wife.name}*: "Aku suka saat kau memelukku seperti ini, Suami. Jangan lepaskan aku."`;
            } else if (action === 'patpat') { 
                 reactionEmoji = '😊';
                if (wife.affection < 40) reactionText = `*${wife.name}*: "Tanganku kotor! Jangan sentuh kepalaku, ${pushName}. (menampar tangan Anda pelan)"`;
                else if (wife.affection < 70) reactionText = `*${wife.name}*: "Pat pat? Hehe, sudah kuduga kau menyayangiku, Suami."`;
                else reactionText = `*${wife.name}*: "Ah, itu membuatku ngantuk. Lebih lembut lagi, Suamiku. 😴"`;
            }
            
            wife.affection = Math.min(100, wife.affection + affectionChange);
            wife.stress = Math.max(0, (wife.stress || 0) - stressChange); 
            wife[lastInteractKey] = Date.now(); 
            
            userData[user].waifus[wifeIndex] = wife;
            await saveUserData();
            addDoubleXp(20); // XP untuk interaksi ringan


            await sock.sendMessage(remoteJid, { react: { text: reactionEmoji, key: msg.key } });
            
            // Gunakan sendImageFallback
            await sendImageFallback(sock, remoteJid, msg, wife.url, 
                `${reactionText}\n\n*Kasih Sayang bertambah +${affectionChange}!* (Saat ini: ${wife.affection}/100, Stress: ${wife.stress}/100)\n💰 *Double XP Reward!*`,
                [user]
            );
            return;
        }

        // ===================================
        // 4. Logika Istri Nakal
        // ===================================
        if (mainCommand === 'istrinakal' || (mainCommand === 'waifu' && subCommand === 'istrinakal')) {
            
             const targetArgs = (mainCommand !== 'waifu') ? args : args.slice(1);
            const target = getTargetWaifu(user, targetArgs);

            if (!target) {
                return msg.reply(`❌ Waifu tidak ditemukan. Anda belum memiliki waifu! Silahkan menikah dulu.`);
            }
            const { wife, wifeIndex } = target; 
            
            const cooldownTime = COOLDOWN_NAUGHTY; 
            const lastInteractTime = wife.lastNaughtyInteraction || 0; 
            const affectionGain = 3; 

            if (Date.now() - lastInteractTime < cooldownTime) {
                const remaining = (lastInteractTime + cooldownTime) - Date.now();
                return msg.reply(`*${wife.name}* sedang fokus dengan kegiatannya. Anda harus menunggu ${formatRemainingTime(remaining)} lagi. 🤭`);
            }

            if (wife.isPregnant) {
                 return msg.reply(`*${wife.name}* sedang hamil. Jangan nakal-nakal dulu, kasihan si jabang bayi! 😉`);
            }
            
            const successChance = 0.05 + (wife.affection / 100) * 0.75; 
            const roll = Math.random();
            let resultText;

            wife.lastNaughtyInteraction = Date.now(); 
            wife.affection = Math.min(100, wife.affection + affectionGain);
            
            if (roll < successChance) {
                wife.lastHeavyInteraction = 0; 
                addDoubleXp(40); // Bonus XP besar jika berhasil
                
                resultText = `*${wife.name}*: "Ehehe, *nggak sabar ya* @${user.split('@')[0]}? Aku juga! Malam ini, kita lanjut lagi ya!"\n\n` +
                             `🎉 *Cooldown Senggama di-reset!* Gunakan *.waifu senggama ${wife.name}* sekarang. Kasih Sayang +${affectionGain}.\n💰 *Double XP Reward!*`;
                await sock.sendMessage(remoteJid, { react: { text: '😏', key: msg.key } });
            } else {
                resultText = `*${wife.name}*: "Hmm, nanti malam saja ya, Suami. Aku masih sedikit lelah, lagipula... kau belum cukup nakal hari ini. 😜"\n\n` +
                             `❌ Cooldown Senggama *tetap*. Kasih Sayang +${affectionGain}.`;
                await sock.sendMessage(remoteJid, { react: { text: '🙁', key: msg.key } });
            }
            
            userData[user].waifus[wifeIndex] = wife;
            await saveUserData();

            await sendImageFallback(sock, remoteJid, msg, wife.url, resultText, [user]);
            return;
        }

        // ===================================
        // 5. COMMAND: SENGGAMA (Interaksi Berat) 
        // ===================================
        
        if (mainCommand === 'senggama' || subCommand === 'senggama') {
            
            const targetArgs = (mainCommand !== 'waifu') ? args : args.slice(1);
            const target = getTargetWaifu(user, targetArgs);

            if (!target) {
                return msg.reply(`❌ Waifu tidak ditemukan. Anda harus menikah dulu! Gunakan *.senggama [Nomor/Nama]*`);
            }
            const { wife, wifeIndex } = target; 
            
            const cooldownTime = COOLDOWN_HEAVY; 
            const lastHeavyInteract = wife.lastHeavyInteraction || 0;
            const affectionGain = 10;
            const stressIncrease = 5; 

            if (Date.now() - lastHeavyInteract < cooldownTime) {
                const remaining = (lastHeavyInteract + cooldownTime) - Date.now();
                return msg.reply(`*${wife.name}* (${wife.affection}/100) masih kelelahan. Anda harus menunggu ${formatRemainingTime(remaining)} lagi.`);
            }

            if (wife.isPregnant) {
                return msg.reply(`*${wife.name}* sedang hamil. Anda tidak bisa berinteraksi dengannya saat ini.`);
            }
            
            let responses = [
                `*${wife.name}*: "Ahh... enak banget, @${user.split('@')[0]}!"`,
                `*${wife.name}*: "Terima kasih atas malam yang indah ini, Suamiku. 💖"`,
                `*${wife.name}*: "Aku tidak akan pernah melupakan malam ini. *ngos-ngosan*"`,
                `*${wife.name}*: "Kau luar biasa, @${user.split('@')[0]}. Aku mencintaimu."`
            ];
            
            const randomResponse = responses[Math.floor(Math.random() * responses.length)];
            
            wife.lastHeavyInteraction = Date.now(); 
            wife.affection = Math.min(100, wife.affection + affectionGain);
            wife.stress = Math.min(100, (wife.stress || 0) + stressIncrease); 
            addDoubleXp(150); // XP Sangat Besar
            
            await sock.sendMessage(remoteJid, { react: { text: '💦', key: msg.key } });

            let resultText = `${randomResponse}\n\n*Kasih Sayang bertambah +${affectionGain}.* (Saat ini: ${wife.affection}/100)\n💰 *Huge Double XP Reward!*`;

            let roll = Math.random();
            if (wife.affection > 60 && roll < 0.30) {
                // Hamil selama 3 jam (3 * 3600000ms)
                wife.isPregnant = true;
                wife.dueDate = Date.now() + (3 * 3600000); 
                resultText += `\n\n*Eits!* Ada kejutan! Sepertinya *${wife.name}* sekarang hamil! Perkiraan melahirkan dalam ${formatRemainingTime(wife.dueDate - Date.now())}. 🤰`;
            } else {
                resultText += `\n\nNamun sepertinya belum ada tanda-tanda kehamilan. Coba lagi nanti!`;
            }
            
            userData[user].waifus[wifeIndex] = wife;
            await saveUserData();
            
            await sendImageFallback(sock, remoteJid, msg, wife.url, resultText, [user]);
            return;
        }


        // ===================================
        // 6. COMMAND: MELAHIRKAN 
        // ===================================

        if (mainCommand === 'birth' || subCommand === 'birth') {
            
            const targetArgs = (mainCommand !== 'waifu') ? args : args.slice(1);
            const target = getTargetWaifu(user, targetArgs);

            if (!target) {
                return msg.reply(`❌ Waifu tidak ditemukan. Anda belum menikah.`);
            }
            const { wife, wifeIndex } = target;

            if (!wife.isPregnant) {
                return msg.reply(`*${wife.name}* tidak sedang hamil.`);
            }

            if (Date.now() < wife.dueDate) {
                const remaining = wife.dueDate - Date.now();
                return msg.reply(`Belum waktunya melahirkan. Tunggu ${formatRemainingTime(remaining)} lagi.`);
            }

            const childName = `Anak ${pushName} ke-${userData[user].children.length + 1}`;
            const isMale = Math.random() > 0.5;
            
            // --- PROPERTI ANAK BARU ---
            const newChild = {
                name: childName,
                gender: isMale ? 'Laki-laki' : 'Perempuan',
                age: 0, 
                mother: wife.name,
                birthDate: new Date().toISOString().split('T')[0],
                happiness: 50, 
                lastPlay: 0, 
            };
            // ---------------------------

            userData[user].children.push(newChild);
            wife.childrenCount++;
            wife.isPregnant = false;
            wife.dueDate = null;
            
            wife.lastHeavyInteraction = Date.now(); 
            
            userData[user].waifus[wifeIndex] = wife;
            await saveUserData();
            addDoubleXp(200); // XP Paling Besar

            await sock.sendMessage(remoteJid, { react: { text: '👶', key: msg.key } });
            return msg.reply(`🎉 *SELAMAT*! *${wife.name}* telah melahirkan ${isMale ? 'seorang putra' : 'seorang putri'} bernama *${childName}*!\n💰 *Huge Double XP Reward!*`);
        }
        
        // ===================================
        // 7. COMMAND: RENAME CHILD 
        // ===================================
        if (mainCommand === 'renamechild' || (mainCommand === 'waifu' && subCommand === 'renamechild')) {
            
            const effectiveArgs = (mainCommand === 'renamechild') ? args : args.slice(1);

            if (effectiveArgs.length < 2) {
                 return msg.reply('❌ Format salah. Gunakan: *.renamechild [No/Nama Anak] [Nama Baru]*');
            }

            const targetArg = effectiveArgs[0]; 
            const targetNumber = parseInt(targetArg);

            let childInfo = null;
            let newNameArgs;
            let targetChildArgs = [];

            if (!isNaN(targetNumber)) {
                // Target adalah nomor
                targetChildArgs = [targetArg];
                childInfo = getTargetChild(user, targetChildArgs); 
                newNameArgs = effectiveArgs.slice(1).join(' ').trim(); 
            } else {
                // Target adalah nama
                
                const potentialName = targetArg.toLowerCase();
                const indexMatch = userData[user]?.children.findIndex(c => c.name.toLowerCase().startsWith(potentialName));

                if (indexMatch !== -1) {
                    childInfo = { child: userData[user].children[indexMatch], childIndex: indexMatch };
                    newNameArgs = effectiveArgs.slice(1).join(' ').trim();
                }
            }


            if (!childInfo) {
                return msg.reply('❌ Anak tidak ditemukan. Pastikan Anda menggunakan Nomor Urut atau Nama yang tepat.');
            }
            
            const { child, childIndex } = childInfo;
            
            if (!newNameArgs) {
                return msg.reply('❌ Berikan nama baru untuk anak Anda.');
            }
            
            const oldName = child.name;
            child.name = newNameArgs;
            userData[user].children[childIndex] = child;
            
            await saveUserData();
            
            return msg.reply(`✅ Nama *${oldName}* (Anak ke-${childIndex + 1}) berhasil diubah menjadi *${newNameArgs}*!`);
        }


        // ===================================
        // 8. COMMAND: STATUS
        // ===================================
        
        if (mainCommand === 'waifustatus' || subCommand === 'status') {
            const totalChildren = userData[user]?.children?.length || 0;
            const waifuLimitText = isUnlimited ? 'Unlimited' : `${MAX_WAIFU_GUEST} (Batasan User)`;

            let statusText = `*WAIFU SIMULATOR STATUS*\n\n`;
            statusText += `Suami: @${user.split('@')[0]}\n`;
            statusText += `Total Waifu: ${waifus.length} (Limit: ${waifuLimitText})\n`;
            statusText += `Total Anak: ${totalChildren}\n`;
            statusText += `--------------------------\n`;
            
            let firstWaifuImage = null;

            waifus.forEach((w, index) => {
                if (index === 0) firstWaifuImage = w.url;
                
                statusText += `💍 *Istri ke-${index + 1}: ${w.name}*\n`;
                statusText += `   - Kasih Sayang: ${w.affection} / 100\n`;
                statusText += `   - Stress Level: ${w.stress || 0} / 100 ${ (w.stress || 0) >= 80 ? '🔥⚠️' : ''}\n`; 
                statusText += `   - Anak Bersama: ${w.childrenCount}\n`;
                
                if (w.isPregnant) {
                    if (Date.now() > w.dueDate) {
                        statusText += `   - Kehamilan: *Siap Melahirkan!* (Gunakan *.waifu birth ${index + 1}*)\n`;
                    } else {
                        const remaining = w.dueDate - Date.now();
                        statusText += `   - Kehamilan: Hamil (Melahirkan dalam ${formatRemainingTime(remaining)})\n`;
                    }
                } else {
                    statusText += `   - Kehamilan: Tidak Hamil\n`;
                }
                
                if (w.marriageCertificateUrl) {
                     statusText += `   - Sertifikat: ✅ Tersimpan (Cek *.marriageid show ${index + 1}*)\n`;
                } else {
                    statusText += `   - Sertifikat: ❌ Belum dibuat (Akan dibuat saat menikah)\n`;
                }
                
                const lastInteraction = Math.max(
                    w.lastKiss || 0,
                    w.lastHug || 0,
                    w.lastPatpat || 0,
                    w.lastHeavyInteraction || 0,
                    w.lastNaughtyInteraction || 0,
                    w.lastDate || 0 
                );
                
                if (lastInteraction && (Date.now() - lastInteraction) > COOLDOWN_NEGLECT && w.affection > 5) {
                     statusText += `   ⚠️: Lupa interaksi! Kasih sayang bisa berkurang.\n`;
                }

                statusText += `--------------------------\n`;
            });
            
            if (totalChildren > 0) {
                 statusText += `👶 *DAFTAR ANAK (${totalChildren})*:\n`;
                 userData[user].children.forEach((c, index) => {
                     const happinessIcon = c.happiness >= 80 ? '😄' : c.happiness >= 50 ? '🙂' : '😔';
                     statusText += `   - ${index + 1}. *${c.name}* (${c.gender}, ${c.mother})\n`;
                     statusText += `     Kebahagiaan: ${c.happiness || 50}/100 ${happinessIcon}\n`;
                 });
                 statusText += `Gunakan *.renamechild [No/Nama] [Nama Baru]* atau *.child list*.\n`;
                 statusText += `--------------------------\n`;
            }

            if (waifus.length === 0) {
                statusText += `Anda belum menikah. Gunakan *.marry [Nama]* untuk memulai!`;
            }

            // Gunakan sendImageFallback
            await sendImageFallback(sock, remoteJid, msg, firstWaifuImage, statusText, [user]);
            return;
        }

        // ===================================
        // 9. DEFAULT HELP MESSAGE (.waifu)
        // ===================================
        
        if (mainCommand === 'waifu' && !subCommand) {
            let help = `*🎮 WAIFU SIMULATOR UPDATE (Double EXP)*\n\n`;
            help += `Gunakan perintah ini untuk berinteraksi dengan waifu Anda.\n\n`;
            help += `*NOTE*: Untuk memilih waifu, gunakan *Nomor Urut (1, 2, dst.)* atau *Nama* di belakang perintah. (Contoh: *.kiss 2* atau *.senggama Asuna*)\n\n`;
            
            help += `*I. Hubungan & Interaksi:*\n`;
            help += `*.marry [Nama]*: Menikahi waifu baru (Reply gambar). *Limit: ${MAX_WAIFU_GUEST} Waifu*.\n`;
            help += `*.date [No/Nama]*: Ajak kencan/jalan (CD ${COOLDOWN_DATE / 3600000} Jam, Affection ⬆️, Stress ⬇️).\n`;
            help += `*.cerai [No/Nama] ya*: Proses perceraian damai (butuh Affection > 60).\n`;
            help += `*.talak [No/Nama] ya*: Talak instan (Affection waifu lain ⬇️, Stress waifu lain ⬆️).\n\n`;
            
            help += `*III. Interaksi Ringan (CD 1 Jam, +5 Affection per aksi)*:\n`;
            help += `*.waifu kiss [No/Nama]* : Memberi ciuman.\n`;
            help += `*.waifu hug [No/Nama]* : Memberi pelukan (mengurangi Stress).\n`;
            help += `*.waifu patpat [No/Nama]* : Mengelus kepala/pundak (mengurangi Stress).\n`;
            help += `*.istrinakal [No/Nama]* : Colek manja (CD 1 Jam). Ada peluang me-reset CD senggama.\n\n`;
            
            help += `*III. Reproduksi & Anak:*\n`;
            help += `*.waifu senggama [No/Nama]*: Mencoba hamil (CD 3 Jam, +10 Affection).\n`;
            help += `*.waifu birth [No/Nama]*: Melahirkan anak (jika sudah waktunya).\n`;
            help += `*.renamechild [No/Nama] [Nama Baru]*: Ganti nama anak.\n`;
            help += `*.child [subcommand]*: Kelola interaksi dengan anak.\n\n`;

            help += `*IV. Status & Lain-lain:*\n`;
            help += `*.waifu status*: Cek status keluarga, Stress Level, dan limit waifu.\n`;
            help += `*.marriageid [subcommand]*: Kelola Kartu ID Pernikahan.\n`;
            
            await sock.sendMessage(remoteJid, { text: help }, { quoted: msg });
            return;
        }

    } catch (e) {
        console.error('[WAIFU HANDLER ERROR]', e);
        msg.reply(`❌ Terjadi error internal pada plugin Waifu.\n\nDetail: ${e.message}`);
    }
};

export default {
    command: ['waifu', 'marry', 'kiss', 'hug', 'patpat', 'senggama', 'birth', 'waifustatus', 'istrinakal', 'cerai', 'talak', 'date', 'renamechild'],
    description: 'Game simulasi menikahi waifu, punya anak, dan poligami.',
    category: 'rpg',
    handler,
};
