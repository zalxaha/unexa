export default {
    command: ['ramadhan', 'puasa', 'ramadan', 'countdownpuasa'],
    category: 'Info',
    description: 'Hitung mundur menuju bulan Ramadhan 1447 H (2026)',

    handler: async ({ sock, msg, reply }) => {
        // --- KONFIGURASI ---
        const targetDateStr = '2026-02-18T00:00:00+07:00'; 
        const sourceUrl = 'https://www.google.com/search?q=jadwal+ramadhan+2026'; 

        // Daftar Gambar Random
        const thumbnails = [
            'https://files.catbox.moe/h87vr4.jpg',
            'https://files.catbox.moe/wp4vtq.jpg',
            'https://files.catbox.moe/bgd2jh.jpg'
        ];
        // Pilih salah satu secara acak
        const randomThumb = thumbnails[Math.floor(Math.random() * thumbnails.length)];
        // -------------------

        await sock.sendMessage(msg.key.remoteJid, { react: { text: '⏳', key: msg.key } });

        const targetTime = new Date(targetDateStr).getTime();
        const now = Date.now();
        const difference = targetTime - now;

        if (difference <= 0) {
            const passedText = `
🕌 *MARHABAN YA RAMADHAN* 🕌

Alhamdulillah, bulan suci Ramadhan 1447 H telah tiba!
Selamat menunaikan ibadah puasa bagi yang menjalankan.
Semoga amal ibadah kita diterima Allah SWT. Aamiin.
`.trim();

            return sock.sendMessage(msg.key.remoteJid, {
                text: passedText,
                contextInfo: {
                    externalAdReply: {
                        title: "✨ Ramadhan Telah Tiba!",
                        body: "Selamat Menunaikan Ibadah Puasa",
                        thumbnailUrl: randomThumb, // Gambar Random
                        sourceUrl: sourceUrl,
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: msg });
        }

        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);

        const targetDateReadable = new Date(targetDateStr).toLocaleDateString('id-ID', { 
            weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: 'Asia/Jakarta' 
        });

        const countdownText = `
🕌 *COUNTDOWN RAMADHAN 1447 H* 🕌

Menuju 1 Ramadhan (${targetDateReadable}):

🗓️ *${days}* Hari
⏰ *${hours}* Jam
⏱️ *${minutes}* Menit
🕰️ *${seconds}* Detik

_Persiapkan diri menyambut bulan penuh berkah._
*(Tanggal bersifat tentatif menunggu sidang isbat)*
`.trim();

        await sock.sendMessage(msg.key.remoteJid, {
            text: countdownText,
            contextInfo: {
                externalAdReply: {
                    title: `⏳ Menuju Ramadhan: ${days} Hari Lagi`,
                    body: "Klik untuk info jadwal imsakiyah",
                    thumbnailUrl: randomThumb, // Gambar Random
                    sourceUrl: sourceUrl,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: msg });
    }
};