import { promises as fs } from 'fs'; 
import path from 'path';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { fileURLToPath } from 'url';
import { createRequire } from 'module'; 
import fetch from 'node-fetch';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url);

import log from '../lib/logger.js';

// Menggunakan require untuk JSON agar lebih stabil di semua versi Node
const cfg = require('../config/config.json');

const dbPath = path.join(__dirname, '../database/users.json');
const featuresPath = path.join(__dirname, '../database/features.json');
const pluginDir = path.join(__dirname, '../plugins');

let sockGlobal = null;
const groupAdminCache = {};
const CACHE_TTL = 30000;

let pluginsCache = {};
let disabledFeatures = {};
let usersDbCache = null;

// Cache untuk pemetaan cepat Alt JID -> Main JID (Optimasi Performa)
const altJidCache = new Map();

const CONFESSION_MAP = new Map();

async function initDatabase() {
    try {
        const fileContent = await fs.readFile(dbPath, 'utf8');
        usersDbCache = JSON.parse(fileContent);
        
        // Membangun cache Alt JID saat start agar tidak looping database setiap pesan
        rebuildAltJidCache();
    } catch (error) {
        usersDbCache = {};
        if (error.code === 'ENOENT') {
            await fs.writeFile(dbPath, JSON.stringify({}, null, 2));
        }
    }
}

// Fungsi helper untuk membangun cache index
function rebuildAltJidCache() {
    altJidCache.clear();
    if (!usersDbCache) return;
    for (const mainJid in usersDbCache) {
        const user = usersDbCache[mainJid];
        if (user.altJids && Array.isArray(user.altJids)) {
            for (const alt of user.altJids) {
                altJidCache.set(alt, mainJid);
            }
        }
    }
}

async function saveDatabase() {
    try {
        if (!usersDbCache) return;
        // Tulis atomik atau debounce jika trafik sangat tinggi, tapi ini standar aman
        await fs.writeFile(dbPath, JSON.stringify(usersDbCache, null, 2));
    } catch (e) {
        log.err(`Gagal menyimpan database: ${e.message}`);
    }
}

async function loadDisabledFeatures() {
    try {
        const data = await fs.readFile(featuresPath, 'utf8');
        disabledFeatures = JSON.parse(data);
    } catch {
        disabledFeatures = {};
        await fs.writeFile(featuresPath, JSON.stringify({}, null, 2));
    }
    log.info(`✅ ${Object.keys(disabledFeatures).length} fitur dinonaktifkan dimuat.`);
}

async function loadPlugins() {
    if (!usersDbCache) await initDatabase();

    log.info('🔄 Memuat ulang/memuat plugin...');
    const newPluginsCache = {};
    let pluginFiles;
    try {
        pluginFiles = (await fs.readdir(pluginDir)).filter(f => f.endsWith('.js'));
    } catch (e) {
        log.err("Gagal membaca folder plugins");
        return;
    }

    for (const file of pluginFiles) {
        const filePath = path.join(pluginDir, file);
        try {
            delete require.cache[filePath]; 
            
            // Tambah timestamp agar cache module benar-benar ter-refresh
            const pluginModule = await import(`../plugins/${file}?v=${Date.now()}`); 
            const plugin = pluginModule.default || pluginModule;

            if (!plugin || !plugin.command) continue;

            const commands = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
            const category = plugin.isOwner ? 'Owner' : plugin.category || 'Uncategorized';

            for (const cmd of commands) {
                newPluginsCache[cmd.toLowerCase()] = {
                    file,
                    handler: plugin.handler,
                    isOwner: !!plugin.isOwner,
                    isPremium: !!plugin.isPremium,
                    isDisabled: disabledFeatures[cmd.toLowerCase()] || false,
                    category: category
                };
            }
        } catch (e) {
            log.err(`❌ Plugin '${file}' error saat memuat: ${e.message}`);
        }
    }

    pluginsCache = newPluginsCache;
    log.info(`✅ ${Object.keys(pluginsCache).length} commands dimuat.`);
}

const parseQuoted = (m, sock) => {
    const q = m.message?.extendedTextMessage?.contextInfo;
    if (!q?.quotedMessage) return;
    const quoted = q.quotedMessage;
    const mtype = Object.keys(quoted)[0];
    const msg = quoted[mtype];
    m.quoted = {
        type: mtype,
        mtype,
        id: q.stanzaId,
        sender: q.participant,
        fromMe: q.participant === sock.user.id,
        isBaileys: !!q.isForwarded,
        text: msg?.text || msg?.caption || '',
        message: quoted,
        download: async () => {
            const stream = await downloadContentFromMessage(quoted[mtype], mtype.replace('Message', ''));
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            return buffer;
        }
    };
};

// Logika mapJid yang DIOPTIMALKAN (O(1) lookup)
function mapJid(incomingJid, ownerJid, ownerAltJids) {
    // 1. Cek Owner
    if (incomingJid === ownerJid || (ownerAltJids && ownerAltJids.includes(incomingJid))) {
        return ownerJid;
    }
    
    // 2. Cek Cache (Jauh lebih cepat daripada loop DB)
    if (altJidCache.has(incomingJid)) {
        return altJidCache.get(incomingJid);
    }

    // 3. Jika tidak ada pemetaan, kembalikan JID asli
    return incomingJid; 
}

async function sendDonationMessage(sock, jid, caption, url) {
    try {
        const imageResponse = await fetch(url);
        if (!imageResponse.ok) throw new Error(`Failed to fetch image: ${imageResponse.statusText}`);
        const imageBuffer = await imageResponse.buffer();
        
        await sock.sendMessage(jid, { 
            image: imageBuffer, 
            caption: caption 
        });
        return true;
    } catch (e) {
        log.err(`Gagal mengirim gambar donasi untuk ${jid}: ${e.message}. Mengirim pesan teks pengganti.`);
        await sock.sendMessage(jid, { 
            text: `🙏 *Bot Online Berkat Donasi Anda!* ${caption}` 
        });
        return false;
    }
}

function clockString(ms) {
    let h = isNaN(ms) ? "--" : Math.floor(ms / 3600000);
    let m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
    let s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
    return [h, m, s].map((v) => v.toString().padStart(2, 0)).join(":");
}

function timeSince(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days} hari`;
    if (hours > 0) return `${hours} jam`;
    if (minutes > 0) return `${minutes} menit`;
    if (seconds > 0) return `${seconds} detik`;
    return 'segera';
}

async function Msg(sock, m) {
    try {
        sockGlobal = sock;

        if (!m || !m.message) return;
        if (m.key.fromMe) return;
        
        const start_time = Date.now(); 
        const now = Date.now();
        const { key, message, pushName } = m;
        const remoteJid = key.remoteJid;
        const ownerConfigJid = cfg.owner + '@s.whatsapp.net';

        m.reply = async (text, opt = {}) => {
            return sock.sendMessage(remoteJid, { text, ...opt }, { quoted: m });
        };

        if (!usersDbCache) await initDatabase();

        const isGroup = remoteJid.endsWith('@g.us');
        let incomingJid = isGroup ? key.participant : remoteJid;
        m.isGroup = isGroup;

        // Handle JID LIDs
        if (isGroup && key.participantPn && /@lid$/.test(key.participant)) {
            incomingJid = key.participantPn;
        }

        const msgType = Object.keys(message || {})[0];
        let body = '';
        
        // Peningkatan deteksi body pesan
        if (msgType === 'conversation') body = message.conversation;
        else if (msgType === 'imageMessage') body = message.imageMessage.caption;
        else if (msgType === 'videoMessage') body = message.videoMessage.caption;
        else if (msgType === 'extendedTextMessage') body = message.extendedTextMessage.text;
        else if (msgType === 'buttonsResponseMessage') body = message.buttonsResponseMessage.selectedButtonId;
        else if (msgType === 'listResponseMessage') body = message.listResponseMessage.singleSelectReply.selectedRowId;
        else if (msgType === 'templateButtonReplyMessage') body = message.templateButtonReplyMessage.selectedId;
        else if (msgType === 'interactiveResponseMessage') {
            // Handle pesan interaktif (button baru)
            const interactive = message.interactiveResponseMessage;
            body = interactive.nativeFlowResponseMessage?.paramsJson 
                ? JSON.parse(interactive.nativeFlowResponseMessage.paramsJson).id 
                : (interactive.body?.text || "");
        }
        body = body || '';
        
        parseQuoted(m, sock);
        const quotedId = m.quoted?.id;
        
        let isDbChanged = false;
        
        // GUNAKAN CACHE (Optimasi)
        const finalSenderJid = mapJid(incomingJid, ownerConfigJid, cfg.ownerAltJids); 
        m.sender = finalSenderJid;
        
        let userDbEntry = usersDbCache[finalSenderJid];
        
        // Inisialisasi User Baru
        if (!userDbEntry) {
            userDbEntry = usersDbCache[finalSenderJid] = {
                nama: pushName || 'User',
                registered: false,
                lastReset: now,
                status: 'guest',
                premiumUntil: 0,
                altJids: [],
                lastDonationSent: 0,
                afk: -1, 
                afkReason: "",
                lastPremiumNotif: 0 
            };
            log.info(`➕ User baru dibuat di RAM: ${finalSenderJid}`);
            isDbChanged = true;
        } else {
            // Migrasi skema database jika properti baru ditambahkan
            if (!('afk' in userDbEntry)) { userDbEntry.afk = -1; isDbChanged = true; }
            if (!('afkReason' in userDbEntry)) { userDbEntry.afkReason = ""; isDbChanged = true; }
            if (!('lastPremiumNotif' in userDbEntry)) { userDbEntry.lastPremiumNotif = 0; isDbChanged = true; }
        }

        const originalIncomingJid = incomingJid;
        // Logika Alt JID (Backup)
        if (originalIncomingJid !== finalSenderJid) {
            if (!userDbEntry.altJids) userDbEntry.altJids = [];
            if (!userDbEntry.altJids.includes(originalIncomingJid)) {
                userDbEntry.altJids.push(originalIncomingJid);
                // Update Cache juga!
                altJidCache.set(originalIncomingJid, finalSenderJid);
                log.info(`🔗 JID alternatif baru ditambahkan: ${originalIncomingJid} -> ${finalSenderJid}`);
                isDbChanged = true;
            }
        }

        // --- CEK EXPIRED PREMIUM ---
        if (!userDbEntry.premiumUntil) userDbEntry.premiumUntil = 0;
        
        if (userDbEntry.premiumUntil > 0 && now > userDbEntry.premiumUntil) {
            userDbEntry.premiumUntil = 0;
            userDbEntry.status = userDbEntry.registered ? 'user' : 'guest';
            log.info(`⬇️ Premium ${finalSenderJid} habis.`);
            // Kirim notif habis premium ke PC
            await sock.sendMessage(finalSenderJid, { text: "⚠️ Masa aktif Premium Anda telah habis." });
            isDbChanged = true;
        }

        const isOwner = finalSenderJid === ownerConfigJid;
        const isPremium = isOwner || (userDbEntry.premiumUntil > 0 && now < userDbEntry.premiumUntil);

        if (isPremium && userDbEntry.status !== 'premium') {
            userDbEntry.status = 'premium';
            isDbChanged = true;
        }
        
        // --- NOTIFIKASI PREMIUM AKAN HABIS (PERBAIKAN) ---
        // Aturan: Hanya dikirim ke PC, Sehari sekali, Tidak spam di grup
        const TWO_DAYS_MS = 48 * 60 * 60 * 1000;
        const ONE_DAY_MS = 24 * 60 * 60 * 1000;

        if (userDbEntry.status === 'premium' && userDbEntry.premiumUntil > 0) {
            const timeRemaining = userDbEntry.premiumUntil - now;
            
            // Jika sisa waktu kurang dari 2 hari
            if (timeRemaining > 0 && timeRemaining <= TWO_DAYS_MS) {
                const lastNotification = userDbEntry.lastPremiumNotif || 0;
                
                // Cek apakah sudah 24 jam sejak notifikasi terakhir
                if (now - lastNotification > ONE_DAY_MS) {
                    const pesanPremium = `
🔔 *Notifikasi Premium*
Halo Kak ${pushName || 'User'}! 👋

Status Premium Anda akan habis dalam waktu:
⏳ *${timeSince(timeRemaining)}*

Silakan perpanjang segera untuk terus menikmati fitur Premium tanpa henti!
`.trim();

                    // KIRIM KE PRIVATE CHAT (Bukan m.reply)
                    try {
                        await sock.sendMessage(finalSenderJid, { text: pesanPremium });
                        userDbEntry.lastPremiumNotif = now; // Update waktu notifikasi
                        isDbChanged = true;
                        log.info(`🔔 Notif premium dikirim ke ${finalSenderJid}`);
                    } catch (e) {
                        log.err(`Gagal kirim notif premium ke ${finalSenderJid}`);
                    }
                }
            } else if (timeRemaining > TWO_DAYS_MS && userDbEntry.lastPremiumNotif !== 0) {
                 // Reset jika user memperpanjang durasi
                 userDbEntry.lastPremiumNotif = 0;
                 isDbChanged = true;
            }
        }
        
        if (isDbChanged) {
            await saveDatabase();
        }
        
        // --- AFK CHECK ---
        if (userDbEntry.afk > -1) {
            await m.reply(
                `
Kamu berhenti AFK${userDbEntry.afkReason ? " setelah " + userDbEntry.afkReason : ""}
Selama ${clockString(now - userDbEntry.afk)}
`.trim()
            );
            userDbEntry.afk = -1;
            userDbEntry.afkReason = "";
            await saveDatabase(); 
        }
        
        let jids = [
            ...new Set([
                ...(m.message?.extendedTextMessage?.contextInfo?.mentionedJid || []),
                ...(m.quoted ? [m.quoted.sender] : []),
            ]),
        ];

        for (let jid of jids) {
            // Gunakan mapJid untuk cek target AFK
            const targetJid = mapJid(jid, ownerConfigJid, cfg.ownerAltJids);
            let taggedUserEntry = usersDbCache[targetJid];
            
            if (!taggedUserEntry) continue;
            let afkTime = taggedUserEntry.afk;
            if (!afkTime || afkTime < 0) continue;
            let reason = taggedUserEntry.afkReason || "";
            
            await m.reply(
                `
Jangan tag dia!
Dia sedang AFK ${reason ? "dengan alasan " + reason : "tanpa alasan"}
Selama ${clockString(now - afkTime)}
`.trim()
            );
        }
        
        // --- MENFESS REPLY ---
        if (quotedId && CONFESSION_MAP.has(quotedId)) {
            const originalSenderJid = CONFESSION_MAP.get(quotedId);
            try {
                await sock.sendMessage(originalSenderJid, { text: `💬 *Balasan Menfess*\nDari: @${remoteJid.split('@')[0]}`, mentions: [remoteJid] });
                const currentMsgType = Object.keys(m.message || {})[0];
                if (currentMsgType) {
                    const payload = {};
                    payload[currentMsgType] = m.message[currentMsgType];
                    await sock.relayMessage(originalSenderJid, payload, { messageId: m.key.id });
                }
                return;
            } catch (e) { log.err('Confession fail'); }
        }
        
        const isCommand = body.startsWith(cfg.prefix);
        if (!isCommand) return; 

        // --- DONATION MESSAGE (Harian) ---
        if (!isGroup && !quotedId) { 
            const timeSinceLastDonation = now - (userDbEntry.lastDonationSent || 0);

            if (timeSinceLastDonation >= ONE_DAY_MS) { 
                 const DONATION_URL = 'https://cdn.jsdelivr.net/gh/rhamt24/zalxzhu.github.io/images/1764680372103.png';
                 const DONATION_CAPTION = 
                    "Halo! 😊 Terima kasih telah menggunakan bot ini.\n\n" +
                    "Untuk membantu kelangsungan biaya server dan pengembangan fitur-fitur baru agar bot tetap online dan bermanfaat, kami menerima donasi seikhlasnya.\n\n" +
                    "Donasi Anda sangat berarti! 🙏\n\n" +
                    "(Pesan ini hanya muncul sekali dalam 24 jam di chat pribadi.)";

                 // Kirim donasi secara async agar tidak blocking command
                 sendDonationMessage(sock, finalSenderJid, DONATION_CAPTION, DONATION_URL)
                    .then(sent => {
                        if (sent) {
                            userDbEntry.lastDonationSent = now;
                            saveDatabase();
                        }
                    });
            }
        }
        
        const rawBody = body.slice(cfg.prefix.length).trim();
        
        if (body === cfg.prefix) {
            const end_time = Date.now();
            const response_time = end_time - start_time;
            return m.reply(`✅ Bot sedang *online*! Respon dalam *${response_time}* ms`);
        }
        
        const args = rawBody.split(/ +/);
        const cmd = args.shift()?.toLowerCase();
        if (!cmd) return; 

        // --- OWNER COMMANDS (Reload & Disable) ---
        if (isOwner) {
            if (cmd === 'reload') {
                m.reply('🔄 Reloading system...');
                await loadDisabledFeatures();
                await loadPlugins();
                // Rebuild cache setelah reload
                rebuildAltJidCache();
                m.reply('✅ System reloaded successfully!');
                return;
            } else if (cmd === 'disable' || cmd === 'enable') {
                const targetCmd = args[0]?.toLowerCase();
                if (!targetCmd) return m.reply(`❌ Gunakan: ${cfg.prefix}${cmd} <command>`);
                
                const status = cmd === 'disable';
                disabledFeatures[targetCmd] = status;
                
                await fs.writeFile(featuresPath, JSON.stringify(disabledFeatures, null, 2));

                if (pluginsCache[targetCmd]) {
                    pluginsCache[targetCmd].isDisabled = status;
                }
                
                m.reply(`✅ Command *${targetCmd}* berhasil di${status ? 'nonaktifkan' : 'aktifkan'}.`);
                return;
            }
        }
        
        const pluginEntry = pluginsCache[cmd];
        if (!pluginEntry) return;

        // --- GROUP ADMIN CHECKING ---
        const participantJidForGroupCheck = key.participant || remoteJid;
        let isAdmin = isOwner;

        if (isGroup && !isOwner) {
            const cacheKey = remoteJid;
            // Gunakan cache admin jika valid
            if (groupAdminCache[cacheKey] && now < groupAdminCache[cacheKey].expiry) {
                const participant = groupAdminCache[cacheKey].participants.find(p => p.id === participantJidForGroupCheck);
                isAdmin = !!(participant?.admin === 'admin' || participant?.admin === 'superadmin');
            } else {
                try {
                    // Fetch metadata
                    const groupMetadata = await sock.groupMetadata(remoteJid);
                    groupAdminCache[cacheKey] = {
                        participants: groupMetadata.participants,
                        expiry: now + CACHE_TTL
                    };
                    const participant = groupMetadata.participants.find(p => p.id === participantJidForGroupCheck);
                    isAdmin = !!(participant?.admin === 'admin' || participant?.admin === 'superadmin');
                } catch (e) { 
                    // Fallback jika gagal fetch metadata (misal network error), anggap bukan admin tapi biarkan command jalan (kecuali butuh admin)
                    log.err(`Gagal fetch group metadata: ${e.message}`);
                    isAdmin = false; 
                }
            }
        }

        if (pluginEntry.isDisabled) return m.reply('🚫 Fitur ini sedang dinonaktifkan.');
        if (pluginEntry.isOwner && !isOwner) return m.reply('🚫 Fitur ini khusus Owner.');
        if (pluginEntry.isPremium && !isPremium) return m.reply('🚫 Fitur ini khusus Premium.');

        // --- EKSEKUSI PLUGIN ---
        try {
            log.evt(`Cmd '${cmd}' dari ${pushName || m.sender} di ${isGroup ? 'Grup' : 'PC'}`);
            await pluginEntry.handler({
                sock,
                msg: m,
                args,
                command: cmd,
                from: remoteJid,
                pushName,
                isOwner,
                isPremium,
                isUserRegistered: !!userDbEntry.registered,
                db: usersDbCache,
                saveDatabase: saveDatabase, 
                sender: m.sender,
                isGroup,
                isAdmin
            });
        } catch (e) {
            log.err(`❌ Plugin '${pluginEntry.file}' error: ${e.message}`);
            // Kirim pesan error ke user agar mereka tahu command gagal
            m.reply('❌ Terjadi *Error* saat menjalankan fitur ini.');
        }

    } catch (e) {
        log.err(`❌ Msg() fatal error: ${e.stack || e.message}`);
    }
}

export { loadPlugins, loadDisabledFeatures, pluginsCache, CONFESSION_MAP };
export default Msg;
