import fs from 'fs';
import path from 'path';
import { tmpdir } from 'os';
import Crypto from 'crypto';
import sharp from 'sharp';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';

function generateFileName(ext = '') {
  return path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}${ext}`);
}

async function getStickerBuffer(stickerMessage) {
  const stream = await downloadContentFromMessage(stickerMessage, 'image');
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

// ---------------------- toimg (Statis ke PNG) ----------------------
async function toimg(sock, msg, from, stickerMessage) {
  const tmpIn = generateFileName('.webp');
  const tmpOut = generateFileName('.png'); 
  let success = false;

  try {
    const mediaBuffer = await getStickerBuffer(stickerMessage);
    fs.writeFileSync(tmpIn, mediaBuffer);

    await sharp(tmpIn)
      .toFormat('png')
      .toFile(tmpOut);

    const finalBuffer = fs.readFileSync(tmpOut);
    await sock.sendMessage(from, {
      image: finalBuffer,
      caption: '✅ Stiker diubah ke gambar (PNG).'
    }, { quoted: msg });
    success = true;
  } catch (err) {
    console.error('[TOIMG ERROR]', err);
    await sock.sendMessage(from, { text: '❌ Gagal mengubah stiker ke gambar.' }, { quoted: msg });
  } finally {
    if (fs.existsSync(tmpIn)) fs.unlinkSync(tmpIn);
    if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut);
  }
  return success;
}

// ---------------------- handler utama ----------------------
const handler = async ({ sock, msg, from }) => {
  const body =
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    '';
  const cmd = body.trim().split(/\s+/)[0].toLowerCase().replace(/^\.|^\//, ''); 

  const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  const stickerMessage = quoted?.stickerMessage;
  let conversionSuccess = false;

  // Cek apakah ada stiker yang direply
  if (!stickerMessage) {
    if (cmd === 'toimg') {
      return sock.sendMessage(from, { text: '❌ Reply stiker yang ingin diubah.' }, { quoted: msg });
    }
    return;
  }
  
  // Hanya proses perintah 'toimg'
  if (cmd !== 'toimg') {
    return sock.sendMessage(from, { text: '❌ Perintah tidak dikenal.' }, { quoted: msg });
  }

  await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

  try {
    conversionSuccess = await toimg(sock, msg, from, stickerMessage);

    if (conversionSuccess) {
      await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });
    } else {
      await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    }
  } catch (err) {
    console.error('[HANDLER ERROR]', err);
    await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
    await sock.sendMessage(from, { text: '❌ Terjadi kesalahan saat mengonversi stiker.' }, { quoted: msg });
  }
};

// ---------------------- export default ----------------------
export default {
  command: ['toimg'],
  description: 'Ubah stiker menjadi gambar PNG.',
  category: 'Media',
  handler,
};