import { remindersDb, saveReminders } from '../lib/database.js';

const monthMap = {
    'januari': 0, 'jan': 0, 'februari': 1, 'feb': 1, 'maret': 2, 'mar': 2,
    'april': 3, 'apr': 3, 'mei': 4, 'juni': 5, 'jun': 5, 'juli': 6, 'jul': 6,
    'agustus': 7, 'agu': 7, 'aug': 7, 'september': 8, 'sep': 8, 'oktober': 9, 'okt': 9,
    'november': 10, 'nov': 10, 'desember': 11, 'des': 11
};

export default {
    command: ['reminder', 'ingatkan', 'remind'],
    category: 'User',
    description: 'Setel pengingat (Support Grup & Recurring)',
    isGroup: true, 

    handler: async ({ sock, msg, args, sender, reply, isPremium, isOwner }) => {
        const text = args.join(' ');
        const subCmd = args[0]?.toLowerCase();

        // targetJid = Lokasi Chat (Grup ID atau PC ID)
        const targetJid = msg.key.remoteJid; 

        // --- FITUR 1: LIST REMINDER ---
        if (subCmd === 'list') {
            const userReminders = remindersDb.filter(r => r.jid === targetJid && r.userJid === sender);
            
            if (userReminders.length === 0) return reply('📭 Kamu tidak punya reminder aktif di chat ini.');
            
            let listTxt = `📋 *DAFTAR REMINDER KAMU*\n_(Di Chat Ini)_\n\n`;
            userReminders.forEach((r, i) => {
                const date = new Date(r.time).toLocaleDateString('id-ID', { 
                    timeZone: 'Asia/Jakarta', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' 
                });
                const typeIcon = r.type === 'recurring' ? '🔁' : '📅';
                listTxt += `${i + 1}. [${r.id}] ${typeIcon} *${date}*\n   "${r.message}"\n`;
            });
            
            listTxt += `\n❌ *Hapus:* .reminder delete [ID]`;
            return reply(listTxt);
        }

        // --- FITUR 2: DELETE REMINDER ---
        if (subCmd === 'delete' || subCmd === 'del' || subCmd === 'hapus') {
            const idToDelete = args[1];
            if (!idToDelete) return reply('❌ Masukkan ID reminder. Cek dengan *.reminder list*');

            const index = remindersDb.findIndex(r => r.id === idToDelete && r.jid === targetJid && r.userJid === sender);
            
            if (index === -1) return reply('❌ ID tidak ditemukan atau bukan milikmu.');

            remindersDb.splice(index, 1);
            await saveReminders();
            return reply(`✅ Reminder ID *${idToDelete}* berhasil dihapus.`);
        }

        // --- FITUR 3: BUAT REMINDER BARU ---
        
        if (!text) {
            return reply(`
⏰ *PANDUAN REMINDER BOT*

*1. Untuk Hari Ini:*
> .reminder hari ini jam 14.00 makan siang
> .reminder hari ini pukul 17.00 pulang kerja

*2. Untuk Besok/Lusa:*
> .reminder besok jam 10.00 meeting
> .reminder 25 Januari pukul 08.00 bayar kos

*3. Reminder Berulang (Premium):*
> .reminder *setiap hari* jam 05.00 bangun pagi

*4. Manajemen:*
> .reminder list _(Lihat daftar)_
> .reminder delete [ID] _(Hapus)_

_(Jika dibuat di Grup, bot akan men-tag kamu saat reminder bunyi)_
            `.trim());
        }

        // Cek Recurring
        const isRecurring = text.toLowerCase().includes('setiap hari') || text.toLowerCase().includes('tiap hari');
        if (isRecurring && !isPremium && !isOwner) {
            return reply('🔒 Fitur reminder *Setiap Hari* khusus untuk User Premium & Owner.');
        }

        // --- LOGIKA WAKTU ---
        const now = new Date();
        const jakartaString = now.toLocaleString("en-US", { timeZone: "Asia/Jakarta" });
        const todayWIB = new Date(jakartaString);

        let targetYear = todayWIB.getFullYear();
        let targetMonth = todayWIB.getMonth();
        let targetDay = todayWIB.getDate();
        
        const lowerText = text.toLowerCase();
        let messageReminder = '';
        
        const timeMatch = lowerText.match(/(?:pukul|jam)\s+(\d{1,2})[:.](\d{1,2})\s*(wib|wita|wit)?/);
        if (!timeMatch) return reply('❌ Format jam salah. Contoh: *jam 10.00*');

        const [fullMatch, hStr, mStr, zone] = timeMatch;
        let hours = parseInt(hStr);
        let minutes = parseInt(mStr);
        
        if (zone === 'wita') hours -= 1; 
        if (zone === 'wit') hours -= 2;

        const splitText = text.split(fullMatch);
        let rawMsg = splitText[1] ? splitText[1].trim() : "Reminder";
        messageReminder = rawMsg.replace(/setiap hari|tiap hari/gi, '').trim();
        if (!messageReminder) messageReminder = "Reminder";

        // Logic Tanggal
        if (lowerText.includes('besok')) {
            targetDay += 1;
        } else {
            const dateMatch = lowerText.match(/(\d{1,2})\s+([a-z]+)/);
            if (dateMatch && !lowerText.includes('hari ini')) {
                const dayInput = parseInt(dateMatch[1]);
                const monthName = dateMatch[2];
                if (monthMap[monthName] !== undefined) {
                    targetDay = dayInput;
                    targetMonth = monthMap[monthName];
                    if (targetMonth < todayWIB.getMonth() || (targetMonth === todayWIB.getMonth() && targetDay < todayWIB.getDate())) {
                        targetYear += 1;
                    }
                }
            }
        }

        const pad = (n) => n.toString().padStart(2, '0');
        const dummyDate = new Date(targetYear, targetMonth, targetDay, hours, minutes);
        const isoTarget = `${dummyDate.getFullYear()}-${pad(dummyDate.getMonth() + 1)}-${pad(dummyDate.getDate())}T${pad(dummyDate.getHours())}:${pad(dummyDate.getMinutes())}:00+07:00`;
        const targetTimestamp = new Date(isoTarget).getTime();

        if (isNaN(targetTimestamp)) return reply('❌ Gagal memproses waktu.');

        const currentTimestamp = Date.now();
        let finalTime = targetTimestamp;
        let autoAdjusted = false;

        if (finalTime <= currentTimestamp) {
            if (isRecurring) {
                finalTime += (24 * 60 * 60 * 1000);
            } 
            else if (!lowerText.includes('besok') && !lowerText.includes('hari ini') && !lowerText.match(/(\d{1,2})\s+([a-z]+)/)) {
                finalTime += (24 * 60 * 60 * 1000);
                autoAdjusted = true;
            } else {
                return reply('❌ Waktu yang kamu masukkan sudah lewat.');
            }
        }

        // =================================================================
        // --- CEK DUPLIKAT (BAGIAN BARU) ---
        // =================================================================
        // Kita cek apakah ada reminder dengan:
        // 1. User yang sama (userJid)
        // 2. Chat yang sama (jid)
        // 3. Pesan yang sama (ignore case)
        // 4. Waktu yang SAMA PERSIS (selisih < 1 menit)
        const isDuplicate = remindersDb.some(r => 
            r.userJid === sender && 
            r.jid === targetJid && 
            r.message.toLowerCase() === messageReminder.toLowerCase() &&
            r.type === (isRecurring ? 'recurring' : 'once') &&
            Math.abs(r.time - finalTime) < 60000 // Toleransi beda 1 menit dianggap sama
        );

        if (isDuplicate) {
            return reply(`⚠️ *GAGAL MENYIMPAN*\n\nReminder dengan pesan *"${messageReminder}"* pada jam yang sama sudah ada di daftar kamu! Tidak bisa double.`);
        }
        // =================================================================

        // --- SIMPAN DATA ---
        const uniqueId = Math.random().toString(36).substring(2, 6);

        const newReminder = {
            id: uniqueId,
            jid: targetJid, 
            userJid: sender, 
            time: finalTime,
            message: messageReminder,
            type: isRecurring ? 'recurring' : 'once',
            setAt: new Date().toLocaleDateString('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit' })
        };

        remindersDb.push(newReminder);
        await saveReminders();

        const dateString = new Date(finalTime).toLocaleDateString('id-ID', { timeZone: 'Asia/Jakarta', weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' });
        
        let successMsg = `✅ *Reminder Disimpan!*\n\n`;
        successMsg += `🎯 *Target:* ${msg.key.remoteJid.endsWith('@g.us') ? 'Grup Ini' : 'Private Chat'}\n`;
        successMsg += `📅 *Waktu:* ${dateString} WIB\n`;
        successMsg += `📝 *Pesan:* ${messageReminder}\n`;
        successMsg += `🔁 *Tipe:* ${isRecurring ? 'Setiap Hari (Recurring)' : 'Sekali'}\n`;
        successMsg += `🔑 *ID:* ${uniqueId}`;

        if (autoAdjusted) successMsg += `\n\n_⚠️ Waktu hari ini lewat, otomatis diatur besok._`;

        return reply(successMsg);
    }
};
