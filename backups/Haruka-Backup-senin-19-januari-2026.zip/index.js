import 'dotenv/config';
import makeWASocket, {
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    getContentType,
    jidNormalizedUser
} from '@whiskeysockets/baileys';

import qr from 'qrcode-terminal';
import pino from 'pino';
import path from 'path';
import fs from 'fs/promises';
import * as fsSync from 'fs';
import { fileURLToPath } from 'url';
import { parsePhoneNumber } from 'libphonenumber-js';
import chalk from 'chalk';
import NodeCache from 'node-cache';

// Import Logger
import log from './lib/logger.js';

// --- GLOBAL VARIABLES ---
let MsgHandler;
let loadPlugins;
let config = {};

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Cache Metadata Grup (1 Jam) & Retry
const groupMetadataCache = new NodeCache({ stdTTL: 60 * 60, checkperiod: 60 });
const msgRetryCounterCache = new NodeCache();

// --- INITIALIZATION ---
async function initHandler() {
    try {
        const configPath = path.join(__dirname, 'config/config.json');
        const configFileContent = await fs.readFile(configPath, 'utf8');
        config = JSON.parse(configFileContent);
        
        const MsgModule = await import(`./handler.js?v=${Date.now()}`); 
        
        if (MsgModule.loadPlugins) {
             const ownerJid = jidNormalizedUser(config.owner + '@s.whatsapp.net');
             await MsgModule.loadPlugins(null, ownerJid);
        }

        MsgHandler = MsgModule.default;
        loadPlugins = MsgModule.loadPlugins;

        console.log(chalk.green('✅ Handler & Plugins loaded.'));
    } catch (e) {
        console.error(chalk.red('⚠️ Fatal Error Loading Handler:'), e);
    }
}

await initHandler();

let CallHandler;
try {
    const CallModule = await import('./lib/call.js');
    CallHandler = CallModule.default;
} catch { 
    log.warn('⚠️ lib/call.js tidak ditemukan, fitur tolak telepon dimatikan.'); 
}

const sessionFolder = path.join(__dirname, 'session');

async function validatePhoneNumber(input) {
    if (!input) return null;
    try {
        let phone = String(input).replace(/[^0-9]/g, "");
        if (!phone.startsWith('+')) phone = '+' + phone;
        const pn = parsePhoneNumber(phone);
        return pn?.isValid() ? pn.number.replace('+', '') : null;
    } catch { return null; }
}

async function Start() {
    try { await fs.access(sessionFolder); } catch { await fs.mkdir(sessionFolder, { recursive: true }); }

    const { state, saveCreds } = await useMultiFileAuthState(sessionFolder);
    const { version } = await fetchLatestBaileysVersion();

    log.info(`Baileys v${version.join('.')}`);
    config.version = version.join('.');
    const usePairing = config.system?.pairing === true;

    const sock = makeWASocket({
        version,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" })),
        },
        logger: pino({ level: "silent" }),
        printQRInTerminal: !usePairing,
        syncFullHistory: false, 
        generateHighQualityLinkPreview: true,
        markOnlineOnConnect: true,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        connectTimeoutMs: 60000,
        retryRequestDelayMs: 2000,
        msgRetryCounterCache,
        getMessage: async (key) => { return undefined; }
    });

    sock.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            const decode = jidNormalizedUser(jid);
            return decode;
        }
        return jid;
    };

    // --- DECODE LID DENGAN TIMEOUT (FIX DELAY) ---
    // Jika decode LID memakan waktu > 2 detik, kembalikan JID asli saja
    sock.decodeLid = async (lid) => {
        if (!lid || !lid.endsWith('@lid')) return sock.decodeJid(lid);
        
        try {
            // Promise Race: Mana yang duluan, Decode atau Timeout 2 Detik
            const decodePromise = async () => {
                const key = sock.signalRepository?.lidMapping;
                if (key) {
                    const mapping = await key.getPNForLID(lid);
                    if (mapping) return sock.decodeJid(mapping);
                }
                return sock.decodeJid(lid);
            };

            const timeoutPromise = new Promise((resolve) => 
                setTimeout(() => resolve(sock.decodeJid(lid)), 2000)
            );

            return await Promise.race([decodePromise(), timeoutPromise]);
        } catch (e) {
            return sock.decodeJid(lid);
        }
    };

    if (usePairing && !sock.authState.creds.registered) {
        setTimeout(async () => {
            const number = await validatePhoneNumber(config.system.number);
            if (!number) return log.err("Nomor pairing invalid di config.json");
            try {
                let code = await sock.requestPairingCode(number);
                code = code?.match(/.{1,4}/g)?.join('-') || code;
                console.log(chalk.bgGreen.black(`\n📞 KODE PAIRING: `) + " " + chalk.white.bold(code));
            } catch (err) { log.err("Gagal request pairing: " + err.message); }
        }, 3000);
    }

    sock.ev.on("connection.update", async ({ connection, lastDisconnect, qr: code }) => {
        if (code && !usePairing && !sock.authState.creds.registered) qr.generate(code, { small: true });
        if (connection === "open") {
            log.ok("Bot Connected & Ready!");
            try {
                const ownerJid = await sock.decodeLid(config.owner + "@s.whatsapp.net");
                await sock.sendMessage(ownerJid, { text: `✅ *Bot Online!*\nVersion: ${config.version}` });
            } catch {}
        }
        if (connection === "close") {
            const code = lastDisconnect?.error?.output?.statusCode;
            if (code === DisconnectReason.loggedOut) {
                log.err("Session Logout.");
                await fs.rm(sessionFolder, { recursive: true, force: true });
                process.exit(1);
            } else {
                log.warn("Reconnecting...");
                Start();
            }
        }
    });

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on('groups.update', async (updates) => {
        for (const update of updates) {
            if (update.subject) groupMetadataCache.set(update.id, { subject: update.subject });
        }
    });

    // ============================================================
    // --- MESSAGE HANDLER UTAMA (OPTIMIZED) ---
    // ============================================================
    sock.ev.on("messages.upsert", async ({ messages, type }) => {
        if (type !== 'notify') return;

        // Gunakan Promise.all agar pesan diproses paralel, bukan antrian panjang
        // (Tapi hati-hati, urutan bisa sedikit acak jika sangat cepat, namun performa jauh lebih baik)
        await Promise.all(messages.map(async (msg) => {
            try {
                // 1. Basic Filters
                if (!msg.message) return;
                if (msg.key.fromMe) return;
                if (msg.key.remoteJid === "status@broadcast") return;

                // 2. Unwrap Message Content
                let mContent = msg.message;
                if (mContent.ephemeralMessage) mContent = mContent.ephemeralMessage.message;
                if (mContent.viewOnceMessageV2) mContent = mContent.viewOnceMessageV2.message;
                else if (mContent.viewOnceMessage) mContent = mContent.viewOnceMessage.message;
                msg.message = mContent;

                // 3. Content Type Check
                const msgType = getContentType(mContent);
                const ignoreTypes = ['protocolMessage', 'senderKeyDistributionMessage', 'messageContextInfo', 'reactionMessage', 'pollUpdateMessage', 'keepInChatMessage'];
                if (!msgType || ignoreTypes.includes(msgType)) return;

                // 4. Raw Info (Untuk Logging Cepat)
                const from = msg.key.remoteJid;
                const isGroup = from.endsWith('@g.us');
                let senderRaw = isGroup ? (msg.key.participant || from) : from;
                const pushName = msg.pushName || "Unknown";
                
                // 5. LOGGING SEGERA (Agar terlihat di console walau proses selanjutnya macet)
                let body = '';
                if (msgType === 'conversation') body = mContent.conversation;
                else if (msgType === 'imageMessage') body = mContent.imageMessage.caption;
                else if (msgType === 'videoMessage') body = mContent.videoMessage.caption;
                else if (msgType === 'extendedTextMessage') body = mContent.extendedTextMessage.text;
                if (typeof body !== 'string') body = '';

                // Cetak Log sebelum Decode LID (biar ga kerasa delay)
                const timeStr = chalk.bgBlack.white(`⏰ ${new Date().toLocaleTimeString()}`);
                const ctxStr = isGroup ? chalk.magenta(`[Group]`) : chalk.blue(`[Private]`);
                // Gunakan senderRaw dulu untuk log agar cepat
                console.log(`${timeStr} ${chalk.cyan(`[${msgType}]`)} ${ctxStr} ${chalk.green(pushName)} : ${chalk.white(body.substring(0, 50).replace(/\n/g, ' ') || '<Media>')}`);

                // 6. Timestamp Filter (Setelah log, biar tau kalo di-skip)
                if (msg.messageTimestamp && (Date.now() - (msg.messageTimestamp * 1000)) > 300000) {
                    console.log(chalk.yellow(`⚠️ Pesan diabaikan: Timestamp terlalu lama (${new Date(msg.messageTimestamp * 1000).toLocaleTimeString()})`));
                    return; 
                }

                // 7. Decode Sender (Safe Mode)
                let sender = senderRaw;
                try {
                    // Ini sekarang punya timeout 2 detik (cek fungsi sock.decodeLid di atas)
                    sender = await sock.decodeLid(senderRaw);
                } catch (e) {
                    sender = senderRaw; // Fallback
                }
                msg.sender = sender; 

                // 8. Execute Handler
                if (MsgHandler) {
                    // Jangan pakai await di sini agar proses upsert tidak memblokir pesan berikutnya
                    MsgHandler(sock, msg).catch(e => {
                        console.error(chalk.red(`❌ Handler Error:`), e);
                    });
                }

            } catch (e) {
                console.error("Error processing msg:", e);
            }
        }));
    });

    sock.ev.on("call", async (calls) => {
        if (CallHandler) {
            try { await CallHandler.code(sock, calls); } catch {}
        }
    });

    fsSync.watch(path.join(__dirname, "plugins"), async (evt, filename) => {
        if (filename && filename.endsWith(".js")) {
            try {
                console.log(chalk.yellow(`🔄 Reloading Plugins due to change in: ${filename}`));
                const ts = Date.now();
                const reload = await import(`./handler.js?v=${ts}`); 
                
                if (reload.loadPlugins) {
                    const ownerJid = jidNormalizedUser(config.owner + '@s.whatsapp.net');
                    await reload.loadPlugins(sock, ownerJid);
                }

                MsgHandler = reload.default;
                log.ok(`✅ Plugin & Handler Reloaded.`);
            } catch (e) {
                log.err(`Gagal Reload: ${e.message}`);
            }
        }
    });
}

process.on("unhandledRejection", (err) => {});
process.on("uncaughtException", (err) => {});

Start();
