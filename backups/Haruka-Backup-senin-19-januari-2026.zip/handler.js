import { jidNormalizedUser, getContentType } from '@whiskeysockets/baileys';
import { createRequire } from 'module';
import path from 'path';
import { fileURLToPath } from 'url';

// --- LIBRARY IMPORTS ---
import log from './lib/logger.js';
import * as db from './lib/database.js';
import * as utils from './lib/utils.js';
import * as sys from './lib/system.js';
import * as sim from './lib/similarity.js';
import { loadPlugins, pluginsCache } from './lib/plugins.js';
import { sender } from './lib/sender.js';

const require = createRequire(import.meta.url);
const cfg = require('./config/config.json');

// --- GLOBAL CACHES ---
export const CONFESSION_MAP = new Map();
const altJidCache = new Map();
let sockGlobal = null;

// --- KONFIGURASI ROLE / TITLE ---
const ROLES = [
    { level: 0, name: 'Kroco Parah' },
    { level: 5, name: 'Kroco Naik Level' },
    { level: 10, name: 'Anak Baru' },
    { level: 20, name: 'Anak Rumahan' },
    { level: 30, name: 'Anak Tongkrongan' },
    { level: 50, name: 'Jago Kandang' },
    { level: 75, name: 'Suhu' },
    { level: 100, name: 'Akamsi' },
    { level: 150, name: 'pejabat' },
    { level: 200, name: 'Sepuh' }
];

// Helper: Get Role based on Level
const getRole = (level) => {
    let role = 'Warga Baru';
    for (const r of ROLES) {
        if (level >= r.level) role = r.name;
    }
    return role;
};

// --- INITIALIZATION ---
await db.initDatabase();
rebuildAltJidCache();

function rebuildAltJidCache() {
    altJidCache.clear();
    for (const mainJid in db.usersDb) {
        const user = db.usersDb[mainJid];
        if (user.altJids && Array.isArray(user.altJids)) {
            user.altJids.forEach(alt => altJidCache.set(alt, mainJid));
        }
    }
}

// Load Plugins
const ownerJidConfig = jidNormalizedUser(cfg.owner + '@s.whatsapp.net');
await loadPlugins(null, ownerJidConfig);

// =================================================================
// --- MAIN MESSAGE HANDLER ---
// =================================================================
const Msg = async (sock, m) => {
    try {
        if (!sockGlobal) {
            sockGlobal = sock;
            // Menjalankan Checker Otomatis (Sewa & Reminder)
            sys.startRentalChecker(sock); 
            sys.startReminderChecker(sock); 
        }
        
        if (!m || !m.message) return;
        if (m.key.fromMe) return;

        const now = Date.now();
        const { key, message, pushName } = m;
        const remoteJid = key.remoteJid;
        const isGroup = remoteJid.endsWith('@g.us');

        // --- 1. SENDER FUNCTIONS ---
        const sendFuncs = sender(sock, remoteJid, m);
        m.reply = sendFuncs.reply;
        m.sendImage = sendFuncs.sendImage;
        m.sendVideo = sendFuncs.sendVideo;
        m.sendAudio = sendFuncs.sendAudio;
        m.sendSticker = sendFuncs.sendSticker;
        m.sendReact = sendFuncs.sendReact;
        m.sendDocument = sendFuncs.sendDocument;
        m.sendContact = sendFuncs.sendContact;
        m.sendLocation = sendFuncs.sendLocation;

        // --- 2. JID NORMALIZATION ---
        let incomingJid = isGroup ? (key.participant || m.participant) : remoteJid;
        if (isGroup && key.participantPn && /@lid$/.test(key.participant)) {
            incomingJid = key.participantPn;
        } else if (isGroup && incomingJid && incomingJid.endsWith('@lid')) {
             incomingJid = key.participant || incomingJid;
        }

        const normalizedSender = jidNormalizedUser(incomingJid);
        const finalSenderJid = utils.mapJid(incomingJid, ownerJidConfig, cfg.ownerAltJids, altJidCache);
        m.sender = finalSenderJid;

        // --- 3. PARSE BODY ---
        const msgType = getContentType(message);
        let body = '';
        if (msgType === 'conversation') body = message.conversation;
        else if (msgType === 'imageMessage') body = message.imageMessage.caption;
        else if (msgType === 'videoMessage') body = message.videoMessage.caption;
        else if (msgType === 'extendedTextMessage') body = message.extendedTextMessage.text;
        else if (msgType === 'interactiveResponseMessage') {
            try { body = JSON.parse(message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id; } catch { body = ""; }
        } else if (msgType === 'templateButtonReplyMessage') body = message.templateButtonReplyMessage.selectedId;
        else if (msgType === 'buttonsResponseMessage') body = message.buttonsResponseMessage.selectedButtonId;
        
        body = body || '';
        await utils.parseQuoted(m, sock);

        // --- 4. FAST RESPONSE ---
        // Cek jika body SAMA PERSIS dengan salah satu prefix
        const configPrefixes = Array.isArray(cfg.prefix) ? cfg.prefix : [cfg.prefix];
        if (configPrefixes.includes(body)) return m.reply(`🤖 Bot *Online*!`);

        // --- 5. USER DATABASE & LEVELING ---
        let isDbChanged = false;
        
        // Buat data user jika belum ada
        if (!db.usersDb[finalSenderJid]) {
            db.usersDb[finalSenderJid] = {
                nama: pushName || 'User',
                limit: db.globalSettings.privateLimit,
                lastLimitDate: '', 
                premiumUntil: 0,
                status: 'guest',
                afk: -1,
                lastDonationSent: 0,
                xp: 0,
                level: 0,
                role: 'Warga Baru'
            };
            isDbChanged = true;
        }
        let user = db.usersDb[finalSenderJid];

        // Inisialisasi field baru jika user lama belum punya
        if (user.xp === undefined) user.xp = 0;
        if (user.level === undefined) user.level = 0;
        if (user.role === undefined) user.role = 'Warga Baru';

        // =================================================================
        // --- 5.5 RESET LIMIT MIDNIGHT (WIB) ---
        // =================================================================
        const todayDate = new Date().toLocaleDateString('id-ID', { timeZone: 'Asia/Jakarta' });
        
        if (user.lastLimitDate !== todayDate) {
            user.limit = db.globalSettings.privateLimit;
            user.lastLimitDate = todayDate;
            user.promoSentToday = false; 
            isDbChanged = true;
        }

        // =================================================================
        // --- 5.6 LEVELING SYSTEM ---
        // =================================================================
        const xpGain = Math.floor(Math.random() * 10) + 1;
        user.xp += xpGain;
        isDbChanged = true;

        const currentLevel = Math.floor(0.1 * Math.sqrt(user.xp));

        if (currentLevel > user.level) {
            user.level = currentLevel;
            user.role = getRole(currentLevel); 
            
            const congratsMsg = `🎉 *CONGRATULATIONS* 🎉\n\n` +
                `Selamat @${finalSenderJid.split('@')[0]} naik level!\n` +
                `🆙 *Level:* ${currentLevel - 1} ➔ *${currentLevel}*\n` +
                `🏷️ *Title:* ${user.role}`;
            
            await sock.sendMessage(remoteJid, { text: congratsMsg, mentions: [finalSenderJid] });
        }

        if (normalizedSender !== finalSenderJid) {
            if (!user.altJids) user.altJids = [];
            if (!user.altJids.includes(normalizedSender)) {
                user.altJids.push(normalizedSender);
                altJidCache.set(normalizedSender, finalSenderJid);
                isDbChanged = true;
            }
        }

        // --- 6. AFK CHECK ---
        if (user.afk > -1) {
            await m.reply(`👋 Kamu kembali online! AFK berhenti.`);
            user.afk = -1; user.afkReason = "";
            isDbChanged = true;
        }
        
        let mentions = [...new Set([...(m.message?.extendedTextMessage?.contextInfo?.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])];
        for (let jid of mentions) {
            const targetJid = utils.mapJid(jid, ownerJidConfig, cfg.ownerAltJids, altJidCache);
            const targetUser = db.usersDb[targetJid];
            if (targetUser && targetUser.afk > -1) {
                await m.reply(`🤫 Jangan tag dia! Sedang AFK: ${targetUser.afkReason || "-"}\nSelama: ${utils.clockString(now - targetUser.afk)}`);
            }
        }

        // --- 7. PREMIUM CHECK ---
        if (user.premiumUntil > 0 && now > user.premiumUntil) {
            user.premiumUntil = 0;
            await sock.sendMessage(finalSenderJid, { text: "⚠️ Masa aktif Premium habis." });
            isDbChanged = true;
        }
        const isOwner = finalSenderJid === ownerJidConfig;
        const isPremium = isOwner || (user.premiumUntil > 0);

        // --- 8. CONFESS REPLY ---
        const quotedId = m.quoted?.id;
        if (quotedId && CONFESSION_MAP.has(quotedId)) {
            const originalSenderJid = CONFESSION_MAP.get(quotedId);
            try {
                await sock.sendMessage(originalSenderJid, { text: `💬 *Balasan Menfess Baru!*\nDari: @${remoteJid.split('@')[0]}`, mentions: [remoteJid] });
                
                if (msgType === 'conversation' || msgType === 'extendedTextMessage') {
                    await sock.sendMessage(originalSenderJid, { text: body });
                } else if (msgType === 'imageMessage') {
                    await sock.sendMessage(originalSenderJid, { image: message.imageMessage.url ? { url: message.imageMessage.url } : message.imageMessage, caption: body });
                } else if (msgType === 'videoMessage') {
                    await sock.sendMessage(originalSenderJid, { video: message.videoMessage.url ? { url: message.videoMessage.url } : message.videoMessage, caption: body });
                } else if (msgType === 'stickerMessage') {
                    await sock.sendMessage(originalSenderJid, { sticker: message.stickerMessage.url ? { url: message.stickerMessage.url } : message.stickerMessage });
                } else {
                    await sock.sendMessage(originalSenderJid, { forward: m });
                }
                return;
            } catch (e) { log.err('Confess Fail: ' + e.message); }
        }

        // =================================================================
        // --- 9. DONASI HARIAN & DETEKSI PREFIX (MULTI PREFIX) ---
        // =================================================================
        
        // 1. Tentukan prefix mana yang dipakai user
        // configPrefixes sudah didefinisikan di atas (langkah 4)
        const matchedPrefix = configPrefixes.find(p => body.startsWith(p));
        const isCommand = !!matchedPrefix;

        if (!isGroup && !isCommand && !quotedId) {
            if (now - (user.lastDonationSent || 0) >= 86400000) {
                await sendFuncs.sendImage('https://cdn.jsdelivr.net/gh/rhamt24/zalxzhu.github.io/images/1764680372103.png', "Bantu donasi server seikhlasnya ya kak :)");
                user.lastDonationSent = now;
                isDbChanged = true;
            }
        }

        if (isDbChanged) db.saveDatabase();
        if (!isCommand) return; // Jika tidak ada prefix yang cocok, STOP.

        // =================================================================
        // --- COMMAND PARSING (MULTI PREFIX) ---
        // =================================================================
        
        // 2. Potong body berdasarkan panjang prefix yang ditemukan
        const rawBody = body.slice(matchedPrefix.length).trim();
        const args = rawBody.split(/ +/);
        const cmd = args.shift()?.toLowerCase();
        if (!cmd) return;

        // --- 10a. SELF MODE CHECK ---
        if (db.globalSettings.selfMode && !isOwner) return;

        // --- 10b. PUBLIC MODE CHECK ---
        if (!db.globalSettings.publicMode) {
            if (!isGroup && !isOwner && !isPremium) {
                 return m.reply(`🔒 *MODE PRIVATE AKTIF*\n\nMaaf, saat ini Bot sedang dalam mode *Self/Maintenance*.\nBot hanya merespon Owner & User Premium di Chat Pribadi.\n\n✅ Silakan gunakan bot di dalam Grup.`);
            }
        }

        // --- 11. LIMIT CHECK ---
        if (!isGroup && !isPremium && !isOwner && db.globalSettings.limitMode) {
            if (user.limit <= 0) {
                const groupLink = db.globalSettings.groupLink || 'https://chat.whatsapp.com/C6KcF2yIWk39eC6KArmWm5';
                const limitMsg = `🛑 *LIMIT HARIAN HABIS* 🛑\n\n` +
                    `Yah, limit penggunaan bot kamu di Private Chat sudah habis untuk hari ini (0).\n` +
                    `Limit akan direset otomatis pada pukul 00:00 WIB.\n\n` +
                    `💡 *TIPS AGAR BEBAS LIMIT:*\n` +
                    `1️⃣ Gunakan Bot di dalam **GRUP** (Gratis & Tanpa Terpotong Limit!)\n` +
                    `2️⃣ Upgrade ke **PREMIUM** (Unlimited Private Chat)\n\n` +
                    `🚀 *Join Grup Official Bot Disini:*\n` +
                    `${groupLink}`;
                return m.reply(limitMsg);
            }
            user.limit -= 1;
            db.saveDatabase();
        }

        // --- 12. SYSTEM COMMANDS ---
        if (await sys.handleSystemCommand(sock, m, cmd, args, isOwner, cfg)) return;

        // --- 13. PLUGIN SEARCH ---
        const pluginEntry = pluginsCache[cmd];
        
        if (!pluginEntry) {
            const allCommands = Object.keys(pluginsCache);
            const suggestions = sim.findSimilarCommands(cmd, allCommands);
            // Kirim cfg.prefix (bisa array) ke formatter
            const suggestionMsg = sim.formatSuggestionMessage(cmd, suggestions, cfg.prefix);
            if (suggestionMsg) return m.reply(suggestionMsg);
            return;
        }

        if (pluginEntry.isDisabled) return m.reply('🚫 Fitur nonaktif.');
        if (pluginEntry.isOwner && !isOwner) return m.reply('🚫 Khusus Owner.');
        if (pluginEntry.isPremium && !isPremium) return m.reply('🚫 Khusus Premium.');

        // --- 14. ADMIN CHECK ---
        let isAdmin = false;
        let botIsAdmin = false;
        let isRAdmin = false;
        let groupMetadata = null;
        let participants = [];

        if (isGroup) {
            if (pluginEntry.isAdmin || pluginEntry.isBotAdmin || pluginEntry.category === 'group') {
                try {
                    groupMetadata = await sock.groupMetadata(remoteJid).catch(_ => null) || {};
                    participants = groupMetadata.participants || [];
                    
                    const botJidRaw = sock.user.id;
                    const botJidDecoded = sock.decodeJid ? sock.decodeJid(botJidRaw) : jidNormalizedUser(botJidRaw);

                    const botParticipant = participants.find(u => {
                        const jid = jidNormalizedUser(u.id);
                        const pn = u.phoneNumber ? (String(u.phoneNumber).replace(/[^0-9]/g, '') + '@s.whatsapp.net') : null;
                        return jid === botJidDecoded || pn === botJidDecoded;
                    });
                    
                    botIsAdmin = botParticipant?.admin === 'admin' || botParticipant?.admin === 'superadmin' || false;

                    const userParticipant = participants.find(u => {
                        const jid = jidNormalizedUser(u.id);
                        const pn = u.phoneNumber ? (String(u.phoneNumber).replace(/[^0-9]/g, '') + '@s.whatsapp.net') : null;
                        return jid === finalSenderJid || pn === finalSenderJid;
                    });

                    isRAdmin = userParticipant?.admin === 'superadmin' || false;
                    isAdmin = isRAdmin || userParticipant?.admin === 'admin' || false;

                    if (isOwner) { isAdmin = true; isRAdmin = true; }
                } catch (e) {
                    if (isOwner) isAdmin = true;
                }
            }
        } else {
            if (isOwner) isAdmin = true;
        }

        if (pluginEntry.isAdmin && !isAdmin) return m.reply('🚫 *ACCESS DENIED* • Command ini hanya untuk Admin Group.');
        if (pluginEntry.isBotAdmin && !botIsAdmin) return m.reply('🚫 *SYSTEM ERROR* • Bot harus menjadi Admin untuk melakukan perintah ini.');

        // --- 15. HANDLER EXECUTION ---
        try {
            await pluginEntry.handler({
                sock, msg: m, args, command: cmd, from: remoteJid, pushName,
                isOwner, isPremium, db: db.usersDb, saveDatabase: db.saveDatabase,
                sender: finalSenderJid, isGroup, isAdmin, botIsAdmin, isRAdmin,
                groupMetadata, participants, confessMap: CONFESSION_MAP,
                reply: m.reply, sendImage: m.sendImage, sendVideo: m.sendVideo, 
                sendAudio: m.sendAudio, sendSticker: m.sendSticker, sendReact: m.sendReact,
                sendDocument: m.sendDocument, sendContact: m.sendContact, sendLocation: m.sendLocation
            });
        } catch (err) {
            m.reply(`❌ Error: ${err.message}`);
            log.err(`CMD ${cmd}: ${err.message}`);
        }
    } catch (e) {
        log.err(`Handler Error: ${e.message}`);
    }
};

export const loadDisabledFeatures = async () => { return; };
export { loadPlugins }; 
export default Msg;
