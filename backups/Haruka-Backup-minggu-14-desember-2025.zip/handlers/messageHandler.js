import { promises as fs } from 'fs'; 
import path from 'path';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { fileURLToPath } from 'url';
import { createRequire } from 'module'; 
import fetch from 'node-fetch';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const require = createRequire(import.meta.url);

import log from '../lib/logger.js';
import cfg from '../config/config.json' assert { type: 'json' };

const dbPath = path.join(__dirname, '../database/users.json');
const featuresPath = path.join(__dirname, '../database/features.json');
const pluginDir = path.join(__dirname, '../plugins');

let sockGlobal = null;
const groupAdminCache = {};
const CACHE_TTL = 30000;

let pluginsCache = {};
let disabledFeatures = {};
let usersDbCache = null;

const CONFESSION_MAP = new Map();

async function initDatabase() {
  try {
    const fileContent = await fs.readFile(dbPath, 'utf8');
    usersDbCache = JSON.parse(fileContent);
  } catch (error) {
    usersDbCache = {};
    if (error.code === 'ENOENT') {
      await fs.writeFile(dbPath, JSON.stringify({}, null, 2));
    }
  }
}

async function saveDatabase() {
    try {
        if (!usersDbCache) return;
        await fs.writeFile(dbPath, JSON.stringify(usersDbCache, null, 2));
    } catch (e) {
        log.err(`Gagal menyimpan database: ${e.message}`);
    }
}

async function loadDisabledFeatures() {
    try {
        const data = await fs.readFile(featuresPath, 'utf8');
        disabledFeatures = JSON.parse(data);
    } catch {
        disabledFeatures = {};
        await fs.writeFile(featuresPath, JSON.stringify({}, null, 2));
    }
    log.info(`✅ ${Object.keys(disabledFeatures).length} fitur dinonaktifkan dimuat.`);
}

async function loadPlugins() {
    if (!usersDbCache) await initDatabase();

    log.info('🔄 Memuat ulang/memuat plugin...');
    const newPluginsCache = {};
    let pluginFiles;
    try {
        pluginFiles = (await fs.readdir(pluginDir)).filter(f => f.endsWith('.js'));
    } catch (e) {
        log.err("Gagal membaca folder plugins");
        return;
    }

    for (const file of pluginFiles) {
        const filePath = path.join(pluginDir, file);
        try {
            delete require.cache[filePath]; 
            
            const pluginModule = await import(`../plugins/${file}?v=${Date.now()}`); 
            const plugin = pluginModule.default || pluginModule;

            if (!plugin || !plugin.command) continue;

            const commands = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
            const category = plugin.isOwner ? 'Owner' : plugin.category || 'Uncategorized';

            for (const cmd of commands) {
                newPluginsCache[cmd.toLowerCase()] = {
                    file,
                    handler: plugin.handler,
                    isOwner: !!plugin.isOwner,
                    isPremium: !!plugin.isPremium,
                    isDisabled: disabledFeatures[cmd.toLowerCase()] || false,
                    category: category
                };
            }
        } catch (e) {
            log.err(`❌ Plugin '${file}' error saat memuat: ${e.message}`);
        }
    }

    pluginsCache = newPluginsCache;
    log.info(`✅ ${Object.keys(pluginsCache).length} commands dimuat.`);
}

const parseQuoted = (m, sock) => {
  const q = m.message?.extendedTextMessage?.contextInfo;
  if (!q?.quotedMessage) return;
  const quoted = q.quotedMessage;
  const mtype = Object.keys(quoted)[0];
  const msg = quoted[mtype];
  m.quoted = {
    type: mtype,
    mtype,
    id: q.stanzaId,
    sender: q.participant,
    fromMe: q.participant === sock.user.id,
    isBaileys: !!q.isForwarded,
    text: msg?.text || msg?.caption || '',
    message: quoted,
    download: async () => {
      const stream = await downloadContentFromMessage(quoted[mtype], mtype.replace('Message', ''));
      let buffer = Buffer.from([]);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }
      return buffer;
    }
  };
};

// Logika mapJid yang diperbarui untuk memetakan JID cadangan (altJids) ke JID utama
function mapJid(incomingJid, db, ownerJid, ownerAltJids) {
    // 1. Cek apakah JID yang masuk adalah JID Owner utama atau JID Owner cadangan
    if (incomingJid === ownerJid || (ownerAltJids && ownerAltJids.includes(incomingJid))) {
        return ownerJid;
    }
    
    // 2. Cek apakah JID yang masuk adalah JID cadangan untuk PENGGUNA MANAPUN
    for (const mainJid in db) {
        if (db[mainJid].altJids && db[mainJid].altJids.includes(incomingJid)) {
            return mainJid; // Kembalikan JID utama yang benar
        }
    }

    // 3. Jika tidak ada pemetaan, kembalikan JID yang masuk
    return incomingJid; 
}

async function sendDonationMessage(sock, jid, caption, url) {
    try {
        const imageResponse = await fetch(url);
        if (!imageResponse.ok) throw new Error(`Failed to fetch image: ${imageResponse.statusText}`);
        const imageBuffer = await imageResponse.buffer();
        
        await sock.sendMessage(jid, { 
            image: imageBuffer, 
            caption: caption 
        });
        return true;
    } catch (e) {
        log.err(`Gagal mengirim gambar donasi untuk ${jid}: ${e.message}. Mengirim pesan teks pengganti.`);
        await sock.sendMessage(jid, { 
            text: `🙏 *Bot Online Berkat Donasi Anda!* ${caption}` 
        });
        return false;
    }
}

function clockString(ms) {
  let h = isNaN(ms) ? "--" : Math.floor(ms / 3600000);
  let m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
  let s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
  return [h, m, s].map((v) => v.toString().padStart(2, 0)).join(":");
}

function timeSince(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days} hari`;
    if (hours > 0) return `${hours} jam`;
    if (minutes > 0) return `${minutes} menit`;
    if (seconds > 0) return `${seconds} detik`;
    return 'segera';
}


async function Msg(sock, m) {
    try {
        sockGlobal = sock;

        if (!m || !m.message) return;
        if (m.key.fromMe) return;
        
        const start_time = Date.now(); 
        const now = Date.now();
        const { key, message, pushName } = m;
        const remoteJid = key.remoteJid;
        const ownerConfigJid = cfg.owner + '@s.whatsapp.net';

        m.reply = async (text, opt = {}) => {
            return sock.sendMessage(remoteJid, { text, ...opt }, { quoted: m });
        };

        if (!usersDbCache) await initDatabase();

        const isGroup = remoteJid.endsWith('@g.us');
        let incomingJid = isGroup ? key.participant : remoteJid;
        m.isGroup = isGroup;

        if (isGroup && key.participantPn && /@lid$/.test(key.participant)) {
            incomingJid = key.participantPn;
        }

        const msgType = Object.keys(message || {})[0];
        let body = '';
        if (msgType === 'conversation') body = message.conversation || '';
        else if (msgType === 'imageMessage') body = message.imageMessage?.caption || '';
        else if (msgType === 'videoMessage') body = message.videoMessage?.caption || '';
        else if (msgType === 'extendedTextMessage') body = message.extendedTextMessage?.text || '';
        else if (msgType === 'buttonsResponseMessage') body = message.buttonsResponseMessage?.selectedButtonId || '';
        else if (msgType === 'listResponseMessage') body = message.listResponseMessage?.singleSelectReply?.selectedRowId || '';
        else if (msgType === 'templateButtonReplyMessage') body = message.templateButtonReplyMessage?.selectedId || '';
        
        parseQuoted(m, sock);
        const quotedId = m.quoted?.id;
        
        let isDbChanged = false;
        // Gunakan mapJid untuk mendapatkan JID utama (mainJid)
        const finalSenderJid = mapJid(incomingJid, usersDbCache, ownerConfigJid, cfg.ownerAltJids); 
        m.sender = finalSenderJid;
        
        let userDbEntry = usersDbCache[finalSenderJid];
        if (!userDbEntry) {
            userDbEntry = usersDbCache[finalSenderJid] = {
                nama: pushName || 'User',
                registered: false,
                lastReset: now,
                status: 'guest',
                premiumUntil: 0,
                altJids: [],
                lastDonationSent: 0,
                afk: -1, 
                afkReason: "",
                lastPremiumNotif: 0 
            };
            log.info(`➕ User baru dibuat di RAM: ${finalSenderJid}`);
            isDbChanged = true;
        } else {
            if (!('afk' in userDbEntry)) {
                userDbEntry.afk = -1;
                isDbChanged = true;
            }
            if (!('afkReason' in userDbEntry)) {
                userDbEntry.afkReason = "";
                isDbChanged = true;
            }
            if (!('lastPremiumNotif' in userDbEntry)) {
                userDbEntry.lastPremiumNotif = 0;
                isDbChanged = true;
            }
        }

        const originalIncomingJid = incomingJid;
        // Logika untuk menambahkan JID yang masuk ke daftar altJids jika JID utama ditemukan berbeda
        if (originalIncomingJid !== finalSenderJid) {
            if (!userDbEntry.altJids) userDbEntry.altJids = [];
            if (!userDbEntry.altJids.includes(originalIncomingJid)) {
                userDbEntry.altJids.push(originalIncomingJid);
                log.info(`🔗 JID alternatif baru ditambahkan: ${originalIncomingJid} -> ${finalSenderJid}`);
                isDbChanged = true;
            }
        }

        if (!userDbEntry.premiumUntil) userDbEntry.premiumUntil = 0;
        if (userDbEntry.premiumUntil > 0 && now > userDbEntry.premiumUntil) {
            userDbEntry.premiumUntil = 0;
            userDbEntry.status = userDbEntry.registered ? 'user' : 'guest';
            log.info(`⬇️ Premium ${finalSenderJid} habis.`);
            isDbChanged = true;
        }

        const isOwner = finalSenderJid === ownerConfigJid;
        const isPremium = isOwner || (userDbEntry.premiumUntil > 0 && now < userDbEntry.premiumUntil);

        if (isPremium && userDbEntry.status !== 'premium') {
            userDbEntry.status = 'premium';
            isDbChanged = true;
        }
        
        const TWO_DAYS_MS = 48 * 60 * 60 * 1000;
        if (userDbEntry.status === 'premium' && userDbEntry.premiumUntil > 0) {
            const timeRemaining = userDbEntry.premiumUntil - now;
            
            if (timeRemaining > 0 && timeRemaining <= TWO_DAYS_MS) {
                const lastNotification = userDbEntry.lastPremiumNotif || 0;
                const ONE_DAY_MS = 24 * 60 * 60 * 1000;
                
                if (now - lastNotification > ONE_DAY_MS || (timeRemaining < ONE_DAY_MS && now - lastNotification > 10000)) {
                     await m.reply(
                        `
🔔 *Notifikasi Premium*
Status Premium Anda akan habis dalam waktu *${timeSince(timeRemaining)}*.
Silakan perpanjang segera untuk terus menikmati fitur Premium!
`.trim()
                    );
                    userDbEntry.lastPremiumNotif = now;
                    isDbChanged = true;
                }
            } else if (timeRemaining > TWO_DAYS_MS && userDbEntry.lastPremiumNotif) {
                 userDbEntry.lastPremiumNotif = 0;
                 isDbChanged = true;
            }
        }
        
        if (isDbChanged) {
            await saveDatabase();
        }
        
        if (userDbEntry.afk > -1) {
            await m.reply(
                `
Kamu berhenti AFK${userDbEntry.afkReason ? " setelah " + userDbEntry.afkReason : ""}
Selama ${clockString(now - userDbEntry.afk)}
`.trim()
            );
            userDbEntry.afk = -1;
            userDbEntry.afkReason = "";
            await saveDatabase(); 
        }
        
        let jids = [
            ...new Set([
                ...(m.message?.extendedTextMessage?.contextInfo?.mentionedJid || []),
                ...(m.quoted ? [m.quoted.sender] : []),
            ]),
        ];

        for (let jid of jids) {
            const targetJid = mapJid(jid, usersDbCache, ownerConfigJid, cfg.ownerAltJids);
            let taggedUserEntry = usersDbCache[targetJid];
            
            if (!taggedUserEntry) continue;
            let afkTime = taggedUserEntry.afk;
            if (!afkTime || afkTime < 0) continue;
            let reason = taggedUserEntry.afkReason || "";
            
            await m.reply(
                `
Jangan tag dia!
Dia sedang AFK ${reason ? "dengan alasan " + reason : "tanpa alasan"}
Selama ${clockString(now - afkTime)}
`.trim()
            );
        }
        
        if (quotedId && CONFESSION_MAP.has(quotedId)) {
            const originalSenderJid = CONFESSION_MAP.get(quotedId);
            try {
                await sock.sendMessage(originalSenderJid, { text: `💬 *Balasan Menfess*\nDari: @${remoteJid.split('@')[0]}`, mentions: [remoteJid] });
                const currentMsgType = Object.keys(m.message || {})[0];
                if (currentMsgType) {
                    const payload = {};
                    payload[currentMsgType] = m.message[currentMsgType];
                    await sock.relayMessage(originalSenderJid, payload, { messageId: m.key.id });
                }
                return;
            } catch (e) { log.err('Confession fail'); }
        }
        
        const isCommand = body.startsWith(cfg.prefix);
        if (!isCommand) return; 

        if (!isGroup && !quotedId) { 
            const ONE_DAY_MS = 24 * 60 * 60 * 1000;
            const timeSinceLastDonation = now - (userDbEntry.lastDonationSent || 0);

            // PERBAIKAN: Menggunakan nama variabel yang benar (timeSinceLastDonation)
            if (timeSinceLastDonation >= ONE_DAY_MS) { 
                 const DONATION_URL = 'https://cdn.jsdelivr.net/gh/rhamt24/zalxzhu.github.io/images/1764680372103.png';
                 const DONATION_CAPTION = 
                    "Halo! 😊 Terima kasih telah menggunakan bot ini.\n\n" +
                    "Untuk membantu kelangsungan biaya server dan pengembangan fitur-fitur baru agar bot tetap online dan bermanfaat, kami menerima donasi seikhlasnya.\n\n" +
                    "Donasi Anda sangat berarti! 🙏\n\n" +
                    "(Pesan ini hanya muncul sekali dalam 24 jam di chat pribadi.)";

                 const sent = await sendDonationMessage(sock, finalSenderJid, DONATION_CAPTION, DONATION_URL);
                 
                 if (sent) {
                     userDbEntry.lastDonationSent = now;
                     await saveDatabase();
                 }
            }
        }
        
        const rawBody = body.slice(cfg.prefix.length).trim();
        
        if (body === cfg.prefix) {
            const end_time = Date.now();
            const response_time = end_time - start_time;
            return m.reply(`✅ Bot sedang *online*! Respon dalam *${response_time}* ms`);
        }
        
        const args = rawBody.split(/ +/);
        const cmd = args.shift()?.toLowerCase();
        if (!cmd) return; 

        if (isOwner) {
            if (cmd === 'reload') {
                m.reply('🔄 Reloading system...');
                await loadDisabledFeatures();
                await loadPlugins();
                m.reply('✅ System reloaded successfully!');
                return;
            } else if (cmd === 'disable' || cmd === 'enable') {
                const targetCmd = args[0]?.toLowerCase();
                if (!targetCmd) return m.reply(`❌ Gunakan: ${cfg.prefix}${cmd} <command>`);
                
                const status = cmd === 'disable';
                disabledFeatures[targetCmd] = status;
                
                await fs.writeFile(featuresPath, JSON.stringify(disabledFeatures, null, 2));

                if (pluginsCache[targetCmd]) {
                    pluginsCache[targetCmd].isDisabled = status;
                }
                
                m.reply(`✅ Command *${targetCmd}* berhasil di${status ? 'nonaktifkan' : 'aktifkan'}.`);
                return;
            }
        }
        
        const pluginEntry = pluginsCache[cmd];
        if (!pluginEntry) return;

        const participantJidForGroupCheck = key.participant || remoteJid;
        let isAdmin = isOwner;

        if (isGroup && !isOwner) {
            const cacheKey = remoteJid;
            if (groupAdminCache[cacheKey] && now < groupAdminCache[cacheKey].expiry) {
                const participant = groupAdminCache[cacheKey].participants.find(p => p.id === participantJidForGroupCheck);
                isAdmin = !!(participant?.admin === 'admin' || participant?.admin === 'superadmin');
            } else {
                try {
                    const groupMetadata = await sock.groupMetadata(remoteJid);
                    groupAdminCache[cacheKey] = {
                        participants: groupMetadata.participants,
                        expiry: now + CACHE_TTL
                    };
                    const participant = groupMetadata.participants.find(p => p.id === participantJidForGroupCheck);
                    isAdmin = !!(participant?.admin === 'admin' || participant?.admin === 'superadmin');
                } catch (e) { isAdmin = false; }
            }
        }

        if (pluginEntry.isDisabled) return m.reply('🚫 Fitur ini sedang dinonaktifkan.');
        if (pluginEntry.isOwner && !isOwner) return m.reply('🚫 Fitur ini khusus Owner.');
        if (pluginEntry.isPremium && !isPremium) return m.reply('🚫 Fitur ini khusus Premium.');

        try {
            log.evt(`Cmd '${cmd}' dari ${pushName || m.sender}`);
            await pluginEntry.handler({
                sock,
                msg: m,
                args,
                command: cmd,
                from: remoteJid,
                pushName,
                isOwner,
                isPremium,
                isUserRegistered: !!userDbEntry.registered,
                db: usersDbCache,
                saveDatabase: saveDatabase, 
                sender: m.sender,
                isGroup,
                isAdmin
            });
        } catch (e) {
            log.err(`❌ Plugin '${pluginEntry.file}' error: ${e.message}`);
            m.reply('❌ Terjadi *Error* saat menjalankan fitur ini.');
        }

    } catch (e) {
        log.err(`❌ Msg() fatal error: ${e.stack || e.message}`);
    }
}

export { loadPlugins, loadDisabledFeatures, pluginsCache, CONFESSION_MAP };
export default Msg;
