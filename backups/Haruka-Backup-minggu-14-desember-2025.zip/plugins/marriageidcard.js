import fs from 'fs/promises'; 
import fsSync from 'fs'; // Import sync fs untuk cleanup
import path from 'path';
import { fileURLToPath } from 'url';
import { uploadCatbox } from '../lib/uploader.js'; // Pastikan uploader tersedia
import { generateCertificate } from '../lib/sertifikat.js'; // Import fungsi pembuat sertifikat

// --- [ SETUP PATH & DATABASE ] ---

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const userDataFile = path.join(__dirname, '../data/userData.json');
let userData = {}; 

async function loadUserData() {
    // Fungsi ini harus sama persis dengan yang ada di marry.js untuk membaca DB
    try {
        const content = await fs.readFile(userDataFile, 'utf8');
        userData = JSON.parse(content);
    } catch (e) {
        userData = {}; // Jika file tidak ada atau error, gunakan objek kosong
    }
}

async function saveUserData() {
    // Fungsi ini harus sama persis dengan yang ada di marry.js untuk menulis DB
    await fs.writeFile(userDataFile, JSON.stringify(userData, null, 2), 'utf8');
}

// --- [ UTILITY WAIFU ] ---

function getWaifuData(userId) {
    if (!userData[userId] || !userData[userId].waifus) {
        return [];
    }
    return userData[userId].waifus; 
}

function getTargetWaifu(userId, args) {
    const waifus = getWaifuData(userId);
    if (waifus.length === 0) return null;

    const targetArg = args[0]?.trim();
    
    const targetNumber = parseInt(targetArg);
    if (!isNaN(targetNumber) && targetNumber >= 1 && targetNumber <= waifus.length) {
        const index = targetNumber - 1; 
        return { wife: waifus[index], wifeIndex: index };
    }

    const targetName = args.join(' ').trim().toLowerCase();
    
    if (targetName) {
        const index = waifus.findIndex(w => w.name.toLowerCase().includes(targetName));
        if (index !== -1) {
            return { wife: waifus[index], wifeIndex: index };
        }
    }
    
    return null; // Mengubah default menjadi null agar user harus spesifik
}

// --- [ FUNGSI KHUSUS GENERATE SERTIFIKAT MANUAL ] ---

async function generateAndStoreCertificate(sock, remoteJid, msg, waifu, pushName, user, wifeIndex) {
    let tempImagePath = '';
    
    try {
        const husbandName = pushName; 
        const wifeName = waifu.name;
        const marriageDate = waifu.dateMarried;
        
        await sock.sendMessage(remoteJid, { react: { text: '⏳', key: msg.key } });

        // 1. Panggil fungsi generateCertificate
        tempImagePath = await generateCertificate(husbandName, wifeName, marriageDate);
        
        // 2. Upload ke Catbox
        const certificateUrl = await uploadCatbox(tempImagePath);

        // 3. Simpan URL di DB
        waifu.marriageCertificateUrl = certificateUrl;
        userData[user].waifus[wifeIndex] = waifu;
        await saveUserData();
        
        await sock.sendMessage(remoteJid, { react: { text: '✅', key: msg.key } });
        await sock.sendMessage(remoteJid, { 
            image: { url: certificateUrl },
            caption: `📜 Sertifikat Pernikahan untuk *${wifeName}* berhasil dibuat dan disimpan! Anda bisa melihatnya lagi dengan *.marriageid show ${wifeIndex + 1}*`,
            mentions: [user] 
        }, { quoted: msg });

    } catch (error) {
        console.error('[CERTIFICATE GENERATION ERROR]', error);
        await sock.sendMessage(remoteJid, { react: { text: '❌', key: msg.key } });
        await sock.sendMessage(remoteJid, { text: `⚠️ Gagal membuat Sertifikat Pernikahan untuk ${waifu.name}. Detail Error: ${error.message}` }, { quoted: msg });
    } finally {
        if (tempImagePath && fsSync.existsSync(tempImagePath)) {
            await fs.unlink(tempImagePath).catch(() => {});
        }
    }
}


// --- [ HANDLER UTAMA ID CARD ] ---

const handler = async ({ sock, msg, from, args, command, pushName, sender }) => {
    
    try {
        await loadUserData(); 

        const user = sender;
        const remoteJid = from; 
        const subCommand = args[0]?.toLowerCase();
        
        const waifus = getWaifuData(user);
        
        if (waifus.length === 0) {
            return sock.sendMessage(remoteJid, { text: `❌ Anda belum memiliki waifu! Tidak ada Kartu ID untuk dikelola.` }, { quoted: msg });
        }
        
        
        // ------------------------------------------------
        // 1. COMMAND: CREATE/GENERATE MANUAL (.marriageid create [No/Nama])
        // ------------------------------------------------
        if (subCommand === 'create' || subCommand === 'generate' || subCommand === 'buat') {
            const targetArgs = args.slice(1);
            if (targetArgs.length === 0) {
                 return sock.sendMessage(remoteJid, { text: `❌ Anda harus menentukan waifu mana yang akan dibuatkan sertifikatnya. Contoh: *.marriageid create 1* atau *.marriageid create Asuna*` }, { quoted: msg });
            }
            
            const target = getTargetWaifu(user, targetArgs);
            
            if (!target) {
                 return sock.sendMessage(remoteJid, { text: `❌ Waifu tidak ditemukan. Silakan gunakan nomor urut atau nama yang benar.` }, { quoted: msg });
            }
            const { wife, wifeIndex } = target;

            if (wife.marriageCertificateUrl) {
                 return sock.sendMessage(remoteJid, { text: `⚠️ Sertifikat untuk *${wife.name}* sudah ada! Gunakan *.marriageid show ${wifeIndex + 1}* untuk melihatnya, atau *.marriageid delete ${wifeIndex + 1}* untuk membuat ulang.` }, { quoted: msg });
            }
            
            // Panggil fungsi pembuatan Sertifikat
            await generateAndStoreCertificate(sock, remoteJid, msg, wife, pushName, user, wifeIndex);
            return;
        }

        // ------------------------------------------------
        // 2. COMMAND: SHOW ID CARD / SERTIFIKAT (.marriageid show [No/Nama])
        // ------------------------------------------------
        if (subCommand === 'show' || subCommand === 'tunjukkan') {
            const targetArgs = args.slice(1);
            // Jika tidak ada argumen, default ke waifu 1. Jika ada argumen, cari berdasarkan argumen.
            const target = getTargetWaifu(user, targetArgs.length > 0 ? targetArgs : ['1']); 
            
            if (!target) {
                 return sock.sendMessage(remoteJid, { text: `❌ Waifu tidak ditemukan. Silakan gunakan nomor urut atau nama.` }, { quoted: msg });
            }
            const { wife } = target;

            if (wife.marriageCertificateUrl) {
                return sock.sendMessage(remoteJid, { 
                    image: { url: wife.marriageCertificateUrl },
                    caption: `📜 Sertifikat Pernikahan resmi untuk *${wife.name}*:\n\n*Suami*: ${pushName}\n*Tanggal*: ${wife.dateMarried}`,
                    mentions: [user] 
                }, { quoted: msg });
            } 
            
            return sock.sendMessage(remoteJid, { 
                text: `❌ Sertifikat Pernikahan untuk *${wife.name}* belum dibuat. Anda bisa membuatnya secara manual dengan *.marriageid create ${wife.name}*` 
            }, { quoted: msg });
        }


        // ------------------------------------------------
        // 3. COMMAND: DELETE ID CARD / SERTIFIKAT (.marriageid delete [No/Nama])
        // ------------------------------------------------
        if (subCommand === 'delete' || subCommand === 'hapus') {
            const targetArgs = args.slice(1);
             if (targetArgs.length === 0) {
                 return sock.sendMessage(remoteJid, { text: `❌ Anda harus menentukan waifu mana yang akan dihapus sertifikatnya. Contoh: *.marriageid delete 1*` }, { quoted: msg });
            }
            const target = getTargetWaifu(user, targetArgs); 

            if (!target) {
                 return sock.sendMessage(remoteJid, { text: `❌ Waifu tidak ditemukan. Silakan gunakan nomor urut atau nama.` }, { quoted: msg });
            }
            const { wife, wifeIndex } = target;

            if (!wife.marriageCertificateUrl) {
                return sock.sendMessage(remoteJid, { text: `❌ Sertifikat untuk *${wife.name}* tidak ditemukan di database.` }, { quoted: msg });
            }
            
            wife.marriageCertificateUrl = null;
            userData[user].waifus[wifeIndex] = wife;
            await saveUserData();
            
            return sock.sendMessage(remoteJid, { 
                text: `🗑️ Sertifikat Pernikahan untuk *${wife.name}* berhasil dihapus dari database. Anda bisa membuatnya lagi dengan *.marriageid create ${wife.name}*`,
                mentions: [user] 
            }, { quoted: msg });
        }
        
        
        // ------------------------------------------------
        // 4. DEFAULT HELP MESSAGE (.marriageid)
        // ------------------------------------------------
        let help = `*KELOLA KARTU ID & SERTIFIKAT PERNIKAHAN*\n\n`;
        help += `Perintah ini digunakan untuk mengelola data Sertifikat Pernikahan yang sudah tersimpan.\n\n`;
        help += `*Waifu Anda:*\n`;
        waifus.forEach((w, index) => {
            help += `  - ${index + 1}. ${w.name} (${w.marriageCertificateUrl ? '✅ Ada' : '❌ Kosong'})\n`;
        });
        help += `\n*Perintah:*\n`;
        help += `*.marriageid create [No/Nama]*: *BUAT MANUAL* Sertifikat Pernikahan jika belum ada.\n`;
        help += `*.marriageid show [No/Nama]*: Tunjukkan Sertifikat Pernikahan yang tersimpan.\n`;
        help += `*.marriageid delete [No/Nama]*: Hapus link Sertifikat dari database.\n`;
        
        return sock.sendMessage(remoteJid, { text: help }, { quoted: msg });

    } catch (e) {
        console.error('[MARRIAGE ID CARD ERROR]', e);
        await sock.sendMessage(from, { 
            text: `❌ Terjadi error internal pada plugin ID Card.\n\n${e.message}` 
        }, { quoted: msg });
    }
};

export default {
    command: ['marriageid', 'marryid'],
    description: 'Mengelola Kartu ID dan Sertifikat Pernikahan.',
    category: 'fun',
    handler,
};