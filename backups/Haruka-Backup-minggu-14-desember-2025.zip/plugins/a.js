import axios from 'axios';
import fileType from 'file-type'; 
import { downloadContentFromMessage } from '@whiskeysockets/baileys'; 
import path from 'path';
import { fileURLToPath } from 'url';

import cfg from '../config/config.json' assert { type: 'json' };
import log from '../lib/logger.js';

class VertexAI {
    constructor() {
        this.api_url = 'https://firebasevertexai.googleapis.com/v1beta';
        this.model_url = 'projects/gemmy-ai-bdc03/locations/us-central1/publishers/google/models';
        this.headers = {
            'content-type': 'application/json',
            'x-goog-api-key': 'AIzaSyD6QwvrvnjU7j-R6fkOghfIVKwtvc7SmLk' 
        };
        this.ratio = ['1:1', '3:4', '4:3', '9:16', '16:9'];
        this.model = {
            search: ['gemini-2.0-flash', 'gemini-2.5-flash', 'gemini-2.5-pro'], 
            chat: ['gemini-1.5-flash', 'gemini-2.5-flash', 'gemini-2.5-pro'],
            image: ['imagen-3.0-generate-002', 'imagen-4.0-generate-preview-06-06']
        };
    }
    
    chat = async function (question, { model = 'gemini-2.5-flash', system_instruction = null, file_buffer = null, search = true } = {}) {
        if (!question) throw new Error('Question is required');
        if (!this.model.chat.includes(model)) throw new Error(`Available models: ${this.model.chat.join(', ')}`);
        
        if (search && !this.model.search.includes(model)) {
            if (model.includes('1.5')) search = false; 
        }

        const parts = [{ text: question }];
        
        if (file_buffer) {
            let mimeType;
            try {
                const type = await fileType.fromBuffer(file_buffer);
                if (!type) throw new Error("Could not determine file type.");
                mimeType = type.mime;
            } catch (e) {
                throw new Error('Gagal memproses file buffer.');
            }
            
            parts.unshift({
                inlineData: {
                    mimeType: mimeType,
                    data: file_buffer.toString('base64')
                }
            });
        }
        
        const payload = {
            contents: [
                ...(system_instruction ? [{
                    role: 'model',
                    parts: [{ text: system_instruction }]
                }] : []),
                {
                    role: 'user',
                    parts: parts
                }
            ],
            ...(search ? {
                tools: [{
                    googleSearch: {}
                }]
            } : {})
        };

        const r = await axios.post(`${this.api_url}/${this.model_url}/${model}:generateContent`, payload, {
            headers: this.headers
        });
        
        if (r.status !== 200) throw new Error(`API Response Error: Status ${r.status}`);
        
        const result = r.data.candidates;
        if (!result || result.length === 0) throw new Error('No candidate response found.');
        
        return result;
    }

    image = async function (prompt, { model = 'imagen-3.0-generate-002', aspect_ratio = '1:1' } = {}) {
        if (!prompt) throw new Error('Prompt is required');
        if (!this.model.image.includes(model)) throw new Error(`Available models: ${this.model.image.join(', ')}`);
        if (!this.ratio.includes(aspect_ratio)) throw new Error(`Available ratios: ${this.ratio.join(', ')}`);
        
        const r = await axios.post(`${this.api_url}/${this.model_url}/${model}:predict`, {
            instances: [
                {
                    prompt: prompt,
                }
            ],
            parameters: {
                sampleCount: 1,
                includeRaiReason: true,
                aspectRatio: aspect_ratio,
                safetySetting: 'block_only_high',
                personGeneration: 'allow_adult',
                addWatermark: false,
                imageOutputOptions: {
                    mimeType: 'image/jpeg',
                    compressionQuality: 95
                }
            }
        }, {
            headers: this.headers
        });
        
        if (r.status !== 200) throw new Error('No result found');
        return r.data.predictions;
    }
}

const ai = new VertexAI();

export default {
    command: ['buatgambar', 'dalle', 'img', 'draw'], 
    
    handler: async function ({ sock, msg, args }) {
        const prompt = args.join(' ');
        
        if (!prompt) {
            const prefix = cfg.prefix || '.';
            return msg.reply(`*Pembuatan Gambar (Image Generation)* 🖼️
Gunakan: ${prefix}buatgambar <deskripsi gambar>
Contoh: ${prefix}buatgambar seekor kucing mengenakan baju astronot, gaya digital art`);
        }

        try {
            await msg.reply('⏳ Sedang memproses pembuatan gambar. Ini mungkin butuh waktu...');

            const predictions = await ai.image(prompt, { 
                model: 'imagen-3.0-generate-002', 
                aspect_ratio: '1:1' 
            });

            log.info(`Prediksi Gambar Diterima.`); // Logging disederhanakan

            const imageBase64 = predictions[0]?.image?.imageBytes;

            if (!imageBase64) {
                // Diagnosis alasan kegagalan dari API jika tersedia
                const safetyReason = predictions[0]?.safetySetting?.reason || 'Tidak diketahui';
                
                if (safetyReason !== 'Tidak diketahui' && safetyReason !== 'N/A') {
                     log.warn(`Gagal Mendapat Base64. Alasan: ${safetyReason}`);
                     // Kirim error yang lebih spesifik ke pengguna
                     return msg.reply(`❌ Gagal: Prompt mungkin diblokir oleh filter keamanan AI. Coba ganti deskripsi. (Alasan: ${safetyReason})`);
                }

                // Error umum jika tidak ada alasan spesifik
                return msg.reply('❌ Gagal menghasilkan gambar. Coba ganti prompt atau aspek rasio.');
            }

            const imageBuffer = Buffer.from(imageBase64, 'base64');
            
            await sock.sendMessage(msg.from, {
                image: imageBuffer,
                caption: `✅ Gambar berhasil dibuat berdasarkan prompt:\n_${prompt}_`
            }, { quoted: msg });

        } catch (e) {
            log.err("Image Gen Error:", e.message);
            return msg.reply(`❌ Terjadi kesalahan saat membuat gambar: ${e.message}`);
        }
    }
};