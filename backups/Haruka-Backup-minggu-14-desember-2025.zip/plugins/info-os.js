import os from 'os';
import {
    createCanvas,
    loadImage
} from 'canvas';
import {
    fileURLToPath
} from 'url';
import path from 'path';

// Mendefinisikan __dirname untuk konteks ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);


const generateOSImage = async (botProfile, sock) => {
    const canvasWidth = 800;
    const canvasHeight = 600;
    const canvas = createCanvas(canvasWidth, canvasHeight);
    const ctx = canvas.getContext('2d');

    // Latar belakang acak (mempertahankan logika asli)
    const isDarkBackground = Math.random() > 0.5;
    ctx.fillStyle = isDarkBackground ? '#000000' : '#FFFFFF';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);

    const textColor = isDarkBackground ? '#FFFFFF' : '#000000';
    ctx.fillStyle = textColor;

    ctx.font = 'bold 50px "Arial Black"';
    ctx.textAlign = 'center';
    ctx.fillText('📊 System Information', canvasWidth / 2, 80);

    const cpus = os.cpus();
    const cpuModel = cpus[0]?.model || 'Unknown CPU';
    const cpuSpeed = cpus[0]?.speed || 'Unknown';
    const coreCount = cpus.length;

    // Data OS
    const totalMemory = (os.totalmem() / (1024 ** 3)).toFixed(2);
    const freeMemory = (os.freemem() / (1024 ** 3)).toFixed(2);
    
    const osType = os.type();
    const osPlatform = os.platform();
    const osRelease = os.release();

    // Uptime System
    const uptime = os.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    
    // Uptime Process (Bot)
    const runtime = process.uptime();
    const runtimeHours = Math.floor(runtime / 3600);
    const runtimeMinutes = Math.floor((runtime % 3600) / 60);
    const runtimeSeconds = Math.floor(runtime % 60);

    // Teks Detail
    ctx.font = '30px "Courier New"';
    ctx.textAlign = 'left';
    
    ctx.fillText(`💻 OS: ${osType} (${osPlatform})`, 20, 150); // Tambahan
    ctx.fillText(`🖥️ CPU: ${cpuModel}`, 20, 200);
    ctx.fillText(`⚡ Speed: ${cpuSpeed} MHz`, 20, 250);
    ctx.fillText(`🧵 Cores: ${coreCount}`, 20, 300);
    
    ctx.fillText(`💾 Total Memory: ${totalMemory} GB`, 20, 350);
    ctx.fillText(`📂 Free Memory: ${freeMemory} GB`, 20, 400);

    ctx.fillText(`⏱️ System Uptime: ${hours}h ${minutes}m ${seconds}s`, 20, 450);
    ctx.fillText(`⚙️ Bot Runtime: ${runtimeHours}h ${runtimeMinutes}m ${runtimeSeconds}s`, 20, 500);
    
    // Gambar Profil Bot
    try {
        const profileImageUrl = botProfile || 'https://i.ibb.co/6P6X13p/default-pfp.jpg'; // Default link
        const profileImage = await loadImage(profileImageUrl);
        const radius = 75;
        const centerX = canvasWidth - 150;
        const centerY = 150;

        ctx.save();
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(profileImage, centerX - radius, centerY - radius, radius * 2, radius * 2);
        ctx.restore();
        ctx.strokeStyle = textColor;
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.closePath();
        ctx.stroke();
    } catch (error) {
        // console.error('Gagal memuat gambar profil:', error.message);
    }

    return canvas.toBuffer();
};

const handler = async ({ sock, msg, from }) => {
    
    await sock.sendMessage(from, { react: { text: '⏳', key: msg.key } });

    try {
        // Mendapatkan URL Foto Profil Bot
        const botProfile = await sock.profilePictureUrl(sock.user.id, 'image').catch(() => null);

        // Mengambil Data OS untuk Caption Teks
        const cpus = os.cpus();
        const cpuModel = cpus[0]?.model || 'Unknown CPU';
        const cpuSpeed = cpus[0]?.speed || 'Unknown';
        const coreCount = cpus.length;

        const totalMemory = (os.totalmem() / (1024 ** 3)).toFixed(2);
        const freeMemory = (os.freemem() / (1024 ** 3)).toFixed(2);

        const osType = os.type();
        const osRelease = os.release();

        const uptime = os.uptime();
        const hours = Math.floor(uptime / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);

        const runtime = process.uptime();
        const runtimeHours = Math.floor(runtime / 3600);
        const runtimeMinutes = Math.floor((runtime % 3600) / 60);
        const runtimeSeconds = Math.floor(runtime % 60);

        const caption = `
📊 *System Information* (Node.js)
💻 *OS Type*: ${osType} (${osRelease})
🖥️ *CPU Model*: ${cpuModel}
⚡ *Speed*: ${cpuSpeed} MHz
✨ *Cores*: ${coreCount}
💾 *Total Memory*: ${totalMemory} GB
📑 *Free Memory*: ${freeMemory} GB
⏱️ *System Uptime*: ${hours}h ${minutes}m ${seconds}s
⚙️ *Bot Runtime*: ${runtimeHours}h ${runtimeMinutes}m ${runtimeSeconds}s
    `.trim();

        // Generate Canvas Image
        const buffer = await generateOSImage(botProfile, sock);
        
        // Kirim hasil
        await sock.sendMessage(from, { react: { text: '✅', key: msg.key } });

        await sock.sendMessage(
            from, {
                text: caption,
                contextInfo: {
                    externalAdReply: {
                        title: 'I N F O • S I S T E M 🔥',
                        body: 'System Information',
                        thumbnail: buffer,
                        sourceUrl: 'https://chat.whatsapp.com/',
                        mediaType: 1,
                        renderLargerThumbnail: true,
                    },
                },
            }, {
                quoted: msg
            }
        );
    } catch (error) {
        console.error("OS Info Error:", error);
        await sock.sendMessage(from, { react: { text: '❌', key: msg.key } });
        await sock.sendMessage(
            from, {
                text: `❌ Gagal mengambil info sistem: ${error.message}`
            }, {
                quoted: msg
            }
        );
    }
};

// --- EXPORT PLUGIN ---
export default {
    command: ['os', 'osinfo', 'systeminfo'],
    description: 'Menampilkan informasi sistem operasi dan sumber daya bot.',
    category: 'info',
    handler: handler
};