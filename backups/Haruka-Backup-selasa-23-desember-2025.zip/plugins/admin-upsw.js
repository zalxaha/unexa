import crypto from "node:crypto";
import * as baileys from "@whiskeysockets/baileys";

const cooldowns = new Map();

/**
 * Fungsi pembantu untuk mengunduh stream ke buffer dengan efisien (Hemat RAM)
 */
async function bufferFromStream(stream) {
    const chunks = [];
    for await (const chunk of stream) {
        chunks.push(chunk);
    }
    return Buffer.concat(chunks);
}

/**
 * Fungsi untuk membangun pesan status grup
 */
async function groupStatus(sock, jid, content) {
    const { backgroundColor } = content;
    // Hapus background agar tidak crash saat generateWAMessageContent jika tidak didukung
    if (content.backgroundColor) delete content.backgroundColor;

    const inside = await baileys.generateWAMessageContent(content, {
        upload: sock.waUploadToServer,
        backgroundColor
    });

    const messageSecret = crypto.randomBytes(32);

    const m = baileys.generateWAMessageFromContent(
        jid,
        {
            messageContextInfo: { messageSecret },
            groupStatusMessageV2: {
                message: {
                    ...inside,
                    messageContextInfo: { messageSecret }
                }
            }
        },
        { userJid: sock.user.id } // Pastikan userJid terdefinisi
    );

    await sock.relayMessage(jid, m.message, { messageId: m.key.id });
    return m;
}

const handler = async ({ sock, msg, args, command, isGroup, isAdmin, isOwner, sender }) => {
    const remoteJid = msg.key.remoteJid;
    const q = msg.quoted ? msg.quoted : msg;
    const caption = args.join(' ').trim();

    // --- Validasi Dasar ---
    if (!isGroup) return msg.reply('❌ Perintah ini hanya bisa digunakan di dalam grup.');
    
    // Validasi Admin
    if (!isAdmin && !isOwner) {
        return msg.reply('🛡️ Perintah ditolak. Bot tidak mendeteksi Anda sebagai Admin (Coba ketik apapun di grup agar bot memperbarui metadata, lalu coba lagi).');
    }

    // --- Cooldown Logic (Anti Spam) ---
    if (!isOwner) {
        const now = Date.now();
        const cooldownAmount = 5000; // 5 Detik
        
        if (cooldowns.has(sender)) {
            const expirationTime = cooldowns.get(sender) + cooldownAmount;
            if (now < expirationTime) {
                const timeLeft = ((expirationTime - now) / 1000).toFixed(1);
                return msg.reply(`⏳ Tunggu ${timeLeft} detik lagi.`);
            }
        }
        cooldowns.set(sender, now);
        // Hapus cooldown otomatis agar Map tidak membengkak (Memory Cleanup)
        setTimeout(() => cooldowns.delete(sender), cooldownAmount);
    }

    try {
        await sock.sendMessage(remoteJid, { react: { text: "⏳", key: msg.key } });

        // Normalisasi pesan (untuk menangani ViewOnce atau struktur yang aneh)
        const messageObject = q.message || q.msg; // Fallback jika msg structure berbeda
        if (!messageObject) {
             if (caption) {
                 // Kirim status teks murni
                 await groupStatus(sock, remoteJid, { text: caption, backgroundColor: "#000000" });
                 return await sock.sendMessage(remoteJid, { react: { text: "✅", key: msg.key } });
             } else {
                 return msg.reply(`⚠️ Harap reply gambar/video atau berikan teks.\n\nContoh: *${command} Info Penting*`);
             }
        }

        // Cari tipe media (Image/Video/Audio)
        // Kita gunakan getContentType dari baileys jika ada, atau manual check
        const content = JSON.parse(JSON.stringify(messageObject)); // Deep copy agar aman
        const msgType = Object.keys(content).find(key => 
            key === 'imageMessage' || 
            key === 'videoMessage' || 
            key === 'audioMessage' ||
            key === 'viewOnceMessage' ||
            key === 'viewOnceMessageV2'
        );

        let finalMediaBuffer = null;
        let finalMediaType = null;
        let targetMessage = content[msgType];

        // Handle ViewOnce (Buka bungkusnya)
        if (msgType === 'viewOnceMessage' || msgType === 'viewOnceMessageV2') {
            const internalMsg = targetMessage.message;
            const internalType = Object.keys(internalMsg)[0];
            targetMessage = internalMsg[internalType]; // Ambil isi dalamnya
            if (/image|video/.test(internalType)) {
                finalMediaType = internalType.replace('Message', '');
            }
        } else if (msgType) {
            if (/image|video/.test(msgType)) {
                finalMediaType = msgType.replace('Message', '');
            } else if (/audio/.test(msgType)) {
                finalMediaType = 'audio';
            }
        }

        // Proses Download jika media ditemukan
        if (finalMediaType && targetMessage) {
            const stream = await baileys.downloadContentFromMessage(targetMessage, finalMediaType);
            finalMediaBuffer = await bufferFromStream(stream); // Menggunakan fungsi optimized

            // Cek ukuran file (Safety agar bot tidak crash jika file > 50MB)
            if (finalMediaBuffer.length > 50 * 1024 * 1024) {
                return msg.reply("❌ Ukuran media terlalu besar (Max 50MB) agar bot tidak berat.");
            }

            let payload = {};
            if (finalMediaType === 'image') {
                payload = { image: finalMediaBuffer, caption };
            } else if (finalMediaType === 'video') {
                payload = { video: finalMediaBuffer, caption };
            } else if (finalMediaType === 'audio') {
                // Status audio biasanya butuh background warna agar valid
                payload = { audio: finalMediaBuffer, mimetype: 'audio/mp4', backgroundColor: "#000000" }; 
            }

            await groupStatus(sock, remoteJid, payload);
            await sock.sendMessage(remoteJid, { react: { text: "✅", key: msg.key } });

        } else {
            // Jika tidak ada media, tapi ada caption (Text only status)
            if (caption) {
                await groupStatus(sock, remoteJid, { text: caption, backgroundColor: "#000000" });
                await sock.sendMessage(remoteJid, { react: { text: "✅", key: msg.key } });
            } else {
                return msg.reply("❌ Tipe media tidak didukung atau tidak ditemukan.");
            }
        }

    } catch (e) {
        console.error("Error Admin UPSW:", e);
        await sock.sendMessage(remoteJid, { react: { text: "❌", key: msg.key } });
        msg.reply("❌ Terjadi kesalahan sistem saat mengirim status.");
    }
};

export default {
    command: ['upswgc', 'swgc', 'swgrup'], 
    description: 'Mengirim Status (Story) ke dalam grup.',
    category: 'admin',
    handler,
};